"""Venus-Earth spin commensurability: how close, how likely by chance, can Earth hold it."""
import math
PV, PE = 224.701, 365.256            # orbital periods (d)
S = 1/(1/PV - 1/PE)                   # synodic period (d)
adv = S/PE                            # Earth-direction advance per synodic period (rev)
for name, P in [('Magellan 1992', 243.0185), ('Margot 2021', 243.0226), ('Mean of modern', 243.024)]:
    k = S/P + adv                     # Venus turns (retro) relative to the Earth line per synodic period
    print(f"{name:15s} P={P} d: turns relative to Earth per synodic period = {k:.4f}; off integer {k-round(k):+.4f} rev")
Pres = S/(4 - adv)
print(f"synodic period {S:.2f} d; exact Earth-face resonance P = {Pres:.3f} d")
P = 243.0226; off = abs(S/P + adv - 4)
print(f"offset {off:.4f} rev = {off*360:.2f} deg per conjunction; full drift cycle {1/off:.0f} conjunctions = {S/off/365.25:.0f} years")
print(f"chance of landing this close to an integer by luck: {2*off:.4f} = 1 in {1/(2*off):.0f}")
print(f"  difference from resonance: {(Pres-P)*24:.1f} h; measured day varies by ~20 min (Margot 2021): resonance is {(Pres-P)*24*60/20:.0f} times that")
# Can Earth hold it? permanent figure (B-A)/C from C22, torque coherent near inferior conjunction
G=6.674e-11; ME=5.972e24; AU=1.496e11
C22=1.5e-6; k=0.337; BAC=4*C22/k
r=(0.723-1.0)*-1*AU
for H in (0.03,0.1,0.3):
    w0=math.sqrt(3*BAC*G*ME/r**3*H)
    Wres=2*math.pi/(Pres*86400); Wnow=2*math.pi/(P*86400)
    print(f"H={H}: (B-A)/C={BAC:.1e}, libration period {2*math.pi/w0/3.156e7:,.0f} yr; resonance half-width {w0:.1e} rad/s; "
          f"today's offset {abs(Wres-Wnow):.1e} rad/s = {abs(Wres-Wnow)/w0:.0f} half-widths")
# relative strength of tides on Venus: Earth vs Sun (body tide ~ M^2/r^6), at closest approach
MS=1.989e30
print(f"Earth/Sun body-tide torque at closest approach: {(ME/MS)**2*(0.723/0.277)**6:.1e}")
print(f"Earth/Sun torque on a permanent figure at closest approach: {(ME/MS)*(0.723/0.277)**3:.1e}")
