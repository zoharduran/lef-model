import math
W=1300
def T(x,y,s,size=15,anchor='middle',fill='#1d2433',bold=False,rtl=True):
    d=' direction="rtl" unicode-bidi="embed"' if rtl else ''
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" fill="{fill}" font-weight="{"bold" if bold else "normal"}"{d}>{s}</text>'
def arrow(x1,y1,x2,y2,col,w=5,dash=''):
    return f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{col}" stroke-width="{w}" {dash} marker-end="url(#m{col[1:]})"/>'
cols=['#1f6f8b','#c0392b','#7d3c98','#2c3e50']
defs=''.join(f'<marker id="m{c[1:]}" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="{c}"/></marker>' for c in cols)
s=[f'<defs>{defs}</defs>']
# panel right: vector triangle
ox,oy=900,470; sc=300
L0=(0,-1); a=math.radians(98); L1=(0.48*math.sin(a),-0.48*math.cos(a))
s.append(T(900,40,'מה צריך כדי להטות את אורנוס ב-98° בעזרת מים שבורחים',17,bold=True))
s.append(arrow(ox,oy,ox+L0[0]*sc,oy+L0[1]*sc,'#1f6f8b'))
s.append(T(ox-12,oy-sc/2,'התנע של אז (100%)',14,'start',fill='#1f6f8b',bold=True))
s.append(T(ox-12,oy-sc/2+20,'סיבוב של 8.3 שעות',12.5,'start',fill='#1f6f8b'))
s.append(arrow(ox,oy,ox+L1[0]*sc,oy+L1[1]*sc,'#2c3e50'))
s.append(T(ox+L1[0]*sc+10,oy+L1[1]*sc+30,'התנע היום (48%), מוטה 98°',14,'end',fill='#2c3e50',bold=True))
s.append(arrow(ox+L1[0]*sc,oy+L1[1]*sc,ox+L0[0]*sc,oy+L0[1]*sc,'#c0392b',5,'stroke-dasharray="9 6"'))
mx=(ox+L1[0]*sc+ox)/2+70; my=(oy+L1[1]*sc+oy-sc)/2
s.append(T(mx+10,my-10,'מה שהמים היו צריכים לקחת:',14,'end',fill='#c0392b',bold=True))
s.append(T(mx+10,my+10,'117% מהתנע של אז,',14,'end',fill='#c0392b'))
s.append(T(mx+10,my+30,'בכיוון שנוטה 24° מהציר',14,'end',fill='#c0392b'))
s.append(f'<path d="M{ox},{oy-60} A60,60 0 0,1 {ox+60*math.sin(a):.1f},{oy-60*math.cos(a):.1f}" fill="none" stroke="#7d3c98" stroke-width="2.5"/>')
s.append(T(ox+48,oy-62,'98°',15,fill='#7d3c98',bold=True,rtl=False))
# panel left: why water can't
lx=320
s.append(T(lx,40,'מה מים שבורחים דרך הקו כן לוקחים',17,bold=True))
cx,cy=lx,300
s.append(f'<ellipse cx="{cx}" cy="{cy}" rx="230" ry="55" fill="none" stroke="#999" stroke-dasharray="5 4"/>')
s.append(f'<circle cx="{cx}" cy="{cy}" r="70" fill="#76d7c4" stroke="#148f77" stroke-width="2"/>')
s.append(arrow(cx,cy,cx,cy-170,'#1f6f8b'))
s.append(T(cx+10,cy-178,'ציר הסיבוב',13,'end',fill='#1f6f8b',bold=True))
for dx in (-230,230):
    s.append(f'<circle cx="{cx+dx}" cy="{cy}" r="9" fill="#5dade2"/>')
s.append(arrow(cx+230,cy-14,cx+230,cy-90,'#1f6f8b',3))
s.append(arrow(cx-230,cy-14,cx-230,cy-90,'#1f6f8b',3))
s.append(T(cx,cy+90,'המים יוצאים בקו המשווה, על הקו,',14))
s.append(T(cx,cy+112,'ולוקחים תנע בדיוק בכיוון הציר:',14))
s.append(T(cx,cy+134,'הם מאטים את הסיבוב, אבל לא מטים אותו',14,fill='#c0392b',bold=True))
s.append(f'<line x1="640" y1="70" x2="640" y2="560" stroke="#ddd"/>')
svg=f'<svg width="{W}" height="580" font-family="Arial,sans-serif" direction="ltr">{"".join(s)}</svg>'
html=f'''<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><style>body{{margin:0;font-family:Arial,sans-serif;color:#1d2433;background:#fff}}.w{{width:{W}px;padding:18px 14px}}h1{{font-size:23px;margin:0 6px 4px}}.s{{color:#5b6475;font-size:15px;margin:6px 6px 8px;line-height:1.55}}</style></head><body><div class="w">
<h1>שאלת סוף 1: האם בריחת המים יכולה להטות את ציר אורנוס?</h1>
<div class="s">כדי שהקו יעמוד בכ-2 רדיוסים בזמן הלידות, אורנוס הסתובב ב-8.3 שעות; היום 17.2 שעות. באותו גוף זה אומר שנשאר 48% מהתנע. התנע הוא חץ: גודל וכיוון. כדי לעבור מהחץ של אז לחץ של היום, המוטה ב-98°, צריך לקחת את החץ האדום.</div>
{svg}
<div class="s">מסקנה: בריחת המים מסבירה את ההאטה ואת התרחקות הקו, אבל לא את הנטייה. כדי להטות, היא הייתה צריכה לקחת יותר תנע ממה שהיה לכוכב, ובכיוון שאינו הציר – ומים שיוצאים בקו המשווה לוקחים תנע רק בכיוון הציר.</div>
</div></body></html>'''
open('uranus_tilt_vec.html','w').write(html)
