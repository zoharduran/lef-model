import math, sys, importlib.util
LANG = sys.argv[1] if len(sys.argv) > 1 else 'he'; HE = LANG == 'he'
spec = importlib.util.spec_from_file_location('lt', 'p12_line_then.py')
lt = importlib.util.module_from_spec(spec); spec.loader.exec_module(lt)
RES = {n: lt.report(n, d) for n, d in lt.P.items()}
def rng(rows, key): return min(r[key] for r in rows), max(r[key] for r in rows)

W = 1560; LBL = 470; L = LBL + 10; R = W - 40; lo, hi = 1.0, 70.0
X = lambda x: L + (R - L) * (math.log(max(x, lo)) - math.log(lo)) / (math.log(hi) - math.log(lo))
def T(x, y, s, size=13, anchor='middle', fill='#1d2433', bold=False, rtl=HE):
    d = ' direction="rtl" unicode-bidi="embed"' if rtl else ''
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" fill="{fill}" font-weight="{"bold" if bold else "normal"}"{d}>{s}</text>'
def ac(GM, P): return (GM * (P * 3600) ** 2 / (4 * math.pi ** 2)) ** (1 / 3)
ISO = (lambda t: '\u2066' + t + '\u2069') if HE else (lambda t: t)
f2 = lambda a, b: ISO(f'{a:.2f}' if abs(a - b) < 0.005 else f'{a:.2f}–{b:.2f}')
f1 = lambda a, b: ISO(f'{a:.2f}' if abs(a - b) < 0.005 else f'{a:.1f}–{b:.1f}')

# name_he, name_en, AU, R km, GM km3/s2, day h, key in RES, moons (name, a km, radius km, captured)
S = [
 ('חמה', 'Mercury', 0.39, 2439.7, 22032, 1407.6, None, []),
 ('נוגה', 'Venus', 0.72, 6051.8, 324859, 5832.5, None, []),
 ('כדור הארץ', 'Earth', 1.0, 6371, 398600, 23.934, 'Earth', [('Moon', 384400, 1737, 0)]),
 ('מאדים', 'Mars', 1.52, 3389.5, 42828, 24.623, 'Mars', [('Phobos', 9376, 11, 0), ('Deimos', 23463, 6, 0)]),
 ('צדק', 'Jupiter', 5.20, 69911, 126686534, 9.925, 'Jupiter', [('Metis', 128000, 22, 0), ('Adrastea', 129000, 8, 0), ('Amalthea', 181366, 84, 0), ('Thebe', 221889, 49, 0), ('Io', 421700, 1822, 0), ('Europa', 671034, 1561, 0), ('Ganymede', 1070412, 2634, 0), ('Callisto', 1882709, 2410, 0)]),
 ('שבתאי', 'Saturn', 9.58, 58232, 37931187, 10.56, 'Saturn', [('Pan', 133584, 14, 0), ('Daphnis', 136505, 4, 0), ('Atlas', 137670, 15, 0), ('Prometheus', 139380, 43, 0), ('Pandora', 141720, 41, 0), ('Epimetheus', 151422, 58, 0), ('Janus', 151472, 89, 0), ('Mimas', 185539, 198, 0), ('Methone', 194440, 1.5, 0), ('Anthe', 197700, 1, 0), ('Pallene', 212280, 2.5, 0), ('Enceladus', 238042, 252, 0), ('Tethys', 294672, 531, 0), ('Telesto', 294710, 12, 0), ('Calypso', 294720, 10, 0), ('Dione', 377415, 561, 0), ('Helene', 377420, 18, 0), ('Polydeuces', 377430, 1.3, 0), ('Rhea', 527068, 764, 0), ('Titan', 1221865, 2575, 0), ('Hyperion', 1500933, 135, 0), ('Iapetus', 3560854, 734, 0)]),
 ('אורנוס', 'Uranus', 19.2, 25362, 5793939, 17.24, 'Uranus', [('Cordelia', 49770, 20, 0), ('Ophelia', 53790, 21, 0), ('Bianca', 59170, 26, 0), ('Cressida', 61780, 40, 0), ('Desdemona', 62680, 32, 0), ('Juliet', 64350, 47, 0), ('Portia', 66090, 68, 0), ('Rosalind', 69940, 36, 0), ('Cupid', 74800, 9, 0), ('Belinda', 75260, 45, 0), ('Perdita', 76420, 15, 0), ('Puck', 86010, 81, 0), ('Mab', 97700, 12, 0), ('Miranda', 129900, 236, 0), ('Ariel', 190900, 579, 0), ('Umbriel', 266000, 585, 0), ('Titania', 436300, 789, 0), ('Oberon', 583500, 761, 0)]),
 ('נפטון', 'Neptune', 30.1, 24622, 6836529, 16.11, 'Neptune', [('Naiad', 48227, 33, 0), ('Thalassa', 50074, 41, 0), ('Despina', 52526, 75, 0), ('Galatea', 61953, 88, 0), ('Larissa', 73548, 97, 0), ('Hippocamp', 105283, 17, 0), ('Proteus', 117647, 210, 0), ('Triton', 354759, 1353, 1)]),
 ('פלוטו', 'Pluto', 39.5, 1188.3, 975.5, 153.29, 'Pluto', [('Charon', 19596, 606, 0), ('Styx', 42656, 8, 0), ('Nix', 48694, 20, 0), ('Kerberos', 57783, 9, 0), ('Hydra', 64738, 25, 0)]),
]
TX = dict(
 he=dict(today='היום', then='אז', day='יממה', h='ש׳', line='הקו', Rthen='רדיוסים של אז', Rnow='של היום',
         nothen=('הקו אז: לא ניתן לשחזור – התנע הלך לגאות השמש', 'לעצירת סיבוב צעיר נדרש איבוד של \u20661.5–9.6%\u2069 מהמסה'), offchart='הקו היום', off2='מחוץ לאיור',
         loss='נדרש איבוד דרך הקו של', ofmass='ממסת הכוכב', noloss='בלי איבוד מסה', noneed='כמעט לא נדרש איבוד (עד',
         pluto='אז (מאמר 11): יממה 1.9 עד 2.5 ש׳ כגוף אחד, הקו \u20660.85–1.02\u2069 רדיוסים – פיצול',
         notes={'Mercury': 'אין ירחים · הקו היום 100 רדיוסים', 'Venus': 'אין ירחים · הקו היום 254 רדיוסים',
                'Earth': 'הירח נבנה על קצה האגס', 'Mars': 'הקו נדד החוצה כשהמים והגז עזבו',
                'Jupiter': 'הקו נשאר כמעט במקום (ברדיוסים של אז)', 'Saturn': 'הקו נשאר כמעט במקום (ברדיוסים של אז)',
                'Uranus': 'הקו נדד החוצה כשהמים והגז עזבו', 'Neptune': 'Triton נלכד (מסלול הפוך) – מחוץ לחישוב',
                'Pluto': 'הקו היום = Charon'}),
 en=dict(today='today', then='then', day='day', h='h', line='line', Rthen='radii of then', Rnow='of today',
         nothen=('Line then: cannot be reconstructed – the momentum went to the solar tide', 'stopping a young spin needs a loss of 1.5–9.6% of the mass'), offchart='line today', off2='off the chart',
         loss='requires loss through the line of', ofmass='of the planet’s mass', noloss='with no mass loss', noneed='almost no loss needed (up to',
         pluto='then (Paper 11): day 1.9–2.5 h as one body, line 0.85–1.02 radii – a split',
         notes={'Mercury': 'no moons · line today 100 radii', 'Venus': 'no moons · line today 254 radii',
                'Earth': 'the Moon was built on the pear’s tip', 'Mars': 'the line moved out as water and gas left',
                'Jupiter': 'the line stayed almost in place (in radii of then)', 'Saturn': 'the line stayed almost in place (in radii of then)',
                'Uranus': 'the line moved out as water and gas left', 'Neptune': 'Triton captured (retrograde) – outside the calculation',
                'Pluto': 'line today = Charon'}),
)[LANG]

svg = []; y = 60
for nh, ne, au, Rk, GM, P, key, moons in S:
    name = nh if HE else ne
    H = 176 if moons else 92
    svg.append(f'<rect x="{L-LBL+4}" y="{y+3}" width="{R-(L-LBL+4)+6}" height="{H-6}" rx="6" fill="#f6f7f9"/>')
    svg.append(f'<rect x="{L-12}" y="{y+3}" width="12" height="{H-6}" fill="#c9b79a"/>')
    ax = L - 22 if HE else L - LBL + 14; an = 'start'
    svg.append(T(ax, y + 24, f'{name}  ({au} AU)', 16, an, bold=True))
    xc = ac(GM, P) / Rk
    svg.append(T(ax, y + 44, f'{TX["today"]}: {TX["day"]} {P:g} {TX["h"]} · {TX["line"]} {xc:.2f}', 13, an, fill='#c0392b'))
    cy = y + H / 2 + 4
    if key in RES:
        o = RES[key]
        if key in ('Jupiter', 'Saturn'):
            rows = o['cons']; lossr = rng([r for r in o['req'] if r['target'][1] == 2.3], 'dm_pct')
        else:
            rows = o['req']; lossr = (min(r['dm_grad_pct'] for r in rows), max(r['dm_pct'] for r in rows))
        p0 = rng(rows, 'P0'); x0 = rng(rows, 'x0'); xR = rng(rows, 'xR')
        svg.append(T(ax, y + 64, f'{TX["then"]}: {TX["day"]} {f1(*p0)} {TX["h"]} · {TX["line"]} {f2(*x0)} {TX["Rthen"]}', 13, an, fill='#6c3483'))
        if key in ('Jupiter', 'Saturn'):
            t3 = f'{TX["noneed"]} {lossr[1]:.1f}%)'
        else:
            t3 = f'{TX["loss"]} {ISO(f'{lossr[0]:.1f}–{lossr[1]:.1f}%')} {TX["ofmass"]}'
        svg.append(T(ax, y + 84, t3, 12.5, an, fill='#5b6475'))
        # then band (in today's radii)
        a, b = xR
        if b - a < 0.02:
            svg.append(f'<line x1="{X(a):.1f}" y1="{y+10}" x2="{X(a):.1f}" y2="{y+H-10}" stroke="#7d3c98" stroke-width="3" stroke-dasharray="2 3"/>')
        else:
            svg.append(f'<rect x="{X(a):.1f}" y="{y+10}" width="{X(b)-X(a):.1f}" height="{H-20}" fill="#7d3c98" opacity=".16"/>')
            for v in (a, b): svg.append(f'<line x1="{X(v):.1f}" y1="{y+10}" x2="{X(v):.1f}" y2="{y+H-10}" stroke="#7d3c98" stroke-width="2" stroke-dasharray="2 3"/>')
        svg.append(T((X(a) + X(b)) / 2, y + 22, f2(a, b), 12, 'middle', fill='#6c3483', bold=True, rtl=False))
        # no-loss marker (grey) where different from then
        if key not in ('Jupiter', 'Saturn'):
            c0, c1 = rng(o['cons'], 'xR')
            if c1 < hi:
                yy = y + H - 16
                svg.append(f'<rect x="{X(c0)-2:.1f}" y="{yy-6}" width="{max(X(c1)-X(c0),0)+4:.1f}" height="10" fill="#9aa3ad"/>')
                svg.append(T(X(c1) + 8, yy + 3, f'{TX["noloss"]}: {f2(c0, c1)}', 11, 'end' if HE else 'start', fill='#6b7280'))
    elif key is None:
        svg.append(T(ax, y + 64, TX['nothen'][0], 12.5, an, fill='#6c3483')); svg.append(T(ax, y + 82, TX['nothen'][1], 12.5, an, fill='#5b6475'))
    if key == 'Pluto':
        svg.append(T(ax, y + 64, TX['pluto'], 12.5, an, fill='#6c3483'))
        svg.append(f'<rect x="{X(1.0):.1f}" y="{y+10}" width="{X(1.06)-X(1.0):.1f}" height="{H-20}" fill="#7d3c98" opacity=".25"/>')
    # today line
    if xc < hi:
        svg.append(f'<line x1="{X(xc):.1f}" y1="{y+8}" x2="{X(xc):.1f}" y2="{y+H-8}" stroke="#c0392b" stroke-width="2.6" stroke-dasharray="7 4"/>')
        svg.append(T(X(xc) + 5, y + 38, f'{xc:.2f}', 12.5, 'start', fill='#c0392b', bold=True, rtl=False))
    else:
        svg.append(f'<polygon points="{R-2},{y+H/2-8} {R+12},{y+H/2} {R-2},{y+H/2+8}" fill="#c0392b"/>')
        svg.append(T(R - 8, y + H / 2 + 4, f'{TX["offchart"]} {xc:.0f} · {TX["off2"]}', 12.5, 'start' if HE else 'end', fill='#c0392b', bold=True))
    # moons: colour relative to today's line; labels placed greedily on 4 levels without overlap
    placed = {0: [], 1: [], 2: [], 3: []}; skipped = []
    for i, (mn, a, r, cap) in enumerate(sorted(moons, key=lambda m: -m[2])):
        x = a / Rk
        if x > hi: continue
        rad = max(2.6, 66 * r / 2634)   # true size: Ganymede = 3/4 of the row height
        col = '#27ae60' if x < xc * 0.95 else ('#e67e22' if x <= xc * 1.05 else '#c0392b')
        svg.append(f'<circle cx="{X(x):.1f}" cy="{cy:.1f}" r="{rad:.1f}" fill="{col}" fill-opacity="{0.82 if rad > 12 else 1}" stroke="#fff" stroke-width="{1.5 if rad > 12 else 0}"/>')
        if cap: svg.append(f'<circle cx="{X(x):.1f}" cy="{cy:.1f}" r="{rad+4:.1f}" fill="none" stroke="#8e44ad" stroke-width="2.4"/>')
        if rad >= 20 and mn:
            svg.append(T(X(x), cy + 4.5, mn, 12.5 if rad > 30 else 10.5, 'middle', fill='#fff', bold=True, rtl=False)); continue
        if rad > 12 and mn:
            svg.append(T(X(x), cy + rad + 13, mn, 11, 'middle', fill='#444', rtl=False))
            for lv in (0, 2): placed[lv].append((X(x), 6.9 * len(mn) + 12))
            continue
        if not mn: continue
        w = 6.9 * len(mn) + 12; px = X(x)
        for lev in (0, 1, 2, 3):
            if all(abs(px - q) > (w + ww) / 2 for q, ww in placed[lev]):
                placed[lev].append((px, w))
                dy = [24, -16, 38, -30][lev]
                svg.append(T(px, cy + dy, mn, 11, 'middle', fill='#444', rtl=False))
                break
        else:
            skipped.append(mn)
    if skipped:
        svg.append(T(R - 6, y + 16, ('+ ' if not HE else '') + ', '.join(skipped) + (' +' if HE else ''), 11, 'end', fill='#777', rtl=False))
    nx = R - 6 if HE else R - 6
    svg.append(T(nx, y + H - 6, TX['notes'][ne], 12, 'end' if not HE else 'start', fill='#5b6475'))
    y += H
for t in [1, 1.5, 2, 3, 5, 7, 10, 20, 30, 50, 70]:
    svg.append(f'<line x1="{X(t):.1f}" y1="56" x2="{X(t):.1f}" y2="{y}" stroke="#000" stroke-opacity=".07"/>')
    svg.append(f'<text x="{X(t):.1f}" y="{y+18}" font-size="13" text-anchor="middle">{t}</text>')
svg.append(T((L + R) / 2, y + 42, 'מרחק ממרכז הכוכב, ברדיוסים של הכוכב היום (סקאלה לוגריתמית)' if HE else 'Distance from the planet’s centre, in today’s planet radii (log scale)', 14))
Ht = y + 56
LG = dict(
 he=[('<i style="border-top:3px dashed #c0392b;height:0"></i>', 'קו הקורוטציה היום (המספר = מיקומו)'),
     ('<i style="background:#7d3c98;opacity:.35"></i>', 'קו הקורוטציה אז, בזמן הלידות (המספר = מיקומו ברדיוסים של היום)'),
     ('<i style="background:#9aa3ad;height:8px"></i>', 'איפה היה הקו בלי איבוד מסה (שימור תנע בלבד)'),
     ('<i style="background:#27ae60;border-radius:50%;width:12px;height:12px"></i>', 'מתחת לקו של היום: יורד'),
     ('<i style="background:#e67e22;border-radius:50%;width:12px;height:12px"></i>', 'על הקו (±5%)'),
     ('<i style="background:#c0392b;border-radius:50%;width:12px;height:12px"></i>', 'מעל הקו: מתרחק'),
     ('<i style="border:2.5px solid #8e44ad;border-radius:50%;width:10px;height:10px"></i>', 'ירח שנלכד')],
 en=[('<i style="border-top:3px dashed #c0392b;height:0"></i>', 'Corotation line today (the number = its position)'),
     ('<i style="background:#7d3c98;opacity:.35"></i>', 'Corotation line then, at the births (the number = its position in today’s radii)'),
     ('<i style="background:#9aa3ad;height:8px"></i>', 'Where the line was with no mass loss (angular momentum conserved only)'),
     ('<i style="background:#27ae60;border-radius:50%;width:12px;height:12px"></i>', 'Below today’s line: descending'),
     ('<i style="background:#e67e22;border-radius:50%;width:12px;height:12px"></i>', 'On the line (±5%)'),
     ('<i style="background:#c0392b;border-radius:50%;width:12px;height:12px"></i>', 'Above the line: receding'),
     ('<i style="border:2.5px solid #8e44ad;border-radius:50%;width:10px;height:10px"></i>', 'Captured moon')])[LANG]
lg = ''.join(f'<span>{a}{b}</span>' for a, b in LG)
TT = dict(
 he=('מפת הירחים: קו הקורוטציה אז והיום',
     'כל שורה היא כוכב, לפי הסדר מהשמש. "אז" = בזמן לידת הירחים, מחושב משימור תנע זוויתי עם כל הפרמטרים: הכבידה, הסיבוב, הרדיוס והצפיפות של אז, הדחיסות ומקדם מומנט ההתמד, הפחיסות מהסיבוב, התנע של הירחים, הגאות של השמש, ומסה שעזבה דרך הקו. בשורות הכוכבים: מיקום הקו אז ברדיוסים של אז, ובאיור – ברדיוסים של היום.',
     '<b>איך לקרוא:</b> בכל שורה, ההפרש בין הפס האפור (בלי איבוד מסה) לבין הפס הסגול (הקו אז) הוא מה שהמסה שעזבה דרך הקו – גז ומים – לקחה איתה. בצדק ובשבתאי אין הפרש: שימור התנע לבדו נותן את הקו אז. במאדים, באורנוס ובנפטון ההפרש גדול. בכדור הארץ קטן. צמיגות אינה משנה את מיקום הקו; היא קובעת רק כמה מהר עובר התנע וכמה מהר מתעגלת הצורה. הנחנו גוף צעיר נוזלי, שצורתו נרגעת לגמרי. טווחים: רדיוס הלידה של הענקים 1.1–1.4 (צדק, שבתאי) ו-1.0–1.2 (אורנוס, נפטון) מהרדיוס של היום; מקדם מומנט ההתמד בין של היום לבין גוף פחות ממוין. כדור הארץ ומאדים: ערכי הלידה של המודל (מאמרים 2 ו-10).'),
 en=('The moon map: the corotation line then and today',
     'Each row is a planet, in order from the Sun. "Then" = at the moons’ births, computed from conservation of angular momentum with every parameter: gravity, spin, radius and density then, compressibility and the moment-of-inertia factor, rotational flattening, the moons’ angular momentum, the solar tide, and mass that left through the line. In the planet rows: the line then in radii of then; in the chart, in today’s radii.',
     '<b>How to read:</b> in each row, the gap between the grey bar (no mass loss) and the purple band (the line then) is what the mass that left through the line – gas and water – carried away. On Jupiter and Saturn there is no gap: conservation alone gives the line then. On Mars, Uranus and Neptune the gap is large; on Earth it is small. Viscosity does not change the line’s position; it only sets how fast angular momentum moves and how fast the shape relaxes. We take the young body as fluid, its shape fully relaxed. Ranges: the giants’ birth radius 1.1–1.4 (Jupiter, Saturn) and 1.0–1.2 (Uranus, Neptune) of today’s; the moment-of-inertia factor from today’s to a less differentiated body. Earth and Mars: the model’s birth values (Papers 2 and 10).'))[LANG]
side = 'right' if HE else 'left'
html = f'''<!doctype html><html lang="{LANG}" dir="{'rtl' if HE else 'ltr'}"><head><meta charset="utf-8"><style>body{{margin:0;font-family:Arial,sans-serif;color:#1d2433;background:#fff}}.w{{width:{W}px;padding:18px 10px}}h1{{font-size:23px;margin:0 16px 4px}}.s{{color:#5b6475;font-size:14px;margin:4px 16px 6px;line-height:1.45}}.lg{{display:flex;gap:8px 22px;font-size:13.5px;margin:8px 16px;flex-wrap:wrap}}.lg i{{display:inline-block;width:22px;height:13px;margin:0 6px;vertical-align:middle}}.nb{{margin:10px 16px;font-size:14px;background:#f6f4ee;border-{side}:4px solid #2a3e5c;padding:8px 12px;line-height:1.5}}</style></head><body><div class="w">
<h1>{TT[0]}</h1><div class="s">{TT[1]}</div><div class="lg">{lg}</div>
<svg width="{W+12}" height="{Ht}" font-family="Arial,sans-serif" direction="ltr">{''.join(svg)}</svg>
<div class="nb">{TT[2]}</div></div></body></html>'''
open(f'lmap_{LANG}.html', 'w', encoding='utf-8').write(html)
