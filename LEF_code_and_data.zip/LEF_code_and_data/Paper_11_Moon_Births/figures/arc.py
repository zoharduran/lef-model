# Fig L.3: the arc of moon births with distance from the Sun (regular moons only)
import math
from playwright.sync_api import sync_playwright
W=1250;L=150;R=1180;T=30;B=560
xlo,xhi=math.log10(0.3),math.log10(50); ylo,yhi=-9,0
X=lambda a:L+(R-L)*(math.log10(a)-xlo)/(xhi-xlo)
Y=lambda m:B-(B-T)*(math.log10(m)-ylo)/(yhi-ylo)
def t(x,y,s,size=14,anchor='middle',fill='#1d2433',bold=False,rtl=True):
    d=' direction="rtl" unicode-bidi="embed"' if rtl else ''
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" fill="{fill}" font-weight="{"bold" if bold else "normal"}"{d}>{s}</text>'
s=[]
# zones as soft gradient
s.append('<defs><linearGradient id="z" x1="0" x2="1"><stop offset="0" stop-color="#f6d7b0"/><stop offset=".33" stop-color="#fbeedd"/><stop offset=".55" stop-color="#dcebf7"/><stop offset=".72" stop-color="#dcebf7"/><stop offset="1" stop-color="#c9d3e6"/></linearGradient></defs>')
s.append(f'<rect x="{L}" y="{T}" width="{R-L}" height="{B-T}" fill="url(#z)" opacity=".75"/>')
s.append(t(X(0.6),T+24,'מתייבש מהר',15,fill='#8a4b10',bold=True))
s.append(t(X(6.5),T+24,'רטוב ודליל',15,fill='#1f5f8b',bold=True))
s.append(t(X(35),T+24,'קפוא',15,fill='#2a3e5c',bold=True))
for e in range(-9,1):
    s.append(f'<line x1="{L}" x2="{R}" y1="{Y(10**e):.1f}" y2="{Y(10**e):.1f}" stroke="#000" stroke-opacity=".07"/>')
    s.append(t(L-10,Y(10**e)+5,f'10<tspan dy="-7" font-size="10">{e}</tspan>',13,'end',rtl=False))
for a in (0.5,1,2,5,10,20,50):
    s.append(f'<line y1="{T}" y2="{B}" x1="{X(a):.1f}" x2="{X(a):.1f}" stroke="#000" stroke-opacity=".07"/>')
    s.append(t(X(a),B+20,f'{a:g}',13,rtl=False))
s.append(t((L+R)/2,B+46,'מרחק מהשמש (יחידות אסטרונומיות, סקאלה לוגריתמית)',14))
s.append(t(36,(T+B)/2,'מסת הירחים הסדירים ביחס לאם',14,rtl=True).replace('<text ',f'<text transform="rotate(-90 36 {(T+B)/2})" '))
ej=[('מאדים',1.52,1.9e-8,2),('צדק',5.2,2.07e-4,8),('שבתאי',9.54,2.47e-4,24),('אורנוס',19.2,1.04e-4,19),('נפטון',30.1,5.1e-7,7)]
pts=' '.join(f'{X(a):.1f},{Y(m):.1f}' for _,a,m,_ in ej)
s.append(f'<polyline points="{pts}" fill="none" stroke="#1f6f8b" stroke-width="3" stroke-dasharray="7 5"/>')
for n,a,m,k in ej:
    s.append(f'<circle cx="{X(a):.1f}" cy="{Y(m):.1f}" r="{6+math.sqrt(k)*2.2:.1f}" fill="#1f6f8b" stroke="#fff" stroke-width="2"/>')
    dy=-22 if n!='נפטון' else 30
    xo=-40 if n=='מאדים' else 0
    s.append(t(X(a)+xo,Y(m)+dy,f'{n} · {k} ירחים',14,bold=True))
s.append(t(X(9.54),Y(2.47e-4)-44,'שיא',14,fill='#9e2c20',bold=True))
# other modes
s.append(f'<rect x="{X(1)-9:.1f}" y="{Y(1.23e-2)-9:.1f}" width="18" height="18" fill="#b07d10" transform="rotate(45 {X(1):.1f} {Y(1.23e-2):.1f})"/>')
s.append(t(X(1),Y(1.23e-2)-20,'כדור הארץ · נבנה',14,fill='#8a5f00',bold=True))
s.append(f'<polygon points="{X(39.5):.1f},{Y(0.122)-11:.1f} {X(39.5)-10:.1f},{Y(0.122)+8:.1f} {X(39.5)+10:.1f},{Y(0.122)+8:.1f}" fill="#7d3c98"/>')
s.append(t(X(39.5)-10,Y(0.122)+32,'פלוטו · התפצל',14,fill='#7d3c98',bold=True))
for n,a in (('חמה',0.387),('נוגה',0.723)):
    s.append(f'<circle cx="{X(a):.1f}" cy="{B-14}" r="7" fill="#fff" stroke="#8a4b10" stroke-width="2.5"/>')
    s.append(t(X(a),B-28,f'{n} · אין',14,fill='#8a4b10',bold=True))
svg=f'<svg width="{W}" height="{B+62}" font-family="Arial,sans-serif" direction="ltr">{"".join(s)}</svg>'
leg='<div class="lg"><span><i style="background:#1f6f8b;border-radius:50%"></i>נפלטו (גודל העיגול = מספר הירחים הסדירים)</span><span><i style="background:#b07d10;transform:rotate(45deg)"></i>נבנה</span><span><i style="background:#7d3c98;clip-path:polygon(50% 0,0 100%,100% 100%)"></i>התפצל</span><span><i style="background:#fff;border:2px solid #8a4b10;border-radius:50%"></i>לא ילד</span></div>'
html=f'''<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><style>body{{margin:0;font-family:Arial,sans-serif;color:#1d2433;background:#fff}}.w{{width:{W}px;padding:18px 14px}}h1{{font-size:22px;margin:0 6px 4px}}.s{{color:#5b6475;font-size:14.5px;margin:6px 6px 8px}}.lg{{display:flex;gap:26px;margin:4px 8px 6px;font-size:14px}}.lg i{{display:inline-block;width:14px;height:14px;margin-left:7px;vertical-align:-2px}}</style></head><body><div class="w"><h1>קשת הלידות: המרחק מהשמש מול מסת הירחים</h1><div class="s">ירחים סדירים בלבד; הנלכדים לפי כלל הלכידה (L.3) אינם נספרים. הקו המקווקו מחבר את הכוכבים שפלטו ירחים.</div>{leg}{svg}</div></body></html>'''
open('/mnt/attach/outputs/Paper12_moon_births/fig_src/arc.html','w').write(html)
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(device_scale_factor=2)
    pg.goto('file:///mnt/attach/outputs/Paper12_moon_births/fig_src/arc.html');pg.locator('.w').screenshot(path='/mnt/attach/outputs/Paper12_moon_births/Paper12_arc.png')
