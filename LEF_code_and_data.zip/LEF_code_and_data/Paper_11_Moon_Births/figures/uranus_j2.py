import math
rows=[('הבליטה של אורנוס עצמו',0.00334,'#7f8c8d'),('מירנדה',9.5e-6,'#1f6f8b'),('אריאל',4.0e-4,'#1f6f8b'),('אומבריאל',8.0e-4,'#1f6f8b'),('טיטניה',5.7e-3,'#1f6f8b'),('אוברון',9.25e-3,'#1f6f8b'),('כל הירחים של היום',0.0162,'#154360'),
('ירח קדום 0.04% ב-10 רדיוסים',0.02,'#7d3c98'),('ירח קדום 0.04% ב-20 רדיוסים',0.08,'#7d3c98'),
('מים במסלול: 0.1% ב-20 רדיוסים',0.2,'#2e86c1'),('מים במסלול: 1% ב-10 רדיוסים',0.5,'#2e86c1'),('מים במסלול: 1% ב-20 רדיוסים',2.0,'#2e86c1'),('מים במסלול: 2% ב-20 רדיוסים',4.0,'#2e86c1')]
W=1300;L=360;R=1200;top=40;H=34
lo,hi=1e-5,10
X=lambda v: L+(R-L)*(math.log10(v)-math.log10(lo))/(math.log10(hi)-math.log10(lo))
def T(x,y,s,size=14,anchor='middle',fill='#1d2433',bold=False,rtl=True):
    d=' direction="rtl" unicode-bidi="embed"' if rtl else ''
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" fill="{fill}" font-weight="{"bold" if bold else "normal"}"{d}>{s}</text>'
s=[]
for t in range(-5,2):
    v=10**t; s.append(f'<line x1="{X(v):.1f}" y1="{top-10}" x2="{X(v):.1f}" y2="{top+H*len(rows)}" stroke="#000" stroke-opacity=".08"/>')
    s.append(f'<text x="{X(v):.1f}" y="{top+H*len(rows)+20}" font-size="12.5" text-anchor="middle">{v:g}</text>')
s.append(f'<line x1="{X(0.00334):.1f}" y1="{top-10}" x2="{X(0.00334):.1f}" y2="{top+H*len(rows)}" stroke="#7f8c8d" stroke-width="2" stroke-dasharray="5 4"/>')
for i,(n,v,c) in enumerate(rows):
    y=top+i*H
    s.append(f'<rect x="{L}" y="{y+6}" width="{X(v)-L:.1f}" height="{H-12}" fill="{c}" rx="3"/>')
    s.append(T(L-10,y+H/2+5,n,13.5,'start',bold=(i in (0,6))))
    r=v/0.00334
    lab=f'{v:.2g}  (פי {r:,.0f})' if r>=1.5 else f'{v:.2g}'
    s.append(T(X(v)+8,y+H/2+5,lab,12.5,'end',fill='#333'))
s.append(T((L+R)/2,top+H*len(rows)+44,'התרומה לקצב הנדנוד של הציר (J₂ אפקטיבי), סקאלה לוגריתמית; בסוגריים: פי כמה מהבליטה',13.5))
svg=f'<svg width="{W}" height="{top+H*len(rows)+60}" font-family="Arial,sans-serif" direction="ltr">{"".join(s)}</svg>'
html=f'''<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><style>body{{margin:0;font-family:Arial,sans-serif;color:#1d2433;background:#fff}}.w{{width:{W}px;padding:18px 14px}}h1{{font-size:22px;margin:0 6px 4px}}.s{{color:#5b6475;font-size:14.5px;margin:6px 6px 8px;line-height:1.5}}</style></head><body><div class="w">
<h1>מה קובע את קצב הנדנוד של ציר אורנוס</h1>
<div class="s">ירח או מים שמקיפים במישור קו המשווה מתנהגים, מבחינת השמש, כחלק מהבליטה של אורנוס. תרומתם היא חצי ממסתם היחסית כפול ריבוע מרחקם ברדיוסים, ולכן גוף רחוק וקטן יכול להשפיע יותר מהבליטה עצמה. הקו האפור המקווקו: הבליטה של אורנוס. התרומה נשמרת עד רדיוס לפלס, כ-53–75 רדיוסים; מעבר לו השמש קובעת את מישור המסלול.</div>
{svg}
</div></body></html>'''
open('uranus_j2.html','w').write(html)
