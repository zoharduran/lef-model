import math
G=6.674e-11
print('--- surface gravity g=4/3 pi G rho R')
for n,R,rho in [('Pan',14.1e3,400),('Atlas',14.9e3,460),('Daphnis',3.8e3,340),('Methone',1.45e3,310),('Deimos',6.2e3,1471),('Phobos',11.1e3,1860),('Iapetus',734.5e3,1088),('Mimas',198e3,1150)]:
    print(n, '%.4f'%(4/3*math.pi*G*rho*R))
print('--- corotation a_c and ring positions')
bodies={ # name: GM(m3/s2), R(km), P(h), rings(km list), density
'Jupiter':(1.26687e17,71492,9.925,[(92000,226000)],1326),
'Saturn':(3.7931e16,60268,10.56,[(66900,136775)],687),
'Uranus':(5.794e15,25559,17.24,[(41837,51149)],1270),
'Neptune':(6.8365e15,24764,16.11,[(41900,62932)],1638),
'Haumea':(2.67e12*1e-0,None,3.915,[(2287,2287)],1885),
'Quaoar':(1.2e21*G,555,17.68,[(2520,2520),(4057,4057)],1700),
'Chariklo':(6e18*G,125,7.004,[(391,391),(405,405)],1000),
}
for n,(GM,R,P,rings,rho) in bodies.items():
    Om=2*math.pi/(P*3600); ac=(GM/Om**2)**(1/3)/1e3
    roche=None
    if R: roche=2.456*R*(rho/900)**(1/3)
    print(n,'a_c=%.0f km'%ac, ('x_c=%.2f'%(ac/R)) if R else '', 'rings',[(round(a/ac,2),round(b/ac,2)) for a,b in rings], 'rocheIce=%.0f'%roche if roche else '')
# Haumea GM: mass 4.006e21
GM=4.006e21*G; Om=2*math.pi/(3.915*3600); print('Haumea a_c',(GM/Om**2)**(1/3)/1e3, 'ring/ac',2287/((GM/Om**2)**(1/3)/1e3))
print('--- Saturn ring lifetime')
M=1.54e19
for r in [432,2870,4800,45000]: print(r,'kg/s ->','%.0f Myr'%(M/r/3.156e13))
for r in [432,4800,45000]:
    tot=r*4.5e9*3.156e7; print('4.5Gyr supply at',r,'= %.2e kg = %.1e of Saturn mass, %.0f ring masses'%(tot,tot/5.683e26,tot/M))
