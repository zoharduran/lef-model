"""LEF series, Paper 12 - the corotation line then and now, planet by planet.
Angular-momentum reconstruction with every parameter that enters the line:
  gravity (GM, mass then), spin today, radius today and at birth (expansion / density),
  moment-of-inertia factor today and at birth (compressibility, differentiation),
  rotational flattening (fluid J2, Darwin-Radau; low viscosity = fully relaxed shape),
  orbital angular momentum of the regular moons (captured moons excluded),
  solar-tide loss (Earth), and mass lost through the line (gas and water).
Viscosity does not enter the line's position: it sets how fast angular momentum moves
(tidal rate) and whether the shape relaxes; we take the young body as fluid (fully relaxed).
Run: python3 p12_line_then.py   (standard library only)
"""
import math
G = 6.674e-11
PSTAR = 13.39  # h; line/Roche(ice) = (P/PSTAR)^(2/3), density cancels (Paper 12, B.5)

def radau_J2(q, k):
    """Fluid J2 of a relaxed rotating body (Darwin-Radau), q = W^2 R^3 / GM."""
    s = 2.5 * (1 - 1.5 * k)            # sqrt(1+eta)
    eta = s * s - 1
    f = 2.5 * q / (1 + eta)            # flattening
    return (2 * f - q) / 3, f

def line(GM, W, R, k):
    """Corotation radius with the planet's own flattening: W^2 a = GM/a^2 (1 + 1.5 J2 (Req/a)^2)."""
    q = W * W * R ** 3 / GM
    J2, f = radau_J2(q, k)
    Req = R * (1 + f / 3)
    a = (GM / W ** 2) ** (1 / 3)
    for _ in range(50):
        a = (GM / W ** 2 * (1 + 1.5 * J2 * (Req / a) ** 2)) ** (1 / 3)
    return a, J2, f

def spin_from_L(L, k, M, R, GM):
    """Spin with a flattened body: C = k M R^2 (1 + 2f/3) approx; iterate f."""
    W = L / (k * M * R * R)
    for _ in range(30):
        q = W * W * R ** 3 / GM
        J2, f = radau_J2(q, k)
        W = L / (k * M * R * R * (1 + 2 * f / 3))
    return W

def roche_units(a, M):
    """Line in units of the Roche limit for ice (rho 900): d = 2.456 (3M / 4 pi 900)^(1/3)."""
    return a / (2.456 * (3 * M / (4 * math.pi * 900)) ** (1 / 3))

def Lorb(GM, moons):
    return sum(m * math.sqrt(GM * a * 1e3 * (1 - e * e)) for m, a, e in moons)

# name: M kg, GM m3/s2, R m, day h, k today, regular moons (mass kg, a km, e), birth radius factors, k at birth
P = {
 'Earth':  dict(M=5.972e24, GM=3.986e14, R=6.371e6, P=23.934, k=0.3307,
                moons=[(7.342e22, 384400, 0.0549)], Rf=(7157/6371,), k0=(0.40,),
                Msun_loss=(0.0, 1.3e33), Madd=7.342e22),
 'Mars':   dict(M=6.417e23, GM=4.283e13, R=3.3895e6, P=24.623, k=0.3644,
                moons=[(1.066e16, 9376, 0.015), (1.48e15, 23463, 0.0003)], Rf=(1.5,), k0=(0.40,)),
 'Jupiter':dict(M=1.898e27, GM=1.26687e17, R=6.9911e7, P=9.925, k=0.254,
                moons=[(8.932e22, 421700, 0.004), (4.800e22, 671034, 0.009), (1.4819e23, 1070412, 0.001),
                       (1.0759e23, 1882709, 0.007), (2.08e18, 181366, 0.003)], Rf=(1.1, 1.4), k0=(0.254, 0.261)),
 'Saturn': dict(M=5.683e26, GM=3.7931e16, R=5.8232e7, P=10.56, k=0.210,
                moons=[(1.3452e23, 1221870, 0.029), (2.307e21, 527108, 0.001), (1.806e21, 3560820, 0.028),
                       (1.095e21, 377396, 0.002), (6.17e20, 294619, 0.000), (1.08e20, 237948, 0.005),
                       (3.75e19, 185539, 0.020), (5.6e18, 1481009, 0.123), (1.54e19, 100000, 0.0)],
                Rf=(1.1, 1.4), k0=(0.21, 0.261)),
 'Uranus': dict(M=8.681e25, GM=5.794e15, R=2.5362e7, P=17.24, k=0.22,
                moons=[(3.40e21, 436300, 0.001), (3.08e21, 583500, 0.001), (1.28e21, 266000, 0.004),
                       (1.25e21, 191020, 0.001), (6.4e19, 129390, 0.001)], Rf=(1.0, 1.3), k0=(0.22, 0.30)),
 'Neptune':dict(M=1.024e26, GM=6.8365e15, R=2.4622e7, P=16.11, k=0.23,
                moons=[(4.4e19, 117647, 0.0005), (4e18, 73548, 0.001), (2e18, 61953, 0.0), (2e18, 52526, 0.0)],
                Rf=(1.0, 1.3), k0=(0.23, 0.30)),
}
BIRTH = (1.75, 2.3)   # Paper 11 birth law, pear/bulge mode, line in birth radii
MODEL = {'Earth': (5.77, 5.77), 'Mars': (7.0, 9.0)}   # model's birth day (Papers 2, 10)

def report(name, d):
    M, GM, R, Pn, k = d['M'], d['GM'], d['R'], d['P'], d['k']
    Wn = 2 * math.pi / (Pn * 3600)
    a_now, J2n, fn = line(GM, Wn, R, k)
    Ls = spin_from_L(1, 1, 1, 1, 1) and k * M * R * R * Wn * (1 + 2 * fn / 3)
    Lm = Lorb(GM, d['moons'])
    out = dict(name=name, now_R=a_now / R, now_km=a_now / 1e3, now_roche=roche_units(a_now, M),
               Lspin=Ls, Lmoons=Lm, J2now=J2n)
    sun = d.get('Msun_loss', (0.0,))
    M0 = M + d.get('Madd', 0.0); GM0 = G * M0 if name == 'Earth' else GM
    rows = []
    for Rf in d['Rf']:
        for k0 in d['k0']:
            for sl in sun:
                R0 = R * Rf; L0 = Ls + Lm + sl
                W0 = spin_from_L(L0, k0, M0, R0, GM0)
                a0, J20, f0 = line(GM0, W0, R0, k0)
                rows.append(dict(Rf=Rf, k0=k0, sun=sl, P0=2 * math.pi / W0 / 3600, x0=a0 / R0,
                                 xR=a0 / R, km=a0 / 1e3, roche=roche_units(a0, M0), J2=J20, f=f0))
    out['cons'] = rows
    # required loss: line at the model's birth day (Earth, Mars) or inside the birth law range (giants)
    req = []
    for r in rows:
        R0 = R * r['Rf']; k0 = r['k0']
        targets = []
        if name in MODEL:
            targets = [('day', p) for p in MODEL[name]]
        else:
            targets = [('x', x) for x in BIRTH]
        for kind, v in targets:
            # find spin W0 with line at target; mass lost dm leaves at that line with circular L
            dm = 0.0
            for _ in range(60):
                Mb = M0 + dm; GMb = G * Mb
                if kind == 'day':
                    Wb = 2 * math.pi / (v * 3600)
                else:
                    # solve W so that line(GMb, W, R0, k0)/R0 = v
                    lo, hi = 1e-7, 1e-2
                    for _ in range(80):
                        mid = math.sqrt(lo * hi)
                        if line(GMb, mid, R0, k0)[0] / R0 > v: lo = mid
                        else: hi = mid
                    Wb = math.sqrt(lo * hi)
                ab, J2b, fb = line(GMb, Wb, R0, k0)
                Lb = k0 * Mb * R0 * R0 * Wb * (1 + 2 * fb / 3)
                dL = Lb - (Ls + Lm + r['sun'])
                h = math.sqrt(GMb * ab)
                dm_new = max(dL, 0) / h
                if abs(dm_new - dm) < 1e-6 * max(dm_new, 1): dm = dm_new; break
                dm = dm_new
            Wc = 2 * math.pi / (r['P0'] * 3600)      # spin with no loss, same birth radius and k
            Ib = k0 * Mb * R0 * R0
            dm_grad = max(0.0, 0.75 * Ib / GMb ** (2 / 3) * (Wb ** (4 / 3) - Wc ** (4 / 3)))
            req.append(dict(Rf=r['Rf'], k0=k0, sun=r['sun'], target=(kind, v), P0=2 * math.pi / Wb / 3600,
                            dm_grad=dm_grad, dm_grad_pct=100 * dm_grad / M,
                            x0=ab / R0, xR=ab / R, km=ab / 1e3, roche=roche_units(ab, Mb), dL=dL,
                            dm=dm, dm_pct=100 * dm / M, J2=J2b, f=fb))
    out['req'] = req
    return out

if __name__ == '__main__':
    print(__doc__)
    for n, d in P.items():
        o = report(n, d)
        print(f"\n=== {n} ===  today: line {o['now_R']:.2f} R = {o['now_km']:,.0f} km = {o['now_roche']:.2f} Roche(ice);"
              f"  L spin {o['Lspin']:.3e}, L moons {o['Lmoons']:.3e} ({100*o['Lmoons']/o['Lspin']:.2f}% of spin)")
        print("  (a) conservation only (no mass loss):")
        for r in o['cons']:
            print(f"     R0={r['Rf']:.2f}R k0={r['k0']:.3f} sun={r['sun']:.1e}: day {r['P0']:6.2f} h, f={r['f']:.3f}, "
                  f"line {r['x0']:.2f} R0 = {r['xR']:.2f} R(today) = {r['km']:,.0f} km = {r['roche']:.2f} Roche")
        print("  (b) the model: line at the birth configuration, and the mass that had to leave through the line:")
        for r in o['req']:
            print(f"     R0={r['Rf']:.2f}R k0={r['k0']:.3f} target {r['target'][0]}={r['target'][1]}: day {r['P0']:5.2f} h, "
                  f"line {r['x0']:.2f} R0 = {r['xR']:.2f} R = {r['km']:,.0f} km = {r['roche']:.2f} Roche; "
                  f"lost dL {r['dL']:.2e} -> {r['dm']:.2e} kg = {r['dm_pct']:.1f}% of today's mass (all at the birth line, upper bound); "
                  f"gradual (line moving out as spin slows): {r['dm_grad_pct']:.1f}%")

    print("\n=== Mercury and Venus: no moons; the angular momentum went to the Sun's tide (unknown amount) ===")
    print("Mass that would have to leave through the line to stop a young spin (gradual estimate / all at the birth line):")
    for n, M, GM, R, k in [('Mercury', 3.301e23, 2.2032e13, 2.4397e6, 0.346), ('Venus', 4.867e24, 3.24859e14, 6.0518e6, 0.337)]:
        for P0 in (5, 8, 12):
            for Rf, kk in ((1.0, k), (1.12, 0.40)):
                I = kk * M * (R * Rf) ** 2; W = 2 * math.pi / (P0 * 3600)
                mg = 0.75 * I * W ** (4 / 3) / GM ** (2 / 3); a = (GM / W ** 2) ** (1 / 3); ml = I * W / math.sqrt(GM * a)
                print(f"  {n:8s} birth day {P0:2d} h, R0={Rf:.2f}R, k0={kk:.3f}: {100*mg/M:.1f}% / {100*ml/M:.1f}% of the mass")
    print("Mass loss can only slow a spin to zero: Mercury's 3:2 lock and Venus's retrograde spin need the solar (and atmospheric) tide.")
