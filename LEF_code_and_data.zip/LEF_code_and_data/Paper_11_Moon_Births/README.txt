Paper 11 - Moon Births (LEF series)

p11_line_then.py - the corotation line then and today, planet by planet (Table L.1 and Figure L.1):
  angular-momentum reconstruction with gravity, spin, birth radius and density, moment-of-inertia factor
  (compressibility), rotational flattening (Darwin-Radau), regular moons' orbital momentum, solar tide (Earth),
  and the mass that had to leave through the line (gradual estimate and upper bound); Mercury and Venus.
  Output: p11_line_then_output.txt.
p11_venus_earth.py - the Venus-Earth spin commensurability: how close, how likely by chance. Output: p11_venus_earth_output.txt.
p11_corotation_and_rings_numbers.py - surface gravity of small moons, corotation radius and ring positions of the
  giant planets and ringed small bodies, ring lifetimes. Output: p11_corotation_and_rings_numbers_output.txt.
figures/ - scripts that draw the paper's figures (moon map then and now, the arc of moon births, the birth-mode
  matrix, Uranus J2 and tilt vector). Run from this folder; some write HTML that is rendered to PNG in a browser.
Standard library only, except the figure scripts (matplotlib or playwright).
