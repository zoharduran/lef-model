# LEF model — code and data, version 3.0 (14 November 2026)

Scripts and result tables behind the numbers of the LEF (Lunar Elevation & Fission) series, Papers 2–13.
Author: Zohar Duran, independent researcher (ORCID 0009-0005-3194-9387). Licence: CC BY 4.0.
Series record: doi:10.5281/zenodo.22743615 (resolves to the latest version).

## Layout

One folder per paper, in the current numbering of the series (as on lef-model.com):

| Folder | Paper | Contents |
|---|---|---|
| Paper_02_Mechanism_in_Principle | 2 · LEF Mechanism in Principle | corotation radius, release and tides (`LEF_code_package`) |
| Paper_03_Mechanism_in_Practice | 3 · LEF Mechanism in Practice | mechanism budget; the pear scenario, its width and the core shift; the cradle; Kiritimati and the LLVP |
| Paper_04_The_Orbit | 4 · The Orbit | inclination, survival and recession after release |
| Paper_05_The_Maria | 5 · The Maria | the four-test reproduction kit (latitude and longitude bands); vents, buried vents, feed domes, thorium mare versus highland, craters on mare floors, activity after release |
| Paper_06_The_Craters | 6 · The Craters | foreign mass, coarse rims (LDEM), the trailing side, size and state near the maria, buried craters, gravity under craters, longitude caps |
| Paper_07_The_Poles | 7 · The Poles | young-crater belts, pole/equator ratios, shape-consistency family, shrink tests, the shape-sequence recompute |
| Paper_08_South_Pole_Aitken | 8 · South Pole–Aitken | the B- and C-section analyses (rings, halo, bands, the crescent rotation, the hinge audit, 34 maria) |
| Paper_09_The_Stripes | 9 · The Stripes | Study 10 (Section C.5): pre-registration, traced paths and result, GEBCO 2024 |
| Paper_10_Mars | 10 · Mars | corotation radius of Mars, inclination damping, the "was the line ever closer?" table (B.5) |
| Paper_11_Moon_Births | 11 · Moon Births | the corotation line then and today planet by planet, the mass that left through the line, Venus–Earth spin, ring and corotation positions, figure scripts |
| Paper_12_The_Rings | 12 · The Rings | ring calculations and figure scripts |
| Paper_13_The_Requirements | 13 · The Requirements | requirement calculations and the GRAIL belt tests T1, T2, T5 |

Paper 1 computes nothing new; Paper 14 (Research Topics) is a companion and has no code.

## Notes

- Python 3 with numpy and scipy; a few figure scripts use matplotlib, and the GEBCO study uses tifffile.
- Scripts in the `LEF_code_package` folders were written for version 1.0 and keep their original file names, which follow the old numbering (for example `paper7_orbit.py` serves Paper 4, The Orbit; `paper5_requirements.py` serves Paper 13).
- Folder names carry the date of the study.
- Third-party catalogues and grids (Robbins 2019, Wang et al. 2021, GRAIL, LOLA/LDEM, Lunar Prospector, GEBCO 2024) are not redistributed in full. Where a subset or derived table is included, the source is the one cited in the paper. The full products can be downloaded from their archives.
- Some scripts read input files from absolute paths on the author's working machine. Set the path at the top of the script to the location of the downloaded catalogue.
