"""LEF series, Paper 12 (The Rings) - reproduction of every number computed in the paper.
Run: python3 p12_rings_calculations.py   (standard library only)
"""
import math
G=6.674e-11; YR=3.156e7
def a_c(GM,P_h): return (GM*(P_h*3600)**2/(4*math.pi**2))**(1/3)
def roche_ice(R,rho): return 2.456*R*(rho/900)**(1/3)
print("== A.3  Corotation line, Roche limit for ice, rings (km; and in units of a_c) ==")
B={'Jupiter':(1.26687e17,71492,9.925,1326,[(92000,226000)]),'Saturn':(3.7931e16,60268,10.56,687,[(66900,136775)]),
   'Uranus':(5.794e15,25559,17.24,1270,[(41837,51149)]),'Neptune':(6.8365e15,24764,16.11,1638,[(41900,62932)]),
   'Haumea':(4.006e21*G,798,3.915,1885,[(2287,2287)]),'Chariklo':(0.40e9,125,7.004,1000,[(391,405)]),'Quaoar':(1.2e21*G,555,17.68,1700,[(2520,2520),(4057,4057)])}
for n,(GM,R,P,rho,rings) in B.items():
    ac=a_c(GM,P)/1e3; rr=roche_ice(R,rho)
    print(f"{n:9s} a_c={ac:9.0f}  Roche={rr:9.0f} ({rr/ac:.2f} a_c)  rings="+", ".join(f"{a/ac:.2f}-{b/ac:.2f}" for a,b in rings))
print("1:3 spin-orbit resonance at 3^(2/3) a_c =",round(3**(2/3),3))
print("\n== B.5  Critical day: x_c/x_R = (P/P*)^(2/3) ==")
Ps=2*math.pi*math.sqrt(3*2.456**3/(4*math.pi*G*900))/3600
print(f"P* = {Ps:.2f} h")
for n,P,xc,xr in [('Jupiter',9.93,2.29,2.80),('Saturn',10.56,1.92,2.24),('Uranus',17.24,3.26,2.76),('Neptune',16.11,3.39,3.00),('Mars today',24.62,6.03,4.02),('Earth today',23.93,6.62,4.49)]:
    print(f"{n:12s} day {P:5.2f} h  (P/P*)^(2/3)={(P/Ps)**(2/3):.2f}   x_c/x_R={xc/xr:.2f}")
for n,rho in [('Young Mars',1170),('Earth at birth',3940)]:
    print(f"{n:15s} Roche (expanded radii) = {2.456*(rho/900)**(1/3):.2f}")
print("\n== D.3  Saturn ring lifetime and supply ==")
M=1.54e19
for r in (432,2870,4800,45000):
    tot=r*4.5e9*YR
    print(f"rain {r:6d} kg/s -> empty in {M/r/YR/1e6:7.0f} Myr; 4.5 Gyr supply {tot:.2e} kg = {tot/M:.0f} ring masses = {tot/5.683e26:.1e} of Saturn")
print("\n== D.4  Angular momentum: moons or water ==")
def Lspin(k,M,R,P): return k*M*R**2*2*math.pi/(P*3600)
for n,k,Mp,R,Pthen,Pnow,GM,moons in [
 ('Uranus',0.22,8.681e25,2.5362e7,8.3,17.24,5.794e15,[(3.40e21,4.363e8),(3.08e21,5.835e8),(1.28e21,2.66e8),(1.25e21,1.909e8),(6.4e19,1.299e8)]),
 ('Neptune',0.23,1.024e26,2.4622e7,7.3,16.11,6.8365e15,[(4.4e19,1.176e8),(4e18,7.35e7),(2e18,6.2e7),(2e18,5.25e7)])]:
    dL=Lspin(k,Mp,R,Pthen)-Lspin(k,Mp,R,Pnow)
    Lm=sum(m*math.sqrt(GM*a) for m,a in moons)
    h=math.sqrt(GM*2*R); mw=dL/h
    print(f"{n}: lost {dL:.2e}; moons {Lm:.1e} ({100*Lm/dL:.3f}%); water through the line at 2R: {mw:.2e} kg = {100*mw/Mp:.1f}% of mass; = {mw/sum(m for m,a in moons):.0f}x the regular moons")
print("\n== D.4  Escape speeds (km/s) ==")
for n,GM,R in [('Jupiter',1.26687e17,71492e3),('Saturn',3.7931e16,60268e3),('Uranus',5.794e15,25559e3),('Neptune',6.8365e15,24764e3)]:
    print(f"{n:8s} {math.sqrt(2*GM/R)/1e3:5.1f}")
print("\n== G.3  Surface gravity of small moons (m/s^2) ==")
for n,R,rho in [('Methone',1.45e3,310),('Daphnis',3.8e3,340),('Pan',14.1e3,400),('Atlas',14.9e3,460),('Deimos',6.2e3,1471),('Phobos',11.1e3,1860),('Iapetus',734.5e3,1088)]:
    print(f"{n:8s} {4/3*math.pi*G*rho*R:.4f}")
