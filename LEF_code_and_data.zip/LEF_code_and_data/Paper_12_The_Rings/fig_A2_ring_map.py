import math
W=1560; LBL=430; L=LBL+10; R=W-40; lo,hi=1.0,70.0
X=lambda x: L+(R-L)*(math.log(max(x,lo))-math.log(lo))/(math.log(hi)-math.log(lo))
def T(x,y,s,size=13,anchor='middle',fill='#1d2433',bold=False,rtl=True):
    d=' direction="rtl" unicode-bidi="embed"' if rtl else ''
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" fill="{fill}" font-weight="{"bold" if bold else "normal"}"{d}>{s}</text>'
def ac(GM,P): return (GM*(P*3600)**2/(4*math.pi**2))**(1/3)
G=6.674e-20
# rings: (r1_km,r2_km,kind,label)  kind: vis, vis2, faint, narrow, small, past, wide
S=[
('חמה',0.39,2439.7,22032,1407.6,5427,[],[],'אין טבעת · אין ירחים'),
('נוגה',0.72,6051.8,324859,5832.5,5243,[],[],'אין טבעת · אין ירחים'),
('כדור הארץ',1.0,6371,398600,23.934,5513,[],[('Moon',384400,1737,0)],'אין טבעת · לפי המודל לא הייתה טבעת ממושכת'),
('מאדים',1.52,3389.5,42828,24.623,3934,[(8800,19000,'past','טבעת בעבר (מאמר 10)')],[('Phobos',9376,11,0),('Deimos',23463,6,0)],'אין טבעת היום · הייתה בעבר, על הקו שנדד החוצה'),
('קרס',2.77,469.7,62.6,9.07,2162,[],[],'אין טבעת · אין ירחים'),
('צדק',5.20,69911,126686534,9.925,1326,[(92000,122500,'faint',''),(122500,129000,'faint','הילה, ראשית, גוסמר'),(129000,226000,'faint','')],[('Metis',128000,22,1),('',129000,8,1),('Amalthea',181400,84,1),('Thebe',221900,49,1),('Io',421700,1822,0),('Europa',671034,1561,0),('Ganymede',1070412,2634,0),('Callisto',1882709,2410,0)],'טבעות לא נראות (אבק) · אין טבעת סביב ירח'),
('שבתאי',9.58,58232,37931187,10.56,687,[(66900,74500,'faint','D'),(74658,92000,'vis2','C'),(92000,117580,'vis','B'),(122170,136775,'vis','A'),(140180,140400,'narrow',''),(166000,175000,'faint','G'),(180000,480000,'wide','E')],[('Pan',133584,14,0),('',137670,15,0),('Janus',151472,89,0),('Mimas',185539,198,0),('Enceladus',238042,252,1),('Tethys',294672,531,0),('Dione',377415,561,0),('Rhea',527068,764,0),('Titan',1221865,2575,0),('Hyperion',1500933,135,0),('Iapetus',3560854,734,0)],'טבעת נראית (A, B, C) + לא נראות · טבעת Phoebe מחוץ לאיור · אין טבעת סביב ירח'),
('Chariklo',15.8,124,0.40,7.004,1000,[(391,391,'smalln','C1R'),(405,405,'smalln','C2R')],[],'2 טבעות לא נראות · אין ירחים ידועים'),
('אורנוס',19.2,25362,5793939,17.24,1270,[(37850,41350,'faint','ζ'),(41837,42570,'narrow','6,5,4'),(44718,44718,'narrow','α'),(45661,45661,'narrow','β'),(47176,47627,'narrow','η γ'),(48300,48300,'narrow','δ'),(51149,51149,'narrow','ε'),(66100,69900,'faint','ν'),(86000,103000,'faint','μ')],[('Cordelia',49770,20,0),('',53790,21,0),('Portia',66090,68,0),('Puck',86010,81,0),('Mab',97700,12,1),('Miranda',129900,236,0),('Ariel',190900,579,0),('Umbriel',266000,585,0),('Titania',436300,789,0),('Oberon',583500,761,0)],'13 טבעות לא נראות, צרות וכהות · אין טבעת סביב ירח'),
('נפטון',30.1,24622,6836529,16.11,1638,[(40900,42900,'faint','Galle'),(53200,53200,'narrow',''),(53200,57200,'faint','Lassell'),(62932,62932,'narrow','Adams (קשתות)')],[('Naiad',48227,33,0),('',52526,75,0),('Galatea',61953,88,1),('Larissa',73548,97,0),('Proteus',117647,210,0),('Triton',354759,1353,0)],'5 טבעות לא נראות, עם קשתות · אין טבעת סביב ירח'),
('פלוטו',39.5,1188.3,975.5,153.29,1854,[],[('Charon',19596,606,0),('Styx',42656,8,0),('Nix',48694,20,0),('Kerberos',57783,9,0),('Hydra',64738,25,0)],'אין טבעת (ניו הורייזונס חיפשה)'),
('Haumea',43.1,798,267.4,3.915,1885,[(2287,2287,'smalln','טבעת')],[('Namaka',25657,85,0),('Hiʻiaka',49880,160,0)],'טבעת לא נראית · אין טבעת סביב ירח'),
('Quaoar',43.7,555,80.1,17.68,1700,[(2520,2520,'smalln','Q2R'),(4057,4057,'smalln','Q1R')],[('Weywot',13300,85,0)],'2 טבעות לא נראות, מחוץ לגבול רוש · אין טבעת סביב ירח'),
('Makemake',45.4,715,207,22.83,1900,[],[('MK2',22250,90,0)],'אין טבעת ידועה'),
('אריס',68,1163,1108,378,2430,[],[('Dysnomia',37300,350,0)],'אין טבעת ידועה'),
]
svg=[]; y=60
for name,au,Rk,GM,P,rho,rings,moons,note in S:
    H=118 if (rings or moons) else 54
    svg.append(f'<rect x="{L-LBL+4}" y="{y+3}" width="{R-(L-LBL+4)+6}" height="{H-6}" rx="6" fill="#f6f7f9"/>')
    svg.append(f'<rect x="{L-12}" y="{y+3}" width="12" height="{H-6}" fill="#c9b79a"/>')
    svg.append(T(L-22,y+26,f'{name}  ({au} AU)',16,'start',bold=True))
    xc=ac(GM,P)/Rk; xr=2.456*(rho/900)**(1/3)
    vis=any(k in('vis','vis2') for *_,k,_l in rings)
    kindtxt='טבעת נראית' if vis else ('טבעת בעבר' if any(k=='past' for *_,k,_l in rings) else ('טבעת לא נראית' if rings else 'אין טבעת'))
    kc={'טבעת נראית':'#9a6a00','טבעת בעבר':'#777','טבעת לא נראית':'#46607a','אין טבעת':'#9a9a9a'}[kindtxt]
    svg.append(T(L-22,y+48,kindtxt,13.5,'start',fill=kc,bold=True))
    cy=y+H/2+2
    # roche
    if xr<hi and (rings or moons):
        svg.append(f'<line x1="{X(xr):.1f}" y1="{y+10}" x2="{X(xr):.1f}" y2="{y+H-10}" stroke="#6b7280" stroke-width="1.6" stroke-dasharray="2 3"/>')
    # rings
    for i,(r1,r2,k,lb) in enumerate(rings):
        a,b=r1/Rk,r2/Rk
        if k in('vis','vis2'):
            svg.append(f'<rect x="{X(a):.1f}" y="{cy-11}" width="{max(X(b)-X(a),2):.1f}" height="22" fill="{"#d7b04a" if k=="vis" else "#e8d595"}"/>')
        elif k=='faint':
            svg.append(f'<rect x="{X(a):.1f}" y="{cy-8}" width="{max(X(b)-X(a),2):.1f}" height="16" fill="#8fa3b8" opacity=".45"/>')
        elif k=='wide':
            svg.append(f'<rect x="{X(a):.1f}" y="{cy-16}" width="{X(b)-X(a):.1f}" height="32" fill="#8fa3b8" opacity=".18"/>')
        elif k=='narrow':
            for v in sorted({a,b}): svg.append(f'<rect x="{X(v)-1.3:.1f}" y="{cy-12}" width="2.6" height="24" fill="#4f6378"/>')
        elif k=='smalln':
            svg.append(f'<rect x="{X(a)-2:.1f}" y="{cy-13}" width="4" height="26" fill="#c0392b"/>')
        elif k=='past':
            svg.append(f'<rect x="{X(a):.1f}" y="{cy-11}" width="{X(b)-X(a):.1f}" height="22" fill="none" stroke="#8a8a8a" stroke-width="2" stroke-dasharray="2 4"/>')
        lx=(X(a)+X(b))/2; ly=cy-20 if i%2==0 else cy-33
        if k=='wide': ly=cy-20
        if lb: svg.append(T(lx,ly,lb,11.5,'middle',fill='#3b4a5a',rtl=not lb.isascii()))
    # corotation
    if xc<hi:
        svg.append(f'<line x1="{X(xc):.1f}" y1="{y+8}" x2="{X(xc):.1f}" y2="{y+H-8}" stroke="#c0392b" stroke-width="2.4" stroke-dasharray="7 4"/>')
        svg.append(T(X(xc)+5,y+18,f'{xc:.2f}',12,'start',fill='#c0392b',bold=True,rtl=False))
    # moons (small, neutral)
    for i,(mn,a,r,feed) in enumerate(moons):
        x=a/Rk
        if x>hi: continue
        rad=max(2.8,min(10,1.8*math.log10(max(r,2))**1.5))
        svg.append(f'<circle cx="{X(x):.1f}" cy="{cy:.1f}" r="{rad:.1f}" fill="#ffffff" stroke="#1d2433" stroke-width="1.4"/>')
        if feed: svg.append(f'<circle cx="{X(x):.1f}" cy="{cy:.1f}" r="{rad+4:.1f}" fill="none" stroke="#2e86c1" stroke-width="2.2"/>')
        dy=rad+15 if i%2==0 else rad+28
        if mn: svg.append(T(X(x),cy+dy,mn,11,'middle',fill='#555',rtl=False))
    if name=='שבתאי':
        svg.append(f'<polygon points="{R-2},{cy-7} {R+10},{cy} {R-2},{cy+7}" fill="#8fa3b8"/>')
    svg.append(T(R-6,y+H-8,note,12,'start',fill='#5b6475'))
    y+=H
for t in [1,1.5,2,3,5,7,10,20,30,50,70]:
    svg.append(f'<line x1="{X(t):.1f}" y1="56" x2="{X(t):.1f}" y2="{y}" stroke="#000" stroke-opacity=".07"/>')
    svg.append(f'<text x="{X(t):.1f}" y="{y+18}" font-size="13" text-anchor="middle">{t}</text>')
svg.append(T((L+R)/2,y+42,'מרחק ממרכז הגוף, ברדיוסים של הגוף (סקאלה לוגריתמית)',14))
Ht=y+56
leg=[('<i style="background:#d7b04a"></i>','טבעת נראית (בטלסקופ ביתי)'),
('<i style="background:#8fa3b8;opacity:.6"></i>','טבעת לא נראית: רחבה (אבק)'),
('<i style="background:#4f6378;width:4px"></i>','טבעת לא נראית: צרה'),
('<i style="background:#c0392b;width:5px"></i>','טבעת של גוף קטן'),
('<i style="border:2px dotted #8a8a8a;height:9px"></i>','טבעת בעבר'),
('<i style="border-top:3px dashed #c0392b;height:0"></i>','קו הקורוטציה היום (המספר = מיקומו)'),
('<i style="border-top:2px dotted #6b7280;height:0"></i>','גבול רוש לקרח'),
('<i style="border:1.5px solid #1d2433;border-radius:50%;width:10px;height:10px;background:#fff"></i>','ירח'),
('<i style="border:2.5px solid #2e86c1;border-radius:50%;width:10px;height:10px"></i>','ירח שמזין טבעת של הכוכב')]
lg=''.join(f'<span>{a}{b}</span>' for a,b in leg)
html=f'''<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><style>body{{margin:0;font-family:Arial,sans-serif;color:#1d2433;background:#fff}}.w{{width:{W}px;padding:18px 10px}}h1{{font-size:23px;margin:0 16px 4px}}.s{{color:#5b6475;font-size:14px;margin:4px 16px 6px;line-height:1.45}}.lg{{display:flex;gap:8px 22px;font-size:13.5px;margin:8px 16px;flex-wrap:wrap}}.lg i{{display:inline-block;width:22px;height:13px;margin-left:6px;vertical-align:middle}}.nb{{margin:10px 16px;font-size:14px;background:#f6f4ee;border-right:4px solid #2a3e5c;padding:8px 12px}}</style></head><body><div class="w">
<h1>מפת הטבעות: כל גוף מול קו הקורוטציה וגבול רוש</h1>
<div class="s">כל שורה היא גוף, לפי הסדר מהשמש. המרחק נמדד ברדיוסים של הגוף, כך שאפשר להשוות בין גופים בגדלים שונים. הירחים מצוירים בלבן כדי שהטבעות יבלטו.</div>
<div class="lg">{lg}</div>
<svg width="{W+12}" height="{Ht}" font-family="Arial,sans-serif" direction="ltr">{''.join(svg)}</svg>
<div class="nb"><b>טבעת סביב ירח:</b> לא נמצאה סביב אף ירח. החשד לגבי Rhea נשלל ב-2010. ירחים רק מזינים טבעות של הכוכב (מסומנים בעיגול כחול): Enceladus את טבעת E, Metis/Adrastea/Amalthea/Thebe את טבעות צדק, Mab את טבעת μ של אורנוס; Galatea מחזיק את הקשתות של נפטון; Phoebe מזין טבעת ענקית מחוץ לאיור (החץ בשורת שבתאי).</div>
<div class="s">מה רואים: בענקי הגז והקרח הטבעות נמצאות לפני קו הקורוטציה או סביבו, בתוך גבול רוש. בגופים הקטנים (Chariklo, Haumea, Quaoar) הטבעות נמצאות אחרי הקו. מאדים: טבעת בעבר סביב הקו, שנדד החוצה עד 6.03.</div>
</div></body></html>'''
open('rings_map.html','w').write(html)
