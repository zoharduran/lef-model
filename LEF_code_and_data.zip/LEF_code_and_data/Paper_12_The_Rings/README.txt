Paper 12 - The Rings (LEF series)
p12_rings_calculations.py reproduces every number computed in the paper (standard library only); its output is in p12_rings_calculations_output.txt.
fig.py draws Figure A.1; fig_A2_ring_map.py, fig_B1_what_keeps_a_ring.py and fig_B2_two_conditions.py write the HTML of Figures A.2, B.1 and B.2 (rendered to PNG in a browser).
