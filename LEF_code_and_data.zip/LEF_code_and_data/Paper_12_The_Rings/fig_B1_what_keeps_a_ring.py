import math
W=1560; LBL=400; L=LBL+10; R=W-40; lo,hi=1.0,70.0
X=lambda x: L+(R-L)*(math.log(max(x,lo))-math.log(lo))/(math.log(hi)-math.log(lo))
def T(x,y,s,size=13,anchor='middle',fill='#1d2433',bold=False,rtl=True):
    d=' direction="rtl" unicode-bidi="embed"' if rtl else ''
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" fill="{fill}" font-weight="{"bold" if bold else "normal"}"{d}>{s}</text>'
def ac(GM,P): return (GM*(P*3600)**2/(4*math.pi**2))**(1/3)
COL={'parent':'#d7b04a','parent_l':'#d7b04a','spread':'#d7b04a','moon':'#8e44ad','open':'#9aa3ad','fade':'#9aa3ad','past':None,'pred':None}
# (r1,r2,src,label,style) style: band/narrow/wide
S=[
('חמה',0.39,2439.7,22032,1407.6,5427,[],[],'אין טבעת'),
('נוגה',0.72,6051.8,324859,5832.5,5243,[],[],'אין טבעת'),
('כדור הארץ',1.0,6371,398600,23.934,5513,[],[('Moon',384400,1737,0)],'אין טבעת · לא הייתה טבעת ממושכת'),
('מאדים',1.52,3389.5,42828,24.623,3934,[(8800,19000,'past','נעלמה: ההזנה נפסקה (מאמר 10)','band')],[('Phobos',9376,11,0),('Deimos',23463,6,0)],'הטבעת נעלמה כשההזנה מהקרקע נפסקה · הירחים יבשים ואינם מזינים'),
('צדק',5.20,69911,126686534,9.925,1326,[(92000,129000,'moon','הילה + ראשית','band'),(129000,226000,'moon','גוסמר','band')],[('Metis',128000,22,1),('Amalthea',181400,84,1),('Thebe',221900,49,1),('Io',421700,1822,0),('Europa',671034,1561,0),('Ganymede',1070412,2634,0),('Callisto',1882709,2410,0)],'כל הטבעות מוזנות מירחים, לפני הקו ואחריו'),
('שבתאי',9.58,58232,37931187,10.56,687,[(66900,74500,'parent','D','band'),(74658,92000,'parent','C','band'),(92000,117580,'parent','B','band'),(122170,136775,'spread','A','band'),(140180,140400,'moon','F','narrow'),(166000,175000,'moon','G','band'),(180000,480000,'moon','E','wide')],[('Pan',133584,14,0),('Janus',151472,89,0),('Mimas',185539,198,0),('Enceladus',238042,252,1),('Tethys',294672,531,0),('Dione',377415,561,0),('Rhea',527068,764,0),('Titan',1221865,2575,0),('Hyperion',1500933,135,0),('Iapetus',3560854,734,0)],'D, C, B בלי ירחים: חיות רק כי מוזנות עכשיו מהקרקע · A, F, G, E: עם ירחים · Phoebe: ירח שנלכד'),
('אורנוס',19.2,25362,5793939,17.24,1270,[(37850,41350,'fade','ζ','band'),(41837,42570,'fade','','narrow'),(44718,44718,'fade','','narrow'),(45661,45661,'fade','','narrow'),(47176,47627,'fade','','narrow'),(48300,48300,'fade','','narrow'),(51149,51149,'moon','ε','narrow'),(66100,69900,'moon','ν','band'),(86000,103000,'moon','μ','band')],[('Cordelia',49770,20,1),('Portia',66090,68,0),('Puck',86010,81,0),('Mab',97700,12,1),('Miranda',129900,236,0),('Ariel',190900,579,0),('Umbriel',266000,585,0),('Titania',436300,789,0),('Oberon',583500,761,0)],'ε (Cordelia, Ophelia), ν ו-μ (Mab): עם ירחים · הטבעות הצרות בלי ירח: צפויות להיעלם'),
('נפטון',30.1,24622,6836529,16.11,1638,[(40900,42900,'fade','Galle','band'),(53200,53200,'moon','','narrow'),(53200,57200,'fade','Lassell','band'),(62932,62932,'moon','Adams','narrow')],[('Despina',52526,75,1),('Galatea',61953,88,1),('Larissa',73548,97,0),('Proteus',117647,210,0),('Triton',354759,1353,0)],'Adams (Galatea), Le Verrier (Despina): עם ירחים · Galle, Lassell בלי ירח: צפויות להיעלם'),
]
svg=[]; y=60
for name,au,Rk,GM,P,rho,rings,moons,note in S:
    H=124 if (rings or moons) else 54
    xc=ac(GM,P)/Rk; xr=2.456*(rho/900)**(1/3)
    svg.append(f'<rect x="{L-LBL+4}" y="{y+3}" width="{R-(L-LBL+4)+6}" height="{H-6}" rx="6" fill="#f6f7f9"/>')
    if rings or moons:
        xcc=min(xc,hi)
        svg.append(f'<rect x="{X(1):.1f}" y="{y+3}" width="{X(xcc)-X(1):.1f}" height="{H-6}" fill="#3b7dd8" opacity=".08"/>')
        if xc<hi: svg.append(f'<rect x="{X(xc):.1f}" y="{y+3}" width="{R-X(xc):.1f}" height="{H-6}" fill="#d84b3b" opacity=".07"/>')
    svg.append(f'<rect x="{L-12}" y="{y+3}" width="12" height="{H-6}" fill="#c9b79a"/>')
    svg.append(T(L-22,y+28,f'{name}  ({au} AU)',16,'start',bold=True))
    cy=y+H/2+4
    if xr<hi and (rings or moons):
        svg.append(f'<line x1="{X(xr):.1f}" y1="{y+12}" x2="{X(xr):.1f}" y2="{y+H-12}" stroke="#6b7280" stroke-width="1.5" stroke-dasharray="2 3"/>')
    for i,(r1,r2,src,lb,st) in enumerate(rings):
        a,b=r1/Rk,r2/Rk
        if src=='pred':
            svg.append(f'<rect x="{X(a):.1f}" y="{cy-17}" width="{X(b)-X(a):.1f}" height="34" fill="none" stroke="#8e44ad" stroke-width="1.8" stroke-dasharray="6 4"/>')
            svg.append(T(X(b)+8,cy+4,lb,11.5,'end',fill='#8e44ad',bold=True)); continue
        if src=='past':
            svg.append(f'<rect x="{X(a):.1f}" y="{cy-11}" width="{X(b)-X(a):.1f}" height="22" fill="#ead9a0" opacity=".5" stroke="#b08a20" stroke-width="2" stroke-dasharray="3 4"/>')
        elif st=='narrow':
            svg.append(f'<rect x="{X(a)-1.4:.1f}" y="{cy-12}" width="{max(2.8,X(b)-X(a)):.1f}" height="24" fill="{COL[src]}" {"stroke-dasharray=\"3 3\" stroke=\"#fff\"" if src=="fade" else ""}/>')
        elif st=='wide':
            svg.append(f'<rect x="{X(a):.1f}" y="{cy-16}" width="{X(b)-X(a):.1f}" height="32" fill="{COL[src]}" opacity=".22"/>')
        else:
            op='1' if src in('parent','parent_l','spread') else ('.75' if src=='fade' else '.6')
            svg.append(f'<rect x="{X(a):.1f}" y="{cy-11}" width="{X(b)-X(a):.1f}" height="22" fill="{COL[src]}" opacity="{op}"/>')
            if src=='fade': svg.append(f'<rect x="{X(a):.1f}" y="{cy-11}" width="{X(b)-X(a):.1f}" height="22" fill="url(#hatchg)"/>')
            if src=='spread':
                svg.append(f'<rect x="{X(a):.1f}" y="{cy-11}" width="{X(b)-X(a):.1f}" height="22" fill="url(#hatch)"/>')
                # propellers
                for k in range(7):
                    xx=X(a)+(X(b)-X(a))*(0.25+0.1*k); yy=cy+(-5 if k%2 else 5)
                    svg.append(f'<circle cx="{xx:.1f}" cy="{yy:.1f}" r="2.3" fill="#1d2433"/>')
        if lb:
            ly=cy-20 if i%2==0 else cy-33
            if st=='wide': ly=cy-22
            svg.append(T((X(a)+X(b))/2,ly,lb,12,'middle',fill='#3b4a5a',bold=True,rtl=not lb.isascii()))
    if xc<hi:
        svg.append(f'<line x1="{X(xc):.1f}" y1="{y+8}" x2="{X(xc):.1f}" y2="{y+H-8}" stroke="#c0392b" stroke-width="2.6" stroke-dasharray="7 4"/>')
        svg.append(T(X(xc)+5,y+20,f'{xc:.2f}',12,'start',fill='#c0392b',bold=True,rtl=False))
    for i,(mn,a,r,feed) in enumerate(moons):
        x=a/Rk
        if x>hi: continue
        rad=max(2.8,min(10,1.8*math.log10(max(r,2))**1.5))
        svg.append(f'<circle cx="{X(x):.1f}" cy="{cy:.1f}" r="{rad:.1f}" fill="#fff" stroke="#1d2433" stroke-width="1.4"/>')
        if feed: svg.append(f'<circle cx="{X(x):.1f}" cy="{cy:.1f}" r="{rad+4:.1f}" fill="none" stroke="#8e44ad" stroke-width="2.4"/>')
        dy=rad+15 if i%2==0 else rad+28
        svg.append(T(X(x),cy+dy,mn,11,'middle',fill='#555',rtl=False))
    if name=='שבתאי': svg.append(T(X(9.5),cy-24,'האבק הרחוק: נוחת על הירחים או מתפזר',11.5,'middle',fill='#8e44ad',bold=True))
    if name=='שבתאי': svg.append(f'<polygon points="{R-2},{cy-7} {R+10},{cy} {R-2},{cy+7}" fill="#8e44ad" opacity=".5"/>')
    svg.append(T(R-6,y+H-9,note,12.5,'start',fill='#3b4a5a'))
    y+=H
for t in [1,1.5,2,3,5,7,10,20,30,50,70]:
    svg.append(f'<line x1="{X(t):.1f}" y1="56" x2="{X(t):.1f}" y2="{y}" stroke="#000" stroke-opacity=".07"/>')
    svg.append(f'<text x="{X(t):.1f}" y="{y+18}" font-size="13" text-anchor="middle">{t}</text>')
svg.append(T((L+R)/2,y+42,'מרחק ממרכז כוכב הלכת, ברדיוסים שלו (סקאלה לוגריתמית)',14))
Ht=y+56
defs='<defs><pattern id="hatch" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="7" stroke="#8a6a10" stroke-width="2" opacity=".55"/></pattern><pattern id="hatchg" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(-45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#fff" stroke-width="2.2"/></pattern></defs>'
leg=[('<i style="background:#3b7dd8;opacity:.25"></i>','לפני הקו: החומר נשחק ונופל'),
('<i style="background:#d84b3b;opacity:.22"></i>','אחרי הקו: החומר נדחף החוצה'),
('<i style="border-top:3px dashed #c0392b;height:0"></i>','קו הקורוטציה'),
('<i style="border-top:2px dotted #6b7280;height:0"></i>','גבול רוש לקרח'),
('<i style="background:#d7b04a"></i>','בלי ירח, מוזנת עכשיו מהקרקע (שבתאי)'),
('<i style="background:repeating-linear-gradient(45deg,#d7b04a 0 4px,#a88520 4px 6px)"></i>','מהקרקע, התפשטה מעבר לקו, עם ירחים'),
('<i style="background:#8e44ad;opacity:.6"></i>','מוזנת או מוחזקת בידי ירח: חיה'),
('<i style="background:repeating-linear-gradient(-45deg,#9aa3ad 0 4px,#fff 4px 6px)"></i>','בלי ירח ובלי הזנה: צפויה להיעלם'),
('<i style="border:2px dashed #b08a20;height:9px"></i>','נעלמה'),

('<i style="background:#1d2433;border-radius:50%;width:6px;height:6px"></i>','גושים גדולים ("מדחפים")'),
('<i style="border:2.5px solid #8e44ad;border-radius:50%;width:10px;height:10px"></i>','ירח שמזין או מחזיק טבעת')]
lg=''.join(f'<span>{a}{b}</span>' for a,b in leg)
html=f'''<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><style>body{{margin:0;font-family:Arial,sans-serif;color:#1d2433;background:#fff}}.w{{width:{W}px;padding:18px 10px}}h1{{font-size:23px;margin:0 16px 4px}}.s{{color:#5b6475;font-size:14px;margin:4px 16px 6px;line-height:1.45}}.lg{{display:flex;gap:8px 22px;font-size:13.5px;margin:8px 16px;flex-wrap:wrap}}.lg i{{display:inline-block;width:22px;height:13px;margin-left:6px;vertical-align:middle}}.nb{{margin:10px 16px;font-size:14.5px;background:#f6f4ee;border-right:4px solid #2a3e5c;padding:10px 14px;line-height:1.6}}</style></head><body><div class="w">
<h1>מי מחזיק את הטבעת: ירחים, הקרקע, או אף אחד</h1>
<div class="s">כל שורה היא כוכב לכת, לפי הסדר מהשמש. כל חומר הטבעות יוצא מהאם – ישירות מהקרקע, או דרך ירחים שיצאו ממנה. הצבע מראה מי מזין את הטבעת היום; הרקע מראה מה קורה לחומר בכל צד של קו הקורוטציה.</div>
<div class="lg">{lg}</div>
<svg width="{W+12}" height="{Ht}" font-family="Arial,sans-serif" direction="ltr">{defs}{''.join(svg)}</svg>
<div class="nb"><b>הכלל:</b> כל חומר הטבעות יוצא מהאם, בשתי דרכים: ישירות – חומר שנפלט מהקרקע (לבה, מים, אדים) ולא חצה את הקו; הוא מקיף בטבעת, נשחק ומתפזר בה, ואינו נעשה ירח – או דרך ירחים שיצאו מהאם וממשיכים לפלוט חומר. טבעת חיה כל עוד אחת משתי הדרכים מזינה אותה. כשההזנה מהקרקע נפסקת והירחים יבשים, הטבעת נעלמת (מאדים). טבעת בלי ירח ובלי הזנה מהקרקע צפויה להיעלם. החומר הרחוק מתפזר לחלל או נוחת על הירחים.<br><b>מחוץ לכלל:</b> ירח שנלכד (Phoebe) לא יצא מהאם; הוא מוגדר במאמר 11.</div>
</div></body></html>'''
open('rings_feed.html','w').write(html)
