import sys
LANG=sys.argv[1]
rows=[ # name_he,name_en, line(lo,hi), roche, leak(bool), leak_he, leak_en, result_he, result_en, kind
('צדק היום','Jupiter today',(2.29,2.29),2.80,False,'כמעט אין: המכסה העבה ביותר','Almost none: the thickest cap','אבק מירחים בלבד','Dust from moons only','part'),
('שבתאי היום','Saturn today',(1.92,1.92),2.24,True,'כן: המכסה דולף','Yes: the cap leaks','טבעת מסיבית מהקרקע','Massive ring from the ground','yes'),
('אורנוס היום','Uranus today',(3.26,3.26),2.76,False,'לא: המים ברחו, קפא','No: the water escaped, frozen','שרידים צרים וטבעות של ירחים','Narrow remnants and moon rings','part'),
('נפטון היום','Neptune today',(3.39,3.39),3.00,False,'לא: קפא','No: frozen','שרידים צרים וטבעות של ירחים','Narrow remnants and moon rings','part'),
('מאדים הצעיר','Young Mars',(1.74,2.05),2.68,True,'כן: הר הגעש על הבליטה','Yes: the volcano on the protrusion','הייתה טבעת','It had a ring','yes'),
('מאדים היום','Mars today',(6.03,6.03),4.02,False,'לא: הקרקע נסגרה','No: the ground closed','הטבעת נעלמה','The ring vanished','no'),
('כדור הארץ בלידה','Earth at birth',(2.29,2.29),4.02,False,'לא: התייבש מהר','No: it dried fast','אין טבעת; הירח נבנה','No ring; the Moon was built','no'),
('כדור הארץ היום','Earth today',(6.62,6.62),4.49,False,'לא','No','אין טבעת','No ring','no'),
]
HE=LANG=="he"
W=1200; ax0,ax1=0,420; lo,hi=1,7
def X(v): return ax0+(v-lo)/(hi-lo)*(ax1-ax0)
trs=''
DAYS={'Jupiter today': '9.9', 'Saturn today': '10.6', 'Uranus today': '17.2', 'Neptune today': '16.1', 'Young Mars': '7–9', 'Mars today': '24.6', 'Earth at birth': '5.8', 'Earth today': '23.9'}
for r in rows:
    n=r[0] if HE else r[1]; dd=DAYS[r[1]]; (a,b),ro,lk=r[2],r[3],r[4]
    ok1=b<ro
    svg=f'<svg width="440" height="46" viewBox="-10 0 440 46">'
    svg+=f'<rect x="{X(1)}" y="12" width="{X(ro)-X(1)}" height="20" fill="#3b7dd8" opacity=".22"/>'
    svg+=f'<line x1="{X(ro)}" y1="6" x2="{X(ro)}" y2="38" stroke="#555" stroke-width="2" stroke-dasharray="3 3"/>'
    if b>a: svg+=f'<rect x="{X(a)}" y="8" width="{X(b)-X(a)}" height="28" fill="#c0392b" opacity=".85"/>'
    else: svg+=f'<line x1="{X(a)}" y1="6" x2="{X(a)}" y2="38" stroke="#c0392b" stroke-width="4"/>'
    for t in range(1,8): svg+=f'<text x="{X(t)}" y="45" font-size="9" text-anchor="middle" fill="#888">{t}</text>'
    svg+='</svg>'
    c1='y' if ok1 else 'n'; c2='y' if lk else 'n'
    t1=('כן' if ok1 else 'לא') if HE else ('Yes' if ok1 else 'No')
    trs+=f'<tr><td class="nm">{n}</td><td>{svg}<div class="num">{"יממה" if HE else "day"} {dd} {"ש׳" if HE else "h"} · {"הקו" if HE else "line"} {a:g}{((" עד " if HE else "–")+format(b,"g")) if b>a else ""} · {"רוש" if HE else "Roche"} {ro:g}</div></td><td class="{c1}">{t1}</td><td class="{c2}">{r[5] if HE else r[6]}</td><td class="res {r[9]}">{r[7] if HE else r[8]}</td></tr>'
H=dict(he=('שני תנאים לטבעת מסיבית','רשת שתופסת כדורים: הרשת (גבול רוש) צריכה להיות במקום שבו הכדורים מגיעים (קו הקורוטציה), ומישהו צריך לזרוק כדורים (דליפה מהקרקע).',
 'כוכב ותקופה','איפה הקו, ואיפה גבול רוש (ברדיוסים של הכוכב)','תנאי 1: יממה קצרה מ-13.4 שעות (הקו לפני גבול רוש)?','תנאי 2: דליפה מהקרקע?','התוצאה',
 '<i class="b"></i>אזור הלכידה: לפני גבול רוש<i class="d"></i>גבול רוש לקרח<i class="r"></i>קו הקורוטציה (במאדים הצעיר: טווח)',
 'רק כששני התנאים מתקיימים יחד יש טבעת מסיבית מהקרקע: שבתאי היום, ומאדים הצעיר. במאדים, כשהסיבוב האט, הקו עבר את גבול רוש וגם ההזנה נפסקה – והטבעת נעלמה. במאדים הצעיר ובכדור הארץ בלידה המרחקים ברדיוסים של אז, כשהכוכב היה מורחב.','rtl'),
 en=('Two conditions for a massive ring','A net that catches balls: the net (the Roche limit) must be where the balls arrive (the corotation line), and someone must throw balls (leakage from the ground).',
 'Planet and time','Where the line is, and where the Roche limit is (in planet radii)','Condition 1: day shorter than 13.4 h (line before the Roche limit)?','Condition 2: leakage from the ground?','Result',
 '<i class="b"></i>Capture zone: before the Roche limit<i class="d"></i>Roche limit for ice<i class="r"></i>Corotation line (young Mars: a range)',
 'Only when both conditions hold together is there a massive ring from the ground: Saturn today and young Mars. On Mars, as the spin slowed, the line passed the Roche limit and the feed stopped – and the ring vanished. For young Mars and the Earth at birth, distances are in the radii of that time, when the planet was expanded.','ltr'))[LANG]
html=f'''<!doctype html><html lang="{LANG}" dir="{H[9]}"><head><meta charset="utf-8"><style>
body{{margin:0;background:#fff;font-family:Arial,sans-serif;color:#1d2433}}.w{{width:{W}px;padding:18px 18px}}
h1{{font-size:22px;margin:0 0 4px}}.s{{color:#5b6475;font-size:14px;margin:2px 0 10px}}
table{{border-collapse:collapse;width:100%}}th{{background:#2a3e5c;color:#fff;font-size:13px;padding:8px;text-align:start}}
td{{border-bottom:1px solid #e1e3e8;padding:6px 8px;font-size:13.5px;vertical-align:middle}}td.nm{{font-weight:bold;font-size:14.5px;white-space:nowrap}}
td.y{{background:#d9f0e1;color:#1f7a44;font-weight:bold}}td.n{{background:#f6e0da;color:#9e2c20}}
td.res.yes{{background:#f3e3a8;font-weight:bold}}td.res.part{{background:#ece6f3}}td.res.no{{background:#eee;color:#666}}
.num{{font-size:11px;color:#666;direction:ltr;text-align:{'right' if LANG=='he' else 'left'}}}
.lg{{font-size:13px;margin:8px 0 10px;display:flex;gap:16px;align-items:center}} .lg i{{display:inline-block;width:18px;height:12px;margin:0 6px;vertical-align:middle}}
.lg i.b{{background:#3b7dd8;opacity:.3}} .lg i.d{{border-left:2px dashed #555;width:2px}} .lg i.r{{background:#c0392b;width:4px}}
.nb{{margin-top:12px;font-size:14px;background:#f6f4ee;border-{'right' if LANG=='he' else 'left'}:4px solid #2a3e5c;padding:8px 12px}}
</style></head><body><div class="w"><h1>{H[0]}</h1><div class="s">{H[1]}</div>
<div class="lg">{H[7]}</div>
<table><tr><th>{H[2]}</th><th>{H[3]}</th><th>{H[4]}</th><th>{H[5]}</th><th>{H[6]}</th></tr>{trs}</table>
<div class="nb">{H[8]}</div></div></body></html>'''
open(f'cond_{LANG}.html','w',encoding='utf-8').write(html)
