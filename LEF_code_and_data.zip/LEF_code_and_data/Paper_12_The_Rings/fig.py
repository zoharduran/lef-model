import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
rows=[('Jupiter (main + gossamer)',92000/160010,226000/160010,199796/160010,'planet'),
('Saturn (D to A ring)',66900/111564,136775/111564,135276/111564,'planet'),
('Uranus',41837/82686,51149/82686,70409/82686,'planet'),
('Neptune',41900/83514,62932/83514,74257/83514,'planet'),
('Haumea',2287/1104,2287/1104,2509/1104,'small'),
('Chariklo (2 rings)',391/186,405/186,318/186,'small'),
('Quaoar Q2R',2520/2018,2520/2018,1685/2018,'small'),
('Quaoar Q1R',4057/2018,4057/2018,1685/2018,'small')]
fig,ax=plt.subplots(figsize=(9,4.6),dpi=200)
for i,(n,a,b,ro,k) in enumerate(rows):
    y=len(rows)-1-i; c='#1f4e79' if k=='planet' else '#b5442d'
    if b-a<0.02: ax.plot([a],[y],'o',color=c,ms=9)
    else: ax.barh(y,b-a,left=a,height=0.5,color=c,alpha=.85)
    ax.plot([ro],[y],marker='|',color='#555',ms=16,mew=2)
ax.axvline(1,color='#2a7d2a',lw=2,ls='--'); ax.text(1.01,len(rows)-0.35,'corotation line',color='#2a7d2a',fontsize=9)
ax.axvline(3**(2/3),color='#8a5a00',lw=1.5,ls=':'); ax.text(2.1,len(rows)-0.35,'1:3 spin–orbit',color='#8a5a00',fontsize=9)
ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows][::-1],fontsize=9)
ax.set_xlabel('Distance from the centre, in units of the corotation radius $a_c$'); ax.set_xlim(0.4,2.45); ax.set_ylim(-0.6,len(rows)-0.1)
ax.plot([],[],marker='|',color='#555',ls='',ms=12,mew=2,label='Roche limit for ice')
ax.legend(loc='center',bbox_to_anchor=(0.7,0.62),fontsize=8,frameon=False)
ax.grid(axis='x',alpha=.3); plt.tight_layout(); plt.savefig('paper12_r01.png')
