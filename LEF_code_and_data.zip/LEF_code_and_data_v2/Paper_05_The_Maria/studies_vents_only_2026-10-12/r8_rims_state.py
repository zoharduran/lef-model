# Size-and-state and rim tests, split by opening vs plain.
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/LEF_המוח/06_נתונים_משותפים/פתחים_ומישורים_2026-10-12'); import openings as O
from scipy.stats import fisher_exact
m=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_שפה_וכימיה_2026-10-11/zip/maria_oct11/results/per_crater_morphometry.csv')
m=m[m.group=='mare'].copy(); m['status']=m.mare.map(O.ST).fillna('plain')
m['cls']=m.class_label
print('== rim retention (rim kept / expected), median, by class and terrain ==')
print(m.groupby(['status','cls']).rim_retention.agg(['median','count']).round(2))
print(m.groupby(['status','cls']).floor_minus_outer_m.median().round(0))
print(m.groupby(['status','cls']).largest_gap_deg.median().round(0))
# size-state on all near-side floor craters >=3 km
n=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ה_מכתבים_לצט_2026-10-11/near_mare_floor_craters_ge3.csv')
n['status']=n.mare.map(O.ST).fillna('plain'); n['cls']=n.cls.replace({'buried':'melted','partly':'smeared','intact':'sharp'})
n['sz']=pd.cut(n.D,[3,5,10,20,40,80,400],right=False)
dc=np.arccos(np.clip(O.xyz(n.lat,n.lon)@O.xyz(24.1,335.2)[0],-1,1))*O.R; n['zone']=np.where(dc<1500,'contact','beyond')
print('\n== state by size, openings vs plains (%) ==')
for s in ['opening','plain']:
    c=pd.crosstab(n[n.status==s].sz,n[n.status==s].cls,normalize='index').mul(100).round(0); c['n']=n[n.status==s].groupby('sz',observed=True).size(); print(s); print(c)
big=n[n.D>=40]
print('\n>=40 km by terrain and zone:'); print(pd.crosstab([big.status,big.zone],big.cls,margins=True))
x=big[big.status=='opening']; y=big[big.status=='plain']
print('melted share >=40: opening %d/%d, plain %d/%d, Fisher p=%.3g'%((x.cls=='melted').sum(),len(x),(y.cls=='melted').sum(),len(y),fisher_exact([[(x.cls=='melted').sum(),len(x)-(x.cls=='melted').sum()],[(y.cls=='melted').sum(),len(y)-(y.cls=='melted').sum()]])[1]))
from scipy.stats import chi2_contingency
for s in ['opening','plain']:
    q=n[n.status==s]; tab=pd.crosstab(q.sz,q.cls); print(s,'trend chi2 p=%.2g'%chi2_contingency(tab)[1])
