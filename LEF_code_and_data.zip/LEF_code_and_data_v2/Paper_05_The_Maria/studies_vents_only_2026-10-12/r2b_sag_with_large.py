# Study 5 with the large openings returned (Imbrium, Serenitatis, Fecunditatis: largest LROC unit of each), plains left out.
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/LEF_המוח/06_נתונים_משותפים/פתחים_ומישורים_2026-10-12'); import openings as O
from scipy.stats import spearmanr, binomtest
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ה_מכתבים_לצט_2026-10-11/named_maria_no_giants.csv')
t['status']=t.name.map(O.ST); t=t[t.status=='opening']
t=t.rename(columns={'delta_centre_minus_margin_elevation_m':'dh','delta_centre_minus_margin_bouguer900_mGal':'dg','delta_centre_minus_margin_FeO_wt':'dFeO','delta_centre_minus_margin_TiO2_wt':'dTiO2'})[['name','dh','dg','dFeO','dTiO2']]
u=pd.read_csv('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/צט_רצפות_הימות_2026-10-09/per_unit_measurements.csv')
x=u[u.name.isin(['Mare Imbrium','Mare Serenitatis','Mare Fecunditatis'])].sort_values('area_polygon_km2',ascending=False).groupby('name').head(1)
x=x.rename(columns={'delta_centre_minus_margin_elevation_m':'dh','delta_centre_minus_margin_bouguer900_mGal':'dg','delta_centre_minus_margin_FeO_wt':'dFeO','delta_centre_minus_margin_TiO2_wt':'dTiO2'})[['name','dh','dg','dFeO','dTiO2']]
a=pd.concat([t,x]).sort_values('dg',ascending=False).reset_index(drop=True); a.to_csv('r2b_openings_table.csv',index=False)
print(a.round(2).to_string(index=False))
r,p=spearmanr(a.dg,a.dh); s=a[a.dg>=30]
print(f'\nall openings n={len(a)} rho={r:+.2f} p={p:.3g}; strong n={len(s)} median dh={s.dh.median():.0f}, lower {(s.dh<0).sum()}/{len(s)} binom p={binomtest(int((s.dh<0).sum()),len(s),0.5,alternative="greater").pvalue:.3g}; weak median {a[a.dg<30].dh.median():.0f}')
print('centre denser: median dg %.0f mGal, FeO %+.2f, TiO2 %+.2f; centre richer in FeO in %d/%d'%(a.dg.median(),a.dFeO.median(),a.dTiO2.median(),(a.dFeO>0).sum(),len(a)))
s2=s[~s.name.isin(['Mare Serenitatis','Lacus Mortis'])]
print('strong without Serenitatis & Mortis: n=%d lower %d, median %.0f'%(len(s2),(s2.dh<0).sum(),s2.dh.median()))
