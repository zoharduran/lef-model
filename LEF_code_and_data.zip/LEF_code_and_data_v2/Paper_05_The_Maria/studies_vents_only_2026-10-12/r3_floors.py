# Craters Study 13 / 10 rerun: raised floors (>50 m above outer mare) on openings vs plains.
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/LEF_המוח/06_נתונים_משותפים/פתחים_ומישורים_2026-10-12'); import openings as O
from scipy.stats import fisher_exact, mannwhitneyu
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ה_מכתבים_לצט_2026-10-11/mare_craters_floor_groups_ge20.csv')
t['status']=t.mare.map(O.ST).fillna('plain')
ct=pd.crosstab([t.status,t.class_label],t.floor_group); ct['n']=ct.sum(1); ct['high%']=(100*ct.high/ct.n).round(0); print(ct)
print(pd.crosstab([t.status,t.zone],t.floor_group))
a=t[t.status=='opening']; b=t[t.status=='plain']
print('high share opening %d/%d vs plain %d/%d'%((a.floor_group=='high').sum(),len(a),(b.floor_group=='high').sum(),len(b)),
      'Fisher p=%.3g'%fisher_exact([[(a.floor_group=='high').sum(),len(a)-(a.floor_group=='high').sum()],[(b.floor_group=='high').sum(),len(b)-(b.floor_group=='high').sum()]])[1])
print('median floor-minus-outer: opening %.0f, plain %.0f, MW p=%.3g'%(a.floor_minus_outer_m.median(),b.floor_minus_outer_m.median(),mannwhitneyu(a.floor_minus_outer_m.dropna(),b.floor_minus_outer_m.dropna()).pvalue))
for D0,D1 in [(20,40),(40,1000)]:
    x=t[(t.D>=D0)&(t.D<D1)]
    print(D0,D1,{s:f"{(q.floor_group=='high').sum()}/{len(q)}" for s,q in x.groupby('status')})
print(t[t.status=='opening'].mare.value_counts())
