# Study 10 rerun on openings only: thorium in the contact by terrain (opening basalt / plain basalt / highland),
# opening floor vs its land, and per-opening correlations.
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/LEF_המוח/06_נתונים_משותפים/פתחים_ומישורים_2026-10-12'); import openings as O
from scipy.stats import spearmanr, mannwhitneyu
F='/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_שפה_וכימיה_2026-10-11/zip/maria_oct11/prior/th/mascons/data/thoriumhd.txt'
d=np.loadtxt(F,comments='#',delimiter=','); lat=(d[:,0]+d[:,1])/2; lon=(d[:,2]+d[:,3])/2; th=d[:,4]; w=np.cos(np.radians(lat))
st,nm=O.classify(lon,lat)
dc=np.arccos(np.clip(O.xyz(lat,lon)@O.xyz(24.1,335.2)[0],-1,1))*O.R
def wmed(x,ww):
    o=np.argsort(x); c=np.cumsum(ww[o]); return x[o][np.searchsorted(c,c[-1]/2)]
print('== thorium by terrain (area-weighted median ppm, share of area) ==')
for zn,m0 in [('contact',dc<1500),('outside',dc>=1500)]:
    for s in ['opening','plain','']:
        m=m0&(st==s); print(f"{zn:8s} {s or 'highland':8s} median {wmed(th[m],w[m]):.2f}  area share {w[m].sum()/w[m0].sum():.3f}")
exc=np.clip(th-3,0,None)*w
for s in ['opening','plain','']:
    print(f"share of the Moon's Th excess >3 ppm on {s or 'highland'}: {exc[st==s].sum()/exc.sum():.3f}")
print('in the contact:',{s or 'highland':round(exc[(dc<1500)&(st==s)].sum()/exc.sum(),3) for s in ['opening','plain','']})
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/תוריום_ימה_מול_יבשה_2026-10-12/th_mare_vs_land.csv')
t['status']=t.mare.map(O.ST)
print('\n== each mare floor against its land 0-150 km ==')
print(t[['mare','status','zone','th_mare','th_land_0_150','mare_minus_land']].sort_values(['status','zone']).to_string(index=False))
# per-name chemistry from units
u=pd.read_csv('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/צט_רצפות_הימות_2026-10-09/per_unit_measurements.csv').copy()
for k in ['FeO_wt','TiO2_wt','Th_ppm','bouguer900_mGal']: u[k]=u[['centre_'+k,'margin_'+k]].mean(axis=1)
g=u.groupby('name').apply(lambda q: pd.Series({k:np.average(q[k].fillna(q[k].mean()),weights=q.area_polygon_km2) for k in ['FeO_wt','TiO2_wt','Th_ppm','bouguer900_mGal']}|{'area':q.area_polygon_km2.sum()}),include_groups=False)
g['status']=g.index.map(O.ST)
big=g[g.area>=20000]
for s in ['opening','plain']:
    q=big[big.status==s].dropna()
    print(f'\n{s}: n={len(q)}  Th vs FeO rho={spearmanr(q.Th_ppm,q.FeO_wt)[0]:+.2f}  Th vs TiO2 {spearmanr(q.Th_ppm,q.TiO2_wt)[0]:+.2f}  Th vs area {spearmanr(q.Th_ppm,q.area)[0]:+.2f}  Th vs gravity {spearmanr(q.Th_ppm,q.bouguer900_mGal)[0]:+.2f}')
    print(q.sort_values('Th_ppm',ascending=False)[['Th_ppm','FeO_wt','TiO2_wt','area']].round(2).to_string())
