# Study 5 rerun: centre-minus-margin elevation against dome strength, openings vs plains (33 named maria file),
# plus the large maria from the units table.
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/LEF_המוח/06_נתונים_משותפים/פתחים_ומישורים_2026-10-12'); import openings as O
from scipy.stats import spearmanr, binomtest
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ה_מכתבים_לצט_2026-10-11/named_maria_no_giants.csv')
t['status']=t.name.map(O.ST).fillna('?')
t['dh']=t.delta_centre_minus_margin_elevation_m; t['dg']=t.delta_centre_minus_margin_bouguer900_mGal
print(t[['name','status','dh','dg','delta_centre_minus_margin_FeO_wt','delta_centre_minus_margin_TiO2_wt']].sort_values(['status','dg'],ascending=[True,False]).to_string(index=False))
for s in ['opening','plain']:
    q=t[t.status==s]; r,p=spearmanr(q.dg,q.dh); st=q[q.dg>=30]
    print(f'\n{s}: n={len(q)} rho(height,gravity)={r:+.2f} p={p:.3g}; strong (>=30 mGal) n={len(st)} median dh={st.dh.median():.0f} m, lower in {(st.dh<0).sum()}/{len(st)}; weak median dh={q[q.dg<30].dh.median():.0f}; centre FeO excess median {q.delta_centre_minus_margin_FeO_wt.median():+.2f}, gravity {q.dg.median():+.1f}')
u=pd.read_csv('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/צט_רצפות_הימות_2026-10-09/per_unit_measurements.csv')
big=['Oceanus Procellarum','Mare Imbrium','Mare Insularum','Mare Tranquillitatis','Mare Fecunditatis','Mare Serenitatis']
x=u[u.name.isin(big)].sort_values('area_polygon_km2',ascending=False).groupby('name').head(1)
x['status']=x.name.map(O.ST)
print('\nsix largest (largest unit of each):'); print(x[['name','status','area_polygon_km2','delta_centre_minus_margin_elevation_m','delta_centre_minus_margin_bouguer900_mGal']].round(1).to_string(index=False))
