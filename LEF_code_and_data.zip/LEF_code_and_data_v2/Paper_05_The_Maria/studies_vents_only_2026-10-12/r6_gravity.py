# Mass beneath melted ("shallow ring") craters, split by opening vs plain; highland control.
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/LEF_המוח/06_נתונים_משותפים/פתחים_ומישורים_2026-10-12'); import openings as O
from scipy.stats import mannwhitneyu
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/כבידה_מתחת_למכתשים_2026-10-12/per_crater_gravity_rings.csv')
m=t.grp!='highland'; s,_=O.classify(t.lon[m],t.lat[m]); t.loc[m,'status']=s; t.loc[~m,'status']='highland'
t['cls']=t.grp.str.replace('mare_','').replace({'buried':'melted','partly':'smeared','intact':'sharp'})
t['sz']=pd.cut(t.D,[20,40,80,400],right=False).astype(str)
rows=[]
for sz,q in t.groupby('sz'):
    hl=q[q.status=='highland']
    for st in ['opening','plain']:
        for c in ['melted','smeared','sharp']:
            x=q[(q.status==st)&(q.cls==c)]
            if len(x)<3: continue
            p=mannwhitneyu(x.crust_C.dropna(),hl.crust_C.dropna()).pvalue
            rows.append(dict(size=sz,where=st,cls=c,n=len(x),centre=round(x.crust_C.median(),2),floor=round(x.crust_F.median(),2),p_vs_highland=f'{p:.2g}'))
    rows.append(dict(size=sz,where='highland',cls='-',n=len(hl),centre=round(hl.crust_C.median(),2),floor=round(hl.crust_F.median(),2),p_vs_highland=''))
r=pd.DataFrame(rows); print(r.to_string(index=False)); r.to_csv('r6_table.csv',index=False)
