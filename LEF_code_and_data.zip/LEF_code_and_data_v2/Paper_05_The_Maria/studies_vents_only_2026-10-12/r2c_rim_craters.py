# Zohar: Serenitatis stayed magma after release, was exposed and dried, and craters still fell on its rim; Imbrium
# moved away from gravity and from the craters. Test: small craters (2-10 km) on the land ring 0-150 km outside each
# opening (all basalt removed), per million km2.
import sys, numpy as np, pandas as pd
from scipy.spatial import cKDTree
sys.path.insert(0,'/home/claude/LEF_המוח/06_נתונים_משותפים/פתחים_ומישורים_2026-10-12'); import openings as O
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3]); c.columns=['lon','lat','D']; c['D']/=1000
c=c[(c.D>=2)&(c.D<10)].reset_index(drop=True)
st,_=O.classify(c.lon,c.lat); land=st==''
la,lo=np.meshgrid(np.arange(-89.875,90,0.25),np.arange(-179.875,180,0.25),indexing='ij'); la=la.ravel(); lo=lo.ravel()
gst,_=O.classify(lo,la); gland=gst==''; gw=np.cos(np.radians(la))*(0.25*np.pi/180*O.R)**2
P=O.xyz(c.lat,c.lon); G=O.xyz(la,lo)
rows=[]
for nm in ['Mare Imbrium','Mare Serenitatis','Mare Crisium','Mare Fecunditatis','Mare Humorum','Mare Nectaris','Mare Smythii','Mare Moscoviense','Mare Orientale','Mare Humboldtianum','Lacus Mortis','Mare Australe']:
    V=np.vstack([np.vstack(O.polys[i]) for i in np.where(O.names==nm)[0]]); tr=cKDTree(O.xyz(V[:,1],V[:,0]))
    dg=2*np.arcsin(np.clip(tr.query(G[gland])[0]/2,0,1))*O.R; area=gw[gland][dg<150].sum()
    dc=2*np.arcsin(np.clip(tr.query(P[land])[0]/2,0,1))*O.R; n=(dc<150).sum()
    cen=O.xyz(V[:,1],V[:,0]).mean(0); cen/=np.linalg.norm(cen)
    dct=np.arccos(np.clip(cen@O.xyz(24.1,335.2)[0],-1,1))*O.R
    rows.append(dict(opening=nm,dist_contact_km=round(dct),n=int(n),ring_area_km2=round(area),density=round(n/area*1e6)))
r=pd.DataFrame(rows).sort_values('density'); print(r.to_string(index=False)); r.to_csv('r2c_rim_craters.csv',index=False)
