# Do large craters gather around the buried vents? Pooled over the 9 buried mascons; mare ground removed on both sides (approx. discs).
import numpy as np, pandas as pd
R=1737.4
t=pd.read_csv('clear_mascons.csv'); B=t[t.buried]
u=pd.read_csv('../צט_רצפות_הימות_2026-10-09/per_unit_measurements.csv'); mm=u[u.main_sample==True]
def V(lat,lon): la,lo=np.radians(lat),np.radians(lon); return np.c_[np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)]
MV=V(mm.lat.values,mm.lonE.values); MR=mm.equiv_radius_km.values
def in_mare(X):
    o=np.zeros(len(X),bool)
    for i in range(0,len(X),20000): o[i:i+20000]=((np.arccos(np.clip(X[i:i+20000]@MV.T,-1,1))*R-MR)<0).any(1)
    return o
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3]); c.columns=['lon','lat','D']; c['D']/=1000
c=c[c.D>=10]; CV=V(c.lat.values,c.lon.values%360); keep=~in_mare(CV); CV=CV[keep]; D=c.D.values[keep]
rng=np.random.default_rng(3); z=rng.uniform(-1,1,1500000); pp=rng.uniform(0,2*np.pi,1500000)
S=np.c_[np.sqrt(1-z*z)*np.cos(pp),np.sqrt(1-z*z)*np.sin(pp),z]; S=S[~in_mare(S)]; A1=4*np.pi*R**2/1500000
bands=[(0,1),(1,2),(2,3),(3,5)]  # in units of the anomaly radius, from the centre
sizes=[(10,20),(20,50),(50,100),(100,300)]
cnt={s:np.zeros(len(bands)) for s in sizes}; area=np.zeros(len(bands))
for _,b in B.iterrows():
    v=V(b.lat,b.lon)[0]; dc=np.arccos(np.clip(CV@v,-1,1))*R/b.r_km; ds=np.arccos(np.clip(S@v,-1,1))*R/b.r_km
    for j,(lo,hi) in enumerate(bands):
        area[j]+=((ds>=lo)&(ds<hi)).sum()*A1
        for s in sizes: cnt[s][j]+=((dc>=lo)&(dc<hi)&(D>=s[0])&(D<s[1])).sum()
print('pooled over',len(B),'buried mascons; density per Mkm2 by distance from centre (units of anomaly radius); relative to 3-5 r')
print('size        '+'   '.join(f'{lo}-{hi} r' for lo,hi in bands))
for s in sizes:
    dens=cnt[s]/area*1e6; rel=dens/dens[-1]
    print(f'{s[0]}-{s[1]} km  '+'   '.join(f'{x:6.1f} ({r:.2f}, n={int(n)})' for x,r,n in zip(dens,rel,cnt[s])))
