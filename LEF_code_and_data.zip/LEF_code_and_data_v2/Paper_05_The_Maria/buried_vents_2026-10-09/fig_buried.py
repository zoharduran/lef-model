import numpy as np, pandas as pd, matplotlib.pyplot as plt
from PIL import Image
from matplotlib.patches import Circle, Ellipse
t=pd.read_csv('clear_mascons.csv')
fig=plt.figure(figsize=(20,10.5))
# left: polar view (same as the maria maps)
ax=fig.add_axes([0.0,0.05,0.42,0.88]); ax.set_aspect('equal')
def P(lat,lon): r=90-lat; a=np.radians(lon); return r*np.cos(a),r*np.sin(a)
th=np.linspace(0,2*np.pi,400)
for lat in [60,30,0,-30,-60]:
    rr=90-lat; ax.plot(rr*np.cos(th),rr*np.sin(th),color='#999' if lat else '#333',lw=0.6 if lat else 1.6)
ax.plot(180*np.cos(th),180*np.sin(th),'k',lw=1)
for lon in range(0,360,30): x,y=P(-90,lon); ax.plot([0,x],[0,y],color='#ddd',lw=0.5,zorder=0)
for _,r in t.iterrows():
    x,y=P(r.lat,r.lon); s=max(60,r.r_km**1.3/2)
    if r.buried:
        ax.scatter(x,y,s=s,color='#b71c1c',edgecolor='k',lw=1,zorder=4)
        ax.text(x,y-np.sqrt(s)/4-3,r.near_basin if r.near_basin!='(unnamed)' else f'unnamed {r.lat:.0f}°,{r.lon:.0f}°',ha='center',va='top',fontsize=10,fontweight='bold',color='#b71c1c',zorder=5)
    else:
        ax.scatter(x,y,s=s,color='#3d3d4a',alpha=0.8,edgecolor='k',lw=0.5,zorder=3)
        lab=r.near_basin if r.near_basin!='(unnamed)' else str(r.mare_names).split(',')[0]
        ax.text(x,y+np.sqrt(s)/4+2,lab.replace('Mare ',''),ha='center',va='bottom',fontsize=8.5,color='#333',zorder=5)
for lon,lab,cc in [(0,'0° near\n(Earth)','k'),(90,'90°E TRAILING','#555'),(-90,'90°W LEADING','#1f3a93'),(180,'180°\nfar side','k')]:
    x,y=P(-99,lon); ax.text(x,y,lab,ha='center',va='center',fontsize=11,fontweight='bold',color=cc)
ax.set_xlim(-212,212); ax.set_ylim(-212,212); ax.axis('off')
ax.set_title('Seen from above the north pole (whole Moon)',fontsize=13)
# right: the GRAIL Bouguer map with the anomalies circled
b=fig.add_axes([0.44,0.12,0.55,0.75])
im=Image.open('grail_bouguer_quickmap.jpg'); b.imshow(im,extent=(-180,180,-75,75),aspect='auto')
for _,r in t.iterrows():
    rd=np.degrees(r.r_km/1737.4); col='#ffffff' if r.buried else '#222'
    b.add_patch(Ellipse((r.lon,r.lat),2*rd/np.cos(np.radians(r.lat)),2*rd,fill=False,ec=col,lw=2.5 if r.buried else 1.2,ls='-' if r.buried else '--'))
    if r.buried: b.text(r.lon,r.lat+rd+2,r.near_basin if r.near_basin!='(unnamed)' else 'unnamed',ha='center',fontsize=9,color='white',fontweight='bold')
b.set_xlabel('longitude (°E)'); b.set_ylabel('latitude'); b.set_xticks(range(-180,181,45))
b.set_title('GRAIL Bouguer gravity (degrees 6–660): white circles = buried, dashed = under a mare',fontsize=12)
n=int(t.buried.sum())
fig.suptitle(f'Clear mascons: {len(t)} found — {n} buried (no mare on them, red), {len(t)-n} under a visible mare (dark)',fontsize=15,fontweight='bold')
plt.savefig('fig_buried_vents.png',dpi=120)
