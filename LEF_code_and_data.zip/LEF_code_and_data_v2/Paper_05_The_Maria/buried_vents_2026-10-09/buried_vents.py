# Clear circular positive Bouguer anomalies (GRAIL 6-660, QuickMap image, cylindrical ±75°) and whether a mapped mare lies on them.
import numpy as np, pandas as pd
from PIL import Image
from scipy import ndimage as nd
R=1737.4
im=np.asarray(Image.open('grail_bouguer_quickmap.jpg').convert('RGB')).astype(int); H,W,_=im.shape
r,g,b=im[...,0],im[...,1],im[...,2]
red=(r>200)&(g<110)&(b<110); white=(r>190)&(g>140)&(b>140)&(abs(r-g)<80)
cold=((g>150)&(r<170))|((b>120)&(r<120))     # green / blue
core=nd.binary_fill_holes(nd.binary_closing(red|white,iterations=2))
lab,n=nd.label(core)
yy,xx=np.mgrid[0:H,0:W]
rows=[]
for i,sl in enumerate(nd.find_objects(lab),1):
    m=lab[sl]==i; A=m.sum()
    if A<120: continue
    h=sl[0].stop-sl[0].start; w=sl[1].stop-sl[1].start
    ys,xs=np.nonzero(m); y0=ys.mean()+sl[0].start; x0=xs.mean()+sl[1].start
    lat=75-y0*150/H; lon=-180+x0*360/W
    rpx=np.sqrt(A/np.pi); fill=A/(h*w); asp=max(h,w)/min(h,w)
    # collar: annulus 1.3-2.0 r (in pixels, x scaled by cos lat for shape)
    cl=max(np.cos(np.radians(lat)),0.25)
    dd=np.sqrt(((xx-x0)*cl)**2+(yy-y0)**2)
    ann=(dd>1.3*rpx)&(dd<2.0*rpx)
    collar=cold[ann].mean() if ann.any() else np.nan
    rows.append(dict(lat=lat,lon=lon,r_km=rpx*(360/W)*np.radians(1)*R*cl,fill=fill,aspect=asp,white=white[sl][m].mean(),collar=collar))
t=pd.DataFrame(rows)
clear=t[(t.fill>=0.55)&(t.aspect<=1.8)&(t.collar>=0.30)&(np.abs(t.lat)<=70)].copy()
# mare presence: LROC units whose centroid is within the anomaly radius
u=pd.read_csv('../צט_רצפות_הימות_2026-10-09/per_unit_measurements.csv')
def V(lat,lon): la,lo=np.radians(lat),np.radians(lon); return np.c_[np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)]
UV=V(u.lat.values,u.lonE.values)
fr=[];nm=[];OV=[]
for _,x in clear.iterrows():
    dist=np.arccos(np.clip(UV@V(x.lat,x.lon)[0],-1,1))*R
    inside=dist<x.r_km*1.0
    overl=dist<(u.equiv_radius_km.values+0.5*x.r_km)
    area=np.pi*x.r_km**2
    fr.append(min(1,u.area_polygon_km2[inside].sum()/area)); ov=u.area_polygon_km2[overl].sum()
    nm.append(', '.join(u.name[overl|inside].value_counts().index[:2]))
    OV.append(ov)
clear['mare_frac']=np.round(fr,3); clear['mare_names']=nm; clear['overlap_mare_km2']=OV
K={'Hertzsprung':(2.0,-129.0),'Freundlich-Sharonov':(18.4,175.0),'Korolev':(-4.4,-157.4),'Mendeleev':(5.7,140.9),'Coulomb-Sarton':(51.7,-123.0),
'Moscoviense':(26.7,148.2),'Humboldtianum':(57.6,82.0),'Mendel-Rydberg':(-49.8,-94.3),'Schiller-Zucchius':(-55.7,-44.8),'Grimaldi':(-5.0,-68.6),
'Lorentz':(32.6,-97.0),'Bailly':(-66.8,-68.9),'Poincare':(-57.3,163.6),'Planck':(-57.4,135.8),'Apollo':(-36.0,-151.0),'Ingenii':(-33.7,163.5),
'Dirichlet-Jackson':(13.4,-158.4),'Birkhoff':(58.9,-147.0),'Fitzgerald-Jackson':(25.1,-169.0),'TOPO-22':(49.4,179.0),'Smythii':(-1.7,87.0),
'Crisium':(17.0,59.1),'Nectaris':(-15.6,34.6),'Humorum':(-24.4,-39.4),'Serenitatis':(27.0,19.0),'Imbrium':(34.0,-17.0),'Orientale':(-20.0,-95.0),
'Fecunditatis':(-4.6,52.0),'Nubium':(-21.0,-15.0),'Australe':(-38.9,93.8),'Milne':(-31.4,112.8),'Keeler-Heaviside':(-10.0,162.0),'Hertzsprung':(2.0,-129.0)}
def name(x):
    best=None;bd=1e9
    for k,(a,o) in K.items():
        dd=np.degrees(np.arccos(np.clip((V(x.lat,x.lon)@V(a,o).T)[0,0],-1,1)))
        if dd<bd: bd,best=dd,k
    return best if bd<6 else '(unnamed)'
clear['near_basin']=clear.apply(name,axis=1)
clear['buried']=(clear.mare_frac<0.05)&(clear.overlap_mare_km2<0.05*np.pi*clear.r_km**2)
clear=clear.sort_values('r_km',ascending=False)
pd.set_option('display.width',220)
print(clear[['lat','lon','r_km','fill','collar','white','mare_frac','overlap_mare_km2','buried','near_basin','mare_names']].round(2).to_string(index=False))
print('clear anomalies:',len(clear),' buried (mare <5%):',clear.buried.sum())
clear.to_csv('clear_mascons.csv',index=False)
