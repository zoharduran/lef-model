# Halo width and east/west shape around each mare (quick look, 9.10.2026)
import pandas as pd, numpy as np
d=pd.read_csv('per_crater_chemistry.csv'); t=d[d.role=='target'].copy()
C={'Mare Crisium':(17,59.1),'Mare Fecunditatis':(-7.8,51.3),'Mare Imbrium':(32.8,344.4),'Mare Moscoviense':(27.3,147.9),
'Mare Nectaris':(-15.2,35.5),'Mare Serenitatis':(28,17.5),'Mare Smythii':(-1.3,87.3),'Mare Tranquillitatis':(8.5,31.4),'Oceanus Procellarum':(18.4,302.7)}
area={}  # from LROC is unknown here; use count proxy
ctl=2.3; ctlT=0.46
print('mare | half-distance of FeO excess (km) | TiO2 | E vs W excess within 0-100 km (FeO, TiO2) | N vs S')
for m,(la,lo) in C.items():
    x=t[t.mare==m].copy()
    if len(x)<50: continue
    dl=((x.lonE-lo+180)%360-180)*np.cos(np.radians(la)); dp=x.lat-la
    x['E']=dl>0; x['N']=dp>0
    def half(k,c0):
        e=x.groupby(pd.cut(x.distance_km,[0,10,25,50,100,150,300,600]),observed=True)[k].median()-c0
        mids=np.array([5,17.5,37.5,75,125,225,450])[:len(e)]
        e0=e.iloc[0]; 
        for i in range(1,len(e)):
            if e.iloc[i]<=e0/2:
                a,b=e.iloc[i-1],e.iloc[i]; return mids[i-1]+(mids[i]-mids[i-1])*(a-e0/2)/(a-b)
        return np.nan
    n=x[x.distance_km<100]
    ew=[n[n.E][k].median()-n[~n.E][k].median() for k in ['FeO_background_3_4R_no_mare','TiO2_background_3_4R_no_mare']]
    ns=[n[n.N][k].median()-n[~n.N][k].median() for k in ['FeO_background_3_4R_no_mare','TiO2_background_3_4R_no_mare']]
    print(f'{m:22s} {half("FeO_background_3_4R_no_mare",ctl):6.0f} {half("TiO2_background_3_4R_no_mare",ctlT):6.0f}   E-W {ew[0]:+.2f} {ew[1]:+.3f}  (nE={n.E.sum()}, nW={(~n.E).sum()})   N-S {ns[0]:+.2f} {ns[1]:+.3f}')
