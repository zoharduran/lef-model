# Mare material in rings around the maria: FeO and TiO2 vs distance (author's main point, 9.10.2026)
import pandas as pd, numpy as np
d=pd.read_csv('per_crater_chemistry.csv')
P8=['Mare Crisium','Mare Fecunditatis','Mare Imbrium','Mare Moscoviense','Mare Nectaris','Mare Serenitatis','Mare Smythii','Mare Tranquillitatis']
t=d[(d.role=='target')]
c=d[d.role=='control']
edges=[0,10,25,50,100,150,300,600]
lab=[f'{a}-{b}' for a,b in zip(edges[:-1],edges[1:])]
def tab(g,name):
    g=g.copy(); g['r']=pd.cut(g.distance_km,edges,labels=lab,right=False)
    out=[]
    for r,x in g.groupby('r',observed=True):
        out.append([r,len(x)]+[round(x[k].median(),2) for k in ['FeO_background_3_4R_no_mare','TiO2_background_3_4R_no_mare','FeO_interior','TiO2_interior']])
    o=pd.DataFrame(out,columns=['ring_km','n','FeO_surr','TiO2_surr','FeO_int','TiO2_int'])
    print('\n==',name); print(o.to_string(index=False))
    return o
rng=np.random.default_rng(1)
o8=tab(t[t.mare.isin(P8)],'8 maria pooled')
tab(t[t.mare=='Oceanus Procellarum'],'Procellarum')
print('\ncontrols n',len(c),[round(c[k].median(),2) for k in ['FeO_background_3_4R_no_mare','TiO2_background_3_4R_no_mare','FeO_interior','TiO2_interior']])
# bootstrap CI for pooled ring medians of surroundings
g=t[t.mare.isin(P8)].copy(); g['r']=pd.cut(g.distance_km,edges,labels=lab,right=False)
print('\nbootstrap 95% CI, surroundings (8 pooled)')
for r,x in g.groupby('r',observed=True):
    for k in ['FeO_background_3_4R_no_mare','TiO2_background_3_4R_no_mare']:
        v=x[k].dropna().values; b=[np.median(rng.choice(v,len(v))) for _ in range(2000)]
        print(r,k[:4],np.round(np.percentile(b,[2.5,97.5]),2))
# Spearman trend per mare
from scipy.stats import spearmanr
print('\nper mare: Spearman rho(distance, surroundings) FeO / TiO2, n, FeO 0-50 vs 150-600')
for m in P8+['Oceanus Procellarum']:
    x=t[t.mare==m]
    if len(x)<20: print(m,len(x),'too few'); continue
    a=spearmanr(x.distance_km,x.FeO_background_3_4R_no_mare,nan_policy='omit'); b=spearmanr(x.distance_km,x.TiO2_background_3_4R_no_mare,nan_policy='omit')
    near=x[x.distance_km<50]; far=x[x.distance_km>=150]
    print(f'{m:22s} n={len(x):5d} rhoFe={a.correlation:+.2f} p={a.pvalue:.1e} rhoTi={b.correlation:+.2f} p={b.pvalue:.1e}  Fe {near.FeO_background_3_4R_no_mare.median():.1f}->{far.FeO_background_3_4R_no_mare.median():.1f}  Ti {near.TiO2_background_3_4R_no_mare.median():.2f}->{far.TiO2_background_3_4R_no_mare.median():.2f}')

print('\nper mare, surroundings FeO / TiO2 medians in rings 0-25, 25-50, 50-100, 100-150, 150-300, 300-600 km')
E=[0,25,50,100,150,300,600]
for m in P8+['Oceanus Procellarum']:
    x=t[t.mare==m].copy(); x['r']=pd.cut(x.distance_km,E,right=False)
    s=x.groupby('r',observed=False).agg(n=('id','size'),Fe=('FeO_background_3_4R_no_mare','median'),Ti=('TiO2_background_3_4R_no_mare','median'))
    print(f'{m:22s}',' | '.join(f'{int(n)}:{fe:.1f}/{ti:.2f}' if n>=10 else f'{int(n)}:--' for n,fe,ti in s.values))
