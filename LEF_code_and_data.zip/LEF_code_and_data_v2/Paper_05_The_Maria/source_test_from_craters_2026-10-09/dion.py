import numpy as np, matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(13,5.6))
x=np.linspace(-40,75,3000)
c=35; R=8.7
d=np.abs(x-c)
surf=np.zeros_like(x)
ins=d<R
surf[ins]=-3.2*(1-(d[ins]/R)**2)+0.7
rim=(d>=R)&(d<R+6)
surf[rim]=0.7*np.exp(-(d[rim]-R)/2)
ax.fill_between(x,-9,surf,color='#d9c7a0')                     # highland rock
ax.fill_between(x,-2.2,surf,where=x<=0,color='#3d3d4a')         # mare basalt
ven=0.9*np.exp(-np.clip(x,0,None)/30)
ax.fill_between(x,surf-ven,surf,where=(x>0)&(~ins),color='#8a7d6b')  # veneer
ax.plot(x,surf,'k',lw=1.2)
ax.axvline(0,color='k',ls=':',lw=1); ax.text(0.5,5.0,'mare boundary',fontsize=10)
def arrow(x0,x1,y,col):
    ax.annotate('',xy=(x0,y),xytext=(x1,y),arrowprops=dict(arrowstyle='<->',color=col,lw=2.2))
arrow(-38,-2,2.6,'#1f3a93')
ax.text(-20,3.0,'1. Mare Tranquillitatis itself\nFeO 17.2%   TiO$_2$ 8.1%',ha='center',fontsize=11.5,color='#1f3a93',fontweight='bold')
arrow(c-4*R,c-3*R,2.6,'#2e7d32'); arrow(c+3*R,c+4*R,2.6,'#2e7d32')
ax.text(c,3.9,'2. Surroundings: ground 3–4 crater radii from the centre (mare pixels removed)\nFeO 12.7%   TiO$_2$ 3.4%',ha='center',fontsize=11,color='#2e7d32',fontweight='bold')
ax.plot([c-4*R,c-4*R],[2.6,0.2],color='#2e7d32',ls='--',lw=0.8); ax.plot([c+4*R,c+4*R],[2.6,0.2],color='#2e7d32',ls='--',lw=0.8)
arrow(c-0.8*R,c+0.8*R,-3.6,'#b22222')
ax.text(c,-4.6,'3. Inside the crater (to 0.8 R)\nFeO 9.1%   TiO$_2$ 0.7%',ha='center',va='top',fontsize=11.5,color='#b22222',fontweight='bold')
ax.annotate('thin veneer of mare material,\nthinning away from the mare',xy=(14,-0.4),xytext=(4,-4.3),fontsize=10,arrowprops=dict(arrowstyle='->'))
ax.annotate('poorer rock below the veneer,\nexposed by the impact',xy=(c+5,-1.3),xytext=(52,-6.8),fontsize=10,arrowprops=dict(arrowstyle='->'))
ax.text(-20,-1.2,'mare basalt',color='w',ha='center',fontsize=11)
ax.text(c,1.3,'Dionysius 17.4 km',ha='center',fontsize=10.5)
ax.annotate('',xy=(0,-8.4),xytext=(c-R,-8.4),arrowprops=dict(arrowstyle='<->',lw=1))
ax.text((c-R)/2,-8.1,'17.6 km from the mare to the rim',ha='center',fontsize=9.5)
ax.set_xlim(-40,75); ax.set_ylim(-9,5.9); ax.axis('off')
ax.set_title('Dionysius: three places, three values  (cross-section, vertical scale exaggerated)',fontsize=12.5)
plt.tight_layout(); plt.savefig('dionysius_xsec.png',dpi=160)
