import pandas as pd, numpy as np, matplotlib.pyplot as plt
d=pd.read_csv('per_crater_chemistry.csv'); t=d[d.role=='target']; c=d[d.role=='control']
P8=['Mare Crisium','Mare Fecunditatis','Mare Imbrium','Mare Moscoviense','Mare Nectaris','Mare Serenitatis','Mare Smythii','Mare Tranquillitatis']
E=[0,10,25,50,100,150,300,600]; mid=[5,17.5,37.5,75,125,225,450]
def curve(x,k):
    x=x.copy(); x['r']=pd.cut(x.distance_km,E,right=False)
    s=x.groupby('r',observed=False)[k].agg(['median','size'])
    return np.where(s['size']>=10,s['median'],np.nan)
fig,axs=plt.subplots(1,2,figsize=(13,5))
cols=plt.cm.tab10(np.arange(9))
for ax,k,ttl,ctl in [(axs[0],'FeO_background_3_4R_no_mare','Iron (FeO, wt%)',c.FeO_background_3_4R_no_mare.median()),(axs[1],'TiO2_background_3_4R_no_mare','Titanium (TiO$_2$, wt%)',c.TiO2_background_3_4R_no_mare.median())]:
    for i,m in enumerate(P8+['Oceanus Procellarum']):
        ax.plot(mid,curve(t[t.mare==m],k),'-o',ms=3,lw=1,color=cols[i],alpha=0.55,label=m.replace('Mare ','').replace('Oceanus ',''))
    ax.plot(mid,curve(t[t.mare.isin(P8)],k),'-o',color='k',lw=3,ms=6,label='eight maria pooled')
    ax.axhline(ctl,color='grey',ls='--'); ax.text(470,ctl*1.04,'far controls (>600 km)',fontsize=9,color='grey',ha='center')
    ax.set_xscale('log'); ax.set_xticks(mid); ax.set_xticklabels(['0–10','10–25','25–50','50–100','100–150','150–300','300–600'],fontsize=9)
    ax.set_xlabel('Distance of the crater from the mare edge (km)'); ax.set_ylabel(ttl+' of the ground around the crater'); ax.set_title(ttl,fontsize=12)
    ax.grid(alpha=0.25)
axs[0].legend(fontsize=8,ncol=2,loc='upper right')
fig.suptitle('Mare material in rings around the maria: the heavy elements fall with distance',fontsize=13)
plt.tight_layout(); plt.savefig('p6_rings_heavy.png',dpi=160)
