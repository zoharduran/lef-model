# Craters Study 9, limitation closed: near vs far at the same distance from a mare edge
exec(open('near_far_land_noray.py').read().split('\nrows=[]\n')[0])
from scipy.spatial import cKDTree
V=[]
for parts in polys:
    for p in parts:
        for (x0,y0),(x1,y1) in zip(p[:-1],p[1:]):
            dd=np.hypot((x1-x0)*np.cos(np.radians((y0+y1)/2)),y1-y0)*np.radians(1)*R; k=max(1,int(dd/3)); t=np.linspace(0,1,k,endpoint=False)
            V.append(np.c_[x0+(x1-x0)*t,y0+(y1-y0)*t])
V=np.vstack(V)
def xyz(lon,lat):
    a,b=np.radians(lon),np.radians(lat); return np.c_[np.cos(b)*np.cos(a),np.cos(b)*np.sin(a),np.sin(b)]
tree=cKDTree(xyz(V[:,0],V[:,1]))
def edist(lon,lat):
    d,_=tree.query(xyz(lon,lat)); return 2*R*np.arcsin(np.clip(d/2,0,1))
m=c[(c.D>=1)&(c.D<2)&c.sharp].copy(); m['e']=edist(m.lon.values,m.lat.values)
se=edist(lo,la)
bands=[0,50,150,300,600,5000]
cid=lambda x,y:(np.floor((np.asarray(x)+180)/10)*100+np.floor((np.asarray(y)+90)/10)).astype(int)
rng=np.random.default_rng(7); rows=[]
for a,b in zip(bands[:-1],bands[1:]):
    km=(m.e>=a)&(m.e<b); ks=(se>=a)&(se<b)
    An=(ks&nearS).sum()*cell; Af=(ks&~nearS).sum()*cell
    nn=(km&m.near).sum(); nf=(km&~m.near).sum()
    if An<1e5 or Af<1e5: rows.append([a,b,round(An/1e6,2),round(Af/1e6,2),nn,nf,None,None,None]); continue
    r=(nn/An)/(nf/Af)
    cc=pd.Series(cid(m.lon[km],m.lat[km])).value_counts(); sc=pd.Series(cid(lo[ks],la[ks])).value_counts()
    cells=sc.index.values; cnt=cc.reindex(cells).fillna(0).values; area=sc.values*cell
    nc=pd.Series(nearS[ks]).groupby(cid(lo[ks],la[ks])).mean().reindex(cells).values>0.5
    out=[]
    for _ in range(2000):
        i=rng.integers(0,len(cells),len(cells)); n=nc[i]
        if n.sum()==0 or (~n).sum()==0: continue
        out.append((cnt[i][n].sum()/area[i][n].sum())/(cnt[i][~n].sum()/area[i][~n].sum()))
    lo_,hi_=np.percentile(out,[2.5,97.5])
    rows.append([a,b,round(An/1e6,2),round(Af/1e6,2),int(nn),int(nf),round(r,2),round(lo_,2),round(hi_,2)])
T=pd.DataFrame(rows,columns=['edge_from_km','edge_to_km','land_near_Mkm2','land_far_Mkm2','n_near','n_far','ratio','lo','hi']); print(T.to_string()); T.to_csv('near_far_by_edge.csv',index=False)
# pooled, weighting each band equally (Mantel-Haenszel style)
