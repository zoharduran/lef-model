# Same as near_far_land.py, with the fields of the young rayed craters removed on both sides (10 crater radii)
exec(open('near_far_land.py').read().split('rows=[]')[0])
rays=[('Copernicus',9.6,-20.1,93),('Tycho',-43.3,-11.4,85),('Aristarchus',23.7,-47.4,40),('Kepler',8.1,-38.0,31),('Proclus',16.1,46.8,28),('Stevinus',-32.5,54.2,75),('Byrgius A',-24.5,-63.7,19),('Glushko',8.4,-77.6,43),
      ('Jackson',22.4,-163.1,71),('Giordano Bruno',36.0,102.9,22),('King',5.0,120.5,76),('Ohm',18.4,-113.5,62),('Necho',-5.0,123.1,30),('Crookes',-10.3,-164.5,49),('Pierazzo',3.3,-100.3,9),('Robertson',21.8,-105.2,88)]
kc=np.ones(len(c),bool); ks=np.ones(len(lo),bool)
for nm,la0,lo0,D in rays:
    r=10*D/2/R*180/np.pi; kc&=ang(c.lon.values,c.lat.values,lo0,la0)>r; ks&=ang(lo,la,lo0,la0)>r
c=c[kc]; lo,la,nearS=lo[ks],la[ks],nearS[ks]
rows=[]
for (a,b) in [(1,2),(2,5),(5,10),(10,20)]:
    An=nearS.sum()*cell; Af=(~nearS).sum()*cell
    for kind in ['all','sharp']:
        m=c[(c.D>=a)&(c.D<b)]
        if kind=='sharp': m=m[m.sharp]
        nn=m.near.sum(); nf=(~m.near).sum(); r=(nn/An)/(nf/Af); se=np.sqrt(1/nn+1/nf)
        rows.append([f'{a}-{b}',kind,int(nn),int(nf),round(An/1e6,2),round(Af/1e6,2),round(nn/An*1e6),round(nf/Af*1e6),round(r,2),round(r*np.exp(-1.96*se),2),round(r*np.exp(1.96*se),2)])
T=pd.DataFrame(rows,columns=['D_km','kind','n_near','n_far','land_near','land_far','near_perMkm2','far_perMkm2','ratio','lo','hi']); print(T.to_string()); T.to_csv('near_far_land_noray.csv',index=False)
# block bootstrap over 10x10 degree cells for 1-2 km sharp (clustering)
m=c[(c.D>=1)&(c.D<2)&c.sharp]
cid=lambda lo_,la_: (np.floor((np.asarray(lo_)+180)/10)*100+np.floor((np.asarray(la_)+90)/10)).astype(int)
cc=pd.Series(cid(m.lon,m.lat)).value_counts(); sc=pd.Series(cid(lo,la)).value_counts()
cells=sc.index.values; nearcell=pd.Series(nearS).groupby(cid(lo,la)).mean().reindex(cells).values>0.5
cnt=cc.reindex(cells).fillna(0).values; area=sc.values*cell
rng=np.random.default_rng(5); out=[]
for _ in range(2000):
    i=rng.integers(0,len(cells),len(cells)); n=nearcell[i]
    out.append((cnt[i][n].sum()/area[i][n].sum())/(cnt[i][~n].sum()/area[i][~n].sum()))
print('1-2 km sharp, cell-bootstrap 95%',np.percentile(out,[2.5,97.5]).round(2))
