# Zohar's test: small craters per km^2 on the land, all maria removed, near side vs far side.
# Additions: SPA removed, latitude within 60 (and by band), all craters and the sharp (fresh) ones apart.
import struct, numpy as np, pandas as pd
from matplotlib.path import Path
SH='/tmp/claude-0/-home-claude/823d745d-d585-5e62-ab3b-cc648f681ccc/scratchpad/lroc/'
shp=open(SH+'LROC_GLOBAL_MARE_180.SHP','rb').read()
polys=[];pos=100
while pos<len(shp):
    clen=struct.unpack('>i',shp[pos+4:pos+8])[0]*2; c=shp[pos+8:pos+8+clen]; pos+=8+clen
    nparts,npts=struct.unpack('<2i',c[36:44]); parts=list(struct.unpack(f'<{nparts}i',c[44:44+4*nparts]))
    pts=np.frombuffer(c[44+4*nparts:44+4*nparts+16*npts],dtype='<f8').reshape(-1,2); parts.append(npts)
    polys.append([pts[parts[j]:parts[j+1]] for j in range(nparts)])
def inmare(lon,lat):
    P=np.c_[lon,lat]; out=np.zeros(len(lon),bool)
    for parts in polys:
        allp=np.vstack(parts); x0,y0=allp.min(0); x1,y1=allp.max(0)
        m=(lon>=x0)&(lon<=x1)&(lat>=y0)&(lat<=y1)
        if not m.any(): continue
        par=np.zeros(m.sum(),bool)
        for p in parts: par^=Path(p).contains_points(P[m])
        out[np.where(m)[0]]|=par
    return out
R=1737.4
def ang(lo1,la1,lo2,la2):
    a,b,c2,d=map(np.radians,(lo1,la1,lo2,la2)); return np.degrees(np.arccos(np.clip(np.sin(b)*np.sin(d)+np.cos(b)*np.cos(d)*np.cos(a-c2),-1,1)))
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3,4]); c.columns=['lon','lat','D','d']; c['D']/=1000
c=c[(c.D>=1)&(c.D<20)&(c.lat.abs()<=60)].reset_index(drop=True)
spa=1000/R*180/np.pi
c=c[ang(c.lon,c.lat,-169,-53)>spa].reset_index(drop=True)
c['mare']=inmare(c.lon.values,c.lat.values); c=c[~c.mare].reset_index(drop=True)
c['dD']=np.where(c.d>0,c.d/1000/c.D,np.nan)
bins=[1,2,5,10,20]; c['bin']=pd.cut(c.D,bins,right=False)
med=c.groupby('bin',observed=True).dD.median(); c['sharp']=c.dD>c.bin.map(med).astype(float)   # deeper than the median land crater of its size
c['near']=ang(c.lon,c.lat,0,0)<=90
# land area by sampling
rng=np.random.default_rng(3); N=4_000_000
lo=rng.uniform(-180,180,N); la=np.degrees(np.arcsin(rng.uniform(-1,1,N))); k=np.abs(la)<=60; lo,la=lo[k],la[k]
k=ang(lo,la,-169,-53)>spa; lo,la=lo[k],la[k]; k=~inmare(lo,la); lo,la=lo[k],la[k]
cell=4*np.pi*R**2/N; nearS=ang(lo,la,0,0)<=90
rows=[]
for band in [(0,60),(0,30),(30,60)]:
    bc=(c.lat.abs()>=band[0])&(c.lat.abs()<band[1]); bs=(np.abs(la)>=band[0])&(np.abs(la)<band[1])
    An=(bs&nearS).sum()*cell; Af=(bs&~nearS).sum()*cell
    for (a,b) in [(1,2),(2,5),(5,10),(10,20)]:
        for kind in ['all','sharp']:
            m=c[bc&(c.D>=a)&(c.D<b)]; 
            if kind=='sharp': m=m[m.sharp]
            nn=m.near.sum(); nf=(~m.near).sum(); r=(nn/An)/(nf/Af); se=np.sqrt(1/nn+1/nf)
            rows.append([f'{band[0]}-{band[1]}',f'{a}-{b}',kind,int(nn),int(nf),round(An/1e6,2),round(Af/1e6,2),round(nn/An*1e6),round(nf/Af*1e6),round(r,2),round(r*np.exp(-1.96*se),2),round(r*np.exp(1.96*se),2)])
T=pd.DataFrame(rows,columns=['lat','D_km','kind','n_near','n_far','land_near_Mkm2','land_far_Mkm2','per_Mkm2_near','per_Mkm2_far','ratio','lo95','hi95'])
print(T.to_string()); T.to_csv('near_far_land.csv',index=False)
