# Maria study 3: crust jump under the 36 openings against ordinary craters of the same size
import json,numpy as np,pandas as pd
from scipy.ndimage import map_coordinates
g=np.load('מאמר_09_SPA/ג_נתונים_וקוד/משלוח_7/09_חומרים_קודמים_של_מאמר_8/14_GRAIL_density_ring_chatgpt/data/grail_compact.npz')
M=np.mean([g[f'Model{i}_thick'] for i in range(1,5)],0)  # 721 x 1440, 0.25 deg, assume row0=90N, col0=0E
def val(lat,lon): return map_coordinates(M,[(90-lat)*4,(lon%360)*4],order=1,mode='wrap')
R=1737.4
def jump(lat,lon,rdeg):
    out=[]
    for f0,f1 in [(0,0.3),(1.3,2.0)]:
        fr=np.linspace(f0,f1,6); az=np.radians(np.arange(0,360,15)); r=np.radians(fr[:,None]*rdeg)
        la=np.degrees(np.arcsin(np.sin(np.radians(lat))*np.cos(r)+np.cos(np.radians(lat))*np.sin(r)*np.cos(az)[None]))
        lo=lon+np.degrees(np.arctan2(np.sin(az)[None]*np.sin(r)*np.cos(np.radians(lat)),np.cos(r)-np.sin(np.radians(lat))*np.sin(np.radians(la))))
        out.append(val(la.ravel(),lo.ravel()).mean())
    return out[1]-out[0]
O=json.load(open('מאמר_09_SPA/ג_נתונים_וקוד/data/zohar_openings_sized.json'))
oj=np.array([jump(a,b,r) for a,b,r,_ in O]); rk=np.array([r*np.pi/180*R for _,_,r,_ in O])
print('openings jump>=8:',(oj>=8).sum(),'of',len(oj),' <4:',(oj<4).sum(), 'median',np.median(oj).round(1))
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3]); c.columns=['lon','lat','D']; c['D']/=1000
c=c[(c.D/2>=40)&(c.D/2<=300)&(c.lat.abs()<70)]
# exclude craters near any opening
def far(row):
    for a,b,r,_ in O:
        d=np.degrees(np.arccos(np.clip(np.sin(np.radians(row.lat))*np.sin(np.radians(a))+np.cos(np.radians(row.lat))*np.cos(np.radians(a))*np.cos(np.radians(row.lon-b)),-1,1)))
        if d<2*r+row.D/2/R*180/np.pi: return False
    return True
c=c[[far(r) for r in c.itertuples()]]
cj=np.array([jump(r.lat,r.lon,r.D/2/R*180/np.pi) for r in c.itertuples()])
print('control craters',len(cj),'jump>=8:',(cj>=8).sum(),round((cj>=8).mean()*100),'%  median',np.median(cj).round(1))
for lo_,hi_ in [(40,120),(120,300)]:
    k=(c.D/2>=lo_)&(c.D/2<hi_); ko=(rk>=lo_)&(rk<hi_)
    print(f'radius {lo_}-{hi_} km: openings {(oj[ko]>=8).sum()}/{ko.sum()}  controls {(cj[k.values]>=8).sum()}/{k.sum()}')
from scipy.stats import fisher_exact
print(fisher_exact([[(oj>=8).sum(),(oj<8).sum()],[(cj>=8).sum(),(cj<8).sum()]]))
