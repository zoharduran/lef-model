# Maria study 1: is the match of 32 of 36 marked openings to the 73 feed domes more than chance?
import pandas as pd,numpy as np,re
m=pd.read_csv('ג_נתונים_וקוד/צט_פקקים_קבורים_2026-10-09/per_mascon_measurements.csv'); m=m[m.band==660]
D=m[['lat','lonE','diameter_km']].values
rows=re.findall(r'^\d+ & [^&]*& (-?\d+\.?\d*) & (-?\d+\.?\d*) &',open('א_מאמר/parts/appA.tex').read(),re.M)
O=np.array([[float(a),float(b)] for a,b in rows]); print('openings',len(O))
R=1737.4
def match(O):
    la1,lo1=np.radians(O[:,0])[:,None],np.radians(O[:,1])[:,None]; la2,lo2=np.radians(D[:,0])[None],np.radians(D[:,1])[None]
    d=R*np.arccos(np.clip(np.sin(la1)*np.sin(la2)+np.cos(la1)*np.cos(la2)*np.cos(lo1-lo2),-1,1))
    lim=np.maximum(D[:,2]/2,150)[None]; return (d<=lim).any(1).sum()
print('observed',match(O))
rng=np.random.default_rng(0)
u=[match(np.c_[np.degrees(np.arcsin(rng.uniform(-1,1,len(O)))),rng.uniform(0,360,len(O))]) for _ in range(5000)]
r=[match(np.c_[O[:,0],(O[:,1]+rng.uniform(0,360))%360]) for _ in range(5000)]
print('uniform random: mean',np.mean(u),'95%',np.percentile(u,[2.5,97.5]),'p(>=obs)',np.mean(np.array(u)>=match(O)))
print('rotated set: mean',np.mean(r),'95%',np.percentile(r,[2.5,97.5]),'p(>=obs)',np.mean(np.array(r)>=match(O)))
