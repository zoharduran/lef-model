# Maria Study 12, closed: crater by crater on the floors, fields of young rayed craters removed, by distance from the contact
exec(open('near_far_land_noray.py').read().split("c=pd.read_csv")[0])
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3]); c.columns=['lon','lat','D']; c['D']/=1000
c=c[(c.D>=1)&(c.D<10)].reset_index(drop=True); c=c[inmare(c.lon.values,c.lat.values)].reset_index(drop=True)
rng=np.random.default_rng(3); N=6_000_000
lo=rng.uniform(-180,180,N); la=np.degrees(np.arcsin(rng.uniform(-1,1,N))); k=inmare(lo,la); lo,la=lo[k],la[k]; cell=4*np.pi*R**2/N
rays=[('Copernicus',9.6,-20.1,93),('Tycho',-43.3,-11.4,85),('Aristarchus',23.7,-47.4,40),('Kepler',8.1,-38.0,31),('Proclus',16.1,46.8,28),('Stevinus',-32.5,54.2,75),('Byrgius A',-24.5,-63.7,19),('Glushko',8.4,-77.6,43),('Jackson',22.4,-163.1,71),('Giordano Bruno',36.0,102.9,22),('King',5.0,120.5,76),('Ohm',18.4,-113.5,62),('Necho',-5.0,123.1,30),('Crookes',-10.3,-164.5,49),('Pierazzo',3.3,-100.3,9),('Robertson',21.8,-105.2,88)]
kc=np.ones(len(c),bool); ks=np.ones(len(lo),bool)
for nm,la0,lo0,D in rays:
    r=10*D/2/R*180/np.pi; kc&=ang(c.lon.values,c.lat.values,lo0,la0)>r; ks&=ang(lo,la,lo0,la0)>r
c=c[kc]; lo,la=lo[ks],la[ks]
dc=ang(c.lon.values,c.lat.values,-24.8,24.1)*np.pi/180*R; ds=ang(lo,la,-24.8,24.1)*np.pi/180*R
zones=[(0,1500,'contact'),(1500,3000,'hill'),(3000,6000,'beyond')]
cid=lambda x,y:(np.floor((np.asarray(x)+180)/5)*100+np.floor((np.asarray(y)+90)/5)).astype(int)
rows=[]
for a,b in [(1,2),(2,5),(5,10)]:
    m=(c.D>=a)&(c.D<b); dens={}; boot={}
    for z0,z1,zn in zones:
        km=m&(dc>=z0)&(dc<z1); kz=(ds>=z0)&(ds<z1)
        cc=pd.Series(cid(c.lon[km],c.lat[km])).value_counts(); sc=pd.Series(cid(lo[kz],la[kz])).value_counts()*cell
        cells=sc.index; cnt=cc.reindex(cells).fillna(0).values; area=sc.values
        dens[zn]=cnt.sum()/area.sum()*1e6
        boot[zn]=[cnt[i].sum()/area[i].sum()*1e6 for i in (rng.integers(0,len(cells),len(cells)) for _ in range(2000))]
    r=np.array(boot['beyond'])/np.array(boot['contact'])
    rows.append([f'{a}-{b}']+[round(dens[z]) for _,_,z in zones]+[round(dens['beyond']/dens['contact'],2)]+list(np.percentile(r,[2.5,97.5]).round(2)))
T=pd.DataFrame(rows,columns=['D_km','contact','hill','beyond','beyond/contact','lo','hi']); print(T.to_string()); T.to_csv('floors_by_zone_noray.csv',index=False)
