#!/usr/bin/env python3
"""Reproduce lunar crater counts. Python 3; numpy,pandas,shapely,pyshp,lxml,xlrd.
Run from any directory. Inputs are next to this script under data/.
Area integration uses a lon/lat midpoint grid with exact spherical cell areas.
"""
from pathlib import Path
import json, re, zipfile
import numpy as np
import pandas as pd
import shapely, shapefile
from lxml import etree
P=Path(__file__).resolve().parent; D=P/'data'; O=P/'results'; O.mkdir(exist_ok=True)
R=1737.4
rad=np.deg2rad

def save(rows,name):
 d=pd.DataFrame(rows);d.to_csv(O/(name+'.csv'),index=False,float_format='%.12g');return d

def area(lo,hi):return 2*np.pi*R**2*(np.sin(rad(hi))-np.sin(rad(lo)))
def regions(lat,lon):
 return [('north_cap30',lat>=60,area(60,90)),('south_cap30',lat<=-60,area(-90,-60)),('both_caps30',abs(lat)>=60,2*area(60,90)),('equator_abs_lt15',abs(lat)<15,area(-15,15)),('far_side',abs(lon)>90,2*np.pi*R**2)]

raw=D/'robbins_Dge20.csv'
if not raw.exists():
 raise FileNotFoundError('Bundle requires data/robbins_Dge20.csv: exact D>=20 subset of full 1296796-row catalogue.')
x=pd.read_csv(raw); assert len(x)==6973 and x.CRATER_ID.is_unique;lat=x.LAT_CIRC_IMG.to_numpy();lon=((x.LON_CIRC_IMG.to_numpy()+180)%360)-180
large=x.DIAM_CIRC_IMG.to_numpy()>=40
sharp=x.ARC_IMG.to_numpy()>=.9
rows=[]
for name,sel,a in regions(lat,lon):
 d=x.loc[sel&large&sharp,'DIAM_CIRC_IMG'];n=len(d)
 rows.append(dict(region=name,N=n,sqrtN=np.sqrt(n),median_km=d.median(),mean_km=d.mean(),fraction_gt80=(d>80).mean(),area_km2=a,density_per_1e6=n/a*1e6,density_error_per_1e6=np.sqrt(n)/a*1e6))
save(rows,'D2_diameters_ARCge0p9_Dge40')

major=x.DIAM_ELLI_MAJOR_IMG.to_numpy();minor=x.DIAM_ELLI_MINOR_IMG.to_numpy();ang=x.DIAM_ELLI_ANGLE_IMG.to_numpy()
e=np.divide(major,minor,out=np.full_like(major,np.nan),where=minor>0)
valid=np.isfinite(e)&np.isfinite(ang)&(major>=minor)&(minor>0)&(ang>=0)&(ang<=180)
rows=[]
for side,ss in [('near',abs(lon)<90),('far',abs(lon)>90),('all',np.ones(len(x),bool))]:
 for quality,qs in [('all_traced',np.ones(len(x),bool)),('ARC_ge_0.9',sharp)]:
  for lo in range(0,90,15):
   bs=(abs(lat)>=lo)&((abs(lat)<lo+15) if lo<75 else (abs(lat)<=90))
   base=large&ss&qs&bs;mask=base&valid&(e>=1.2);t=ang[mask];n=len(t)
   a=2*area(lo,lo+15)*(1 if side=='all' else .5)
   ns=int(np.sum(abs(t-90)<=30));ew=int(np.sum((t<=30)|(t>=150)))
   rows.append(dict(side=side,quality=quality,abs_lat_min=lo,abs_lat_max=lo+15,N_Dge40=int(base.sum()),N_valid_ellipse=int((base&valid).sum()),N_elliptical=n,sqrtN=np.sqrt(n),area_km2=a,density_elliptical_per_1e6=n/a*1e6,density_error_per_1e6=np.sqrt(n)/a*1e6,N_NS=ns,N_EW=ew,fraction_NS=ns/n if n else np.nan,fraction_EW=ew/n if n else np.nan))
save(rows,'D4_orientation_Dge40_ellipticity_ge1p2')

# The published age string is used; do not infer age from morphology.
age=pd.read_excel(D/'losiak.xls',sheet_name='Database');cp=age[age.iloc[:,50].astype(str).str.strip().eq('Copernican')].copy()
cp=pd.DataFrame({'name':cp.iloc[:,0],'diameter_km':cp.iloc[:,1],'lat':cp.iloc[:,2],'lon':cp.iloc[:,3],'age_label':cp.iloc[:,50],'age_class':cp.iloc[:,51],'remarks':cp.iloc[:,52],'age_source':cp.iloc[:,53],'other_age_sources':cp.iloc[:,54]})
cp.to_csv(D/'copernican_losiak_selected.csv',index=False)

def young_stats(df,sample,coverage=90):
 lat=df.lat.to_numpy();lon=df.lon.to_numpy();r=[];rr=regions(lat,lon)[:4]
 rr +=[(f'abs_lat_{lo}_{lo+15}',(abs(lat)>=lo)&((abs(lat)<lo+15) if lo<75 else abs(lat)<=90),2*area(lo,lo+15)) for lo in range(0,90,15)]
 for name,sel,a in rr:
  n=int(sel.sum());covered=a
  if name in ('north_cap30','south_cap30'):covered=area(60,coverage)
  elif name=='both_caps30':covered=2*area(60,coverage)
  elif name.startswith('abs_lat_'):
   lo,hi=map(int,name.split('_')[-2:]);covered=2*area(lo,min(hi,coverage)) if lo<coverage else 0
  r.append(dict(sample=sample,region=name,N=n,sqrtN=np.sqrt(n),nominal_area_km2=a,covered_area_km2=covered,density_nominal_per_1e6=n/a*1e6,density_covered_per_1e6=n/covered*1e6 if covered else np.nan,density_error_covered_per_1e6=np.sqrt(n)/covered*1e6 if covered else np.nan))
 return r
ys=young_stats(cp,'Losiak2015_Copernican_allD')+young_stats(cp[cp.diameter_km>=10],'Losiak2015_Copernican_Dge10')
if (D/'mazrouei_111.csv').exists():ys+=young_stats(pd.read_csv(D/'mazrouei_111.csv'),'Mazrouei2019',80)
y=save(ys,'D5_young_counts');rat=[]
for sample,g in y.groupby('sample',sort=False):
 p=g[g.region=='both_caps30'].iloc[0];q=g[g.region=='equator_abs_lt15'].iloc[0]
 for scope in ['nominal','covered']:
  rat.append(dict(sample=sample,area_definition=scope,pole_N=p.N,equator_N=q.N,pole_equator_ratio=p[f'density_{scope}_per_1e6']/q[f'density_{scope}_per_1e6'] if q.N else np.nan))
save(rat,'D5_pole_equator_ratios')

# Main/outer rim diameter (Table 1), retaining possible and scaling-estimated rings.
tree=etree.parse(str(D/'neumann_table_T1.xml'));bas=[]
for tr in tree.xpath('//tbody/tr'):
 cols=[''.join(el.itertext()).strip().replace('−','-') for el in tr];diam=float(re.search(r'\d+(?:\.\d+)?',cols[3]).group())
 if diam<500:continue
 name=''.join(tr[0].xpath('text()')).strip()
 ba=dict(name=name,lat=float(cols[1]),lon=float(cols[2]),diameter_km=diam,rim_entry=cols[3]);ba['angular_radius_deg']=float(np.rad2deg(diam/(2*R)))
 ba['centre_band_low']=min(75,15*np.floor(ba['lat']/15));ba['overlapping_latitude_bands']=';'.join(f'{lo}:{lo+15}' for lo in range(-90,90,15) if max(-90,ba['lat']-ba['angular_radius_deg'])<lo+15 and min(90,ba['lat']+ba['angular_radius_deg'])>lo)
 bas.append(ba)
bas=pd.DataFrame(bas);bas.to_csv(D/'neumann_basins_ge500.csv',index=False);save(bas,'A4_basin_locations')
mp=D/'mare'
if not mp.exists():
 mp.mkdir()
 with zipfile.ZipFile(D/'mare.zip') as z:z.extractall(mp)
shp=next(mp.rglob('*.SHP'));sr=shapefile.Reader(str(shp));mare=shapely.union_all([shapely.make_valid(shapely.geometry.shape(s.__geo_interface__)) for s in sr.shapes()]);shapely.prepare(mare)

def masked(lats,lons):
 la,ln=np.broadcast_arrays(lats,lons);m=shapely.intersects_xy(mare,ln,la);sl=np.sin(rad(la));cl=np.cos(rad(la))
 for b in bas.itertuples():
  m|=(sl*np.sin(rad(b.lat))+cl*np.cos(rad(b.lat))*np.cos(rad(ln-b.lon)))>=np.cos(b.diameter_km/(2*R))
 return m
mask=masked(lat,lon)
x.assign(mask_basin_or_mare=mask).to_csv(D/'robbins_Dge20_mask_flags.csv',index=False)
counts=[]
for lo in range(-90,90,15):
 sel=(lat>=lo)&((lat<lo+15) if lo<75 else lat<=90)
 counts.append(dict(lat_min=lo,lat_max=lo+15,N_before=int(sel.sum()),N_after=int((sel&~mask).sum()),area_before_km2=area(lo,lo+15)))
areas={}
for step in [.1,.05]:
 cache=D/f'area_grid_{step}.npy'
 if cache.exists():
  areas[step]=np.load(cache);continue
 ls=np.arange(-180+step/2,180,step);acc=np.zeros(12)
 for lo in range(-90,90,15):
  for la in np.arange(lo+step/2,lo+15,step):
   n=(~masked(np.array(la),ls)).sum();acc[(lo+90)//15]+=n*R**2*rad(step)*2*np.sin(rad(step/2))*np.cos(rad(la))
 areas[step]=acc
 np.save(cache,acc)
 print('area grid completed',step,flush=True)
res=[];conv=[]
for i,c in enumerate(counts):
 c['area_after_km2']=areas[.05][i]
 for tag in ['before','after']:
  c['sqrtN_'+tag]=np.sqrt(c['N_'+tag]);c['density_'+tag+'_per_1e6']=c['N_'+tag]/c['area_'+tag+'_km2']*1e6;c['density_error_'+tag+'_per_1e6']=c['sqrtN_'+tag]/c['area_'+tag+'_km2']*1e6
 res.append(c);conv.append(dict(lat_min=c['lat_min'],lat_max=c['lat_max'],area_step0p1=areas[.1][i],area_step0p05=areas[.05][i],relative_difference=(areas[.05][i]-areas[.1][i])/areas[.05][i]))
save(res,'A4_masked_latitude_profile');save(conv,'A4_area_convergence')
print('Done:',len(x),'D>=20;',large.sum(),'D>=40;',len(cp),'Copernican;',len(bas),'basins')
