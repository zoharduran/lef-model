# Zohar's 34 maria (13.10.2026): footprint = core circle of the feed dome under the point; cooked domes (Ingenii,
# Apollo, Bailly) get 150 km.
import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/claude/LEF_המוח/06_נתונים_משותפים/פתחים_ומישורים_2026-10-12'); import openings as O
M=pd.read_csv('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/פתחים_של_זוהר_2026-10-13/zohar_maria_final.csv')
d=np.arccos(np.clip(O.xyz(M.lat,M.lonE)@O.DV.T,-1,1))*O.R; j=d.argmin(1)
M['clat']=np.where(M.dome=='yes',O.D.lat.values[j],M.lat); M['clon']=np.where(M.dome=='yes',O.D.lonE.values[j],M.lonE)
M['radius_km']=np.where(M.dome=='yes',O.D.core_radius_km.values[j],150.0)
M['dome_mGal']=np.where(M.dome=='yes',O.D.centre_mGal.values[j],np.nan)
M['cover']=np.where(M.dome=='yes',O.D['class'].values[j],'cooked')
dc=np.arccos(np.clip(O.xyz(M.clat,M.clon)@O.xyz(24.1,335.2)[0],-1,1))*O.R
dh=np.arccos(np.clip(O.xyz(M.clat,M.clon)@O.xyz(16.6,13.1)[0],-1,1))*O.R
# contact: the last 3,000 km of the tip (radius 1,500 km about 24.1N 335.2E); hill: the base of the bulge, 6,000 km across
# (radius 3,000 km about 16.6N 13.1E) — Paper 3. Fixed 13.10 (before: hill = 1,500-3,000 km from the contact centre).
M['zone']=np.where(dc<1500,'contact',np.where(dh<3000,'hill','beyond'))
def footprint_dist(lat,lon):
    """distance (in radii) of each point to the nearest mare centre, and the index"""
    a=np.arccos(np.clip(O.xyz(lat,lon)@O.xyz(M.clat,M.clon).T,-1,1))*O.R/M.radius_km.values[None,:]
    return a.min(1),a.argmin(1)
