# Control for מכתשים-14: the dome itself bends the gravity field, so any point on a mare floor may show a "centre excess".
# For each melted crater on a mare floor, 50 random points on basalt within the same dome core, same diameter.
import numpy as np, pandas as pd
src=open('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/כבידה_מתחת_למכתשים_2026-10-12/gravity_under_craters.py').read().split("rows=[]")[0]
import os; os.chdir('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/כבידה_מתחת_למכתשים_2026-10-12'); exec(src)
os.chdir('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/מחקרים_על_ימות_זוהר_2026-10-13'); exec(open('maria_def.py').read())
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/כבידה_מתחת_למכתשים_2026-10-12/per_crater_gravity_rings.csv')
fr,ix=footprint_dist(t.lat.values,t.lon.values%360)
sel=(t.grp=='mare_buried')&(fr<1); T=t[sel].copy(); T['mi']=ix[sel]
rng=np.random.default_rng(141); out=[]
for _,r in T.iterrows():
    m=M.iloc[int(r.mi)]; cen=O.xyz(m.clat,m.clon)[0]; vals=[]; tries=0
    while len(vals)<50 and tries<3000:
        tries+=1
        # random point within the core
        u=rng.uniform(0,1); a=rng.uniform(0,2*np.pi); dist=m.radius_km*np.sqrt(u)/O.R
        e=np.cross(cen,[0,0,1.0]); e/=np.linalg.norm(e); f=np.cross(cen,e)
        v=np.cos(dist)*cen+np.sin(dist)*(np.cos(a)*e+np.sin(a)*f)
        la_=np.degrees(np.arcsin(v[2])); lo_=np.degrees(np.arctan2(v[1],v[0]))
        if inside_index(np.array([lo_]),np.array([la_]))[0]<0: continue
        res=rings(la_,lo_%360,r.D/2,g,LATg,LONg,True)
        if res is None: continue
        vals.append(res[0]['C'])
    out.append(dict(name=m['name'],D=r.D,crater=r.crust_C,control_median=np.nanmedian(vals),pct=np.mean(np.array(vals)<r.crust_C)*100,n=len(vals)))
o=pd.DataFrame(out); o.to_csv('c14_control.csv',index=False); print(o.round(2).to_string(index=False))
print('median crater',o.crater.median(),'median control',o.control_median.median(),'crater above its control median in',(o.crater>o.control_median).sum(),'of',len(o),'median percentile',o.pct.median())
from scipy.stats import wilcoxon; print(wilcoxon(o.crater-o.control_median))
