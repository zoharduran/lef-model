# ימות-12 all sizes: pooled floors by zone with 5-degree-cell bootstrap of beyond/contact and hill/contact ratios.
import numpy as np, pandas as pd
src=open('s7_s12_floors_noray.py').read().split("bins=[(1,2)")[0].replace("(c.D>=1)&(c.D<10)","(c.D>=1)&(c.D<1000)")
exec(src)
bins=[(1,2),(2,5),(5,10),(10,20),(20,40),(40,1000)]
op=M[M.cover=='under mare']
gz=np.full(len(la),''); cz=np.full(len(c),'',dtype=object); gz=gz.astype(object)
for _,m in op.iterrows():
    cen=O.xyz(m.clat,m.clon)[0]
    fl=(np.arccos(np.clip(G@cen,-1,1))*O.R<m.radius_km)&gb&(gw>0); gz[fl]=m.zone
    cf=(np.arccos(np.clip(Cx@cen,-1,1))*O.R<m.radius_km)&cb&(c.D.values>0); cz[cf]=m.zone
gcell=(np.floor((la+90)/5)*100+np.floor(((lo)%360)/5)).astype(int); ccell=(np.floor((c.lat.values+90)/5)*100+np.floor((c.lon.values%360)/5)).astype(int)
rng=np.random.default_rng(3); rows=[]
for a,b in bins:
    k=(c.D.values>=a)&(c.D.values<b); R={}
    for z in ['contact','hill','beyond']:
        cells=np.unique(gcell[gz==z]); A=pd.Series(gw[gz==z]).groupby(gcell[gz==z]).sum().reindex(cells).fillna(0).values
        N=pd.Series(k[cz==z].astype(int)).groupby(ccell[cz==z]).sum().reindex(cells).fillna(0).values
        bs=[]
        for _ in range(3000):
            i=rng.integers(0,len(cells),len(cells)); bs.append(N[i].sum()/max(A[i].sum(),1)*1e6)
        R[z]=(N.sum()/A.sum()*1e6,np.array(bs),int(N.sum()))
    r=dict(size=f'{a}-{b}')
    for z in R: r[z]=round(R[z][0],1); r['n_'+z]=R[z][2]
    for z in ['hill','beyond']:
        rat=R[z][1]/np.maximum(R['contact'][1],1e-9); r[z+'/contact']=round(R[z][0]/max(R['contact'][0],1e-9),1); r[z+'_ci']=f'{np.percentile(rat,2.5):.1f}-{np.percentile(rat,97.5):.1f}' if R['contact'][0]>0 else 'contact=0'
    rows.append(r)
t=pd.DataFrame(rows); t.to_csv('s12b_boot.csv',index=False); pd.set_option('display.width',250); print(t.to_string(index=False))
