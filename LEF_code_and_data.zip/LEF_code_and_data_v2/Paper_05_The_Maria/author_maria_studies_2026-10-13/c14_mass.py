# מכתשים-14 on Zohar's 34 maria: mass under the centre of craters (Moho-uplift proxy, + = excess vs 1.5-3R) for melted
# (shallow ring) craters on mare floors (inside a dome core) vs on plains vs highland, by size; and vs the missing depth.
import numpy as np, pandas as pd
from scipy.stats import mannwhitneyu, spearmanr
exec(open('maria_def.py').read())
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/כבידה_מתחת_למכתשים_2026-10-12/per_crater_gravity_rings.csv')
fr,ix=footprint_dist(t.lat.values,t.lon.values%360)
t['where']=np.where(t.grp=='highland','highland',np.where(fr<1,'mare','plain'))
t['cls']=t.grp.str.replace('mare_','').replace({'buried':'melted','partly':'smeared','intact':'sharp','highland':'-'})
t['sz']=pd.cut(t.D,[20,40,80,400],right=False).astype(str)
rows=[]; rng=np.random.default_rng(14)
def boot(x):
    x=x.dropna().values; b=[np.median(rng.choice(x,len(x))) for _ in range(2000)]; return np.percentile(b,[2.5,97.5])
for sz,q in t.groupby('sz'):
    hl=q[q['where']=='highland'].crust_C.dropna()
    for w in ['mare','plain']:
        for c in ['melted','smeared','sharp']:
            x=q[(q['where']==w)&(q.cls==c)].crust_C.dropna()
            if len(x)<3: continue
            lo,hi=boot(x); rows.append(dict(size=sz,where=w,cls=c,n=len(x),centre=round(x.median(),2),lo=round(lo,2),hi=round(hi,2),p_vs_highland=float(f'{mannwhitneyu(x,hl).pvalue:.2g}')))
    lo,hi=boot(hl); rows.append(dict(size=sz,where='highland',cls='-',n=len(hl),centre=round(hl.median(),2),lo=round(lo,2),hi=round(hi,2)))
r=pd.DataFrame(rows); r.to_csv('c14_table.csv',index=False); pd.set_option('display.width',200); print(r.to_string(index=False))
m=t[(t['where']=='mare')&(t.cls=='melted')]; p=t[(t['where']=='plain')&(t.cls=='melted')]
print('melted mare vs plain all sizes p=%.2g'%mannwhitneyu(m.crust_C.dropna(),p.crust_C.dropna()).pvalue, len(m),len(p))
print('melted on mare: rho(D, centre)',spearmanr(m.D,m.crust_C,nan_policy='omit'))
print('melted on mare: rho(missing depth hfill, centre)',spearmanr(m.hfill_km,m.crust_C,nan_policy='omit'))
print(m.groupby(np.array(M.name.values)[ix[(t['where']=='mare')&(t.cls=='melted')]]).size())
