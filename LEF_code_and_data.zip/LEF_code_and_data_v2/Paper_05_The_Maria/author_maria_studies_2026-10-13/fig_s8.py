import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.family']='DejaVu Sans Mono'
c=pd.read_csv('s8_craters.csv'); c['bin6']=pd.cut(c.D,[3,5,10,20,40,80,1000],right=False)
lab=['3–5','5–10','10–20','20–40','40–80','80+']; col={'intact':'#2b6cb0','smeared':'#d69e2e','melted':'#c0392b'}; nm={'intact':'sharp','smeared':'smeared','melted':'melted (ring)'}
fig,axs=plt.subplots(1,2,figsize=(12,4.4),sharey=True)
for ax,(g,title) in zip(axs,[('mare','On the floors of the maria (dome cores)'),('plain','On the plains (basalt with no dome)')]):
    t=pd.crosstab(c[c['where']==g].bin6,c[c['where']==g].cls).reindex(columns=['intact','smeared','melted'],fill_value=0)
    n=t.sum(axis=1).values; f=t.div(n,axis=0).values*100; x=np.arange(len(lab)); b=np.zeros(len(lab))
    for k,cl in enumerate(['intact','smeared','melted']):
        ax.bar(x,f[:,k],0.62,bottom=b,color=col[cl],edgecolor='white',lw=1.5,label=nm[cl]); b+=f[:,k]
    for i,v in enumerate(n): ax.text(i,102,f'n={v}',ha='center',fontsize=8)
    ax.set_xticks(x); ax.set_xticklabels(lab); ax.set_xlabel('crater diameter, km'); ax.set_title(title,fontsize=10)
    ax.set_ylim(0,110); ax.spines[['top','right']].set_visible(False)
axs[0].set_ylabel('share of craters, %'); axs[0].legend(loc='upper center',bbox_to_anchor=(1.05,-0.16),ncol=3,frameon=False,fontsize=9)
fig.tight_layout(); fig.savefig('/home/claude/LEF_המוח/מאמר_07_הימות/א_מאמר/fig/p5_size_state_maria_plains.png',dpi=180)
