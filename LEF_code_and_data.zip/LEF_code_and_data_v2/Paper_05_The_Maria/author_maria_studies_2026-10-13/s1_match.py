# ימות-1 on Zohar's 34 maria: how many of his points sit on a feed dome, and could chance do it?
# Match rule (as in C.5): point within the dome's core radius or 150 km of its centre, whichever is larger.
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
rng=np.random.default_rng(1)
Rm=np.maximum(O.D.core_radius_km.values,150.0)
def n_on(lat,lon):
    d=np.arccos(np.clip(O.xyz(lat,lon)@O.DV.T,-1,1))*O.R
    return (d<Rm[None,:]).any(1)
on=n_on(M.lat.values,M.lonE.values); M['on_dome']=on
print('domes in catalogue',len(O.D)); print('on dome',on.sum(),'of',len(M))
print(M[~on][['n','name','lat','lonE','dome']])
# domes carrying a mare
d=np.arccos(np.clip(O.xyz(M.lat,M.lonE)@O.DV.T,-1,1))*O.R
carried=(d<Rm[None,:]).any(0); print('domes carrying a mare',carried.sum())
print(pd.crosstab(O.D['class'],carried))
N=len(M); T=20000
# random uniform on sphere
z=rng.uniform(-1,1,(T,N)); lo=rng.uniform(0,360,(T,N)); la=np.degrees(np.arcsin(z))
r1=np.array([n_on(la[i],lo[i]).sum() for i in range(T)])
# longitude rotation keeping clustering
rot=rng.uniform(0,360,T)
r2=np.array([n_on(M.lat.values,(M.lonE.values+a)%360).sum() for a in rot])
# latitude-and-longitude rotation (random rotation of whole set)
from scipy.spatial.transform import Rotation as Rr
X=O.xyz(M.lat.values,M.lonE.values); r3=[]
for i in range(T):
    Y=Rr.random(random_state=i).apply(X); r3.append(n_on(np.degrees(np.arcsin(Y[:,2])),np.degrees(np.arctan2(Y[:,1],Y[:,0]))%360).sum())
r3=np.array(r3); k=on.sum()
for nm,r in [('uniform',r1),('lon-rotation',r2),('full-rotation',r3)]:
    print(nm,'mean %.1f'%r.mean(),'95%%',np.percentile(r,95),'max',r.max(),'P(>=%d)=%.5f'%(k,(r>=k).mean()))
# also near side / far side split
for s in ['near','far']:
    print(s,(on&(M.side==s)).sum(),'of',(M.side==s).sum())
pd.DataFrame(dict(uniform=r1,lonrot=r2,fullrot=r3)).to_csv('s1_null.csv',index=False)
M.to_csv('s1_table.csv',index=False)
