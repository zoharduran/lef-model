# Zohar 13.10: margins of non-contact maria are built of crater layers thrown from the mare -> the ground near the mare
# stands higher than the ground farther out. Non-basalt land heights (LDEM_4): rings 0-150, 150-300, 300-600 km beyond the dome core.
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
L=np.fromfile('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/data/ldem_4.img',dtype='<i2').reshape(720,1440)*0.5
la=90-(np.arange(720)+.5)/4; lo=(np.arange(1440)+.5)/4
LA,LO=np.meshgrid(la,lo,indexing='ij'); LA=LA.ravel(); LO=LO.ravel(); Z=L.ravel(); P=O.xyz(LA,LO)
st,_=O.classify(((LO+180)%360)-180,LA); B=st!=''
rows=[]
for _,m in M[M.cover!='cooked'].iterrows():
    c=O.xyz(m.clat,m.clon)[0]; d=np.arccos(np.clip(P@c,-1,1))*O.R-m.radius_km
    r=dict(n=m.n,name=m['name'],zone=m.zone,cover=m.cover)
    for a,b in [(0,150),(150,300),(300,600)]:
        k=(d>=a)&(d<b)&~B; r[f'h_{a}_{b}']=round(np.median(Z[k])) if k.sum()>=20 else np.nan
    r['near_minus_far']=r['h_0_150']-r['h_300_600'] if r['h_0_150']==r['h_0_150'] and r['h_300_600']==r['h_300_600'] else np.nan
    rows.append(r)
t=pd.DataFrame(rows); t.to_csv('s6d_margin_height.csv',index=False); pd.set_option('display.width',250); print(t.to_string(index=False))
for z,q in [('contact',t[t.zone=='contact']),('non-contact open/partial',t[(t.zone!='contact')&(t.cover!='buried')]),('buried',t[t.cover=='buried'])]:
    v=q.near_minus_far.dropna(); print(z,len(v),'median',v.median(),'near higher in',(v>0).sum(),'/',len(v))
