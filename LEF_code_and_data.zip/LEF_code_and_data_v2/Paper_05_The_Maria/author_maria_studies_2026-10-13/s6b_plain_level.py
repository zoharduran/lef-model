# Zohar 13.10: contact maria are not deep — their floor equals the nearby plain. Floor (basalt in dome core) vs the
# plain next to it (basalt outside every footprint, R..R+300 km), and vs non-basalt land; LDEM_4; plus the step at the edge
# (basalt 0.85-1.0R inside vs plain 1.0-1.15R outside).
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
L=np.fromfile('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/data/ldem_4.img',dtype='<i2').reshape(720,1440)*0.5
la=90-(np.arange(720)+.5)/4; lo=(np.arange(1440)+.5)/4
LA,LO=np.meshgrid(la,lo,indexing='ij'); LA=LA.ravel(); LO=LO.ravel(); Z=L.ravel(); P=O.xyz(LA,LO)
st,_=O.classify(((LO+180)%360)-180,LA); B=st!=''
fr,_=footprint_dist(LA,LO); plainmask=B&(fr>=1)
rows=[]
for _,m in M.iterrows():
    c=O.xyz(m.clat,m.clon)[0]; d=np.arccos(np.clip(P@c,-1,1))*O.R; r=d/m.radius_km
    fl=(r<1)&B
    if fl.sum()<30: continue
    near=plainmask&(d>=m.radius_km)&(d<m.radius_km+300)
    edge_in=B&(r>=0.85)&(r<1); edge_out=plainmask&(r>=1)&(r<1.15)
    rows.append(dict(n=m.n,name=m['name'],zone=m.zone,floor_m=round(np.median(Z[fl])),
        plain_m=round(np.median(Z[near])) if near.sum()>=10 else np.nan, plain_pix=int(near.sum()),
        floor_minus_plain=round(np.median(Z[fl])-np.median(Z[near])) if near.sum()>=10 else np.nan,
        edge_step=round(np.median(Z[edge_in])-np.median(Z[edge_out])) if (edge_in.sum()>=10 and edge_out.sum()>=10) else np.nan))
t=pd.DataFrame(rows); t.to_csv('s6b_plain_level.csv',index=False); print(t.to_string(index=False))
