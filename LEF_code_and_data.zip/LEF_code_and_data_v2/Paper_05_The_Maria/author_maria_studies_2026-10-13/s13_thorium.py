# ימות-13 on Zohar's maria: thorium inside the contact by terrain (mare footprints / plains of basalt / highland);
# each mare footprint against its ring R..R+150 km (other footprints removed).
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
F='/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_שפה_וכימיה_2026-10-11/zip/maria_oct11/prior/th/mascons/data/thoriumhd.txt'
d=np.loadtxt(F,comments='#',delimiter=','); lat=(d[:,0]+d[:,1])/2; lon=(d[:,2]+d[:,3])/2; th=d[:,4]; w=np.cos(np.radians(lat))
P=O.xyz(lat,lon)
A=np.arccos(np.clip(P@O.xyz(M.clat,M.clon).T,-1,1))*O.R   # km to each mare centre
inside=(A<M.radius_km.values[None,:])
foot=inside.any(1)
st,_=O.classify(lon,lat); basalt=st!=''
dc=np.arccos(np.clip(P@O.xyz(24.1,335.2)[0],-1,1))*O.R; C=dc<1500
def wmed(x,ww):
    o=np.argsort(x); c=np.cumsum(ww[o]); return x[o][np.searchsorted(c,c[-1]/2)]
exc=np.clip(th-3,0,None)*w
print('== inside the contact ==')
for lab,m in [('maria (footprints)',C&foot),('plains of basalt',C&~foot&basalt),('highland',C&~foot&~basalt)]:
    print(f'{lab:20s} area {w[m].sum()/w[C].sum():.3f}  median {wmed(th[m],w[m]):.2f} ppm  share of Moon excess {exc[m].sum()/exc.sum():.3f}')
print('== outside the contact ==')
for lab,m in [('maria (footprints)',~C&foot),('plains of basalt',~C&~foot&basalt),('highland',~C&~foot&~basalt)]:
    print(f'{lab:20s} median {wmed(th[m],w[m]):.2f} ppm')
rows=[]
for i,mm in M.iterrows():
    k=list(M.index).index(i)
    f=inside[:,k]; ring=(A[:,k]>=mm.radius_km)&(A[:,k]<mm.radius_km+150)&~foot
    if f.sum()<3 or ring.sum()<3: continue
    rows.append(dict(n=mm.n,name=mm['name'],zone=mm.zone,cover=mm.cover,th_mare=round(wmed(th[f],w[f]),2),th_ring=round(wmed(th[ring],w[ring]),2)))
t=pd.DataFrame(rows); t['diff']=(t.th_mare-t.th_ring).round(2); t=t.sort_values(['zone','diff']); t.to_csv('s13_table.csv',index=False)
print(t.to_string(index=False))
for z in ['contact','hill','beyond']:
    q=t[t.zone==z]; print(z,len(q),'median diff',q['diff'].median(),'poorer',(q['diff']<0).sum())
