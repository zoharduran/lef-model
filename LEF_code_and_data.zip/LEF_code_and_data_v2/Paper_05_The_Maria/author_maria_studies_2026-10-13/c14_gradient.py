# מכתשים-14, gradient check (Zohar 13.10: "I am sure there is no body, unless its edge sticks out above the ground").
# Bouguer 6-660 (GRAIL), horizontal gradient magnitude. A compact body with a sharp edge under a crater puts a ring of
# high gradient at its edge. Edge index E = median |grad| at 0.8-1.2R / median |grad| at 0.3-0.6R and 1.5-2.0R.
# Groups: melted (vanished-ring) craters on mare floors; 50 random points per crater on the same floor, same D;
# melted craters on plains; highland craters 20-160 km (a crater's own edge, for scale).
import numpy as np, pandas as pd
from PIL import Image
Image.MAX_IMAGE_PIXELS=None
exec(open('maria_def.py').read())
G=np.array(Image.open('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_שפה_וכימיה_2026-10-11/zip/maria_oct11/prior/th/mascons/data/gravity660.tif')).astype(float)
d=0.075; LAT=90-(np.arange(2400)+.5)*d; LON=-180+(np.arange(4800)+.5)*d
gy,gx=np.gradient(G); kmlat=d*np.pi/180*O.R; kmlon=kmlat*np.cos(np.radians(LAT))[:,None]
GR=np.hypot(gx/kmlon,gy/kmlat)   # mGal/km
def edge(lat,lon,Rk):
    lon=((lon+180)%360)-180; w=2.0*Rk/O.R*180/np.pi
    i=np.where(np.abs(LAT-lat)<=w)[0]; cl=max(np.cos(np.radians(lat)),0.2); dl=((LON-lon+180)%360)-180; j=np.where(np.abs(dl)<=w/cl)[0]
    if len(i)==0 or len(j)==0: return np.nan
    y=(LAT[i][:,None]-lat)*np.pi/180*O.R; x=dl[j][None,:]*np.cos(np.radians(LAT[i][:,None]))*np.pi/180*O.R
    r=np.hypot(x,y)/Rk; z=GR[np.ix_(i,j)]
    e=np.median(z[(r>=0.8)&(r<1.2)]); b=np.median(z[((r>=0.3)&(r<0.6))|((r>=1.5)&(r<2.0))])
    return e/b
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/כבידה_מתחת_למכתשים_2026-10-12/per_crater_gravity_rings.csv')
fr,ix=footprint_dist(t.lat.values,t.lon.values%360)
exec(open('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/גודל_ומצב_על_הימות_2026-10-11/size_state.py').read().split("c=pd.read_csv")[0])
rng=np.random.default_rng(1414); rows=[]
for k,r in t[(t.grp=='mare_buried')&(fr<1)].iterrows():
    m=M.iloc[int(ix[k])]; cen=O.xyz(m.clat,m.clon)[0]; e=np.cross(cen,[0,0,1.0]); e/=np.linalg.norm(e); f=np.cross(cen,e); vals=[]; tries=0
    while len(vals)<50 and tries<3000:
        tries+=1; dist=m.radius_km*np.sqrt(rng.uniform())/O.R; a=rng.uniform(0,2*np.pi)
        v=np.cos(dist)*cen+np.sin(dist)*(np.cos(a)*e+np.sin(a)*f); la_=np.degrees(np.arcsin(v[2])); lo_=np.degrees(np.arctan2(v[1],v[0]))
        if inside_index(np.array([lo_]),np.array([la_]))[0]<0: continue
        vals.append(edge(la_,lo_,r.D/2))
    rows.append(dict(group='melted on mare floor',name=m['name'],D=r.D,E=edge(r.lat,r.lon,r.D/2),E_control=np.nanmedian(vals)))
for k,r in t[(t.grp=='mare_buried')&(fr>=1)].iterrows():
    rows.append(dict(group='melted on plain',D=r.D,E=edge(r.lat,r.lon,r.D/2)))
hl=t[(t.grp=='highland')&(t.D<160)].sample(400,random_state=1)
for k,r in hl.iterrows(): rows.append(dict(group='highland crater',D=r.D,E=edge(r.lat,r.lon,r.D/2)))
o=pd.DataFrame(rows); o.to_csv('c14_gradient.csv',index=False)
print(o.groupby('group').E.describe()[['count','50%','25%','75%']].round(2))
q=o[o.group=='melted on mare floor'].dropna(subset=['E']); print(q[['name','D','E','E_control']].round(2).to_string(index=False))
from scipy.stats import wilcoxon, mannwhitneyu
print('mare crater vs own floor control: median diff',round((q.E-q.E_control).median(),3),wilcoxon(q.E-q.E_control).pvalue,'above in',(q.E>q.E_control).sum(),'/',len(q))
print('mare melted vs highland',mannwhitneyu(q.E,o[o.group=='highland crater'].E.dropna()).pvalue)
