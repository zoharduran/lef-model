# ימות-12 extended to all sizes (Zohar 13.10: small and large are one question). Floors of the open maria, pooled by zone:
# counts and density per million km2, rays masked as in s7_s12_floors_noray.py. Plains (basalt outside every footprint) for reference.
import numpy as np, pandas as pd
src=open('s7_s12_floors_noray.py').read().split("bins=[(1,2)")[0].replace("(c.D>=1)&(c.D<10)","(c.D>=1)&(c.D<1000)")
exec(src)
bins=[(1,2),(2,5),(5,10),(10,20),(20,40),(40,1000)]
fr_c,_=footprint_dist(c.lat.values,c.lon.values%360); fr_g,_=footprint_dist(la,lo%360)
op=M[M.cover=='under mare']; rows=[]
for z in ['contact','hill','beyond']:
    A=0; cnt={b:0 for b in bins}
    for _,m in op[op.zone==z].iterrows():
        cen=O.xyz(m.clat,m.clon)[0]; dg=np.arccos(np.clip(G@cen,-1,1))*O.R; dc=np.arccos(np.clip(Cx@cen,-1,1))*O.R
        fl=(dg<m.radius_km)&gb; A+=gw[fl].sum(); cf=(dc<m.radius_km)&cb
        for a,b in bins: cnt[(a,b)]+=(cf&(c.D>=a)&(c.D<b)).sum()
    r=dict(group='floors '+z,area_km2=round(A))
    for a,b in bins: r[f'n_{a}_{b}']=cnt[(a,b)]; r[f'd_{a}_{b}']=round(cnt[(a,b)]/A*1e6,1)
    rows.append(r)
# near-side basalt: mare floors (all 34 footprints) vs plains
near_g=np.abs(lo)<=90; near_c=np.abs(c.lon.values)<=90
for lab,mg,mc in [('near maria (all footprints)',gb&(fr_g<1)&near_g,cb&(fr_c<1)&near_c),('near plains',gb&(fr_g>=1)&near_g,cb&(fr_c>=1)&near_c)]:
    A=gw[mg].sum(); r=dict(group=lab,area_km2=round(A))
    for a,b in bins: k=mc&(c.D>=a)&(c.D<b); r[f'n_{a}_{b}']=k.sum(); r[f'd_{a}_{b}']=round(k.sum()/A*1e6,1)
    rows.append(r)
# near-side highland for reference
mg=~gb&near_g&(np.abs(la)<60); mc=~cb&near_c&(np.abs(c.lat.values)<60); A=gw[mg].sum(); r=dict(group='near highland |lat|<60',area_km2=round(A))
for a,b in bins: k=mc&(c.D>=a)&(c.D<b); r[f'n_{a}_{b}']=k.sum(); r[f'd_{a}_{b}']=round(k.sum()/A*1e6,1)
rows.append(r)
t=pd.DataFrame(rows); t.to_csv('s12_allsizes.csv',index=False)
pd.set_option('display.width',250); print(t.to_string(index=False))
