# ימות-9 on Zohar's maria: ground FeO/TiO2 (3-4R, mare pixels removed) in six rings, maria vs plains.
import pandas as pd, numpy as np
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_מבחן_המקור_2026-10-09/per_crater_chemistry.csv')
MARIA=['Mare Crisium','Mare Imbrium','Mare Moscoviense','Mare Nectaris','Mare Serenitatis','Mare Smythii']
G={'maria (six)':MARIA,'plains: Tranquillitatis + Fecunditatis':['Mare Tranquillitatis','Mare Fecunditatis'],'plain: Procellarum':['Oceanus Procellarum']}
tg=t[t.role=='target'].copy(); edges=[0,25,50,100,150,300,600]
tg['r6']=pd.cut(tg.distance_km,edges,right=False)
rows=[]
for g,L in G.items():
    q=tg[tg.mare.isin(L)]
    r=q.groupby('r6',observed=True).agg(n=('id','size'),FeO=('FeO_background_3_4R_no_mare','median'),TiO2=('TiO2_background_3_4R_no_mare','median')).round(2)
    r['group']=g; rows.append(r.reset_index())
for m in MARIA+['Mare Tranquillitatis','Mare Fecunditatis']:
    q=tg[tg.mare==m]; r=q.groupby('r6',observed=True).agg(n=('id','size'),FeO=('FeO_background_3_4R_no_mare','median'),TiO2=('TiO2_background_3_4R_no_mare','median')).round(2); r['group']=m; rows.append(r.reset_index())
R=pd.concat(rows); R.to_csv('s9_rings6.csv',index=False)
P=R.pivot_table(index='group',columns='r6',values='FeO',observed=False); print(P.round(1).to_string())
P=R.pivot_table(index='group',columns='r6',values='TiO2',observed=False); print(P.round(2).to_string())
c=t[t.role=='control']; print('control',c.FeO_background_3_4R_no_mare.median(),c.TiO2_background_3_4R_no_mare.median())
