# ימות-6 on Zohar's 34 maria: the floor (basalt inside the dome core) — one level?; floor vs rim and land; basalt on the rim
# ring; where the lowest part lies. LDEM_4 (7.6 km pixels). Rim = 95th percentile of height at 1.0-1.5R; land = median of
# non-basalt at R..R+300 km; levels = peaks of the detrended (plane-removed) height histogram (KDE, bw 60 m, peak >=15% of max).
import numpy as np, pandas as pd
from scipy.stats import gaussian_kde
from scipy.signal import find_peaks
exec(open('maria_def.py').read())
L=np.fromfile('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/data/ldem_4.img',dtype='<i2').reshape(720,1440)*0.5
la=90-(np.arange(720)+.5)/4; lo=(np.arange(1440)+.5)/4
LA,LO=np.meshgrid(la,lo,indexing='ij'); LA=LA.ravel(); LO=LO.ravel(); Z=L.ravel(); P=O.xyz(LA,LO)
st,_=O.classify(((LO+180)%360)-180,LA); B=st!=''
W=np.cos(np.radians(LA))
rows=[]
for _,m in M.iterrows():
    c=O.xyz(m.clat,m.clon)[0]; d=np.arccos(np.clip(P@c,-1,1))*O.R; r=d/m.radius_km
    fl=(r<1)&B; A=(W[fl]).sum()*(0.25*np.pi/180*O.R)**2
    row=dict(n=m.n,name=m['name'],zone=m.zone,cover=m.cover,radius_km=round(m.radius_km),floor_km2=round(A))
    rim=np.percentile(Z[(r>=1)&(r<1.5)],95); land=np.median(Z[(d>=m.radius_km)&(d<m.radius_km+300)&~B]) if ((d>=m.radius_km)&(d<m.radius_km+300)&~B).sum()>5 else np.nan
    row['basalt_rim_ring_%']=round(100*B[(r>=0.9)&(r<1.1)].mean())
    row['basalt_core_%']=round(100*B[r<1].mean())
    if A>=5000 and fl.sum()>=30:
        x=(P[fl]@np.cross(c,[0,0,1]))*O.R; y=(P[fl]@np.cross(c,np.cross(c,[0,0,1])))*O.R
        X=np.c_[np.ones(fl.sum()),x,y]; coef,*_=np.linalg.lstsq(X,Z[fl],rcond=None); det=Z[fl]-X@coef
        kde=gaussian_kde(det,bw_method=60/det.std()); g=np.linspace(det.min(),det.max(),400); f=kde(g)
        pk,_=find_peaks(f,height=0.15*f.max(),prominence=0.1*f.max())
        row.update(floor_m=round(np.median(Z[fl])),rim_m=round(rim),land_m=round(land) if land==land else np.nan,
                   floor_minus_rim=round(np.median(Z[fl])-rim),floor_minus_land=round(np.median(Z[fl])-land) if land==land else np.nan,
                   levels=len(pk),detrended_sd=round(det.std()),
                   lowest_r_over_R=round(float(np.median(r[fl][Z[fl]<=np.percentile(Z[fl],5)])),2),n_pix=int(fl.sum()))
    rows.append(row)
t=pd.DataFrame(rows); t.to_csv('s6_table.csv',index=False); pd.set_option('display.width',250); print(t.to_string(index=False))
q=t.dropna(subset=['levels']); print('\nmeasured floors',len(q),'one level',(q.levels==1).sum(),'below rim',(q.floor_minus_rim<0).sum(),'below land',(q.floor_minus_land<0).sum(),'of',q.floor_minus_land.notna().sum())
print('median floor-rim',q.floor_minus_rim.median(),'floor-land',q.floor_minus_land.median(),'lowest r/R median',q.lowest_r_over_R.median(),'next to wall (>0.9)',(q.lowest_r_over_R>0.9).sum())
print('basalt in rim ring (open maria) median',t[t.cover=='under mare']['basalt_rim_ring_%'].median())
