# ימות-2 and ימות-9 on Zohar's maria: iron (and titanium) of craters and their ground by distance, around his maria
# (Crisium, Imbrium, Moscoviense, Nectaris, Serenitatis, Smythii) against the plains (Fecunditatis, Tranquillitatis, Procellarum).
import pandas as pd, numpy as np
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_מבחן_המקור_2026-10-09/per_crater_chemistry.csv')
MARIA=['Mare Crisium','Mare Imbrium','Mare Moscoviense','Mare Nectaris','Mare Serenitatis','Mare Smythii']
PLAINS=['Mare Fecunditatis','Mare Tranquillitatis','Oceanus Procellarum']
tg=t[t.role=='target'].copy(); tg['grp']=np.where(tg.mare.isin(MARIA),'maria',np.where(tg.mare.isin(PLAINS),'plains','other'))
order=['0–50','50–150','150–300','300–600']
rng=np.random.default_rng(1)
def boot(x):
    x=x.dropna().values; s=[np.median(rng.choice(x,len(x))) for _ in range(1000)]; return np.percentile(s,[2.5,97.5])
rows=[]
for g in ['maria','plains']:
    for r in order:
        q=tg[(tg.grp==g)&(tg.ring==r)]
        if len(q)<10: continue
        ci=boot(q.FeO_interior-q.FeO_background_3_4R_no_mare)
        rows.append(dict(group=g,ring=r,n=len(q),FeO_crater=round(q.FeO_interior.median(),2),FeO_ground=round(q.FeO_background_3_4R_no_mare.median(),2),
                         TiO2_ground=round(q.TiO2_background_3_4R_no_mare.median(),2),crater_minus_ground=round((q.FeO_interior-q.FeO_background_3_4R_no_mare).median(),2),ci=f'{ci[0]:+.2f}..{ci[1]:+.2f}'))
c=t[t.role=='control']
rows.append(dict(group='control',ring='>600',n=len(c),FeO_crater=round(c.FeO_interior.median(),2),FeO_ground=round(c.FeO_background_3_4R_no_mare.median(),2),TiO2_ground=round(c.TiO2_background_3_4R_no_mare.median(),2),crater_minus_ground=round((c.FeO_interior-c.FeO_background_3_4R_no_mare).median(),2),ci=''))
r=pd.DataFrame(rows); print(r.to_string(index=False)); r.to_csv('s2_s9_table.csv',index=False)
print('\nper mare, ground FeO 0-50 vs 150-300:')
for m in MARIA+PLAINS:
    q=tg[tg.mare==m]; a=q[q.ring=='0–50'].FeO_background_3_4R_no_mare.median(); b=q[q.ring=='150–300'].FeO_background_3_4R_no_mare.median()
    print(f'{m:22s} 0-50 {a:.2f}  150-300 {b:.2f}  n={len(q)}')
