# מכתשים-4 on Zohar's 34 maria (14.10.2026): craters >=10 km on the basalt, whole Moon, split into mare floors
# (inside a dome core) and plains (basalt outside every footprint); zones fixed (contact 1500 km about 24.1N 335.2E,
# hill 3000 km about 16.6N 13.1E). Classes as in the original study (95/75 of highland craters of the same size).
import numpy as np, pandas as pd
from scipy.stats import chi2_contingency
exec(open('maria_def.py').read())
c=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/מכתשים_קבורים_בימות_2026-10-11/mare_floor_craters_ge10.csv')
c['cls']=c.cls.replace({'buried':'melted','partly':'smeared','intact':'sharp'})
fr,ix=footprint_dist(c.lat.values,c.lon.values%360); c['where']=np.where(fr<1,'mare','plain'); c['mare_n']=np.where(fr<1,M.name.values[ix],'')
def zone(lat,lon):
    X=O.xyz(lat,lon%360); dc=np.arccos(np.clip(X@O.xyz(24.1,335.2)[0],-1,1))*O.R; dh=np.arccos(np.clip(X@O.xyz(16.6,13.1)[0],-1,1))*O.R
    return np.where(dc<1500,'contact',np.where(dh<3000,'hill','beyond'))
c['zone']=zone(c.lat.values,c.lon.values)
la,lo=np.meshgrid(np.arange(-89.9,90,0.2),np.arange(-179.9,180,0.2),indexing='ij'); la=la.ravel(); lo=lo.ravel()
gst,_=O.classify(lo,la); gb=gst!=''; gw=np.cos(np.radians(la))*(0.2*np.pi/180*O.R)**2
gfr,_=footprint_dist(la,lo%360); gz=zone(la,lo)
rows=[]
for w,gm in [('mare',gb&(gfr<1)),('plain',gb&(gfr>=1))]:
    for z in ['contact','hill','beyond','all']:
        q=c[(c['where']==w)&((c.zone==z)|(z=='all'))]; A=gw[gm&((gz==z)|(z=='all'))].sum()
        q20=q[q.D>=20]
        rows.append(dict(where=w,zone=z,area_km2=round(A),n10=len(q),melted10=(q.cls=='melted').sum(),smeared10=(q.cls=='smeared').sum(),sharp10=(q.cls=='sharp').sum(),
            melted_pct10=round((q.cls=='melted').mean()*100) if len(q) else np.nan,n20=len(q20),melted20=(q20.cls=='melted').sum(),sharp20=(q20.cls=='sharp').sum(),
            all20_per_Mkm2=round(len(q20)/A*1e6,1) if A else np.nan,sharp20_per_Mkm2=round((q20.cls=='sharp').sum()/A*1e6,1) if A else np.nan))
t=pd.DataFrame(rows); pd.set_option('display.width',250); print(t.to_string(index=False)); t.to_csv('c4_table.csv',index=False)
for w in ['mare','plain']:
    q=c[c['where']==w]; ct=pd.crosstab(q.zone,q.cls); print(w,ct.to_string(),'chi2 p=%.2g'%chi2_contingency(ct)[1])
print(c[c['where']=='mare'].groupby('mare_n').size().sort_values())
c.to_csv('c4_craters.csv',index=False)
