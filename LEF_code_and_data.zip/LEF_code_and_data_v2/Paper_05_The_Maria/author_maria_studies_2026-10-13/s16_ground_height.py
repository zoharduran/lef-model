# ימות-16 (new, Zohar 13.10): the height of the ground around a far mare. Non-basalt land heights (LDEM_4) in rings beyond the
# dome core: 0-150, 150-300, 300-600, 600-900 km. Collar = ring 150-300 minus ring 300-600. Control: 2,000 random
# points with no mare footprint and no basalt within 900 km, given radius 150 km (the median core radius), same rings.
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
L=np.fromfile('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/data/ldem_4.img',dtype='<i2').reshape(720,1440)*0.5
la=90-(np.arange(720)+.5)/4; lo=(np.arange(1440)+.5)/4
LA,LO=np.meshgrid(la,lo,indexing='ij'); LA=LA.ravel(); LO=LO.ravel(); Z=L.ravel(); P=O.xyz(LA,LO)
st,_=O.classify(((LO+180)%360)-180,LA); B=st!=''
rings=[(0,150),(150,300),(300,600),(600,900)]
def prof(c,R):
    lat0=np.degrees(np.arcsin(c[2])); w=np.degrees((R+900)/O.R)+1
    sel=np.abs(LA-lat0)<w
    d=np.full(len(LA),1e9); d[sel]=np.arccos(np.clip(P[sel]@c,-1,1))*O.R-R; out=[]
    for a,b in rings:
        k=(d>=a)&(d<b)&~B; out.append(np.median(Z[k]) if k.sum()>=20 else np.nan)
    return out
rows=[]
for _,m in M[M.cover!='cooked'].iterrows():
    h=prof(O.xyz(m.clat,m.clon)[0],m.radius_km); rows.append(dict(n=m.n,name=m['name'],zone=m.zone,cover=m.cover,**{f'h_{a}_{b}':round(v) for (a,b),v in zip(rings,h)}))
t=pd.DataFrame(rows); t['collar']=t.h_150_300-t.h_300_600; t['near_minus_far']=t.h_0_150-t.h_300_600
# control
rng=np.random.default_rng(16); C=[]
Mx=O.xyz(M.clat,M.clon); Bx=P[B][::5]
g=np.array([(a,b) for a in np.arange(-57,58,4.0) for b in np.arange(0,360,4.0)]); V=O.xyz(g[:,0],g[:,1])
okm=((np.arccos(np.clip(V@Mx.T,-1,1))*O.R-M.radius_km.values[None,:])>=450).all(1)
from scipy.spatial import cKDTree
dB,_=cKDTree(Bx).query(V); okb=2*np.arcsin(np.clip(dB/2,0,1))*O.R>=300
for v in V[okm&okb]:
    h=prof(v,150.0); C.append(h[1]-h[2])
C=np.array(C); C=C[~np.isnan(C)]
t.to_csv('s16_table.csv',index=False); pd.set_option('display.width',250); print(t.to_string(index=False))
print('control (footprint edge >=450 km, basalt >=300 km): n',len(C),'collar median',round(np.median(C)),'share >0',round((C>0).mean(),2))
from scipy.stats import mannwhitneyu, binomtest
for lab,q in [('contact',t[t.zone=='contact']),('far, open/partial',t[(t.zone!='contact')&(t.cover!='buried')]),('far, buried',t[(t.zone!='contact')&(t.cover=='buried')]),('far, all',t[t.zone!='contact'])]:
    v=q.collar.dropna(); print(lab,len(v),'collar median',v.median(),'positive',(v>0).sum(),'MW vs control p=%.3g'%mannwhitneyu(v,C).pvalue, 'sign p=%.3g'%binomtest(int((v>0).sum()),len(v),(C>0).mean()).pvalue)
np.save('s16_control.npy',C)
