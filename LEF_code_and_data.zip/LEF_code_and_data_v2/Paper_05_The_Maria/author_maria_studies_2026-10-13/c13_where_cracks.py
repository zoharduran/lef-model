# Zohar 14.10 (new מכתשים-13): why are some crater floors cracked and others not? First look: where the floor-fractured
# craters (Thorey catalogue, type 1, 131 of 10,907 craters >= ~15 km) lie: terrain at the centre, distance to basalt, zone.
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
exec(open('maria_def.py').read())
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_מכתב8_2026-10-14/zip/letter8/input/thorey_craters.csv')
t['lonE']=t.lon0%360; lon180=((t.lonE+180)%360)-180
st,_=O.classify(lon180.values,t.lat0.values); bas=st!=''
fr,ix=footprint_dist(t.lat0.values,t.lonE.values)
t['terrain']=np.where(bas&(fr<1),'mare floor',np.where(bas,'plain','highland'))
# distance from crater centre to nearest basalt (grid 0.25 deg)
la,lo=np.meshgrid(np.arange(-89.875,90,0.25),np.arange(-179.875,180,0.25),indexing='ij'); la=la.ravel(); lo=lo.ravel()
gs,_=O.classify(lo,la); B=O.xyz(la[gs!=''],lo[gs!=''])
dd,_=cKDTree(B).query(O.xyz(t.lat0,lon180)); t['d_basalt_km']=2*np.arcsin(np.clip(dd/2,0,1))*O.R
dc=np.arccos(np.clip(O.xyz(t.lat0,t.lonE)@O.xyz(24.1,335.2)[0],-1,1))*O.R; dh=np.arccos(np.clip(O.xyz(t.lat0,t.lonE)@O.xyz(16.6,13.1)[0],-1,1))*O.R
t['zone']=np.where(dc<1500,'contact',np.where(dh<3000,'hill','beyond'))
t['side']=np.where(abs(lon180)<=90,'near','far')
t['dband']=pd.cut(np.where(t.terrain=='highland',t.d_basalt_km,0),[-1,0.1,50,150,400,5000],labels=['on basalt','0-50 km','50-150','150-400','>400'])
t['ffc']=t.type==1
for col in ['terrain','dband','zone','side']:
    g=t.groupby(col,observed=True).agg(craters=('ffc','size'),ffc=('ffc','sum')); g['rate_%']=(g.ffc/g.craters*100).round(2); print(g,'\n')
t.to_csv('c13_where_cracks.csv',index=False)
