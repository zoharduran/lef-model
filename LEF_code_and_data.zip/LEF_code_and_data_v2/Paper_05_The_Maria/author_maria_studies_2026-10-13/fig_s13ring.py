import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.family']='DejaVu Sans'
t=pd.read_csv('s13_table.csv'); o={'contact':0,'hill':1,'beyond':2}; t['o']=t.zone.map(o); t=t.sort_values(['o','diff'])
col={'contact':'#e8673a','hill':'#2b78d4','beyond':'#9a9a9a'}
fig,ax=plt.subplots(figsize=(9,10)); y=np.arange(len(t))[::-1]
ax.barh(y,t['diff'],color=[col[z] for z in t.zone],height=0.7)
ax.set_yticks(y); ax.set_yticklabels([f"{n} {m}" for n,m in zip(t.n,t.name)],fontsize=9); ax.axvline(0,color='k',lw=1)
ax.set_xlabel('Thorium: mare minus the ring around it (ppm)'); ax.set_title('Every mare of the contact is poorer in thorium than the ground around it',fontsize=11)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=col[z],label=z) for z in ['contact','hill','beyond']],loc='lower left',frameon=False)
ax.spines[['top','right']].set_visible(False); fig.tight_layout(); fig.savefig('/home/claude/LEF_המוח/מאמר_07_הימות/א_מאמר/fig/p5_thorium_maria_ring.png',dpi=160)
