# מכתשים-10/11 on Zohar's maria (14.10.2026): floors of the large craters on the basalt against the basalt outside
# them, split into mare floors (inside a dome core) and plains; and iron of high vs low floors.
import numpy as np, pandas as pd
from scipy.stats import mannwhitneyu
exec(open('maria_def.py').read())
R='/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_שפה_וכימיה_2026-10-11/zip/maria_oct11/results/'
m=pd.read_csv(R+'per_crater_morphometry.csv'); ch=pd.read_csv(R+'per_crater_chemistry.csv')
print(m.group.value_counts().head(), m.cls.value_counts())
b=m[m.group!='highland'].copy() if 'highland' in set(m.group) else m[m.mare.notna()].copy()
fr,ix=footprint_dist(b.lat.values,b.lon.values%360); b['where']=np.where(fr<1,'mare','plain')
b['grp']=np.where(b.floor_minus_outer_m>50,'above',np.where(b.floor_minus_outer_m<-50,'below','level'))
ok=b.valid_mare_background==True if 'valid_mare_background' in b else True
big=b[(b.D>=40)&ok&b.floor_minus_outer_m.notna()]
t=big.groupby(['where','cls']).agg(n=('id','size'),above=('grp',lambda x:(x=='above').sum()),level=('grp',lambda x:(x=='level').sum()),below=('grp',lambda x:(x=='below').sum()),median=('floor_minus_outer_m','median')).round(0)
print(t); t.to_csv('c10_table.csv')
hl=m[m.group=='highland']; hl=hl[hl.D>=40]; print('highland',len(hl),hl.floor_minus_outer_m.median() if 'floor_minus_outer_m' in hl else '')
# Study 11
x=b[(b.D>=20)&b.cls.isin(['buried','partly','melted','smeared'])&ok&b.floor_minus_outer_m.notna()].merge(ch[['id','FeO_floor_median','TiO2_floor_median']],on='id')
g=x.groupby(['where','grp']).agg(n=('id','size'),FeO=('FeO_floor_median','median'),TiO2=('TiO2_floor_median','median')).round(1); print(g); g.to_csv('c11_table.csv')
for w in ['mare','plain','all']:
    q=x if w=='all' else x[x['where']==w]
    a=q[q.grp=='below'].FeO_floor_median.dropna(); h=q[q.grp=='above'].FeO_floor_median.dropna()
    a2=q[q.grp=='below'].TiO2_floor_median.dropna(); h2=q[q.grp=='above'].TiO2_floor_median.dropna()
    if len(a)>2 and len(h)>2: print(w,'FeO below vs above p=%.3f'%mannwhitneyu(a,h).pvalue,'TiO2 p=%.3f'%mannwhitneyu(a2,h2).pvalue,len(a),len(h))
