# מכתשים-2 on Zohar's maria: thorium of the ejecta and TiO2 inside, by ring, maria vs plains (Paper 6 C.5/L.1)
import pandas as pd, numpy as np
t=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_מבחן_המקור_2026-10-09/per_crater_chemistry.csv')
MARIA=['Mare Crisium','Mare Imbrium','Mare Moscoviense','Mare Nectaris','Mare Serenitatis','Mare Smythii']
PLAINS=['Mare Fecunditatis','Mare Tranquillitatis','Oceanus Procellarum']
t['grp']=np.where(t.role=='control','control',np.where(t.mare.isin(MARIA),'maria',np.where(t.mare.isin(PLAINS),'plains','other')))
g=t[t.grp!='other'].groupby(['grp','ring']).agg(n=('id','size'),FeO_in=('FeO_interior','median'),TiO2_in=('TiO2_interior','median'),Th_ej=('Th_ejecta','median')).round(2)
print(g); g.to_csv('c2_th_rings.csv')
