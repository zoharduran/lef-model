# ימות-5 on Zohar's maria: centre (0-0.3R) minus margin (0.7-1.0R) surface height over each dome, against dome strength.
import numpy as np, pandas as pd
from scipy.stats import spearmanr, binomtest
exec(open('maria_def.py').read())
L=np.fromfile('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/data/ldem_4.img',dtype='<i2').reshape(720,1440)*0.5
la=90-(np.arange(720)+.5)/4; lo=(np.arange(1440)+.5)/4
LA,LO=np.meshgrid(la,lo,indexing='ij'); P=O.xyz(LA.ravel(),LO.ravel()); Z=L.ravel()
rows=[]
for _,m in M.iterrows():
    r=np.arccos(np.clip(P@O.xyz(m.clat,m.clon)[0],-1,1))*O.R/m.radius_km
    c=np.median(Z[r<0.3]); g=np.median(Z[(r>=0.7)&(r<1.0)])
    rows.append(dict(n=m.n,name=m['name'],cover=m.cover,zone=m.zone,dome_mGal=m.dome_mGal,radius_km=round(m.radius_km),dh_m=round(c-g)))
t=pd.DataFrame(rows).sort_values('dome_mGal',ascending=False); t.to_csv('s5_table.csv',index=False); print(t.to_string(index=False))
for lab,q in [('open (under mare)',t[t.cover=='under mare']),('partial',t[t.cover=='partial']),('buried',t[t.cover=='buried']),('all with dome',t[t.cover!='cooked'])]:
    if len(q)<3: continue
    r,p=spearmanr(q.dome_mGal,q.dh_m); low=(q.dh_m<0).sum()
    print(f'{lab:18s} n={len(q):2d} centre lower in {low}/{len(q)} (sign p={binomtest(int(low),len(q),0.5,alternative="greater").pvalue:.3g}), median dh {q.dh_m.median():.0f} m, rho(strength,dh)={r:+.2f} p={p:.3g}')
