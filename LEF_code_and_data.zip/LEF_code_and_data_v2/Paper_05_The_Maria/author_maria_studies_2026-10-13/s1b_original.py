# The chance test on the original marks (made before any dome list was seen): 36 points; and the 30 of them kept as maria.
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
P=pd.read_csv('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/פתחים_של_זוהר_2026-10-13/zohar_openings_points.csv')
Rm=np.maximum(O.D.core_radius_km.values,150.0)
def n_on(lat,lon): return (np.arccos(np.clip(O.xyz(lat,lon)@O.DV.T,-1,1))*O.R<Rm[None,:]).any(1)
rng=np.random.default_rng(2); T=20000
for lab,S in [('original 36',P),('30 kept',P[P.app_n.isin(M.n)])]:
    k=n_on(S.lat.values,S.lonE.values).sum(); N=len(S)
    z=rng.uniform(-1,1,(T,N)); la=np.degrees(np.arcsin(z)); lo=rng.uniform(0,360,(T,N))
    r1=np.array([n_on(la[i],lo[i]).sum() for i in range(T)])
    r2=np.array([n_on(S.lat.values,(S.lonE.values+a)%360).sum() for a in rng.uniform(0,360,T)])
    print(lab,'on dome',k,'of',N,'| random mean %.1f max %d P=%.5f'%(r1.mean(),r1.max(),(r1>=k).mean()),'| lon-rot mean %.1f P=%.4f'%(r2.mean(),(r2>=k).mean()))
