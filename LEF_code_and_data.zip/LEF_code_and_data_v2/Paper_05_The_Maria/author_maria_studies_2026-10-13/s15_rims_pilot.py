# ימות-15 pilot: rim and floor of craters >=40 km on near-side basalt, from LDEM_4 (7.6 km pixels): rim = median height
# 0.9-1.15R minus ground 1.6-2.4R; floor = median 0-0.4R minus ground. Groups: contact plains, Imbrium+Serenitatis basalt,
# beyond-contact plains, mare footprints; highland control >=40 km near side |lat|<60, no basalt within 2.4R.
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
L=np.fromfile('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/data/ldem_4.img',dtype='<i2').reshape(720,1440)*0.5
la=90-(np.arange(720)+.5)/4; lo=(np.arange(1440)+.5)/4
def prof(lat,lon,D):
    R=D/2; dl=np.degrees(2.6*R/O.R); i0=np.searchsorted(-la,-(lat+dl)); i1=np.searchsorted(-la,-(lat-dl))
    ii=np.arange(max(i0-1,0),min(i1+1,720)); w=dl/max(np.cos(np.radians(lat)),0.15)
    jj=(np.arange(int((lon-w)*4)-1,int((lon+w)*4)+2))%1440
    A,B=np.meshgrid(la[ii],lo[jj],indexing='ij'); Z=L[np.ix_(ii,jj)]
    r=np.arccos(np.clip(O.xyz(A.ravel(),B.ravel())@O.xyz(lat,lon)[0],-1,1))*O.R/R; Z=Z.ravel()
    g=np.median(Z[(r>=1.6)&(r<2.4)]); return np.median(Z[(r>=0.9)&(r<1.15)])-g, np.median(Z[r<0.4])-g
s=pd.read_csv('s8_craters.csv'); s=s[s.D>=40].copy()
C0=O.xyz(24.1,335.2)[0]; s['dc']=np.arccos(np.clip(O.xyz(s.lat,s.lon%360)@C0,-1,1))*O.R
s['grp']=np.where(s['where']=='mare','mare footprint',np.where(s.mare.isin(['Mare Imbrium','Mare Serenitatis']),'Imbrium/Serenitatis basalt',np.where(s.dc<1500,'contact plains','beyond plains')))
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3,4]); c.columns=['lon','lat','D','d']; c['D']/=1000
h=c[(c.D>=40)&(c.D<300)&(c.lon.abs()<=90)&(c.lat.abs()<60)].copy()
st,_=O.classify(h.lon.values,h.lat.values); h=h[st==''].copy(); h['grp']='highland control'; h['cls']=''
h['dD']=h.d/1000/h.D
X=pd.concat([s[['lon','lat','D','dD','cls','grp','mare']],h[['lon','lat','D','dD','cls','grp']]],ignore_index=True)
out=[prof(a,b%360,D) for a,b,D in zip(X.lat,X.lon,X.D)]
X['rim_m']=[o[0] for o in out]; X['floor_m']=[o[1] for o in out]
X.to_csv('s15_rims_pilot.csv',index=False)
for sz in [(40,60),(60,400)]:
    q=X[(X.D>=sz[0])&(X.D<sz[1])]
    print('size',sz); print(q.groupby('grp').agg(n=('D','size'),rim=('rim_m','median'),floor=('floor_m','median'),dD=('dD','median')).round(3).to_string())
print(X[X.grp=='Imbrium/Serenitatis basalt'][['mare','D','cls','rim_m','floor_m']].round(0).to_string())
q=X[X.grp=='contact plains']; print(q.groupby('cls')[['rim_m','floor_m']].median().round(0))
