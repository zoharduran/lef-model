# Zohar 13.10: are the maria poor in iron against their surroundings, and against the plains?
# (a) each mare's dome core FeO vs the annulus around it (per_mascon_measurements, Kaguya MI, band 660)
# (b) LROC basalt units: on a mare footprint vs plains, area-weighted, by zone
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
P=pd.read_csv('../צט_פקקים_קבורים_2026-10-09/per_mascon_measurements.csv'); P=P[P.band==660].reset_index(drop=True)
d=np.arccos(np.clip(O.xyz(M.lat,M.lonE)@O.xyz(P.lat,P.lonE).T,-1,1))*O.R; j=d.argmin(1)
M['FeO_core']=P.FeO_core_mean.values[j]; M['FeO_ann']=P.FeO_annulus_mean.values[j]; M['ann_mare']=P.annulus_mare_fraction.values[j]
M['TiO2_core']=P.TiO2_core_mean.values[j]; M['TiO2_ann']=P.TiO2_annulus_mean.values[j]
M.loc[M.dome!='yes',['FeO_core','FeO_ann']]=np.nan
M['dFeO']=M.FeO_core-M.FeO_ann
t=M[['n','name','cover','zone','FeO_core','FeO_ann','ann_mare','dFeO','TiO2_core','TiO2_ann']].round(2)
print(t.to_string(index=False))
for cv in ['under mare','partial','buried']:
    q=t[t.cover==cv]; print(cv,len(q),'median core %.2f annulus %.2f diff %.2f, core<annulus in %d'%(q.FeO_core.median(),q.FeO_ann.median(),q.dFeO.median(),(q.dFeO<0).sum()))
t.to_csv('s2b_maria_core_annulus.csv',index=False)
U=pd.read_csv('../תוריום_ימה_מול_יבשה_2026-10-12/units_opening_vs_plain.csv')
fr,ix=footprint_dist(U.lat.values,U.lonE.values)
U['grp']=np.where(fr<1,'mare','plain'); dc=np.arccos(np.clip(O.xyz(U.lat,U.lonE)@O.xyz(24.1,335.2)[0],-1,1))*O.R; U['cz']=np.where(dc<1500,'contact','beyond')
def wmed(x,w):
    o=np.argsort(x.values); c=np.cumsum(w.values[o]); return x.values[o][np.searchsorted(c,c[-1]/2)]
rows=[]
for z in ['contact','beyond','all']:
    for g in ['mare','plain']:
        q=U[(U.grp==g)&((U.cz==z)|(z=='all'))].dropna(subset=['FeO_wt'])
        rows.append(dict(zone=z,group=g,units=len(q),area_km2=round(q.area_polygon_km2.sum()),FeO=round(wmed(q.FeO_wt,q.area_polygon_km2),2),TiO2=round(wmed(q.TiO2_wt,q.area_polygon_km2),2)))
r=pd.DataFrame(rows); print(r.to_string(index=False)); r.to_csv('s2b_units_mare_vs_plain.csv',index=False)
print(U[U.grp=='mare'].groupby(ix[U.grp=='mare']).apply(lambda q: pd.Series(dict(name=M.name.values[q.name],FeO=round(wmed(q.FeO_wt,q.area_polygon_km2),2) if q.FeO_wt.notna().any() else np.nan,area=round(q.area_polygon_km2.sum())))).to_string())
