import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.family']='DejaVu Sans Mono'
R=pd.read_csv('s9_rings6.csv'); x=np.arange(6); lab=['0–25','25–50','50–100','100–150','150–300','300–600']
S=[('maria (six)','six maria, pooled','#1f3a68','-','o'),('plain: Procellarum','plain: Procellarum','#888','--','s'),('plains: Tranquillitatis + Fecunditatis','plains: Tranquillitatis + Fecunditatis','#bbb',':','^')]
fig,axs=plt.subplots(1,2,figsize=(12,4.2))
for ax,v,ctrl,yl in [(axs[0],'FeO',2.30,'FeO of the ground, wt%'),(axs[1],'TiO2',0.46,'TiO$_2$ of the ground, wt%')]:
    for g,l,c,ls,mk in S:
        q=R[R.group==g]; ax.plot(x[:len(q)],q[v].values,ls=ls,marker=mk,color=c,lw=2,ms=7,label=l)
    ax.axhline(ctrl,color='#c0392b',lw=1,ls='-'); ax.text(5,ctrl*1.02,'controls',color='#c0392b',ha='right',va='bottom',fontsize=8)
    ax.set_xticks(x); ax.set_xticklabels(lab,fontsize=8); ax.set_xlabel('distance from the edge of the basalt, km'); ax.set_ylabel(yl)
    ax.spines[['top','right']].set_visible(False); ax.grid(axis='y',color='#eee')
axs[0].legend(fontsize=8,frameon=False)
fig.tight_layout(); fig.savefig('/home/claude/LEF_המוח/מאמר_07_הימות/א_מאמר/fig/p5_rings_maria_plains.png',dpi=180)
