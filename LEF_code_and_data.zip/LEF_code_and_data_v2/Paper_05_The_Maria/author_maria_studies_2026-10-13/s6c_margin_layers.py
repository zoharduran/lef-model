# Zohar 13.10: the margins of non-contact maria (and Serenitatis) are layers of craters that came out of the mare.
# Test: crater density on non-basalt land in the near ring (R..R+300 km) against the far ring (R+300..R+600), ray fields removed.
import numpy as np, pandas as pd
src=open('s7_s12_floors_noray.py').read().split("bins=[(1,2)")[0].replace("(c.D>=1)&(c.D<10)","(c.D>=2)&(c.D<1000)")
exec(src)
rows=[]
for _,m in M[M.cover!='cooked'].iterrows():
    cen=O.xyz(m.clat,m.clon)[0]; dg=np.arccos(np.clip(G@cen,-1,1))*O.R; dc=np.arccos(np.clip(Cx@cen,-1,1))*O.R
    r=dict(n=m.n,name=m['name'],zone=m.zone,cover=m.cover)
    for lab,a,b in [('near',0,300),('far',300,600)]:
        g=(dg>=m.radius_km+a)&(dg<m.radius_km+b)&~gb; cc=(dc>=m.radius_km+a)&(dc<m.radius_km+b)&~cb&(c.D.values>0)
        A=gw[g].sum()
        for s1,s2 in [(2,5),(5,20),(20,1000)]:
            k=cc&(c.D.values>=s1)&(c.D.values<s2); r[f'{lab}_{s1}_{s2}']=round(k.sum()/A*1e6,1) if A>20000 else np.nan
    rows.append(r)
t=pd.DataFrame(rows)
for s in ['2_5','5_20','20_1000']: t['ratio_'+s]=(t['near_'+s]/t['far_'+s]).round(2)
t.to_csv('s6c_margin_layers.csv',index=False); pd.set_option('display.width',250); print(t.to_string(index=False))
for z,q in [('contact',t[t.zone=='contact']),('non-contact open',t[(t.zone!='contact')&(t.cover!='buried')]),('buried',t[t.cover=='buried'])]:
    print(z,len(q),{s:q['ratio_'+s].median() for s in ['2_5','5_20','20_1000']},'near>far (5-20):',(q.ratio_5_20>1).sum(),'/',q.ratio_5_20.notna().sum())
