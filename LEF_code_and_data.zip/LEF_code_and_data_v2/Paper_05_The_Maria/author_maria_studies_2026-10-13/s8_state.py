# ימות-8 on Zohar's maria: state of craters (>=3 km, near-side basalt floors) on mare floors (inside the dome core of one of
# his maria) against plains (basalt outside every footprint). Classes as in G.2 (set on highland craters).
import numpy as np, pandas as pd
from scipy.stats import fisher_exact, spearmanr
exec(open('maria_def.py').read())
c=pd.read_csv('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/גודל_ומצב_על_הימות_2026-10-11/near_mare_floor_craters_ge3.csv')
c['cls']=c.cls.replace({'buried':'melted','partly':'smeared'})
fr,ix=footprint_dist(c.lat.values,c.lon.values%360)
c['where']=np.where(fr<1,'mare','plain'); c['mare_n']=np.where(fr<1,M.name.values[ix],'')
c['zone']=np.where(fr<1,M.zone.values[ix],'')
c['sz']=pd.cut(c.D,[3,10,40,1000],right=False,labels=['3-10','10-40','40+'])
def tab(s):
    t=pd.crosstab(s.sz,s.cls); t=t.reindex(columns=['intact','smeared','melted'],fill_value=0); t['n']=t.sum(1)
    for k in ['intact','smeared','melted']: t[k+'%']=(t[k]/t.n*100).round(0)
    return t
out=[]
for lab,s in [('mare',c[c['where']=='mare']),('plain',c[c['where']=='plain']),('mare contact',c[(c['where']=='mare')&(c.zone=='contact')]),('mare beyond-contact',c[(c['where']=='mare')&(c.zone!='contact')])]:
    t=tab(s); print('==',lab); print(t.to_string()); t.insert(0,'group',lab); out.append(t.reset_index())
pd.concat(out).to_csv('s8_table.csv',index=False)
print(c[c['where']=='mare'].groupby('mare_n').size())
for sz in ['40+','10-40','3-10']:
    a=c[(c.sz==sz)&(c['where']=='mare')]; b=c[(c.sz==sz)&(c['where']=='plain')]
    print(sz,'melted mare %d/%d plain %d/%d'%((a.cls=='melted').sum(),len(a),(b.cls=='melted').sum(),len(b)),
          'p=%.3g'%fisher_exact([[(a.cls=='melted').sum(),len(a)-(a.cls=='melted').sum()],[(b.cls=='melted').sum(),len(b)-(b.cls=='melted').sum()]])[1],
          '| sharp mare %d plain %d'%((a.cls=='intact').sum(),(b.cls=='intact').sum()))
m=c[c['where']=='mare']
for g in ['mare','plain']:
    s=c[c['where']==g]; print(g,'rho size vs dD/hl', spearmanr(s.D,s.dD).correlation)
# trend melted share with size bins (G.2 bins)
c['bin6']=pd.cut(c.D,[3,5,10,20,40,80,1000],right=False)
print(pd.crosstab([c['where'],c.bin6],c.cls,normalize='index').round(2))
print(pd.crosstab([c['where'],c.bin6],c.cls).sum(1))
c.to_csv('s8_craters.csv',index=False)
