# ימות-7 / ימות-12 on Zohar's maria: small craters on the floor (basalt inside the dome core) of each open mare,
# against the land around it (non-basalt, R..R+300 km), by zone; plains given for reference.
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3]); c.columns=['lon','lat','D']; c['D']/=1000
c=c[(c.D>=1)&(c.D<10)].reset_index(drop=True)
cst,cnm=O.classify(c.lon,c.lat); cb=cst!=''
la,lo=np.meshgrid(np.arange(-89.9,90,0.2),np.arange(-179.9,180,0.2),indexing='ij'); la=la.ravel(); lo=lo.ravel()
gst,gnm=O.classify(lo,la); gb=gst!=''; gw=np.cos(np.radians(la))*(0.2*np.pi/180*O.R)**2
G=O.xyz(la,lo); Cx=O.xyz(c.lat,c.lon)
bins=[(1,2),(2,5),(5,10)]
rows=[]
op=M[M.cover=='under mare']
for _,m in op.iterrows():
    cen=O.xyz(m.clat,m.clon)[0]; dg=np.arccos(np.clip(G@cen,-1,1))*O.R; dc=np.arccos(np.clip(Cx@cen,-1,1))*O.R
    fl=(dg<m.radius_km)&gb; ld=(dg>=m.radius_km)&(dg<m.radius_km+300)&~gb
    cf=(dc<m.radius_km)&cb; cl=(dc>=m.radius_km)&(dc<m.radius_km+300)&~cb
    r=dict(n=m.n,name=m['name'],zone=m.zone,floor_km2=round(gw[fl].sum()))
    for a,b in bins:
        k=(c.D>=a)&(c.D<b)
        r[f'floor_{a}_{b}']=round((cf&k).sum()/gw[fl].sum()*1e6) if gw[fl].sum()>0 else np.nan
        r[f'land_{a}_{b}']=round((cl&k).sum()/gw[ld].sum()*1e6)
    r['floor_share_2_10']=round((r['floor_2_5']*1+0)/max(r['land_2_5'],1),2)
    rows.append(r)
t=pd.DataFrame(rows).sort_values(['zone','floor_2_5']); t.to_csv('s7_s12_table.csv',index=False); print(t.to_string(index=False))
for z in ['contact','hill','beyond']:
    q=t[t.zone==z]; print(z,len(q),{f'{a}-{b}':int(q[f'floor_{a}_{b}'].median()) for a,b in bins}, 'floor/land 2-5 median',q.floor_share_2_10.median())
