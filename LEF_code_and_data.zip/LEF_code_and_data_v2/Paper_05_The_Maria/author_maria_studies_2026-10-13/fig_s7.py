import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.family']='DejaVu Sans Mono'
t=pd.read_csv('s7_s12_table_noray.csv').dropna(subset=['floor_2_5'])
order={'contact':0,'hill':1,'beyond':2}; t['o']=t.zone.map(order); t=t.sort_values(['o','floor_2_5'])
col={'contact':'#1f3a68','hill':'#c08a1e','beyond':'#b03a2e'}
fig,ax=plt.subplots(figsize=(11,4.6)); x=np.arange(len(t)); w=0.38
ax.bar(x-w/2,t.land_2_5,w,color='#bdbdbd',label='land around the mare (0–300 km)')
ax.bar(x+w/2,t.floor_2_5,w,color=[col[z] for z in t.zone])
for i,(f,l) in enumerate(zip(t.floor_2_5,t.land_2_5)): ax.text(i+w/2,f*1.12,f'{int(f)}',ha='center',fontsize=7.5)
ax.set_yscale('log'); ax.set_ylim(100,30000); ax.set_xticks(x); ax.set_xticklabels(t.name,rotation=30,ha='right',fontsize=9)
ax.set_ylabel('craters 2–5 km per million km²'); ax.spines[['top','right']].set_visible(False); ax.grid(axis='y',color='#eee',lw=0.6); ax.set_axisbelow(True)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color='#bdbdbd',label='land around the mare (to 300 km)')]+[Patch(color=col[z],label=f'floor — {z}') for z in ['contact','hill','beyond']],fontsize=8,frameon=False,ncol=4,loc='upper left')
fig.tight_layout(); fig.savefig('/home/claude/LEF_המוח/מאמר_07_הימות/א_מאמר/fig/p5_floors_clean.png',dpi=180)
