# מכתשים-12 on Zohar's maria (14.10.2026): ejecta minus the basalt around, for craters on mare floors vs plains.
import numpy as np, pandas as pd
exec(open('maria_def.py').read())
R='/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_שפה_וכימיה_2026-10-11/zip/maria_oct11/results/'
ch=pd.read_csv(R+'per_crater_chemistry.csv')
fr,ix=footprint_dist(ch.lat.values,ch.lon.values%360); ch['where']=np.where(fr<1,'mare','plain')
ch['sz']=pd.cut(ch.D,[3,5,10,20,1000],right=False)
t=ch.groupby(['where','sz'],observed=True).agg(n=('id','size'),dFeO=('FeO_delta_ejecta','median')).round(2); print(t)
print(ch.groupby('where').agg(n=('id','size'),dFeO=('FeO_delta_ejecta','median'),neg=('FeO_delta_ejecta',lambda x:(x<0).mean())).round(2))
t.to_csv('c12_table.csv')
