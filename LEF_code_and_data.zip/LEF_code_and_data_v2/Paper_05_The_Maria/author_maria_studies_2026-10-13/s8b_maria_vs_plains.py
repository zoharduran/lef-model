# ימות-8 finding 1, like for like: crater density on near-side mare floors vs plains, within the contact and beyond it.
import numpy as np, pandas as pd
src=open('s7_s12_floors_noray.py').read().split("bins=[(1,2)")[0].replace("(c.D>=1)&(c.D<10)","(c.D>=1)&(c.D<1000)")
exec(src)
bins=[(2,5),(5,10),(10,20),(20,40),(40,1000)]
fr_c,_=footprint_dist(c.lat.values,c.lon.values%360); fr_g,_=footprint_dist(la,lo%360)
C0=O.xyz(24.1,335.2)[0]
zg=np.arccos(np.clip(G@C0,-1,1))*O.R<1500; zc=np.arccos(np.clip(Cx@C0,-1,1))*O.R<1500
ng=np.abs(lo)<=90; nc=np.abs(c.lon.values)<=90; rows=[]
for zl,zG,zC in [('contact',zg,zc),('beyond contact',~zg,~zc)]:
    for lab,mg,mc in [('maria',gb&(fr_g<1),cb&(fr_c<1)),('plains',gb&(fr_g>=1),cb&(fr_c>=1))]:
        mg=mg&ng&zG; mc=mc&nc&zC; A=gw[mg].sum(); r=dict(zone=zl,group=lab,area_km2=round(A))
        for a,b in bins: k=mc&(c.D>=a)&(c.D<b); r[f'n_{a}_{b}']=k.sum(); r[f'd_{a}_{b}']=round(k.sum()/A*1e6,1)
        rows.append(r)
t=pd.DataFrame(rows); t.to_csv('s8b_maria_vs_plains.csv',index=False); pd.set_option('display.width',250); print(t.to_string(index=False))
# size of the large melted craters on the contact plains
s=pd.read_csv('s8_craters.csv'); dc=np.arccos(np.clip(O.xyz(s.lat,s.lon%360)@C0,-1,1))*O.R
q=s[(s['where']=='plain')&(dc<1500)&(s.D>=40)]
print(q.groupby('cls').D.describe().round(0))
print(pd.crosstab(pd.cut(q.D,[40,60,80,120,400]),q.cls))
