import struct, numpy as np, pandas as pd
from matplotlib.path import Path
shp=open('LROC_GLOBAL_MARE_180.SHP','rb').read(); dbf=open('LROC_GLOBAL_MARE_180.DBF','rb').read()
n=struct.unpack('<I',dbf[4:8])[0]; hl,rl=struct.unpack('<HH',dbf[8:12])
fields=[];i=32
while dbf[i]!=0x0D:
    fields.append((dbf[i:i+11].split(b'\0')[0].decode(),dbf[i+16])); i+=32
recs=[]
for k in range(n):
    r=dbf[hl+k*rl+1:hl+(k+1)*rl]; o=0; row={}
    for nm,ln in fields: row[nm]=r[o:o+ln].decode('latin1').strip(); o+=ln
    recs.append(row)
polys=[];pos=100
while pos<len(shp):
    clen=struct.unpack('>i',shp[pos+4:pos+8])[0]*2; c=shp[pos+8:pos+8+clen]; pos+=8+clen
    st=struct.unpack('<i',c[:4])[0]
    if st==0: polys.append([]); continue
    nparts,npts=struct.unpack('<2i',c[36:44]); parts=list(struct.unpack(f'<{nparts}i',c[44:44+4*nparts]))
    pts=np.frombuffer(c[44+4*nparts:44+4*nparts+16*npts],dtype='<f8').reshape(-1,2)
    parts.append(npts); polys.append([Path(pts[parts[j]:parts[j+1]]) for j in range(nparts)])
cr=pd.read_csv('/home/claude/LEF_המוח/06_נתונים_משותפים/Robbins_Dge20_selected.csv')
lon=((cr.LON_CIRC_IMG+180)%360)-180; P=np.c_[lon,cr.LAT_CIRC_IMG]
inside=np.zeros(len(cr),dtype=int)-1
for idx,parts in enumerate(polys):
    if not parts: continue
    par=np.zeros(len(cr),bool)
    for pth in parts: par^=pth.contains_points(P)
    inside[par]=idx
cr['unit']=inside; cr['name']=[recs[u]['MARE_NAME'] if u>=0 else '' for u in inside]
area=pd.DataFrame(recs); area['Area_km']=area.Area_km.astype(float)
A=area.groupby('MARE_NAME').Area_km.sum()
print('craters>=20 inside any mare',(inside>=0).sum(),'of',len(cr),'| flag in file',cr.inside_mare.sum())
near=['Oceanus Procellarum','Mare Imbrium','Mare Serenitatis','Mare Tranquillitatis','Mare Fecunditatis','Mare Nubium','Mare Frigoris','Mare Crisium','Mare Nectaris','Mare Humorum','Mare Insularum','Mare Cognitum','Mare Vaporum','Mare Spumans','Mare Undarum','Mare Marginis','Mare Smythii','Mare Australe','Mare Orientale','Mare Moscoviense','Mare Ingenii']
rows=[]
for nm in near:
    m=cr[cr.name==nm]; a=A.get(nm,np.nan)
    rows.append((nm,round(a/1e3),len(m),(m.DIAM_CIRC_IMG<40).sum(),(m.DIAM_CIRC_IMG>=40).sum(),round(len(m)/a*1e6,1) if a==a else None, ', '.join(f'{d:.0f}' for d in sorted(m.DIAM_CIRC_IMG,reverse=True)[:6])))
t=pd.DataFrame(rows,columns=['mare','area_kkm2','N>=20','20-40','>=40','per_Mkm2','largest_km']); print(t.to_string())
# highlands reference: total moon area 37.9e6
tot=4*np.pi*1737.4**2; marea=area.Area_km.sum()
print('highland density >=20 (all outside maria):',round(((inside<0).sum())/(tot-marea)*1e6,1),'| mare overall',round((inside>=0).sum()/marea*1e6,1))
t.to_csv('near_maria_floor_craters.csv',index=False)
cr[cr.unit>=0][['CRATER_ID','LAT_CIRC_IMG','LON_CIRC_IMG','DIAM_CIRC_IMG','name']].to_csv('craters_on_mare_floors.csv',index=False)
