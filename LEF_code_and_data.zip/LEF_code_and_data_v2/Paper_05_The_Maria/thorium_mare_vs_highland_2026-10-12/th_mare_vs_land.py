# Zohar (12.10): in the large maria there is little thorium; the land around kept (trapped) it, the maria let it escape.
# Test: for each named mare (LROC polygons merged by name), thorium on the mare floor against the land just outside it
# (0-150 km from the mare edge, all mare removed), area-weighted medians, by zone (contact / beyond).
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
F='/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/צט_שפה_וכימיה_2026-10-11/zip/maria_oct11/prior/th/mascons/data/thoriumhd.txt'
d=np.loadtxt(F,comments='#',delimiter=',')
lat=(d[:,0]+d[:,1])/2; lon=(d[:,2]+d[:,3])/2; th=d[:,4]
w=np.cos(np.radians(lat))
exec(open('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/גודל_ומצב_על_הימות_2026-10-11/size_state.py').read().split("c=pd.read_csv")[0])
idx=inside_index(lon,lat); mname=np.where(idx>=0,names[np.clip(idx,0,None)],'')
R=1737.4
def xyz(la,lo):
    la,lo=np.radians(la),np.radians(lo); return np.c_[np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)]
P=xyz(lat,lon)
def wmed(x,ww):
    o=np.argsort(x); c=np.cumsum(ww[o]); return x[o][np.searchsorted(c,c[-1]/2)]
C=xyz(24.1,-24.8)[0]
rows=[]
landmask=mname==''
for nm in sorted(set(mname)-{''}):
    m=mname==nm
    area=(w[m]).sum()*(0.5*np.pi/180*R)**2
    if area<20000: continue
    # vertices of this mare's polygons for distance
    V=np.vstack([np.vstack(polys[i]) for i in np.where(names==nm)[0]])
    tree=cKDTree(xyz(V[:,1],V[:,0]))
    cand=landmask & (P@xyz(lat[m].mean(),0)[0]>-2)  # all land
    dd,_=tree.query(P[landmask]); dist=np.full(len(lat),np.inf); dist[landmask]=2*np.arcsin(np.clip(dd/2,0,1))*R
    ring=landmask&(dist<150)
    if ring.sum()<5: continue
    cen=P[m].mean(0); cen/=np.linalg.norm(cen)
    dc=np.degrees(np.arccos(np.clip(cen@C,-1,1)))*np.pi/180*R
    rows.append(dict(mare=nm,area_km2=round(area),th_mare=round(wmed(th[m],w[m]),2),th_land_0_150=round(wmed(th[ring],w[ring]),2),
                     dist_contact_km=round(dc),zone='contact' if dc<1500 else ('hill' if dc<3000 else 'beyond'),
                     near=bool(abs(((np.degrees(np.arctan2(cen[1],cen[0])))+180)%360-180)<=90)))
t=pd.DataFrame(rows); t['mare_minus_land']=(t.th_mare-t.th_land_0_150).round(2)
t=t.sort_values('area_km2',ascending=False)
t.to_csv('th_mare_vs_land.csv',index=False)
print(t.to_string(index=False))
from scipy.stats import wilcoxon
for z in ['contact','hill','beyond']:
    s=t[t.zone==z]
    if len(s)>=3: print(z,len(s),'median mare-land',s.mare_minus_land.median(),'mare<land in',(s.mare_minus_land<0).sum(),'of',len(s),'p=%.3g'%wilcoxon(s.mare_minus_land).pvalue)
big=t[t.area_km2>=100000]
print('large (>=100,000 km2):',len(big),'median',big.mare_minus_land.median(),'mare<land',(big.mare_minus_land<0).sum())
