# Central figure of Paper 7: three definitions of a mare on one map.
import struct, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
plt.rcParams['font.family']='DejaVu Sans Mono'
SH='/tmp/claude-0/-home-claude/823d745d-d585-5e62-ab3b-cc648f681ccc/scratchpad/lroc/'
shp=open(SH+'LROC_GLOBAL_MARE_180.SHP','rb').read(); polys=[];pos=100
while pos<len(shp):
    clen=struct.unpack('>i',shp[pos+4:pos+8])[0]*2; c=shp[pos+8:pos+8+clen]; pos+=8+clen
    nparts,npts=struct.unpack('<2i',c[36:44]); parts=list(struct.unpack(f'<{nparts}i',c[44:44+4*nparts]))
    pts=np.frombuffer(c[44+4*nparts:44+4*nparts+16*npts],dtype='<f8').reshape(-1,2); parts.append(npts)
    polys+= [pts[parts[j]:parts[j+1]] for j in range(nparts)]
d=pd.read_csv('צט_פקקים_קבורים_2026-10-09/per_mascon_measurements.csv'); d=d[d.band==660]
d['lon']=((d.lonE+180)%360)-180
op=[(26,18),(-6,26),(-16,33),(18,60),(57,83),(-3,86),(-31,113),(-21,129),(5,142),(26,148),(-58,163),(-32,169),(17,175),(-46,176),(51,178),(51,183),(26,192),(14,201),(-5,203),(-37,209),(59,214),(38,219),(2,232),(50,239),(34,265),(-19,265),(-48,266),(-5,292),(-68,293),(-16,294),(44,302),(-56,316),(-25,320),(38,341),(7,342),(11,352)]
Z=pd.read_csv('פתחים_של_זוהר_2026-10-13/zohar_maria_final.csv'); op=np.c_[Z.lat.values,((Z.lonE.values+180)%360)-180]
fig,ax=plt.subplots(figsize=(13,7.4))
for p in polys: ax.add_patch(Polygon(p,closed=True,fc='#555',ec='none',alpha=0.55))
col={'under mare':'#2b6cb0','partial':'#d69e2e','buried':'#c0392b'}
for k,g in d.groupby('class'):
    ax.scatter(g.lon,g.lat,s=(g.diameter_km/12)**2,facecolors='none',edgecolors=col[k],lw=1.8,)
ax.scatter(op[:,1],op[:,0],marker='x',s=46,c='k',lw=1.6)
for (a,b),n in zip(op,Z.n): ax.text(b+2.2,a+1.6,str(n),fontsize=7,color='k')
ax.plot([],[],color='#555',lw=8,alpha=0.55,label='mapped basalt, LROC (646 units)')
ax.set_xlim(-180,180); ax.set_ylim(-80,80); ax.axvline(0,color='#bbb',lw=0.6); ax.axvline(90,color='#ddd',ls='--',lw=0.6); ax.axvline(-90,color='#ddd',ls='--',lw=0.6)
ax.text(0,82,'near side 0°',ha='center',fontsize=9); ax.text(90,82,'90°E trailing',ha='center',fontsize=9); ax.text(-90,82,'90°W leading',ha='center',fontsize=9); ax.text(178,82,'far 180°',ha='right',fontsize=9)
ax.set_xlabel('longitude °E'); ax.set_ylabel('latitude °'); ax.set_aspect('equal')
from matplotlib.lines import Line2D
h=[Line2D([],[],ls='none',marker='o',mfc='none',mec=col[k],mew=1.8,ms=11,label=f'feed dome in gravity — {k} ({(d["class"]==k).sum()})') for k in ['buried','partial','under mare']]
h+=[Line2D([],[],ls='none',marker='x',color='k',ms=8,mew=1.4,label='mare identified by the author on the GRAIL gradients (34)'),Line2D([],[],color='#555',lw=8,alpha=0.55,label='mapped basalt, LROC (646 units)')]
ax.legend(handles=h,loc='upper center',bbox_to_anchor=(0.5,-0.1),ncol=3,fontsize=8,frameon=False)
fig.tight_layout(); fig.savefig('../א_מאמר/fig/p5_maria34_counts.png',dpi=180)
print(d['class'].value_counts().to_dict(), (d.hemisphere+'_'+d['class']).value_counts().to_dict())
