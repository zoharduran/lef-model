Supplemental handoff — Paper 9 / Maria — 2026-09-26

- Four_Crater_Tests_Tables.md: Markdown reproduction/provenance document for the earlier four crater tests; contains exact selections, mask geometry, area-grid method, sources, and references to the original reproduction scripts.
- Four_Crater_Tests_Tables.html: HTML rendering of the same four-crater-tests reproduction/provenance document.
- Robbins_Crater_Ellipticity_20_40km.xlsx: Spreadsheet of Robbins crater ellipticity/orientation statistics by regions/caps; provenance for the ellipticity work. This is not the Wang & Wu d/D test.
- Paper_7_HE_Literal.pdf: Literal Hebrew rendering of Paper 7; includes crater-test discussion, sources, and code/data-availability statement.
- Paper_7_HE_Literal.tex: LaTeX source of the literal Hebrew Paper 7.
- AUDIT_Paper9_Maria_2026-09-26.md: Audit requested after Claude reviewed the 85-file bundle: code status, d/D status, conversation-search limitation, Part A status, and newly found provenance files.
- README_SUPPLEMENTAL_HANDOFF_2026-09-26.txt: This index: one line per file and its provenance/purpose.