# Zohar's test: one last active mare scattered small craters onto the sealed maria; floor density of small craters
# should rise toward it, while the scatterer itself is nearly clean.
import struct, numpy as np, pandas as pd
from matplotlib.path import Path
from scipy.stats import spearmanr
R=1737.4; SH='/tmp/claude-0/-home-claude/823d745d-d585-5e62-ab3b-cc648f681ccc/scratchpad/lroc/'
shp=open(SH+'LROC_GLOBAL_MARE_180.SHP','rb').read(); dbf=open(SH+'LROC_GLOBAL_MARE_180.DBF','rb').read()
n=struct.unpack('<I',dbf[4:8])[0]; hl,rl=struct.unpack('<HH',dbf[8:12])
fields=[];i=32
while dbf[i]!=0x0D: fields.append((dbf[i:i+11].split(b'\0')[0].decode(),dbf[i+16])); i+=32
recs=[]
for k in range(n):
    r=dbf[hl+k*rl+1:hl+(k+1)*rl]; o=0; row={}
    for nm,ln in fields: row[nm]=r[o:o+ln].decode('latin1').strip(); o+=ln
    recs.append(row)
polys=[];pos=100
while pos<len(shp):
    clen=struct.unpack('>i',shp[pos+4:pos+8])[0]*2; c=shp[pos+8:pos+8+clen]; pos+=8+clen
    nparts,npts=struct.unpack('<2i',c[36:44]); parts=list(struct.unpack(f'<{nparts}i',c[44:44+4*nparts]))
    pts=np.frombuffer(c[44+4*nparts:44+4*nparts+16*npts],dtype='<f8').reshape(-1,2); parts.append(npts)
    polys.append([pts[parts[j]:parts[j+1]] for j in range(nparts)])
names=np.array([r['MARE_NAME'] for r in recs]); areas=np.array([float(r['Area_km']) for r in recs])
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3]); c.columns=['lon','lat','D']; c['D']/=1000
c=c[(c.D>=1)&(c.D<10)].reset_index(drop=True)
lon=c.lon.values; lat=c.lat.values; P=np.c_[lon,lat]; ci=np.full(len(c),-1)
for idx,parts in enumerate(polys):
    allp=np.vstack(parts); x0,y0=allp.min(0); x1,y1=allp.max(0)
    m=(lon>=x0)&(lon<=x1)&(lat>=y0)&(lat<=y1)
    if not m.any(): continue
    par=np.zeros(m.sum(),bool)
    for p in parts: par^=Path(p).contains_points(P[m])
    ci[np.where(m)[0][par]]=idx
c['unit']=ci; c['name']=np.where(ci>=0,names[np.clip(ci,0,None)],'')
def xyz(lo,la):
    lo,la=np.radians(lo),np.radians(la); return np.c_[np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)]
rows=[]
for nm in np.unique(names):
    fa=areas[names==nm].sum()
    if fa<5000: continue
    m=c[c.name==nm]
    allp=np.vstack([np.vstack(polys[k]) for k in np.where(names==nm)[0]]); v=xyz(allp[:,0],allp[:,1]).mean(0); v/=np.linalg.norm(v)
    rows.append(dict(mare=nm,area=round(fa),x=v[0],y=v[1],z=v[2],lat=round(np.degrees(np.arcsin(v[2])),1),lonE=round(np.degrees(np.arctan2(v[1],v[0])),1),
        n_1_2=((m.D>=1)&(m.D<2)).sum(),n_2_5=((m.D>=2)&(m.D<5)).sum(),n_5_10=((m.D>=5)&(m.D<10)).sum()))
t=pd.DataFrame(rows)
for b in ['n_1_2','n_2_5','n_5_10']: t['d'+b[1:]]=t[b]/t.area*1e6
t.to_csv('mare_floor_small_craters.csv',index=False)
V=t[['x','y','z']].values
for col in ['d_1_2','d_2_5']:
    res=[]
    for i,r in t.iterrows():
        o=np.arange(len(t))!=i
        dist=R*np.arccos(np.clip(V[o]@V[i],-1,1))
        rho,p=spearmanr(dist,t[col].values[o]); res.append((r.mare,round(rho,2),p,round(r[col]),round(t[col].median())))
    s=pd.DataFrame(res,columns=['candidate','rho_density_vs_distance','p','own_density','median_all']).sort_values('rho_density_vs_distance')
    print('\n==',col); print(s.head(10).to_string(index=False))
print(t.sort_values('d_1_2')[['mare','area','lat','lonE','d_1_2','d_2_5','d_5_10']].to_string(index=False))
