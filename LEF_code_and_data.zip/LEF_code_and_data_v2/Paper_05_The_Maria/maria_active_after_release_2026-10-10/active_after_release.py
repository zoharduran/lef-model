# Which maria stayed active after release? Small craters (2-10 km, Wang&Wu 2021) on each mare floor
# and in a ring just outside its edge (0-50 km) against the ground farther out (100-300 km); mare removed both sides.
import struct, numpy as np, pandas as pd
from matplotlib.path import Path
from scipy.spatial import cKDTree
R=1737.4; SH='/tmp/claude-0/-home-claude/823d745d-d585-5e62-ab3b-cc648f681ccc/scratchpad/lroc/'
shp=open(SH+'LROC_GLOBAL_MARE_180.SHP','rb').read(); dbf=open(SH+'LROC_GLOBAL_MARE_180.DBF','rb').read()
n=struct.unpack('<I',dbf[4:8])[0]; hl,rl=struct.unpack('<HH',dbf[8:12])
fields=[];i=32
while dbf[i]!=0x0D: fields.append((dbf[i:i+11].split(b'\0')[0].decode(),dbf[i+16])); i+=32
recs=[]
for k in range(n):
    r=dbf[hl+k*rl+1:hl+(k+1)*rl]; o=0; row={}
    for nm,ln in fields: row[nm]=r[o:o+ln].decode('latin1').strip(); o+=ln
    recs.append(row)
polys=[];pos=100
while pos<len(shp):
    clen=struct.unpack('>i',shp[pos+4:pos+8])[0]*2; c=shp[pos+8:pos+8+clen]; pos+=8+clen
    nparts,npts=struct.unpack('<2i',c[36:44]); parts=list(struct.unpack(f'<{nparts}i',c[44:44+4*nparts]))
    pts=np.frombuffer(c[44+4*nparts:44+4*nparts+16*npts],dtype='<f8').reshape(-1,2); parts.append(npts)
    polys.append([pts[parts[j]:parts[j+1]] for j in range(nparts)])
names=np.array([r['MARE_NAME'] for r in recs]); areas=np.array([float(r['Area_km']) for r in recs])
def xyz(lon,lat):
    lo,la=np.radians(lon),np.radians(lat); return np.c_[np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)]
def inside_index(lon,lat):
    P=np.c_[lon,lat]; out=np.full(len(lon),-1)
    for idx,parts in enumerate(polys):
        allp=np.vstack(parts); x0,y0=allp.min(0); x1,y1=allp.max(0)
        m=(lon>=x0)&(lon<=x1)&(lat>=y0)&(lat<=y1)
        if not m.any(): continue
        par=np.zeros(m.sum(),bool)
        for p in parts: par^=Path(p).contains_points(P[m])
        out[np.where(m)[0][par]]=idx
    return out
# boundary vertices, densified to <=2 km
V=[];L=[]
for idx,parts in enumerate(polys):
    for p in parts:
        a=p[:-1];b=p[1:]
        for (x0,y0),(x1,y1) in zip(a,b):
            d=np.hypot((x1-x0)*np.cos(np.radians((y0+y1)/2)),y1-y0)*np.radians(1)*R
            k=max(1,int(d/2)); t=np.linspace(0,1,k,endpoint=False)
            V.append(np.c_[x0+(x1-x0)*t,y0+(y1-y0)*t]); L.append(np.full(k,idx))
V=np.vstack(V);L=np.concatenate(L); tree=cKDTree(xyz(V[:,0],V[:,1]))
def edge(lon,lat):
    d,j=tree.query(xyz(lon,lat)); return 2*R*np.arcsin(np.clip(d/2,0,1)), names[L[j]]
# craters
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3]); c.columns=['lon','lat','D']; c['D']/=1000
c=c[(c.D>=2)&(c.D<10)].reset_index(drop=True)
ci=inside_index(c.lon.values,c.lat.values)
cd,cn=edge(c.lon.values,c.lat.values)
# area sampling
rng=np.random.default_rng(1); N=4_000_000
u=rng.uniform(-1,1,N); lon=rng.uniform(-180,180,N); lat=np.degrees(np.arcsin(u))
si=inside_index(lon,lat); sd,sn=edge(lon,lat); cell=4*np.pi*R**2/N
rows=[]
for nm in np.unique(names):
    fa=areas[names==nm].sum()
    if fa<5000: continue
    nf=((ci>=0)&(names[np.clip(ci,0,None)]==nm)).sum()
    out_c=(ci<0)&(cn==nm); out_s=(si<0)&(sn==nm)
    rim_n=(out_c&(cd<50)).sum(); rim_a=(out_s&(sd<50)).sum()*cell
    bg_n=(out_c&(cd>=100)&(cd<300)).sum(); bg_a=(out_s&(sd>=100)&(sd<300)).sum()*cell
    # centroid
    allp=np.vstack([np.vstack(polys[k]) for k in np.where(names==nm)[0]]); v=xyz(allp[:,0],allp[:,1]).mean(0)
    clat=np.degrees(np.arcsin(v[2]/np.linalg.norm(v))); clon=np.degrees(np.arctan2(v[1],v[0]))
    ang=np.degrees(np.arccos(np.cos(np.radians(clat))*np.cos(np.radians(clon))))
    zone='near' if ang<60 else ('limb' if ang<100 else 'far')
    rows.append(dict(mare=nm,area_km2=round(fa),lat=round(clat,1),lonE=round(clon,1),from_subEarth=round(ang),zone=zone,
        floor_N=nf,floor_per_Mkm2=round(nf/fa*1e6),rim_N=rim_n,rim_per_Mkm2=round(rim_n/rim_a*1e6) if rim_a>0 else np.nan,
        bg_N=bg_n,bg_per_Mkm2=round(bg_n/bg_a*1e6) if bg_a>0 else np.nan,
        rim_over_bg=round((rim_n/rim_a)/(bg_n/bg_a),2) if rim_a>0 and bg_a>0 and bg_n>0 else np.nan))
t=pd.DataFrame(rows).sort_values('from_subEarth'); t.to_csv('maria_floor_and_ring_2to10km.csv',index=False)
pd.set_option('display.width',250); print(t.to_string(index=False))
