import pandas as pd, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.family']='DejaVu Sans Mono'
t=pd.read_csv('mare_floor_small_craters.csv')
fig,axs=plt.subplots(2,1,figsize=(12,10.5))
for ax,col,ttl in [(axs[0],'d_1_2','craters 1–2 km on the mare floor, per Mkm²'),(axs[1],'d_2_5','craters 2–5 km on the mare floor, per Mkm²')]:
    v=t[col]; vmin,vmax=np.percentile(v,5),np.percentile(v,95)
    sc=ax.scatter(t.lonE,t.lat,s=np.sqrt(t.area)*1.1,c=v,cmap='viridis_r',vmin=vmin,vmax=vmax,edgecolor='k',lw=0.4)
    for _,r in t.iterrows():
        if r.area>40000 or r[col]<np.percentile(v,15): ax.text(r.lonE,r.lat+3.5,r.mare.replace('Mare ','').replace('Oceanus ',''),fontsize=7.5,ha='center')
    ax.set_xlim(-180,180); ax.set_ylim(-70,70); ax.axvline(0,color='#bbb',lw=0.6); ax.axvline(90,color='#ddd',lw=0.6,ls='--'); ax.axvline(-90,color='#ddd',lw=0.6,ls='--')
    ax.set_xlabel('longitude °E'); ax.set_ylabel('latitude °'); ax.set_title(ttl,loc='left',fontsize=10,color='#2a3e5c')
    fig.colorbar(sc,ax=ax,label='per Mkm² (yellow = clean)',shrink=0.8)
fig.tight_layout(); fig.savefig('fig_floor_small_craters.png',dpi=170)
