"""LEF series — shared constants and helpers.
Python 3.10+, numpy, scipy. All SI unless noted.
"""
import numpy as np
from scipy.optimize import brentq

G   = 6.674e-11          # m^3 kg^-1 s^-2
ME  = 5.972e24           # Earth mass after the transfer, kg
m   = 7.35e22            # lunar mass, kg
Mt  = ME + m             # initial parent mass, kg
mu  = ME*m/Mt            # reduced mass
YR  = 3.15576e7          # Julian year, s
T0  = 5.5*3600           # initial day, s (adopted)
w0  = 2*np.pi/T0
RV0 = 6.517e6            # initial volumetric radius, m (6,397 km cold + 120 km expansion)

def maclaurin(e):
    """Maclaurin relation: omega^2/(pi G rho) as a function of eccentricity e."""
    return 2*np.sqrt(1-e**2)/e**3*(3-2*e**2)*np.arcsin(e) - 6*(1-e**2)/e**2

def figure(M, RV, w):
    """Equatorial radius a and eccentricity e of a homogeneous Maclaurin spheroid
    of mass M, volumetric radius RV, spin w (near-spherical branch)."""
    rho = M/(4/3*np.pi*RV**3)
    e = brentq(lambda e: maclaurin(e) - w**2/(np.pi*G*rho), 1e-4, 0.95)
    return a_of(RV, e), e

def a_of(RV, e): return RV/(1-e**2)**(1/6)

def rsync(M, w): return (G*M/w**2)**(1/3)
