import numpy as np
G=6.674e-11; M=5.97e24; m=7.35e22; GM=G*M; Gm=G*m
Re=6721e3
for label,P,xb,hw in [("centre at corotation (5.5 h)",5.5,15818e3,2100e3),("release (6.44 h)",6.44,20595e3,1500e3)]:
    w=2*np.pi/(P*3600); rc=(GM/w**2)**(1/3)
    print(f"\n== {label}: corotation {rc/1e3:,.0f} km, body centre {xb/1e3:,.0f}, bridge half-width {hw/1e3:,.0f} km")
    near = xb-2597e3 if 'release' in label else xb-2000e3
    for x in np.linspace(Re, near, 5):
        d=xb-x
        k_in = GM/x**3 + Gm/d**3 - w**2     # in-plane transverse curvature
        k_out= GM/x**3 + Gm/d**3            # out-of-plane
        well_in = 0.5*k_in*hw**2; well_out=0.5*k_out*hw**2
        # axial: effective potential difference from x up to the body's near edge (support needed below x)
        def phi(r): return -GM/r - 0.5*w**2*r**2
        print(f"x={x/1e3:7,.0f} km | curvature in-plane {k_in:+.2e}, out {k_out:+.2e} s^-2 | lateral well (in/out) {3000*well_in/1e9:5.2f}/{3000*well_out/1e9:5.2f} GPa")
    dphi=(-GM/near-0.5*w**2*near**2)-(-GM/Re-0.5*w**2*Re**2)
    print(f"axial: pressure at the surface opening to hold melt up to {near/1e3:,.0f} km: {3000*dphi/1e9:.0f} GPa at 3,000 kg/m3; {1300*dphi/1e9:.0f} GPa at 1,300")
