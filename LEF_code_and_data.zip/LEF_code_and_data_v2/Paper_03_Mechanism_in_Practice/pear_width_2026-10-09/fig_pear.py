import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Ellipse, Polygon
G=6.674e-11; ME=5.97e24; m=7.35e22; GM=G*ME; Gm=G*m
NAVY='#1f2a44'; CREAM='#fbf6e9'; RED='#a8322d'; EARTH='#cfd8e3'; PEAR='#e8d8b0'; SAND='#d9a441'
def profile(day,xm,xtip,xs,floor,lat,rho=3000,load=True):
    w=2*np.pi/(day*3600); c2=np.cos(np.deg2rad(lat))**2
    geff=lambda x: GM/x**2-w**2*x*c2-Gm/(xm-x)**2
    k=lambda x: GM/x**3+Gm/(xm-x)**3-w**2
    Pl=max(0,m*(GM/xm**2-w**2*xm*c2))/(np.pi*(floor/2)**2) if load else 0
    xx=np.linspace(xs,xtip,400); W=[]
    for x in xx:
        x2=np.linspace(x,xtip,300); n=rho*np.trapezoid(geff(x2),x2)+Pl
        a2=n/(np.pi*G*rho**2+rho*0.5*k(x)) if n>0 else 0
        W.append(max(2*np.sqrt(max(a2,0)),floor))
    return xx,np.array(W)
def pearpoly(xx,W,B,floor):
    Wp=floor+(W-floor)*(B-floor)/(W[0]-floor)
    n=41; pad=np.r_[np.full(n,Wp[0]),Wp,np.full(n,Wp[-1])]
    return np.convolve(pad,np.ones(n)/n,'same')[n:-n]
xs=6650e3; RE=6650
fig,axs=plt.subplots(2,1,figsize=(15,10.5))
def earth(ax):
    ax.add_patch(Circle((0,0),RE,facecolor=EARTH,edgecolor=NAVY,lw=1.2,zorder=6))
    ax.text(-2500,0,'EARTH',zorder=7,ha='center',va='center',fontsize=10,family='monospace',color=NAVY)
def draw_pear(ax,xx,W,floor,label_x):
    k=lambda B: pearpoly(xx,W,B,floor)
    W11=k(11000e3)/2e3; W9=k(9000e3)/2e3; X=xx/1e3
    X=np.r_[3500,X]; W11=np.r_[W11[0],W11]; W9=np.r_[W9[0],W9]
    ax.fill_between(X,-W11,W11,color=PEAR,alpha=0.55,zorder=2)
    ax.fill_between(X,-W9,W9,color=PEAR,alpha=0.9,zorder=2)
    for Wq in (W11,W9): ax.plot(X,Wq,color=NAVY,lw=0.9,zorder=3); ax.plot(X,-Wq,color=NAVY,lw=0.9,zorder=3)
    Wm=W/2e3; ax.plot(xx/1e3,Wm,color=RED,ls='--',lw=1.2,zorder=4); ax.plot(xx/1e3,-Wm,color=RED,ls='--',lw=1.2,zorder=4)
    ax.annotate('base 9,000–11,000 km',xy=(6900,W11[1]-300),xytext=(1500,7400),fontsize=10,family='monospace',color=NAVY,arrowprops=dict(arrowstyle='->',color=NAVY))
    ax.annotate('minimum self-holding\nwidth (dashed)',xy=(xx[30]/1e3,-Wm[30]),xytext=(9500,-7300),fontsize=9.5,family='monospace',color=RED,arrowprops=dict(arrowstyle='->',color=RED))
def frame(ax,title):
    ax.set_aspect('equal'); ax.set_xlim(-7200,20500); ax.set_ylim(-9300,8300); ax.axis('off')
    ax.set_title(title,loc='left',fontsize=13,family='monospace',color=NAVY,fontweight='bold')
    for d in range(0,20001,5000):
        ax.plot([d,d],[-8100,-7900],color=NAVY,lw=0.8); ax.text(d,-8250,f'{d:,}',ha='center',va='top',fontsize=8,family='monospace',color=NAVY)
    ax.text(-7000,-8900,'km from the Earth\'s centre, along the 22.5° line →',ha='left',va='top',fontsize=8,family='monospace',color=NAVY)
# --- A: start of rounding
ax=axs[0]; earth(ax)
xm=13000e3; a=3300; c=(4/3*np.pi*2381**3)/(4/3*np.pi*a**2); xtip=xm-c*1e3
xx,W=profile(5.5,xm,xtip,xs,6000e3,22.5); draw_pear(ax,xx,W,6000e3,0)
ax.add_patch(Ellipse((xm/1e3,0),2*c,2*a,facecolor=CREAM,edgecolor=NAVY,lw=1.4,zorder=5))
ax.plot([xtip/1e3]*2,[-3000,3000],color=RED,lw=4,zorder=6)
ax.text(xtip/1e3+2000,3700,'tip of the pear\n= contact 6,000 km',ha='left',fontsize=10,family='monospace',color=RED)
ax.text(xm/1e3,0,'body\n1,300 kg/m³\nsquashed',ha='center',va='center',fontsize=9,family='monospace',color=NAVY,zorder=7)
w=2*np.pi/(5.5*3600); rc=(GM/(w**2*np.cos(np.deg2rad(22.5))**2))**(1/3)/1e3
ax.axvline(rc,color=NAVY,ls=':',lw=1.2); ax.text(rc+150,7300,f'corotation line\n{rc:,.0f} km (5.5 h)',fontsize=9,family='monospace',color=NAVY)
ax.text(12800,-6200,'short, wide pear:\nreaches 6,000 km\n~2,000 km above the surface',fontsize=9,family='monospace',color=NAVY)
frame(ax,'A  Start of rounding — body centre ~13,000 km, pear ~4,000 km long')
# --- B: release
ax=axs[1]; earth(ax)
xm=17287e3; R=1890; xtip=xm-np.sqrt(R**2-1500**2)*1e3
xx,W=profile(5.77,xm,xtip,xs,3000e3,22.5); draw_pear(ax,xx,W,3000e3,0)
ax.add_patch(Circle((xm/1e3,0),R,facecolor=CREAM,edgecolor=NAVY,lw=1.4,zorder=5))
ax.plot([xtip/1e3]*2,[-1500,1500],color=RED,lw=4,zorder=6)
ax.text(xtip/1e3-300,-3300,'tip of the pear\n= contact 3,000 km',ha='right',fontsize=10,family='monospace',color=RED)
ax.text(xm/1e3,0,'Moon\n2,600 kg/m³',ha='center',va='center',fontsize=9,family='monospace',color=NAVY,zorder=7)
ax.axvline(17287,color=NAVY,ls=':',lw=1.2); ax.text(17287+150,7300,'corotation line\n17,287 km (5.77 h):\nthe Moon\'s centre on it',fontsize=9,family='monospace',color=NAVY)
ax.text(10200,5300,'long pear, one arc, no waist;\nwholly inside the line;\nfalls back whole',fontsize=9,family='monospace',color=NAVY)
frame(ax,'B  Release — Moon centre on the line, pear ~8,700 km long')
plt.tight_layout(rect=(0,0.045,1,1))
fig.text(0.01,0.004,'To scale. Pear of material 3,000 kg/m³; light band: bases 9,000–11,000 km \n(lower bound: self-holding, about 7,800–8,800 km; upper: lift energy ~1e31 J, the scale of core formation). The tip narrows from 6,000 to 3,000 km while the base widens.',fontsize=8.5,family='monospace',color=NAVY)
plt.savefig('/tmp/claude-0/pear/pear_two_stages.png',dpi=150)
