import numpy as np
G=6.674e-11; ME=5.97e24; m=7.35e22; GM=G*ME; Gm=G*m
exec(open('/tmp/claude-0/pear/fig_pear.py').read().split("xs=6650e3; RE=6650")[0].split("import matplotlib.pyplot")[0].replace("matplotlib.use('Agg')",""))
exec("def profile"+open('/tmp/claude-0/pear/fig_pear.py').read().split("def profile")[1].split("def pearpoly")[0])
def pearpoly(xx,W,B,floor): return floor+(W-floor)*(B-floor)/(W[0]-floor)
xs=6650e3
def case(label,day,xm,xtip,floor,B,rho=3000,rho_m=5000):
    xx,W=profile(day,xm,xtip,xs,floor,22.5,rho); Wp=pearpoly(xx,W,B,floor); a=Wp/2
    dM=rho*np.pi*a**2; Mp=np.trapezoid(dM,xx); Dp=np.trapezoid(dM*xx,xx)/Mp
    # field at Earth's centre from coaxial discs
    g_p=np.trapezoid(2*np.pi*G*rho*(1-xx/np.sqrt(xx**2+a**2)),xx)
    g_m=Gm/xm**2
    w=2*np.pi/(day*3600); c2=np.cos(np.deg2rad(22.5))**2
    s=(Mp*Dp+m*xm)/(ME)              # barycentre offset from Earth's centre (mass taken from Earth)
    g_c=w**2*s*c2
    g=g_p+g_m-g_c; k=4/3*np.pi*G*rho_m; d=g/k
    print(f'{label}: pear {Mp/m:.1f} lunar masses, centroid {Dp/1e3:,.0f} km | field at centre: pear {g_p:.3f}, Moon {g_m:.3f}, centrifugal -{g_c:.3f} -> net {g:.3f} m/s2 | barycentre {s/1e3:,.0f} km | core shift toward pear {d/1e3:,.0f} km')
    return Mp
for B in (9000e3,11000e3):
    case(f'start of rounding, base {B/1e3:,.0f}',5.5,13000e3,13000e3-1239e3,6000e3,B)
    case(f'release,           base {B/1e3:,.0f}',5.77,17287e3,17287e3-1150e3,3000e3,B)
# after fall-back: pear mass spread as a layer over the attached hemisphere (uncompensated)
R=6371e3
for Mp in (8.8*m,12.1*m):
    g=G*Mp/(2*R**2); print(f'after fall-back, uncompensated hemispheric layer {Mp/m:.1f} m: field {g:.3f} m/s2 -> shift {g/(4/3*np.pi*G*5000)/1e3:,.0f} km toward the attached half')
print('after isostatic compensation the far field of the layer is small: shift -> ~0 (core returns toward the centre, i.e. back toward the antipode)')
