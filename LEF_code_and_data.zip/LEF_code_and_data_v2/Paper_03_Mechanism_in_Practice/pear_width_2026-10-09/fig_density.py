import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
NAVY='#1f2a44'; RED='#a8322d'; PEAR='#e8d8b0'
m=7.35e22; a=3000.; Rt=4000.          # contact radius, radius of curvature of the pear tip (km)
sag=Rt-np.sqrt(Rt**2-a**2)
cap=lambda h: np.pi*h*(3*a**2+h**2)/6
Vlow=cap(sag)
def h_for_rho(rho):
    V=m/rho/1e9+Vlow; hs=np.linspace(500,6000,20000); return hs[np.argmin(abs(cap(hs)-V))]
def rho_for_h(h): return m/((cap(h)-Vlow)*1e9)
cases=[('A  Old drawing (to be replaced)',None,3000,'flat base;\nhemisphere r = 3,000 km'),
       ('B  Tall upper dome',h_for_rho(1300),None,'keeps 1,300:\nthe Poles paper unchanged'),
       ('C  Upper dome as high as a hemisphere',3000,None,'about 2,000'),
       ('D  Low upper dome',h_for_rho(3344),None,'3,344 = the Moon today:\nthe lowest possible')]
fig,axs=plt.subplots(1,4,figsize=(20,6.4))
for ax,(title,h,hA,note) in zip(axs,cases):
    t=np.linspace(-a,a,300)
    # pear tip (below), convex upward
    tipy=np.sqrt(Rt**2-t**2)-Rt+ (0 if hA is None else -sag)   # top of the pear tip; old drawing: flat at y=0
    if hA is not None:
        ax.add_patch(Polygon(np.r_[np.c_[[-4200,4200],[0,0]],[[4200,-2600],[-4200,-2600]]],facecolor=PEAR,edgecolor=NAVY,lw=1.2))
        upper=np.sqrt(np.maximum(hA**2-t**2,0)); base=np.zeros_like(t)
        rho=m/(2/3*np.pi*(hA*1e3)**3)
    else:
        xs=np.linspace(-3600,3600,300); ys=np.sqrt(np.maximum(Rt**2-xs**2,0))-Rt
        ax.add_patch(Polygon(np.r_[np.c_[xs,ys],[[3600,-3300],[-3600,-3300]]],facecolor=PEAR,edgecolor=NAVY,lw=1.2))
        Rc=(a**2+h**2)/(2*h); upper=np.sqrt(Rc**2-t**2)-(Rc-h)-sag; base=tipy
        rho=rho_for_h(h)
    ax.fill_between(t,base,upper,color='#fbf6e9',edgecolor=NAVY,lw=1.4)
    ax.plot(t,base,color=RED,lw=3)
    top=upper.max()
    ax.annotate('',xy=(a+500,top),xytext=(a+500,base[-1] if hA is None else 0),arrowprops=dict(arrowstyle='<->',color=NAVY))
    H=top-(base.min() if hA is None else 0)
    ax.text(a+650,(top)/2,f'{H:,.0f} km',fontsize=10,family='monospace',color=NAVY,va='center')
    ax.text(0,top-1150,f'{rho:,.0f}\nkg/m³',ha='center',fontsize=15,fontweight='bold',family='monospace',color=RED if hA is None else NAVY)
    ax.text(0,-2600,'tip of the pear' if hA is None else 'old: flat base',ha='center',fontsize=9,family='monospace',color=NAVY)
    ax.set_title(title,loc='left',fontsize=12,family='monospace',color=NAVY,fontweight='bold')
    ax.text(-4300,-3550,'contact 6,000 km  ·  '+note,fontsize=9.5,family='monospace',color=NAVY,va='top')
    ax.set_aspect('equal'); ax.set_xlim(-4400,4800); ax.set_ylim(-4200,4600); ax.axis('off')
    if hA is not None:
        ax.text(2600,3900,'OLD',fontsize=14,color=RED,alpha=0.6,family='monospace',fontweight='bold')
fig.suptitle('The same mass, one lunar mass, sitting on a 6,000-km contact. The higher the upper dome, the larger the volume and the lower the density.',fontsize=11.5,family='monospace',color=NAVY,y=0.995)
fig.text(0.01,0.02,'Question: how high did the upper dome stand?  B (tall, 1,300) keeps the Poles paper as it is · C (~2,000) changes its starting point · D is the limit.  Pear-tip curvature assumed 4,000 km (sag 1,350 km under the contact).',fontsize=10,family='monospace',color=NAVY)
plt.tight_layout(rect=(0,0.06,1,0.96))
plt.savefig('/tmp/claude-0/pear/density_question.png',dpi=150)
for c in cases[1:]: print(c[0], c[1] or 3000, rho_for_h(c[1] or 3000))
print('sag',sag)
