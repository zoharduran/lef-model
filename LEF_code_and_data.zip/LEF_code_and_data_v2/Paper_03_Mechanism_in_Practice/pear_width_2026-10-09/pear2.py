import numpy as np
G=6.674e-11; ME=5.97e24; m=7.35e22; GM=G*ME; Gm=G*m
def run(day_h,xm,Rm,xs,floor,lat_deg,rho,label,moon_load=True,quiet=False):
    w=2*np.pi/(day_h*3600); c2=np.cos(np.deg2rad(lat_deg))**2
    xtip=xm-Rm
    geff=lambda x: GM/x**2 - w**2*x*c2 - Gm/(xm-x)**2
    k_t=lambda x: GM/x**3 + Gm/(xm-x)**3 - w**2
    gm_moon=GM/xm**2 - w**2*xm*c2           # Moon's own net weight per kg (toward Earth)
    Pload=max(0,m*gm_moon)/(np.pi*(floor/2)**2) if moon_load else 0
    def need(x):
        xx=np.linspace(x,xtip,400); return rho*np.trapezoid(geff(xx),xx)+Pload
    xx=np.linspace(xs,xtip,600); W=[]
    for x in xx:
        n=need(x)
        a2=n/(np.pi*G*rho**2+rho*0.5*k_t(x)) if n>0 else 0
        W.append(max(2*np.sqrt(max(a2,0)),floor))
    W=np.array(W); mass=np.trapezoid(rho*np.pi*(W/2)**2,xx)
    if not quiet:
        print(f'\n== {label} | rho {rho} | day {day_h} h | Moon centre {xm/1e3:,.0f} km | R_moon {Rm/1e3:,.0f} | contact {floor/1e3:,.0f} km | Moon load {Pload/1e9:.1f} GPa | corot(lat) {((GM/(w**2*c2))**(1/3))/1e3:,.0f} km')
        for f in (0,0.25,0.5,0.75,0.9):
            i=int(f*(len(xx)-1)); print(f'   {xx[i]/1e3:7,.0f} km ({(xx[i]-xs)/1e3:5,.0f} above surface): width {W[i]/1e3:6,.0f} km')
        j=np.argmax(W<=floor*1.0001); print(f'   reaches contact width at {xx[j]/1e3:,.0f} km; pear length {(xtip-xs)/1e3:,.0f} km; mass {mass/m:.1f} lunar masses ({mass/ME*100:.1f}% Earth)')
    return W[0]
# check: reproduce old table (6.5853 h, 20,595 km, equator, no load)
run(6.5853,20595e3,1890e3,6603e3,3000e3,0,3000,'OLD check',moon_load=False)
Rm=lambda rho_m:(3*m/(4*np.pi*rho_m))**(1/3)
for rho in (3000,4000):
    run(5.77,17287e3,Rm(2600),6650e3,3000e3,22.5,rho,'RELEASE, contact 3,000')
    run(5.5,13000e3,Rm(1300),6650e3,6000e3,22.5,rho,'START OF ROUNDING, contact 6,000')
print('\n== base width vs where the body sits (contact 6,000, 5.5 h, rho_body 1,300, 22.5 deg)')
for xm in (10000e3,11000e3,12000e3,13000e3,14000e3,15000e3):
    print(f'  Moon centre {xm/1e3:6,.0f} km: base {run(5.5,xm,Rm(1300),6650e3,6000e3,22.5,3000,"",quiet=True)/1e3:6,.0f} km (3,000)  {run(5.5,xm,Rm(1300),6650e3,6000e3,22.5,4000,"",quiet=True)/1e3:6,.0f} km (4,000)')

print('\n== mass and lift energy of a pear with a chosen base width (release config, 5.77 h, 22.5 deg)')
day=5.77; xm=17287e3; Rmn=Rm(2600); xs=6650e3; xtip=xm-Rmn; w=2*np.pi/(day*3600); c2=np.cos(np.deg2rad(22.5))**2
phi=lambda x: -GM/x - 0.5*w**2*x**2*c2 - Gm/(xm-x)
xx=np.linspace(xs,xtip,600)
for rho in (3000,4000):
    # minimum profile
    w0=[]
    for x in xx:
        xx2=np.linspace(x,xtip,400); n=rho*np.trapezoid(GM/xx2**2-w**2*xx2*c2-Gm/(xm-xx2)**2,xx2)
        k=GM/x**3+Gm/(xm-x)**3-w**2; a2=n/(np.pi*G*rho**2+rho*0.5*k) if n>0 else 0
        w0.append(max(2*np.sqrt(max(a2,0)),3000e3))
    w0=np.array(w0); B0=w0[0]
    for B in (B0,9000e3,10000e3,11000e3):
        Wp=3000e3+(w0-3000e3)*(B-3000e3)/(B0-3000e3)
        A=np.pi*(Wp/2)**2; M=np.trapezoid(rho*A,xx); E=np.trapezoid(rho*A*(phi(xx)-phi(xs)),xx)
        print(f'  rho {rho}: base {B/1e3:6,.0f} km -> mass {M/m:5.1f} lunar masses ({M/ME*100:4.1f}% Earth), lift energy {E:.2e} J')
