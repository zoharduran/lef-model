import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Wedge, Circle
NAVY='#1f2a44'; RED='#a8322d'; SAND='#d9a441'; PEAR='#e8d8b0'; CREAM='#fbf6e9'; BLUE='#3b5b92'
a=3000.; Rt=4000.; h=3647.8; sag=Rt-np.sqrt(Rt**2-a**2); Rc=(a**2+h**2)/(2*h)
fig,axs=plt.subplots(1,3,figsize=(19,7.2),gridspec_kw={'width_ratios':[1.15,1,1]})
# body on tip
ax=axs[0]
xs=np.linspace(-3700,3700,300); ys=np.sqrt(Rt**2-xs**2)-Rt
ax.add_patch(Polygon(np.r_[np.c_[xs,ys],[[3700,-3400],[-3700,-3400]]],facecolor=PEAR,edgecolor=NAVY,lw=1))
t=np.linspace(-a,a,400); base=np.sqrt(Rt**2-t**2)-Rt; up=np.sqrt(Rc**2-t**2)-(Rc-h)-sag
ax.fill_between(t,base,up,color=CREAM)
ax.plot(t,up,color=BLUE,lw=5)
m=np.abs(t)<=1500; ax.plot(t[t<-1500],base[t<-1500],color=SAND,lw=5); ax.plot(t[t>1500],base[t>1500],color=SAND,lw=5); ax.plot(t[m],base[m],color=RED,lw=5)
ax.text(0,1300,'body, 1,300 kg/m³',ha='center',fontsize=10,family='monospace',color=NAVY)
ax.text(0,4000,'upper dome  67% of the surface',ha='center',fontsize=10.5,family='monospace',color=BLUE,fontweight='bold')
ax.text(-3300,-1700,'lower dome\n(peeled annulus)\n26%',fontsize=10,family='monospace',color='#9a6a10',ha='center')
ax.text(0,-900,'contact 3,000 km: 7%',ha='center',fontsize=10,family='monospace',color=RED,fontweight='bold')
ax.text(0,-2900,'tip of the pear',ha='center',fontsize=9,family='monospace',color=NAVY)
ax.set_title('The body on the tip of the pear (option B)',loc='left',fontsize=12,family='monospace',color=NAVY,fontweight='bold')
ax.set_aspect('equal'); ax.set_xlim(-4600,4600); ax.set_ylim(-3600,4900); ax.axis('off')
def moon(ax,cap,rim,title,lines,col):
    R=1
    ax.add_patch(Wedge((0,0),R,-rim,rim,width=0.12,facecolor=SAND))
    ax.add_patch(Wedge((0,0),R,rim,360-rim,width=0.12,facecolor=BLUE))
    ax.add_patch(Wedge((0,0),R,-cap,cap,width=0.12,facecolor=RED))
    ax.add_patch(Circle((0,0),0.88,facecolor=CREAM,edgecolor='none'))
    for ang in (cap,rim):
        for s in (1,-1):
            th=np.deg2rad(s*ang); ax.plot([0,np.cos(th)],[0,np.sin(th)],color=NAVY,lw=0.6,ls='--')
    ax.plot([0,0],[-1,1],color=NAVY,lw=0.8,ls=':')
    ax.text(1.12,0,'→ Earth',va='center',fontsize=9,family='monospace',color=NAVY)
    ax.text(0.35,0.08,f'cap {cap:.0f}°',fontsize=9,family='monospace',color=RED)
    ax.text(-0.15,0.62 if rim>80 else 0.5,f'rim {rim:.0f}°',fontsize=9,family='monospace',color='#9a6a10')
    ax.text(-0.75,-0.05,'far side',fontsize=9,family='monospace',color=BLUE)
    ax.set_title(title,loc='left',fontsize=12,family='monospace',color=NAVY,fontweight='bold')
    ax.text(-1.25,-1.25,lines,fontsize=9.5,family='monospace',color=col,va='top')
    ax.set_aspect('equal'); ax.set_xlim(-1.3,1.6); ax.set_ylim(-2.0,1.25); ax.axis('off')
moon(axs[1],30.8,69.7,'1  Each part keeps its share',
     'all parts shrink alike (×0.60 in length)\nupper dome → far side + outer limb belt\nrim of the base at 70°, not at the limb\ncontact → near-side cap of 31°\nno difference far/near: matches the 5 tests',NAVY)
moon(axs[2],38.3,90,'2  Rim = limb (halves)',
     'upper dome → far side only: ×0.52 in length\nlower dome → near side: ×0.75 in length\nfar-side craters 0.70 of near-side twins\n→ rejected by the tests (far 16.5–17 km\n   vs near 14–15 km transition)',RED)
fig.text(0.01,0.02,'Areas: upper dome 7.0×10¹³ m², lower dome 3.4×10¹³ (contact 0.73×10¹³), Moon today 3.79×10¹³. Pear-tip curvature 4,000 km. Question: which rule carries the surface of the body onto the Moon?',fontsize=9.5,family='monospace',color=NAVY)
plt.tight_layout(rect=(0,0.05,1,0.95))
plt.savefig('/tmp/claude-0/pear/mapping_question.png',dpi=150)
