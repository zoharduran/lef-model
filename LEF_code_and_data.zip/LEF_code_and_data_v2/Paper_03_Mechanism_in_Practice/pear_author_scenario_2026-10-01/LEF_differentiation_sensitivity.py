# NEW SUPPLEMENT: run python LEF_differentiation_sensitivity.py
# The inherited reference-model documentation is below. Actual output is the
# differentiation/drainage sensitivity supplement at the end of this file.
# No age-to-density mapping is claimed. See supplementary assumptions below.
#!/usr/bin/env python3
"""LEF angular-momentum audit -- conditional mass-distribution calculation.

Run: python lef_angular_momentum.py
Requires: Python 3, NumPy, SciPy. All internal quantities are SI.

THIS IS NOT A HYDRODYNAMIC SOLUTION OR A PROVEN LEF MINIMUM.
It does not certify support, stability, detachment, or long-term tidal survival.
In fact, the default conditional minimum fails the immediate outward-motion
test when the prescribed extended pear gravity is retained (about -0.40 m/s^2).

Assumptions:
1. M_E=5.97e24 kg is final Earth including fallback; m=7.35e22 kg.
2. Initial total mass M_T=M_E+m. L_EM=3.5e34 kg m^2/s.
3. Initial volume-equivalent radius R_V=6,721 km (an additional assumption,
   NOT an identification of the user's fixed equatorial radius with a measured
   volume radius). Incompressible initial/core/fallback Earth density is
   M_T/(4*pi*R_V^3/3). No thermal expansion on fallback.
4. Central body's inertia follows the lower-eccentricity Maclaurin branch.
   The pear's and Moon's tidal distortion of the central body is omitted.
   Its mass is M_E-M_pear, not M_E or M_T.
5. Prescribed pear radii interpolate linearly through (s,b), in km:
   (6721,4500),(10000,3100),(12000,1950),(13000,1500),(r-A,1500).
   These are a mass-moment surrogate, not a solved free surface. The fixed
   root, matching to the changing central spheroid, and the root pressure are
   NOT resolved. Cross sections are circular, normal to the radial pear axis.
6. Pear density is independently assigned. This requires thermodynamic
   justification not present here. The upper density option changes only
   s>13000 km. 'fixed mass' renormalizes density, not width.
7. Moon is a homogeneous prolate ellipsoid of density 2600 kg/m^3, radial
   semiaxis A (default 2600 km), other axes B=sqrt(3*m/(4*pi*rho_m*A)).
   Its shape is prescribed, not a tidal equilibrium solution.
8. Release uses the USER'S monopole rule omega^2=G*M_E/[(r-A)^3*cos(lat)^2].
   It is NOT recomputed from full gravity. Pear axial gravity is calculated
   separately to expose this limitation. Latitude is geocentric.
9. All components corotate at release. Exact mass moments, lunar intrinsic
   inertia, system-barycentre correction, and angular-momentum vector are
   included for the prescribed distribution. Nonzero latitude is an
   instantaneous budget, not a torque-free steady rotating configuration.
10. Fallback is represented by internal contraction of the Earth+pear about
    its own centre of mass, with no lunar torque/impulse. Its spin angular
    momentum is conserved. This approximation omits real fallback dynamics.
11. A post-collapse two-body monopole orbit is inferred from instantaneous
    relative position and velocity: no radial release velocity. The Moon's
    distance from the remnant COM is D=r-Q/M_E, not r. Orbital parameter uses
    G*(M_E+m). Only D>=20100 km and 1<beta<2 are screened in optimization;
    these ensure initial outward radial acceleration and a bound Kepler
    orbit with perigee D. NO claim about net secular tidal recession or
    perigee during actual fallback/later tidal evolution is made.
12. Initial and fallback days solve I_Mac(M,omega)*omega=|L_spin|.
    Initial spin is a consequence, not an independent optimization variable.
13. Search r in [20100,200000] km, with all parameters held fixed unless
    explicitly varied. Grid bracketing plus scalar refinement; not a global
    optimization over possible self-gravitating fluid shapes.
14. Gravity diagnostic integrates over both the finite prolate Moon and
    the pear volume. The central body is a monopole for this force diagnostic;
    its oblateness and deformation by the pear are not included. Numerical
    refinement (24/12/48 to 36/18/72 Moon-axial/radial/azimuthal quadrature)
    changes the quoted separation acceleration by less than 2e-7 m/s^2; this
    is convergence, not a bound on the physical model error.
15. Lagging-flow savings hold geometry and omega fixed and change only the
    specified mass's velocity. They are bookkeeping, not a flow solution.

Verified references (DOIs, not code dependencies):
Canup 2012, Science 338, 1052-1055: 10.1126/science.1226073.
Cuk & Stewart 2012, Science 338, 1047-1052: 10.1126/science.1225542.
Rufu & Canup 2020, JGR Planets 125, e2019JE006312: 10.1029/2019JE006312.
Ward, Canup & Rufu 2020, JGR Planets 125, e2019JE006266:
10.1029/2019JE006266.
Lock & Stewart 2017, JGR Planets 122, 950-982: 10.1002/2016JE005239.
Roberts & Stewartson 1963, ApJ 137, 777-790: 10.1086/147555.
"""
import json
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq, minimize_scalar

G = 6.67430e-11
ME, MM = 5.97e24, 7.35e22
MT = ME + MM
LEM = 3.5e34
DEFAULT_RV = 6_721_000.0
RHO_MOON = 2600.0
SECULAR_E = 0.812670
E_MAX = 0.92995
Z, W = np.polynomial.legendre.leggauss(32)


def mac_function(e):
    if e < 1e-3:
        return 8*e**2/15 + 8*e**4/105
    return (2*np.sqrt(1-e*e)*(3-2*e*e)*np.arcsin(e)/e**3
            - 6*(1-e*e)/e**2)


def earth_density(rv):
    return MT/(4*np.pi*rv**3/3)


def maclaurin(mass, omega, rv):
    rho = earth_density(rv)
    e = brentq(lambda e: np.pi*G*rho*mac_function(e)-omega**2,
               0, E_MAX, xtol=1e-13)
    a = (3*mass/(4*np.pi*rho))**(1/3)/(1-e*e)**(1/6)
    c = a*np.sqrt(1-e*e)
    tensor = np.diag([mass*(a*a+c*c)/5]*2 + [2*mass*a*a/5])
    return tensor, e, a, c


def spin_from_L(mass, angular_momentum, rv):
    rho = earth_density(rv)
    def state(e):
        omega = np.sqrt(np.pi*G*rho*mac_function(e))
        a = (3*mass/(4*np.pi*rho))**(1/3)/(1-e*e)**(1/6)
        return 0.4*mass*a*a*omega, omega
    e = brentq(lambda e: state(e)[0]-angular_momentum,
               0, E_MAX, xtol=1e-13)
    return 2*np.pi/state(e)[1]/3600, e


def pear_nodes(r, A=2.6e6, density=3000., upper_factor=1.,
               fixed_mass=None, none=False, rv=DEFAULT_RV):
    ends = np.array([rv, 1e7, 1.2e7, 1.3e7, r-A])
    widths = np.array([4.5e6, 3.1e6, 1.95e6, 1.5e6, 1.5e6])
    if not np.all(np.diff(ends)>0):
        raise ValueError('Pear endpoint must be beyond 13000 km')
    s, b, ds, rho = [], [], [], []
    for k in range(4):
        lo, hi = ends[k:k+2]
        sk = (lo+hi)/2+(hi-lo)*Z/2
        bk = widths[k]+(widths[k+1]-widths[k])*(sk-lo)/(hi-lo)
        s.extend(sk); b.extend(bk); ds.extend((hi-lo)*W/2)
        rho.extend(np.full_like(sk, density*(upper_factor if k==3 else 1)))
    s,b,ds,rho = map(np.array,(s,b,ds,rho))
    if none:
        rho *= 0
    dm = np.pi*b*b*rho*ds
    if fixed_mass is not None and not none:
        rho *= fixed_mass/dm.sum()
        dm = np.pi*b*b*rho*ds
    return s,b,ds,rho,dm,ends,widths


def audit(r, A=2.6e6, lat=0., density=3000., upper_factor=1.,
          fixed_mass=None, none=False, rv=DEFAULT_RV, internals=False):
    s,b,ds,rho,dm,ends,widths = pear_nodes(
        r,A,density,upper_factor,fixed_mass,none,rv)
    mp = dm.sum()
    if ME-mp <= 0:
        raise ValueError('Pear contains more than final Earth mass')
    Q = np.dot(dm,s)
    phi = np.deg2rad(lat)
    n = np.array([np.cos(phi),0.,np.sin(phi)])
    nn = np.outer(n,n)
    ident = np.eye(3)
    omega = np.sqrt(G*ME/(r-A)**3)/np.cos(phi)
    omega_vec = np.array([0.,0.,omega])
    earth_I, earth_e, ae, ce = maclaurin(ME-mp,omega,rv)
    jp = np.dot(dm,s*s+b*b/4)  # moment about axis normal to pear
    ja = np.dot(dm,b*b/2)      # moment about pear axis
    pear_I = jp*ident+(ja-jp)*nn
    B = np.sqrt(3*MM/(4*np.pi*RHO_MOON*A))
    moon_perp = MM*(A*A+B*B)/5
    moon_parallel = 2*MM*B*B/5
    moon_I = moon_perp*ident+(moon_parallel-moon_perp)*nn
    d = (Q+MM*r)/MT
    total_I = (earth_I+pear_I+moon_I
               +(MM*r*r-MT*d*d)*(ident-nn))
    Lvec = total_I@omega_vec
    L = np.linalg.norm(Lvec)
    remnant_I = earth_I+pear_I-Q*Q/ME*(ident-nn)
    Srem = remnant_I@omega_vec
    D = r-Q/ME
    beta = omega**2*D**3*np.cos(phi)**2/(G*MT)
    ecc = abs(beta-1)
    aorb = D/(2-beta) if beta<2 else np.inf
    peri = aorb*(1-ecc) if beta<2 else np.nan
    mu = ME*MM/MT
    Lorb = mu*np.cross(D*n,np.cross(omega_vec,D*n))
    Lmoon = moon_I@omega_vec
    # Nontrivial bookkeeping check: total decomposes into both spins + orbit.
    assert np.allclose(Lvec,Srem+Lorb+Lmoon,rtol=2e-12,atol=1e18)
    pi, ei = spin_from_L(MT,L,rv)
    pf, ef = spin_from_L(ME,np.linalg.norm(Srem),rv)
    out = dict(r_km=r/1000,D_km=D/1000,L_LEM=L/LEM,
        pear_lunar=mp/MM,initial_day_h=pi,release_day_h=2*np.pi/omega/3600,
        fallback_day_h=pf,excess_LEM=L/LEM-1,
        ecc=ecc,beta=beta,a_orbit_km=aorb/1000,perigee_km=peri/1000,
        initial_figure_e=ei,release_figure_e=earth_e,
        fallback_figure_e=ef,initial_secular_stable=bool(ei<SECULAR_E),
        central_equatorial_radius_km=ae/1000,
        ballistic_screen=bool(D>=20.1e6-1 and 1<beta<2),
        Lz_LEM=Lvec[2]/LEM,lat_deg=lat,
        mean_pear_density=(mp/np.dot(np.pi*b*b,ds) if mp else 0.))
    if internals:
        out.update(s=s,b=b,ds=ds,rho=rho,dm=dm,ends=ends,widths=widths,
                   omega=omega,earth_I=earth_I,Q=Q,d=d,mp=mp,A=A,r=r,
                   B=B,Lvec=Lvec,n=n)
    return out


def optimize(**kwargs):
    # A reproducible bounded search in the specified surrogate family.
    grid = np.linspace(20.1e6,200e6,500)
    def objective(r):
        try:
            t = audit(r,**kwargs)
            return t['L_LEM'] if t['ballistic_screen'] else 1e6
        except ValueError:
            return 1e6
    values = np.array([objective(r) for r in grid])
    k = values.argmin()
    if values[k] >= 1e6:
        raise ValueError('No screened configuration on search grid')
    opt = minimize_scalar(objective,
        bounds=(grid[max(0,k-1)],grid[min(len(grid)-1,k+1)]),
        method='bounded',options={'xatol':.01})
    candidates = [audit(opt.x,**kwargs)]
    for r in (grid[0],grid[-1]):
        try:
            t=audit(r,**kwargs)
            if t['ballistic_screen']: candidates.append(t)
        except ValueError: pass
    return min(candidates,key=lambda t:t['L_LEM'])


def at_minimum_D(**kwargs):
    r=brentq(lambda r:audit(r,**kwargs)['D_km']-20100,20.1e6,30e6)
    return audit(r,**kwargs)


def axial_pear_gravity(x,state):
    """Exact on-axis disk-stack formula; quadrature error is numerical only.
    Returns signed acceleration (positive toward tip) and potential.
    Density constant on each of the four segments; split at x to integrate
    the acceleration's sign function without a quadrature discontinuity.
    """
    g=pot=0.
    ends=state['ends']; widths=state['widths']
    for k in range(4):
        lo,hi=ends[k:k+2]
        rho=state['rho'][k*len(Z)]
        def radius(t):
            return widths[k]+(widths[k+1]-widths[k])*(t-lo)/(hi-lo)
        def kern(t):
            dx=x-t
            return np.sign(dx)-dx/np.hypot(dx,radius(t))
        cuts=[lo]+([x] if lo<x<hi else [])+[hi]
        for l,h in zip(cuts[:-1],cuts[1:]):
            g -= 2*np.pi*G*rho*quad(kern,l,h,epsabs=1e-5)[0]
        pot -= 2*np.pi*G*rho*quad(
            lambda t:np.hypot(x-t,radius(t))-abs(x-t),lo,hi,
            points=([x] if lo<x<hi else None),epsabs=1.)[0]
    return g,pot


def lag_savings(state,upper_x=None,fractional_speed=.5):
    """Equatorial bookkeeping reduction in L/LEM, not a flow solution."""
    if state['lat_deg']!=0:
        raise ValueError('This savings estimate is equatorial only')
    mask=np.ones_like(state['s'],dtype=bool)
    if upper_x is not None: mask=state['s']<=upper_x
    Ic=np.dot(state['dm'][mask],
              (state['s'][mask]-state['d'])**2+state['b'][mask]**2/4)
    return (1-fractional_speed)*state['omega']*Ic/LEM


def finite_force(t, nq=24, nr=12, nphi=48):
    """Volume-averaged force: exact prescribed pear, monopole central body.
    Third output is initial radial separation acceleration with pear extended.
    NOT the post-collapse orbital screen. Returns signed m/s^2.
    """
    u,wu=np.polynomial.legendre.leggauss(nr);u=(u+1)/2;wu=wu/2
    ph=(np.arange(nphi)+.5)*2*np.pi/nphi
    # source pear: axial disks with radial quadrature and azimuthal sum
    sx=t['s'][:,None,None]
    sr=t['b'][:,None,None]*u[None,:,None]
    sm=t['dm'][:,None,None]*(2*u*wu)[None,:,None]/nphi
    xi,wi=np.polynomial.legendre.leggauss(nq)
    gp=ge=0.
    for xj,wj in zip(xi,wi):
        x=t['r']+t['A']*xj
        bj=t['B']*np.sqrt(1-xj*xj)
        for uj,wuj in zip(u,wu):
            y=bj*uj
            wt=.75*(1-xj*xj)*wj*2*uj*wuj
            ds=sx-x
            den=(ds*ds+sr*sr+y*y-2*sr*y*np.cos(ph)[None,None,:])**1.5
            gp+=wt*G*np.sum(sm*ds/den)
            ge-=wt*G*(ME-t['mp'])*x/(x*x+y*y)**1.5
    D=t['r']-t['Q']/ME
    acc=t['omega']**2*D+(1+MM/ME)*(gp+ge)
    return gp,ge,acc

def main():
    rows={
      'quoted widths, r=20100 km (fails remnant distance)':audit(20.1e6),
      'quoted widths, minimum permitted D':at_minimum_D(),
      'quoted widths, optimized r':optimize(),
      'same widths, density 2600, optimized r':optimize(density=2600),
      'same widths, density 2000, optimized r':optimize(density=2000),
      '11 lunar masses imposed, minimum D':at_minimum_D(fixed_mass=11*MM),
      '3.3 lunar masses imposed, minimum D':at_minimum_D(fixed_mass=3.3*MM),
      'no pear, minimum D (not LEF)':audit(20.1e6,none=True),
      'no pear, optimized r (not LEF)':optimize(none=True),
    }
    sens={
      'latitude':{str(p):optimize(lat=p) for p in (0,10,15,25)},
      'Moon semiaxis km':{str(a):optimize(A=a*1000) for a in (1900,2200,2600,3000)},
      'Earth volume radius km':{str(r):optimize(rv=r*1000) for r in (6371,6721,7000)},
      'upper neck density multiplier':{str(f):optimize(upper_factor=f) for f in (.5,1,2)},
    }
    t=rows['quoted widths, optimized r']
    state=audit(t['r_km']*1000,internals=True)
    gravity={}
    for x in (1e7,1.2e7,1.3e7,state['r']-state['A'],state['r']):
        gp,ph=axial_pear_gravity(x,state)
        ge=-G*(ME-state['mp'])/x**2
        gravity[str(x/1000)]={'pear_g_m_s2':gp,
            'central_monopole_g_m_s2':ge,'pear_potential_J_kg':ph}
    gp,ge,acc=finite_force(state)
    D=state['r']-state['Q']/ME
    w_force=np.sqrt(-(1+MM/ME)*(gp+ge)/D)
    I_force,_,_,_=maclaurin(ME-state['mp'],w_force,DEFAULT_RV)
    Iold=state['Lvec'][2]/state['omega']
    L_force=(Iold-state['earth_I'][2,2]+I_force[2,2])*w_force
    out={'force_balance_at_same_geometry_NOT_release_rule':{
              'day_h':2*np.pi/w_force/3600,'L_LEM':L_force/LEM},
         'warning':'Conditional budgets, NOT supported fluid equilibria.',
         'assumed_initial_density':earth_density(DEFAULT_RV),
         'rows':rows,'sensitivities':sens,'pear_axial_gravity':gravity,
         'finite_Moon_force_at_conditional_minimum':dict(zip(
             ['pear_g_m_s2','core_monopole_g_m_s2','initial_separation_acceleration_m_s2'],
             (gp,ge,acc))),
         'half_speed_savings_LEM':{'whole_pear':lag_savings(state),
             'below_13000_km':lag_savings(state,upper_x=1.3e7)}}
    print(json.dumps(out,indent=2))


# Supplement: prescribed two-layer inertia and upper-neck drainage.
# This is a sensitivity study, not a 600 Myr evolutionary integration.
# Reference radius, Moon shape, equatorial spin, and all caveats of the base
# code apply. The central envelope follows the BASE Maclaurin proxy: its
# hydrostatic figure is NOT recomputed for stratification. Homothetic layers
# give an exact inertia coefficient for the prescribed envelope, not an
# equilibrium proof. Central gravity remains a monopole, independent of k.
# Core radius ratio x=.55; f_core is fraction of CENTRAL BODY mass.
# Drainage scales cross-sectional areas for s>13000 km by h, at density 3000.
# All removed mass is returned to the central body. Lower pear is unchanged.
# This produces a discontinuity at 13000 km and is deliberately not a free
# surface solution. h=0 is a disconnected diagnostic endpoint.
# Fixed-omega rows are separate possible budgets, NOT a conserved-L history.
# Extra fixed-L rows solve omega for L=LEM and no longer impose base corotation.
# No source power, viscosity, timescale, or state at 600 Myr is inferred.


def layer_k(f_core, x=.55):
    return .4*(f_core*x*x+(1-f_core)*(1-x**5)/(1-x**3))


def diff_state(h=1., k=.4, omega=None):
    t=audit(29573511.67,internals=True)
    if omega is None: omega=t['omega']
    mask=t['s']>1.3e7
    t['b'][mask]*=np.sqrt(h)
    t['dm'][mask]*=h
    t['mp']=t['dm'].sum()
    t['Q']=np.dot(t['dm'],t['s'])
    t['d']=(t['Q']+MM*t['r'])/MT
    t['omega']=omega
    Ie,_,_,_=maclaurin(ME-t['mp'],omega,DEFAULT_RV)
    J=np.dot(t['dm'],t['s']**2+t['b']**2/4)
    Im=MM*(t['A']**2+t['B']**2)/5
    t['modified_L_LEM']=(k/.4*Ie[2,2]+J+Im+MM*t['r']**2-MT*t['d']**2)*omega/LEM
    return t


def summarize(t):
    gp,ge,acc=finite_force(t)
    return dict(pear_lunar=t['mp']/MM,
        L_LEM=t['modified_L_LEM'],day_h=2*np.pi/t['omega']/3600,
        lunar_distance_from_remnant_km=(t['r']-t['Q']/ME)/1000,
        pear_g_inward=-gp,earth_g_inward=-ge,separation_accel_outward=acc)


def differentiation_main():
    x=.55
    layers=[]
    for fc in (x**3,.25,.32,.4):
        k=layer_k(fc,x)
        layers.append(dict(core_mass_fraction=fc,core_radius_ratio=x,k=k,
                           **summarize(diff_state(k=k))))
    k=layer_k(.32)
    drainage=[]
    fixed_L=[]
    ref=diff_state()
    upper0=ref['dm'][ref['s']>1.3e7].sum()/MM
    for h in (1.,.75,.5,.25,0.):
        drainage.append(dict(neck_mass_fraction_remaining=h,
            neck_diameter_km=3000*np.sqrt(h),**summarize(diff_state(h,k))))
        w=brentq(lambda w:diff_state(h,k,w)['modified_L_LEM']-1,
                 ref['omega']*.25,ref['omega']*2)
        fixed_L.append(dict(neck_mass_fraction_remaining=h,**summarize(diff_state(h,k,w))))
    h_target=brentq(lambda h:diff_state(h,k)['modified_L_LEM']-1,0,1)
    target=dict(neck_mass_fraction_remaining=h_target,
                neck_diameter_km=3000*np.sqrt(h_target),**summarize(diff_state(h_target,k)))
    # Acceleration threshold at fixed release omega, not a fluid-stability limit.
    h_threshold=brentq(lambda h:finite_force(diff_state(h,k))[2],0,1,xtol=1e-6)
    threshold=dict(neck_mass_fraction_remaining=h_threshold,
                   neck_diameter_km=3000*np.sqrt(h_threshold),
                   **summarize(diff_state(h_threshold,k)))
    def fixed_L_state(h):
        w=brentq(lambda w:diff_state(h,k,w)['modified_L_LEM']-1,
                 ref['omega']*.25,ref['omega']*2,xtol=1e-15)
        return diff_state(h,k,w)
    h_conserved=brentq(lambda h:finite_force(fixed_L_state(h))[2],.25,.5,xtol=1e-6)
    conserved_threshold=dict(neck_mass_fraction_remaining=h_conserved,
        neck_diameter_km=3000*np.sqrt(h_conserved),
        **summarize(fixed_L_state(h_conserved)))
    print(json.dumps(dict(warning='Not an evolutionary or hydrostatic solution',
        zero_acceleration_fixed_total_L=conserved_threshold,
        reference_upper_neck_lunar_masses=upper0,layer_cases=layers,
        fixed_release_omega=drainage,fixed_total_L=fixed_L,
        budget_one_LEM_at_fixed_release_omega=target,
        zero_initial_acceleration_at_fixed_release_omega=threshold),indent=2))

if __name__=='__main__':
    differentiation_main()
