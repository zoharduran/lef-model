import numpy as np
rho=3000; a=1.5e6; L=6.0e6; k=3.0; dT=1000.; kap=1e-6; cp=1000.
load=4.38e22   # connection load at release, Paper 3 C.6
for Md,lab in [(2.33e7,"100 Myr"),(3.88e6,"600 Myr")]:
    v=Md/(rho*np.pi*a*a)
    Pe=v*L/kap
    Q=Md*cp*dT
    area=2*np.pi*a*L
    skin=k*dT*area/Q
    for eta in (1e17,1e19):
        tau=4*eta*v/a; F=tau*2*np.pi*a*L
        print(f"{lab}: v={v*3.156e7*100:.1f} cm/yr, Peclet={Pe:,.0f}, heat carried {Q:.1e} W, frozen skin ~{skin/1e3:.0f} km | eta={eta:.0e}: wall drag {tau/1e6:.3f} MPa, pull {F:.1e} N = {F/load*100:.4f}% of the connection load")
