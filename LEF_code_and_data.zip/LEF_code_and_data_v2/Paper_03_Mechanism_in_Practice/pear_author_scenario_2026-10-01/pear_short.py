import numpy as np
G=6.674e-11; ME=5.97e24; m=7.35e22; GM=G*ME; Gm=G*m; xs=6603e3
def shape(xm,Ph,rho=3000):
    w=2*np.pi/(Ph*3600); xtip=xm-1890e3
    geff=lambda x: GM/x**2 - w**2*x - Gm/(xm-x)**2
    kt=lambda x: GM/x**3 + Gm/(xm-x)**3 - w**2
    xx=np.linspace(xs,xtip,600)
    def need(x):
        q=np.linspace(x,xtip,300); return rho*np.trapezoid(geff(q),q)
    W=[]
    for x in xx:
        n=need(x)
        W.append(3000e3 if n<=0 else max(2*np.sqrt(n/(np.pi*G*rho**2+rho*0.5*kt(x))),3000e3))
    W=np.array(W); mass=np.trapezoid(rho*np.pi*(W/2)**2,xx)
    tension=[x for x in xx if need(x)<=0]
    return W[0],mass,(tension[0] if tension else None),(GM/w**2)**(1/3),xtip
cases=[("x=1.00, release at the line (Paper 4: contracts, fails)",17239.7e3,6.2196),
       ("x=1.068, first release at perigee (recedes from start)",18704.3e3,6.3703),
       ("perigee at fluid Roche 19,971",19971e3,6.53),
       ("x=1.15, Paper 4 reference (passes both)",20595.5e3,6.5853)]
for name,xm,Ph in cases:
    w0,mass,t,rc,xtip=shape(xm,Ph)
    print(f"{name}\n   Moon centre {xm/1e3:,.0f} km (line {rc/1e3:,.0f}), pedestal base {w0/1e3:,.0f} km wide, length to Moon base {(xtip-xs)/1e3:,.0f} km, mass {mass/ME*100:.0f}% Earth = {mass/m:.0f} lunar masses, tension beyond {t/1e3 if t else 0:,.0f} km")
