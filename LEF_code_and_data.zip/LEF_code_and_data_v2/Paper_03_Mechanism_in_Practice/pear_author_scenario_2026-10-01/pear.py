import numpy as np
G=6.674e-11; ME=5.97e24; m=7.35e22; GM=G*ME; Gm=G*m
P=6.5853*3600; w=2*np.pi/P            # Earth's day at release (Paper 4)
xs=6603e3; xm=20595e3; xtip=xm-1890e3  # surface at 25N, Moon centre, base of the truncated Moon
def geff(x):   # inward-positive effective gravity along the axis
    return GM/x**2 - w**2*x - Gm/(xm-x)**2
def need(x,rho,n=400):
    xx=np.linspace(x,xtip,n); return rho*np.trapezoid(geff(xx),xx)
def k_t(x): return GM/x**3 + Gm/(xm-x)**3 - w**2
print(f"day {P/3600:.2f} h, corotation {(GM/w**2)**(1/3)/1e3:,.0f} km; lobe from {xs/1e3:,.0f} to {xtip/1e3:,.0f} km")
xs_list=np.linspace(xs,xtip-500e3,8)
for rho in (3000,4000):
  print(f"\n== density {rho} kg/m3")
  for W in (3000e3,6000e3,8000e3,10000e3,12000e3):
    a=W/2; worst=1e9; wx=None
    for x in xs_list:
        cap=np.pi*G*rho**2*a**2 + rho*0.5*k_t(x)*a**2
        r=cap/need(x,rho)
        if r<worst: worst,wx=r,x
    mass=rho*np.pi*a**2*(xtip-xs)
    print(f"width {W/1e3:6,.0f} km: weakest point at {wx/1e3:6,.0f} km holds {worst*100:4.0f}% | lobe mass {mass/ME*100:4.0f}% of Earth, {mass/m:4.0f} lunar masses | base pressure need {need(xs,rho)/1e9:4.0f} GPa")

print("\n=== only where the lobe is compressed (need > 0) ===")
xx=np.linspace(xs,xtip,600)
nd=[need(x,1.0) for x in xx]
sign=[x for x,n in zip(xx,nd) if n<=0]
print(f"beyond {sign[0]/1e3:,.0f} km the lobe is pulled outward (tension), not compressed")
for rho in (3000,4000):
  print(f"\n-- density {rho}")
  for W in (3000e3,6000e3,8000e3,10000e3,12000e3):
    a=W/2; worst=1e9; wx=None
    for x,n in zip(xx,nd):
        if n*rho<=1e9: continue
        cap=np.pi*G*rho**2*a**2 + rho*0.5*k_t(x)*a**2
        r=cap/(n*rho)
        if r<worst: worst,wx=r,x
    mass=rho*np.pi*a**2*(xtip-xs)
    print(f"width {W/1e3:6,.0f} km: weakest compressed point at {wx/1e3:6,.0f} km holds {worst*100:4.0f}% | lobe {mass/ME*100:3.0f}% of Earth")
