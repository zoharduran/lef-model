import numpy as np
exec(open('pear.py').read().split("print(f\"day")[0])
xx=np.linspace(xs,xtip,800)
for rho in (3000,4000):
    widths=[]; 
    for x in xx:
        n=need(x,rho)
        if n<=0: widths.append(3000e3); continue   # tension zone: only the contact width needed
        a2=n/(np.pi*G*rho**2 + rho*0.5*k_t(x)); widths.append(max(2*np.sqrt(a2),3000e3))
    widths=np.array(widths); mass=np.trapezoid(rho*np.pi*(widths/2)**2,xx)
    print(f"\n== density {rho}: minimum self-holding shape (width needed at each height)")
    for x in [6603e3,8000e3,10000e3,12000e3,13000e3,13917e3,16000e3,18705e3]:
        i=np.argmin(abs(xx-x)); print(f"   {x/1e3:7,.0f} km from centre ({(x-xs)/1e3:6,.0f} km above surface): width {widths[i]/1e3:6,.0f} km")
    print(f"   lobe mass {mass/ME*100:.0f}% of Earth = {mass/m:.0f} lunar masses")
