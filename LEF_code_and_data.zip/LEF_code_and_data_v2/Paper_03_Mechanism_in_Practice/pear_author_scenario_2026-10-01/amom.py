import numpy as np
G=6.674e-11; Mtot=5.97e24+7.35e22; m=7.35e22; GM=G*5.97e24
a_eq=6721e3; Ltot=3.466e34           # Paper 2: parent at 5.5 h
P0=5.5*3600; w0=2*np.pi/P0
print(f"check: 0.4 M a^2 w0 = {0.4*Mtot*a_eq**2*w0:.3e} (Paper 2: 3.466e34)")
# pear shape (minimal self-holding, density 3000) from pear_shape.py at release (Moon centre 20,617 km)
exec(open('pear.py').read().split('print(f"day')[0])
xm=20617e3; xtip=xm-2597e3; rho=3000.; lat=np.radians(10)
xx=np.linspace(xs,xtip,800)
def need_(x):
    q=np.linspace(x,xtip,300); return rho*np.trapezoid(GM/q**2 - w**2*q - Gm/(xm-q)**2, q)
W=[]
for x in xx:
    n=need_(x)
    W.append(3000e3 if n<=0 else max(2*np.sqrt(n/(np.pi*G*rho**2+rho*0.5*(GM/x**3+Gm/(xm-x)**3-w**2))),3000e3))
W=np.array(W); dm=rho*np.pi*(W/2)**2
mp=np.trapezoid(dm,xx); Ip=np.trapezoid(dm*(xx*np.cos(lat))**2,xx)
Im=m*(xm*np.cos(lat))**2 + 0.4*m*(1890e3)**2
for label,Ie in [("Earth keeps its inertia",0.4*(Mtot)*a_eq**2),("Earth minus Moon and pear mass",0.4*(Mtot-m-mp)*a_eq**2)]:
    wr=Ltot/(Ie+Ip+Im); Pr=2*np.pi/wr/3600
    Lm=Im*wr; Lp=Ip*wr
    print(f"\n[{label}] pear mass {mp/m:.1f} lunar masses")
    print(f"  day at release (all attached, corotating): {Pr:.2f} h")
    print(f"  share of angular momentum: Moon {Lm/Ltot*100:.1f}%, pear {Lp/Ltot*100:.1f}%, Earth {100-(Lm+Lp)/Ltot*100:.1f}%")
    Ie_after=0.4*(Mtot-m)*a_eq**2
    wa=(Ltot-Lm)/Ie_after
    print(f"  after the pear falls back: Earth's day {2*np.pi/wa/3600:.2f} h (pear returns its angular momentum)")
# torque / stress through the pear
for T_yr,lab in [(1e8,"slow rise over 100 Myr"),(1e3,"final phase over 1,000 yr")]:
    vr=(xm-8991e3)/(T_yr*3.156e7)
    F=2*(m+mp)*w0*vr       # Coriolis force to keep moving mass corotating (upper bound, all mass moving at vr)
    Mb=F*(xm-xs); a0=W[0]/2; Z=np.pi*a0**3/4
    print(f"\n{lab}: radial speed {vr:.2e} m/s, sideways force {F:.2e} N, bending stress at the base {Mb/Z:.2e} Pa")

print("\n=== how heavy may the pear be for the tip still to reach the line? ===")
Ie=0.4*(Mtot)*a_eq**2
for f in [0,0.05,0.1,0.2,0.3,0.5,1.0]:
    I=Ie+f*Ip+Im; wr=Ltot/I; Pr=2*np.pi/wr/3600
    rc=(GM/wr**2)**(1/3)/np.cos(lat)**(2/3)
    print(f"pear {f*mp/m:5.1f} lunar masses: day {Pr:5.2f} h, line at 10N {rc/1e3:7,.0f} km  -> tip at 18,020 km {'reaches' if rc<=18020e3 else 'does NOT reach'}")
# minimal Moon-only case
