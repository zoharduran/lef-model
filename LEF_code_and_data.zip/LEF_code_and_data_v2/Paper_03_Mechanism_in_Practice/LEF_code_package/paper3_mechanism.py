import os,sys;sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','shared'))
"""Paper 3 — The Mechanism. Reproduces:
  A.9-A.10  pressure test: p_s=150.26 GPa, I_d, I_o, table, threshold 3,864 kg/m^3
  A.11      Poiseuille viscosity ceilings (b^4)
  A.12      lifting work 1.6e30 J
  A.13      joint test at lat 25: p_r, dp_visc, remainder, lateral stress, bridge mass; threshold 854 km
  B.2       hemisphere: density 1,300, surface 5.65e13, ratio to far hemisphere 2.98
  B.4       translation rule areas; 41 deg cap
  B.7       shell mass 2.85e21 (18 km) vs far-side crust
  C.2       connection load at lat 25: a_r, a_lambda, F_conn = 4.17e22 N
  C.5       Stefan release: Delta r ~ 2 d0, times
"""
import numpy as np
from scipy.integrate import solve_ivp
from lef_common import *
M0=Mt; R=RV0
# --- A.9–A.10 ---
r_star=(G*M0/w0**2)**(1/3); rho_p=3*M0/(4*np.pi*R**3)
ps=rho_p/2*(G*M0/R-w0**2*R**2)
Id=0.5*(G*M0/R-w0**2*R**2); Io=G*M0*(1/R-1/r_star)-w0**2/2*(r_star**2-R**2)
print(f"A.9  r*={r_star/1e3:,.1f} km  p_s={ps/1e9:.2f} GPa  I_d={Id:.5e}  I_o={Io:.5e}")
rho_o=1500
for rho_d in (1500,3000,3500,4000,4500):
    head=rho_d*Id+rho_o*Io; print(f"A.10 rho_d={rho_d}: head={head/1e9:.2f} GPa  remainder={(ps-head)/1e9:.2f}")
print(f"A.10 rho_d,max = {(ps-rho_o*Io)/Id:,.0f} kg/m^3   d rho/dGPa = {1e9/Id:.1f}")
# --- A.11 ---
for b in (1e5,5e5,1e6):
    for T in (1e8,6e8): print(f"A.11 b={b/1e3:,.0f} km T={T:.0e} yr: eta_max={np.pi*b**4*1e10*3500*T*YR/(8*1e7*m):.2e} Pa s")
# --- A.12 ---
print(f"A.12 W_g = {G*ME*m*(1/8.991e6-1/2.0595e7):.2e} J")
# --- A.13 joint test (lat 25, two-body coupled state r=17,239.7 km, T=6.2196 h) ---
r=17239.7e3; w=2*np.pi/(6.2196*3600); lam=np.radians(25); K=G*Mt; m_r=ME*m/Mt
Rb=(3*m/(4*np.pi*2600))**(1/3); ut=r-Rb; rho_pE=3*ME/(4*np.pi*R**3)
Phi=lambda u: (-G*ME/(2*R)*(3-u**2/R**2) if u<=R else -G*ME/u) - G*m/(r-u) + G*m/r**2*u - 0.5*w**2*u**2*np.cos(lam)**2
Id2=Phi(R)-Phi(0); Io2=Phi(ut)-Phi(R); ps2=rho_pE*Id2
a_r=K/r**2-w**2*r*np.cos(lam)**2; a_l=w**2*r*np.sin(lam)*np.cos(lam)
print(f"A.13 p_s={ps2/1e9:.2f} GPa  I_d={Id2:.5e}  I_o={Io2:.5e}  a_r={a_r:.4f}  a_lam={a_l:.4f}  F_conn={m_r*np.hypot(a_r,a_l):.3e} N")
Mdot=3.882e6; eta=1e19
for b in (5e5,1e6,1.5e6):
    p_r=m_r*a_r/(np.pi*b**2); tau=m_r*a_l/(np.pi*b**2)
    dpv=8*eta*Mdot/(np.pi*b**4)*(R/3500+(ut-R)/1500)
    rem=ps2-3500*Id2-1500*Io2-p_r-dpv; Mb=np.pi*b**2*1500*(ut-R)
    print(f"A.13 b={b/1e3:,.0f}: p_r={p_r/1e9:.3f}  dp_visc={dpv/1e9:.6f}  rem={rem/1e9:.3f} GPa  tau_lat={tau/1e9:.2f}  M_bridge={Mb/m:.3f} m")
from scipy.optimize import brentq
bth=brentq(lambda b: ps2-3500*Id2-1500*Io2-m_r*a_r/(np.pi*b**2)-8*eta*Mdot/(np.pi*b**4)*(R/3500+(ut-R)/1500), 6e5,1.2e6)
print(f"A.13 radial threshold b = {bth/1e3:.0f} km  bridge mass = {np.pi*bth**2*1500*(ut-R)/m:.3f} m")
# --- B.2, B.4, B.7 ---
Rh=3.0e6; A_dome=2*np.pi*Rh**2; V=2/3*np.pi*Rh**3; A_moon=4*np.pi*1.7374e6**2
print(f"B.2  hemisphere: rho={m/V:,.0f}  surface={A_dome:.3e}  far hemisphere today={A_moon/2:.3e}  ratio={A_dome/(A_moon/2):.2f}")
A_c=np.pi*1.5e6**2; f=A_c*0.67/A_moon; th=np.degrees(np.arccos(1-2*f))
print(f"B.4  contact -> cap: {f:.3f} of surface, {th:.0f} deg, arc {2*np.radians(th)*1737.4:,.0f} km; base -> {np.pi*Rh**2*0.67/A_moon:.2f} of surface")
print(f"B.7  shell 18 km: {2800*18e3*A_dome:.3e} kg = {2800*18e3*A_dome/m:.1%};  far-side crust 55 km: {A_moon/2*55e3*2550:.3e} kg")
# --- C.5 Stefan release ---
wf=2.71e-4; grad=3*wf**2
def release(eta,d0,Rc,N=3):
    rhs=lambda t,y:[2*m*grad*(y[0]-d0)*y[0]**3/(3*np.pi*eta*Rc**4)]
    ev=lambda t,y:y[0]-N*d0; ev.terminal=True
    s=solve_ivp(rhs,[0,1e9*YR],[d0*1.001],events=ev,rtol=1e-8); return s.t_events[0][0]/YR,(N-1)*d0/1e3
for eta,d0 in ((1e13,20e3),(1e15,20e3),(1e15,50e3),(1e17,20e3)):
    t,dr=release(eta,d0,1.5e6); print(f"C.5  eta={eta:.0e} d0={d0/1e3:.0f} km: t={t:.3g} yr  Delta r={dr:.0f} km")
print(f"C.5  corotation shear stress: {2*m*wf*1.76e7*(1e3/YR)/(1e6*np.pi*1e12):.0f} Pa")
