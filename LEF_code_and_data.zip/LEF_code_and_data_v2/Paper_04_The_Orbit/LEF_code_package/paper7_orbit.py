import os,sys;sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','shared'))
"""Paper 7 — The Orbit After Release. Reproduces:
  B.1-B.2  release ellipses at lat 25 for the coupled branches; tidal sign test (Hut, eq 14)
  C.1      Laplace radius scale: 16.56 / 16.19 R_E
  D.1      tan-law final inclination for a0 = 15,818 / 14,627 / 27,433 / 37,580 km
  D.3      constant-Q clock from 27,433 km: 1.60 Gyr, 3.70 cm/yr
"""
import numpy as np
from lef_common import G, ME, m, Mt, YR
K=G*Mt; lat=np.radians(25)
cases=[(17239.70966523755,6.219608881367797),(18704.3,6.3703),(18977,6.3998),(19429,6.4499),(20595.45235847983,6.585342935334913),(21820.045585097465,6.7372050411453515),(18002.7,5.3818)]
for r_km,day in cases:
    r=1e3*r_km; w=2*np.pi/(3600*day); B=w**2*r**3*np.cos(lat)**2/K; a,e=r/(2-B),abs(1-B); n=np.sqrt(K/a**3)
    f1=1+15.5*e**2+31.875*e**4+11.5625*e**6+.390625*e**8; f2=1+7.5*e**2+5.625*e**4+.3125*e**6
    print(f"B.2  r0={r_km:,.0f}: a0={a/1e3:,.0f}  e0={e:.4f}  rp={a*(1-e)/1e3:,.0f}  lhs={w*np.cos(lat)/n:.4f}  rhs={f1/((1-e**2)**1.5*f2):.4f}")
for T in (6.2196,6.5853):
    w=2*np.pi/(T*3600); J2=1.0826e-3*(w/7.2921e-5)**2; rL=(2*J2*6.371e6**2*1.496e11**3*ME/1.989e30)**0.2
    print(f"C.1  T={T} h: r_L = {rL/6.371e6:.2f} R_E")
for a0 in (15818,14627.2,27432.7,37579.9): print(f"D.1  a0={a0:,.0f}: i_final={np.degrees(np.arctan(np.tan(lat)*np.sqrt(a0/384400))):.3f} deg")
A=3*(0.299/12)*(m/ME)*np.sqrt(G*ME)*6.371e6**5; t=2/(13*A)*(384400e3**6.5-27432.7e3**6.5)
print(f"D.3  time to 384,400 km: {t/YR/1e9:.2f} Gyr   present rate: {A*384400e3**-5.5*YR*100:.2f} cm/yr")
