"""Mars 2 -- every number of the paper. Python 3, no external input."""
import math
G=6.674e-11; M=6.4171e23; GM=G*M/1e9  # km^3/s^2
R_now=3389.5; k_now=0.3644; T_now=24.6229
R0=1.5*R_now; T0=5.0; w=2*math.pi/(T0*3600)
rho=M/(4/3*math.pi*(R0*1e3)**3)
vt=w*R0; g=GM/R0**2*1e3; ac=w**2*R0*1e3; vc=math.sqrt(GM/R0); vesc=math.sqrt(2*GM/R0)
line=(GM/w**2)**(1/3)
L_ratio=(0.4*R0**2/T0)/(k_now*R_now**2/T_now)
print("B  young Mars: R0 %.0f km  rho %.0f  vt %.3f km/s  g %.2f  ac %.2f  geff %.2f m/s2  v_circ %.2f  v_esc %.2f  line %.0f km (%.2f R0)"%(R0,rho,vt,g,ac,g-ac,vc,vesc,line,line/R0))
print("B  spin vs today: L/L0 %.1f -> loss %.0f%%;  contracting to today's radius keeping L would give a %.1f-h day"%(L_ratio,100*(1-1/L_ratio),T0*k_now/0.4*(R_now/R0)**2))
def orbit(vr,vt=vt,R=R0):
    v2=vr*vr+vt*vt; eps=v2/2-GM/R; a=-GM/(2*eps); h=R*vt; e=math.sqrt(1+2*eps*h*h/GM**2); return a*(1-e),a*(1+e),h
def throw_for(ra):
    lo,hi=0.0,math.sqrt(vesc**2-vt**2)-1e-6
    for _ in range(100):
        m=(lo+hi)/2; rp,rA,h=orbit(m)
        if rA<ra: lo=m
        else: hi=m
    return lo
moons={'Deimos':23463.0,'Phobos':9375.0}
for n,a in moons.items():
    vr=throw_for(a); rp,ra,h=orbit(vr); vapo=h/ra; vcirc=math.sqrt(GM/ra)
    vneed=math.sqrt(2*GM*R0/(ra*(ra+R0)))
    print(f"E  {n}: throw {vr:.2f} km/s (total {math.hypot(vr,vt):.2f}); lowest point {rp:.0f} km (surface {R0:.0f}); speed at top {vapo:.2f}, circular {vcirc:.2f}; "
          f"to clear the surface {vneed:.2f} ({100*(vneed-vapo)/(vcirc-vapo):.0f}% of the missing speed)")
print("E  free gas expansion limit ~1.0-1.2 km/s (cited); piston needs 2.3-3.2 km/s radial")
# moons today
P=dict(a=9375.0,e=0.0151,i=1.093,R=11.08,V=5740,rho=1853)
D=dict(a=23463.0,e=0.0003,i=1.79,R=6.2,V=4/3*math.pi*6.2**3,rho=1471)
for n,x in (('Phobos',P),('Deimos',D)):
    per=2*math.pi*math.sqrt(x['a']**3/GM)/3600; v=math.sqrt(GM/x['a'])
    print(f"A  {n}: a {x['a']:.0f} km  e {x['e']}  i {x['i']}  period {per:.2f} h ({T_now/per:.2f} per Mars day)  speed {v:.3f} km/s  V {x['V']:.0f} km3")
print("A  today's corotation radius %.0f km"%((GM/(2*math.pi/(T_now*3600))**2)**(1/3)))
# Pavonis caldera volume
for dep in (4.8,5.0):
    print("D  Pavonis caldera cylinder 47 km x %.1f km = %.0f km3; moons together %.0f km3"%(dep,math.pi*23.5**2*dep,P['V']+D['V']))
room=math.pi*23.5**2*4.8-P['V']; print("J  room left for a first plug if both came from the caldera volume: %.0f km3 -> sphere diameter %.1f km"%(room,2*(3*room/(4*math.pi))**(1/3)))
print("J  Deimos at exit (sphere diameter -> volume -> share lost by today):")
for d in (12.4,15,17.6,20,22.2,25):
    V=4/3*math.pi*(d/2)**3; print(f"     {d:5.1f} km  {V:7.0f} km3  lost {100*max(0,1-D['V']/V):4.0f}%  layer removed {max(0,(d/2-6.2)):.1f} km")
# ring: momentum needed
for n,a in moons.items():
    vr=throw_for(a); rp,ra,h=orbit(vr); dv=math.sqrt(GM/ra)-h/ra
    print(f"F  {n}: missing speed at the top {dv:.2f} km/s; perfectly coupled ring mass >= {dv/math.sqrt(GM/ra):.2f} x body mass")
# ---- Phobos: where it really started (today's dissipation, back-integration as in Paper 10) ----
aP=9.375e6; mP=1.0637e16; R_m=3.3895e6; YR=3.15576e7; Dref=1.816e-3; Gs=6.674e-11
def a_start(t,D=Dref): return (aP**6.5+39*D*mP*math.sqrt(Gs*M)*R_m**5*t*1e9*YR/(2*M))**(1/6.5)/1e3
for t in (3.5,3.9,4.5): print("H  Phobos back-integrated start %.1f Gyr ago: %.0f km"%(t,a_start(t)))
print("H  line reaches 19,000 km when the day is %.1f h"%(2*math.pi/math.sqrt(GM/19000**3)/3600))
for Rm,T in ((3390,24.6),(3600,22),(4000,22)):
    ww=2*math.pi/(T*3600); vtt=ww*Rm
    def orb(vr):
        v2=vr*vr+vtt*vtt; eps=v2/2-GM/Rm; a=-GM/(2*eps); h=Rm*vtt; e=math.sqrt(1+2*eps*h*h/GM**2); return a*(1-e),a*(1+e),h
    lo,hi=0,math.sqrt(2*GM/Rm-vtt**2)-1e-6
    for _ in range(100):
        m=(lo+hi)/2
        if orb(m)[1]<19000: lo=m
        else: hi=m
    rp,ra,h=orb(lo); vc=math.sqrt(GM/ra); vn=math.sqrt(2*GM*Rm/(ra*(ra+Rm)))
    print(f"H  Phobos from R {Rm} km, day {T} h: tangential {vtt:.2f}, throw {lo:.2f} km/s, at top {h/ra:.2f} vs circular {vc:.2f}; clear surface needs {100*(vn-h/ra)/(vc-h/ra):.0f}% of the missing speed")
print("H  Deimos tidal recession over 4.5 Gyr with today's Mars: ~154 km (Paper 10)")
vr=throw_for(19000); rp,ra,h=orbit(vr); vc=math.sqrt(GM/ra); vn=math.sqrt(2*GM*R0/(ra*(ra+R0)))
print(f"H  Phobos to 19,000 km from the fast expanded Mars (5 h, 5,084 km): throw {vr:.2f} km/s; at top {h/ra:.2f} vs circular {vc:.2f}; clear surface needs {100*(vn-h/ra)/(vc-h/ra):.0f}%")
# ---- piston: ideal gas-gun limit and required pressure ----
for T in (1200,1500,2000):
    c0=math.sqrt(1.3*8.314*T/0.018); print(f"C  steam at {T} K: sound speed {c0/1e3:.2f} km/s; free expansion into vacuum limit 2c0/(gamma-1) = {2*c0/0.3/1e3:.1f} km/s")
for v in (3.19,3.07,2.34):
    for Lb in (20,50,200):
        Lp=15e3; p=1500*(v*1e3)**2*Lp/(2*Lb*1e3); print(f"C  plug 15 km long, 1,500 kg/m3, to {v} km/s over a {Lb}-km barrel: mean pressure {p/1e9:.2f} GPa")
print("C  lithostatic pressure at 20 km in the expanded Mars (rho 3000, g 1.0): %.2f GPa"%(3000*1.0*20e3/1e9))
# ---- spin to be removed: mass that must leave through the line (all through the line) ----
M0=M; L0=k_now*M*(R_now*1e3)**2*2*math.pi/(T_now*3600)
def back(rho_start,frac,n=6000):
    m=M0; L=L0; target=M0/(1-frac); dm=(target-M0)/n
    for i in range(n):
        f=(m-M0)/(target-M0); r=3934+(rho_start-3934)*f; k=0.3644+(0.4-0.3644)*min(1,4*f)
        R=(3*m/(4*math.pi*r))**(1/3); ww=L/(k*m*R**2); rl=(G*m/ww**2)**(1/3); L+=dm*ww*rl**2; m+=dm
    R=(3*m/(4*math.pi*rho_start))**(1/3); ww=L/(0.4*m*R**2); return 2*math.pi/ww/3600, R/1e3
lo,hi=0.01,0.4
for _ in range(40):
    mid=(lo+hi)/2; T,R=back(1166,mid)
    if T>5: lo=mid
    else: hi=mid
T,R=back(1166,lo); print(f"I  to start at a 5-h day with radius ~{R:.0f} km, about {lo*100:.0f}% of the starting mass must leave through the line")

# ==== version 2 additions (20.10.2026) ====
print("\n--- v2 ---")
_GM=42828.0; _R0=5084.0; _w=2*math.pi/(5*3600); _vt=_w*_R0
def _apo(u):
    E=(u*u+_vt*_vt)/2-_GM/_R0; a=-_GM/(2*E); h=_R0*_vt; e=math.sqrt(1-h*h/(_GM*a)); return a*(1+e),a*(1-e),h
for tgt,lab in ((15000,'Deimos, ring height'),(12000,'Deimos, lower'),(11000,'Phobos, braked'),(10000,'Phobos, lower'),(23463,'Deimos straight')):
    lo,hi=0.5,6.0
    for _ in range(60):
        m=(lo+hi)/2; lo,hi=((m,hi) if _apo(m)[0]<tgt else (lo,m))
    ra,rp,h=_apo(m); vc=math.sqrt(_GM/ra)
    p=[1500*(m*1e3)**2*15e3/(2*Lb*1e3)/1e9 for Lb in (20,50,200)]
    print(f"E  {lab}: to {tgt} km throw {m:.2f} km/s; top {h/ra:.2f}, circular {vc:.2f}; lowest point {rp:.0f} km; ring >= {(vc-h/ra)/vc:.2f} body mass; pressure 20/50/200 km barrel {p[0]:.1f}/{p[1]:.1f}/{p[2]:.2f} GPa")
def _tmig(a0,a1,R,m,mult,n=20001):
    s=0.0; da=(a1-a0)/(n-1)
    for i in range(n):
        a=(a0+i*da)*1e3; nn=math.sqrt(_GM*1e9/a**3)
        dadt=3*1.816e-3*mult*(m/6.4171e23)*(R*1e3/a)**5*nn*a
        wgt=0.5 if i in (0,n-1) else 1.0
        s+=wgt/dadt*da*1e3
    return s/3.156e7
for loss in (0.3,0.5,0.6):
    V0=1000/(1-loss); m=V0*1e9*1471
    print(f"G.2 Deimos lost {loss:.0%}: exit {V0:,.0f} km3; constant-mass climb 15,000->23,463 km at x10 dissipation: {_tmig(15000,23463,5084,m,10)/1e6:,.0f} Myr")
print(f"G.3 Phobos (5,800 km3) climb 11,000->19,000 km at x8/x20: {_tmig(11000,19000,5084,5800e9*1860,8)/1e6:,.0f}/{_tmig(11000,19000,5084,5800e9*1860,20)/1e6:,.0f} Myr (young radius)")
for a in (11000,15000,19000,20428): print(f"G.3 line at {a} km when the day is {2*math.pi*math.sqrt(a**3/_GM)/3600:.1f} h")
for a in (15000,23463): print(f"J.1 Deimos at {a} km: period {2*math.pi*math.sqrt(a**3/_GM)/3600:.1f} h, speed {math.sqrt(_GM/a):.2f} km/s")
print(f"K.1 Phobos 1% loss: layer {11.08*(1-0.99**(1/3))*1000:.0f} m")
for v in (2.57,2.89):
    print(f"C.4 Coriolis on a plug rising at {v} km/s: {2*_w*v*1e3:.2f} m/s2")
for Lb in (20,50,200):
    print(f"C.4 net gravity 1.04 m/s2 over a {Lb}-km barrel adds {100*1.04*Lb*1e3/(0.5*(2.89e3)**2):.1f}% to the work for 2.89 km/s")
print(f"K.3 Stickney impactor 2 km at 1 km/s slows Phobos by {(4/3*math.pi*1e3**3*2000)*1e3/1.0659e16:.2f} m/s")
for Lb in (20,50,100,200,300):
    pD=1500*(2.89e3)**2*15e3/(2*Lb*1e3)/1e9; pP=1500*(2.57e3)**2*15e3/(2*Lb*1e3)/1e9
    print(f"C.6 path {Lb} km: Deimos {pD:.2f}, Phobos {pP:.2f} GPa; confining mean {2500*1.04*Lb*1e3/2e9:.2f}, base {2500*1.04*Lb*1e3/1e9:.2f} GPa")
for v,m,lab in ((2.89,3.0e15,'Deimos'),(2.57,1.08e16,'Phobos')):
    KE=0.5*m*(v*1e3)**2; print(f"C.8 {lab}: kinetic energy {KE:.1e} J; steam (3e6 J/kg, 40%) {KE/(0.4*3e6):.1e} kg")
print(f"C.7 200-km path: {2*200e3/2.89e3:.0f} s, mean acceleration {(2.89e3)**2/(2*200e3):.0f} m/s2")
