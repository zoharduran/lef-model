import numpy as np
G=6.6743e-11; M=6.4171e23; Rm=3389.5e3; rhoM=M/(4/3*np.pi*Rm**3)
A=1.19e12  # spot area m2 (polygon 1.19e6 km2)
print(f"Mars mean density {rhoM:.0f}")
print("thickness | volume km3 | x Phobos vol | mass @1500 / 1860 / 2900 kg/m3 | equiv sphere D km")
for th in [1,3,7]:
    V=A*th*1e3
    D=2*(3*V/(4*np.pi))**(1/3)/1e3
    ms=[V*r for r in (1500,1860,2900)]
    print(f"{th} km | {V/1e9:,.0f} | {V/5.7e12:,.0f} | "+" / ".join(f"{m:.2e}" for m in ms)+f" | {D:.0f}")
print("\nlength of a 'sausage' through the opening (cylinder), km:")
for th in [1,3,7]:
    V=A*th*1e3
    row=[]
    for Dop in [32,47,112,150]:
        L=V/(np.pi*(Dop*1e3/2)**2)/1e3; row.append(f"D={Dop}: {L:,.0f}")
    print(f"{th} km layer -> "+"; ".join(row))
print("\nPhobos/Deimos analog: body cross-section = caldera/3.5 .. caldera/2.4 -> for Arsia 112 km: %.0f-%.0f km"%(112/3.5,112/2.4))
# fluid Roche limit around Mars and tide/self-gravity ratio
for rho in (1500,1860,2900):
    dR=2.44*Rm*(rhoM/rho)**(1/3); print(f"fluid Roche limit for rho={rho}: {dR/1e3:,.0f} km from centre")
r_rel=Rm+6.9e6
for d in [r_rel, 8e6, 6e6, 4.5e6]:
    for rho in (1500,2900):
        ratio=2*M/(d**3*(4/3)*np.pi*rho)  # tidal stretching / self-gravity at body surface
        print(f"d={d/1e3:,.0f} km rho={rho}: tide/self-gravity = {ratio:.2f}")
# rounding timescales for a ~130 km body
R=65e3
for rho in (1500,2900):
    g=4/3*np.pi*G*rho*R
    print(f"rho={rho}: self-gravity {g:.3f} m/s2, inertial rounding time ~ {np.sqrt(R/g)/60:.0f} min")
    for eta in [1e4,1e8,1e10,1e12]:
        print(f"   eta={eta:.0e}: viscous rounding time ~ {eta/(rho*g*R)/3600:.3g} h")
print("lift energy at 7.9 MJ/kg:")
for th in [1,3,7]:
    m=A*th*1e3*1860; print(f"  {th} km: {m*7.9e6:.2e} J")
