import numpy as np
G=6.6743e-11; M=6.4171e23; GM=G*M
def fall(h,P,R):
    w=2*np.pi/(P*3600); r0=R+h; v0=w*r0
    a=1/(2/r0-v0**2/GM); e=r0/a-1; p=a*(1-e*e)
    if a*(1-e)>=R: return None
    f=2*np.pi-np.arccos((p/R-1)/e)
    n=np.sqrt(GM/a**3)
    E=2*np.arctan(np.sqrt((1-e)/(1+e))*np.tan(f/2)); tof=((E-e*np.sin(E))/n)%(2*np.pi/n)-np.pi/n
    east=R*((f-np.pi)-w*tof)
    vr=np.sqrt(GM/p)*e*np.sin(f); vt=np.sqrt(GM/p)*(1+e*np.cos(f))-w*R
    return east, tof/60, np.hypot(vr,vt), np.degrees(np.arctan2(abs(vr),abs(vt))), r0/(GM/w**2)**(1/3)
def solve(P,R,target=1347e3):
    lo,hi=1e4,4e7
    for _ in range(90):
        mid=(lo+hi)/2; r=fall(mid,P,R)
        if r is None or r[0]>target: hi=mid
        else: lo=mid
    return lo, fall(lo,P,R)
print("P[h] | R[km] | corotation km | release h km | r0/rc | flight min | impact km/s | angle deg")
for R in (3389.5e3, 3389.5e3*1.06):
    for P in (10,15,20,24.62,30.37,40):
        w=2*np.pi/(P*3600); rc=(GM/w**2)**(1/3)
        h,r=solve(P,R)
        if r: print(f"{P:5.2f} | {R/1e3:,.0f} | {rc/1e3:,.0f} | {h/1e3:,.0f} | {r[4]:.2f} | {r[1]:.0f} | {r[2]/1e3:.2f} | {r[3]:.0f}")
