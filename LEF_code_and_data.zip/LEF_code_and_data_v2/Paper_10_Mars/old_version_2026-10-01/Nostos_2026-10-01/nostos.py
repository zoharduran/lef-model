import numpy as np
G=6.6743e-11; M=6.4171e23; GM=G*M; R=3389.5e3; P=24.6229*3600; w=2*np.pi/P
rc=(GM/w**2)**(1/3); g=GM/R**2
print(f"g={g:.3f}  omega={w:.4e}  corotation={rc/1e3:,.0f} km  surface spin speed={w*R:.0f} m/s")
def fall(h):
    r0=R+h; v0=w*r0
    a=1/(2/r0-v0**2/GM); e=r0/a-1; p=a*(1-e*e); rp=a*(1-e)
    if rp>=R: return None
    cosf=(p/R-1)/e; f=2*np.pi-np.arccos(cosf)   # past apoapsis (pi) toward periapsis
    def t_from_peri(f):
        E=2*np.arctan(np.sqrt((1-e)/(1+e))*np.tan(f/2)); Mm=E-e*np.sin(E); return Mm/np.sqrt(GM/a**3)
    n=np.sqrt(GM/a**3); T=2*np.pi/n
    t_apo=T/2; t_imp=t_from_peri(f)%T
    tof=t_imp-t_apo
    dth=f-np.pi
    east=R*(dth-w*tof)
    vr=np.sqrt(GM/p)*e*np.sin(f); vt=np.sqrt(GM/p)*(1+e*np.cos(f))
    vrel_t=vt-w*R; vimp=np.hypot(vr,vrel_t); ang=np.degrees(np.arctan2(abs(vr),abs(vrel_t)))
    dPhi=GM*(1/R-1/r0)-0.5*w**2*(r0**2-R**2)
    vl=np.sqrt(2*dPhi)
    return dict(h=h/1e3,r0frac=r0/rc,tof_min=tof/60,east_km=east/1e3,vimp=vimp,ang=ang,vlaunch=vl,E=dPhi/1e6)
print("h_km | r0/rc | flight min | east km | impact m/s | angle from horizontal | equiv launch m/s | energy MJ/kg")
for h in [500,1000,2000,3000,4000,6000,8000,10000,11000]:
    d=fall(h*1e3)
    if d: print(f"{d['h']:>6,.0f} | {d['r0frac']:.2f} | {d['tof_min']:6.1f} | {d['east_km']:7,.0f} | {d['vimp']:6.0f} | {d['ang']:4.1f} | {d['vlaunch']:6.0f} | {d['E']:.2f}")
# threshold
lo,hi=1e5,2e7
for _ in range(60):
    mid=(lo+hi)/2
    if fall(mid) is None: hi=mid
    else: lo=mid
print(f"fall-back threshold: release below r={(R+lo)/1e3:,.0f} km from centre (h={lo/1e3:,.0f} km), = {(R+lo)/rc:.2f} of corotation")
# Syria: offset < 600 km
for h in np.arange(500,6001,100):
    d=fall(h*1e3)
    if d['east_km']>600: print("east offset reaches 600 km at h≈",h-100,"km");break
# cooling during flight
k=1e-6
for t_h in [0.25,1,3,24,24*30,24*365]:
    print(f"t={t_h:>7} h  conductive crust ~ {2*np.sqrt(k*t_h*3600):.2f} m")
# spreading (Huppert 1982 axisymmetric viscous gravity current): r = 0.894*(rho g V^3 t/(3 eta))^(1/8)
A=np.pi*615e3**2
for thick in [1e3,3e3,7e3]:
    V=A*thick; Req=(3*V/(4*np.pi))**(1/3)
    print(f"deposit thickness {thick/1e3:.0f} km: volume {V/1e9:,.0f} km3 = {V/5.7e12:,.0f} x Phobos; equivalent sphere diameter {2*Req/1e3:.0f} km")
    for eta in [1e2,1e4,1e6,1e8,1e10,1e12]:
        rho=2800
        t=(615e3/0.894)**8*3*eta/(rho*g*V**3)
        print(f"   eta={eta:.0e} Pa s -> time to spread to 615 km radius: {t/3.15e7:.3g} yr")
