import math
G=6.674e-11;M=6.4171e23;R0=3389.5e3;k0=0.3644;T0=24.6229*3600
w0=2*math.pi/T0;L0=k0*M*R0**2*w0
print("L0 %.3e"%L0)
for Ri,k in [(R0,k0),(R0*1.059,0.4)]:
  for Th in [8,10,15]:
    wi=2*math.pi/(Th*3600);Li=k*M*Ri**2*wi;dL=Li-L0
    rc=(G*M/wi**2)**(1/3)
    j_c=math.sqrt(G*M*rc)        # per kg leaving at corotation
    j_s=wi*Ri**2                 # per kg leaving the surface co-rotating
    print(f"R={Ri/1e3:.0f}km k={k} T={Th}h rc={rc/1e3:.0f} dL/L0={dL/L0:.2f} mass@rc={dL/j_c:.2e} kg ({dL/j_c/M*100:.2f}% of Mars) mass@surf={dL/j_s:.2e}")
# volatile inventories
print("1 bar Mars atm mass ~ %.1e kg"%(1e5*4*math.pi*R0**2/3.71))
print("1 km global water layer %.1e kg"%(1000*1000*4*math.pi*R0**2))
# tidal migration of Deimos: time to go from a1 to a2 (Mars tide), k2/Q
k2,Q=0.169,90; mD=1.4762e15
def t(a1,a2):
  C=3*k2/Q*(mD/M)*R0**5*math.sqrt(G*M)
  return (2/13)*(a2**6.5-a1**6.5)/C/3.156e7
for a1 in [11e6,15e6,20e6,23e6]:
  print("Deimos tidal time %d->23460 km: %.1e yr"%(a1/1e3,t(a1,23.46e6)))
# vapor envelope scale height
for T in [2000,4000,6000]:
  g=G*M/(R0*1.059)**2;H=1.38e-23*T/(30*1.67e-27*g);print("T",T,"H km",H/1e3)
# net inward pull on co-rotating material (30h and 10h)
for Th in [30,10]:
  w=2*math.pi/(Th*3600);rc=(G*M/w**2)**(1/3)
  for f in [1,2,3,4,5,6]:
    r=R0*1.059*f
    if r<rc: print(Th,"h r=%.0f km net pull %.3f m/s2 (gravity %.3f)"%(r/1e3,G*M/r**2-w**2*r,G*M/r**2))
