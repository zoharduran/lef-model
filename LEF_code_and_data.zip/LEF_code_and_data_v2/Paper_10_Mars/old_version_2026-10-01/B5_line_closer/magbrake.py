import math
G=6.674e-11;M=6.4171e23;R=3.589e6;mu0=4e-7*math.pi;yr=3.156e7
I=0.4*M*R**2
def run(B0,dm,tau_yr,v=5e3,P0=5.0):
    Md=dm/(tau_yr*yr)
    rA=(4*math.pi*B0**2*R**2/(mu0*Md*v))**0.25*R
    # dOmega/dt = -(2/3) Md rA^2 Omega / I  -> exponential
    rate=(2/3)*Md*rA**2/I
    W=2*math.pi/(P0*3600)*math.exp(-rate*tau_yr*yr)
    return 2*math.pi/W/3600, rA/R
print("B0(uT) mass_lost(kg) duration(yr) -> final day(h)  rA/R")
for B0 in [50e-6,100e-6,300e-6]:
  for dm in [1e18,1e19,1e20,1e21]:
    for tau in [1e7,1e8,1e9]:
      P,ra=run(B0,dm,tau)
      print(f"{B0*1e6:5.0f} {dm:8.0e} {tau:6.0e} -> {P:10.1f} h  rA/R={ra:5.1f}")
# reference: water layers
A=4*math.pi*3389.5e3**2
print("1e19 kg = %.0f m water GEL; 1e20 = %.0f m"%(1e19/1000/A,1e20/1000/A))
