import os,sys;sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','shared'))
"""Paper 4 — The Corotation Radius of Mars. Reproduces:
  B.1  r_co = 20,428 km; L_spin; L_sat/L_spin
  B.3  ancient states (k=0.4, R_i/R_0 = 1, 1.03, 1.06): 27.03/28.67/30.37 h; 21,737/22,611/23,493 km
  C.1  pressure test: p_s, dPhi, rho_max (1,548 / 1,414 / 1,295)
  D.1  required k2/Q for 3.5/4.1/4.5 Gyr from corotation
  D.2  Deimos recession 154 km
  E.2  return boundary x_ret = 0.708
  E.3  J2 M scale; Tharsis ratio
  G.1  release radius of Phobos from measured k2/Q: 19,550 km (96%)
  G.2  descent timeline; 38 Myr remaining
"""
import numpy as np
from lef_common import G, YR
M=6.4171e23; R0=3.3895e6; k0=0.3644; T0=24.6229*3600; w0=2*np.pi/T0
mP=1.0659e16; aP=9.376e6; mD=1.4762e15; aD=2.3463e7; Dref=1.816e-3
rco0=(G*M/w0**2)**(1/3); Lspin=k0*M*R0**2*w0
Lsat=mP*np.sqrt(G*M*aP)+mD*np.sqrt(G*M*aD)
print(f"B.1  r_co={rco0/1e3:,.1f} km  L_spin={Lspin:.5e}  L_sat/L_spin={Lsat/Lspin:.4e}")
for x in (1.0,1.03,1.06):
    T=T0*(0.4/k0)*x**2; w=2*np.pi/T; rco=(G*M/w**2)**(1/3); R=R0*x
    rho=3*M/(4*np.pi*R**3); ps=3*G*M**2/(8*np.pi*R**4)-0.5*rho*w**2*R**2; dPhi=1.5*G*M*(1/R-1/rco)
    print(f"B.3/C.1 x={x}: T={T/3600:.3f} h  r_co={rco/1e3:,.1f} km  p_s={ps/1e9:.2f} GPa  dPhi={dPhi:.5e}  rho_max={ps/dPhi:,.0f}")
for t in (3.5,4.1,4.5):
    D=2*M*(rco0**6.5-aP**6.5)/(39*mP*np.sqrt(G*M)*R0**5*t*1e9*YR); print(f"D.1  {t} Gyr: k2/Q required = {D:.3e} ({D/Dref:.3f} x ref)")
A=3*Dref*(mD/M)*np.sqrt(G*M)*R0**5; print(f"D.2  Deimos recession in 4.5 Gyr: {((aD**6.5+6.5*A*4.5e9*YR)**(1/6.5)-aD)/1e3:.0f} km")
from scipy.optimize import brentq
x6=1.06; Rr=R0*x6/23493.4e3; xr=brentq(lambda x: x**4-Rr*(2-x**3),0.3,0.99); print(f"E.2  x_ret (6% state) = {xr:.4f}")
print(f"E.3  J2*M = {1.96e-3*M:.3e} kg;  Tharsis/J2M = {8.7e20/(1.96e-3*M):.2f};  Tharsis/moons = {8.7e20/(mP+mD):,.0f}")
def ai(D,t): return (aP**6.5+39*D*mP*np.sqrt(G*M)*R0**5*t*1e9*YR/(2*M))**(1/6.5)
for D in (1.0e-3,Dref,2.423e-3,3.0e-3):
    print(f"G.1  k2/Q={D:.3e}: a_i(3.5,4.1,4.5 Gyr) = {ai(D,3.5)/1e3:,.0f} {ai(D,4.1)/1e3:,.0f} {ai(D,4.5)/1e3:,.0f} km  (4.5: {ai(D,4.5)/rco0:.3f} of r_co)")
a_i=ai(Dref,4.5); f=lambda a:(a_i**6.5-a**6.5)/(a_i**6.5-aP**6.5)*4.5
for a in (19000e3,18000e3,17000e3,15000e3,13000e3,aP,5000e3): print(f"G.2  {a/1e3:,.0f} km after {f(a):.2f} Gyr")
print(f"G.2  remaining to 5,000 km: {(f(5000e3)-4.5)*1e3:.0f} Myr")
