import numpy as np
G=6.674e-11; M=6.4171e23; R=3389.5e3; GM=G*M; yr=3.15576e7; T=4.5e9*yr
D=1.816e-3; mP=1.0659e16; mD=1.4762e15; RsP=11.08e3; RsD=6.2e3
aP0=19550e3; aPf=9376e3; aD=23463e3
# Phobos a(t): a^{13/2}(t)=a0^{13/2} - C t, C chosen so a(T)=aPf
C=(aP0**6.5-aPf**6.5)/T
t=np.linspace(0,T,200001); a=(aP0**6.5-C*t)**(1/6.5); n=np.sqrt(GM/a**3)
def needed(K, Rs, m, a_arr, n_arr, t_arr, I0, If):
    integ=np.trapezoid(0.75*(M/m)*(Rs/a_arr)**5*n_arr, t_arr)
    return np.log(I0/If)/integ
kP=needed(None,RsP,mP,a,n,t,18.65,1.08)
nD=np.sqrt(GM/aD**3)
kD1=np.log(18.65/1.79)/(0.75*(M/mD)*(RsD/aD)**5*nD*T)
kD2=np.log(18.65/0.93)/(0.75*(M/mD)*(RsD/aD)**5*nD*T)
print(f"Phobos 18.65->1.08 deg needs k2/Q_s = {kP:.2e}")
print(f"Deimos 18.65->1.79 deg (to Mars equator) needs {kD1:.2e}; ->0.93 (to Laplace plane) needs {kD2:.2e}; ratio to Phobos {kD1/kP:.0f}x / {kD2/kP:.0f}x")
# Deimos with Phobos-like value: final inclination
fin=18.65*np.exp(-kP*0.75*(M/mD)*(RsD/aD)**5*nD*T); print(f"Deimos with Phobos value: 18.65 -> {fin:.1f} deg")
for lam in [0.6,1,2,5,10,18.65]:
    print(f"Deimos from {lam} deg with Phobos-like k2/Q -> {lam*np.exp(-kP*0.75*(M/mD)*(RsD/aD)**5*nD*T):.2f}")
