import os,sys;sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','shared'))
"""Paper 2 §E.6 — release at vs beyond corotation, Hut (1981) constant-time-lag tides
in both bodies, Earth spin from the Earth-tide torque only.
Reproduces: release at corotation with u>0 -> infall; sustained-recession threshold x
(u=0.02: 1.0001, u=0.05: 1.0008, u=0.10: 1.0031).
"""
import numpy as np
from scipy.integrate import solve_ivp
from lef_common import *
R = 6.635e6; k2 = 0.299; I = 0.4*ME*R**2; Rm = 1.89e6; k2m = 0.03
Rs = 1.757e7; W0 = np.sqrt(G*Mt/Rs**3); tau = 1/(2*W0*12); taum = tau   # Q~12 at 2*Omega
f1=lambda x:1+31/2*x+255/8*x**2+185/16*x**3+25/64*x**4; f2=lambda x:1+15/2*x+45/8*x**2+5/16*x**3
f3=lambda x:1+15/4*x+15/8*x**2+5/64*x**3;               f4=lambda x:1+3/2*x+1/8*x**2
def rates(a,e,W):
    x=e*e; n=np.sqrt(G*Mt/a**3); q=m/ME
    pre=k2*tau*G*ME/R**3*q*(1+q)*(R/a)**8
    daE=-6*pre*a/(1-x)**7.5*(f1(x)-(1-x)**1.5*f2(x)*W/n); deE=-27*pre*e/(1-x)**6.5*(f3(x)-11/18*(1-x)**1.5*f4(x)*W/n)
    prem=k2m*taum*G*m/Rm**3*(1/q)*(1+1/q)*(Rm/a)**8
    daM=-6*prem*a/(1-x)**7.5*(f1(x)-(1-x)**1.5*f2(x));  deM=-27*prem*e/(1-x)**6.5*(f3(x)-11/18*(1-x)**1.5*f4(x))
    return daE,deE,daM,deM
def rhs(t,y):
    a,e,W=y; daE,deE,daM,deM=rates(a,e,W); Lo=mu*np.sqrt(G*Mt*a*(1-e*e))
    return [daE+daM, deE+deM, -Lo*(0.5*daE/a-e*deE/(1-e*e))/I]
def ic_corot(x,u):   # corotation kept to r = x*Rs; radial speed u*v_circ
    r=x*Rs; vc=np.sqrt(G*Mt/r); vt=W0*r; vr=u*vc; eps=(vt**2+vr**2)/2-G*Mt/r; a=-G*Mt/(2*eps)
    return a, np.sqrt(max(0.0,1-(r*vt)**2/(G*Mt*a)))
def outcome(a0,e0,T=2e5*YR):
    ev1=lambda t,y:y[0]*(1-y[1])-1.9971e7; ev1.terminal=True; ev1.direction=1
    ev2=lambda t,y:y[0]-0.9*Rs;            ev2.terminal=True; ev2.direction=-1
    s=solve_ivp(rhs,[0,T],[a0,e0,W0],method='LSODA',rtol=1e-10,atol=[1e-2,1e-13,1e-20],events=[ev1,ev2])
    if len(s.t_events[0]): return 'out', s.t_events[0][0]/YR
    if len(s.t_events[1]): return 'in',  s.t_events[1][0]/YR
    return 'stall', s.t[-1]/YR
for u in (0.0,0.02,0.05,0.10):
    print(f"x=1.000 u={u}: {outcome(*ic_corot(1.0,u))}")
    lo,hi=1.0,1.2
    for _ in range(14):
        mid=(lo+hi)/2; o=outcome(*ic_corot(mid,u))[0]; (lo,hi)=(lo,mid) if o=='out' else (mid,hi)
    print(f"      sustained-recession threshold x = {hi:.4f}")
