import os,sys;sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','shared'))
"""Paper 2 — The Corotation Radius. Reproduces:
  B.2  reference corotation 15,818 km, 5,020 m/s
  D.1  initial budget L0 = 3.466e34
  D.2  coupled end state 17,570 km / 6.438 h (test particle), 17,631 km / 6.432 h (two-body)
  D.2  end state for final inertia coefficient k_f = 0.40, 0.3644, 0.3307 (15,561 km)
  D.5  present budget, scalar vs vector surplus; k threshold 0.397
  D.7  classical Jacobi bifurcation factor 2.74
  E.1  Roche limits 19,971 / 10,313 km
  D.9  release at latitude 25 deg: 6.19 h, 17,115 km, spin tilt 4.48 deg
"""
import numpy as np
from lef_common import *

# --- B.2 reference ---
Rs0 = rsync(ME, w0); print(f"B.2  R_sync,0 = {Rs0/1e3:,.0f} km   v = {w0*Rs0:,.0f} m/s")

# --- D.1 initial budget ---
a0, e0 = figure(Mt, RV0, w0); I0 = 0.4*Mt*a0**2; L0 = I0*w0
L0mat = m*w0*0.4*a0**2
print(f"D.1  a0 = {a0/1e3:,.0f} km  e0 = {e0:.4f}  I0 = {I0:.4e}  L0 = {L0:.4e}")
print(f"D.2  base cost = {(m*w0*Rs0**2 - L0mat)/L0:.3%}")

# --- D.2 coupled end state ---
RVp = RV0*(ME/Mt)**(1/3)
def coupled(kf=0.4, lat_deg=0.0, two_body=False):
    l = np.radians(lat_deg); w = w0
    for _ in range(500):
        a, e = figure(ME, RVp, w); I = kf*ME*a**2
        R  = rsync(Mt if two_body else ME, w)
        Lo = (mu if two_body else m)*w*R**2*np.cos(l)
        Ls = np.array([Lo*np.sin(l), 0.0, L0 - Lo*np.cos(l)])
        wn = np.linalg.norm(Ls)/I
        if abs(wn - w) < 1e-15: break
        w = wn
    tilt = np.degrees(np.arctan2(Ls[0], Ls[2]))
    return dict(T_h=2*np.pi/w/3600, Rsync_km=R/1e3, a_km=a/1e3, e=e,
                Lorb=Lo/L0, added=(Lo-L0mat)/L0, tilt_deg=tilt)
for kf in (0.4, 0.3644, 0.3307):
    r = coupled(kf); print(f"D.2  k_f={kf}: T={r['T_h']:.3f} h  R_sync={r['Rsync_km']:,.0f} km  L_orb={r['Lorb']:.3%}  added={r['added']:.3%}")
r = coupled(0.4, two_body=True); print(f"D.4  two-body: T={r['T_h']:.4f} h  R={r['Rsync_km']:,.0f} km")
r = coupled(0.4, lat_deg=25); print(f"D.9  lat 25: T={r['T_h']:.3f} h  R={r['Rsync_km']:,.0f} km  L_orb={r['Lorb']:.2%}  tilt={r['tilt_deg']:.2f} deg")

# --- D.5 present budget ---
Ls = 8.034e37*7.2921e-5
Lo = mu*np.sqrt(G*Mt*3.844e8*(1-0.0549**2))
print(f"D.5  orbit fraction = {Lo/(Ls+Lo):.2%}   scalar surplus = {L0/(Ls+Lo)-1:.2%}")
for th in (18.3, 23.4, 28.6):
    Lv = np.sqrt(Ls**2+Lo**2+2*Ls*Lo*np.cos(np.radians(th)))
    print(f"D.5  vector surplus at {th} deg = {L0/Lv-1:.2%}")
print(f"D.5  k threshold (scalar) = {0.4*(Ls+Lo)/L0:.4f}")

# --- D.7 classical route ---
rho0 = Mt/(4/3*np.pi*RV0**3); e = 0.81267
a = a_of(RV0, e); W = np.sqrt(0.37423*np.pi*G*rho0)
print(f"D.7  Jacobi bifurcation: T={2*np.pi/W/3600:.2f} h  a={a/1e3:,.0f} km  ratio={0.4*Mt*a**2*W/(Ls+Lo):.2f}")

# --- E.1 Roche ---
x = (3*ME/(4*np.pi*2600))**(1/3)
print(f"E.1  fluid {2.44*x/1e3:,.0f} km   rigid {1.26*x/1e3:,.0f} km   rho_s for fluid limit at 17,570: {2600*(19971/17570)**3:,.0f}")
