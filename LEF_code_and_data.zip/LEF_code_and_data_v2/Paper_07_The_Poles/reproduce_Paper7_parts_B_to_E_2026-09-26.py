#!/usr/bin/env python3
"""
Paper 7 (Why the Poles Are Crowded) — reproduction of the numbers added on 26.9.2026
to Parts B, C, D and E. Python 3, numpy, scipy, pandas.

Inputs (place next to this script, or pass paths):
  Robbins_Dge20_selected.csv                       (Robbins 2019, D>=20 km, 6,973 craters; in the Paper 5 rebuild kit)
  RERUN_A7_polar_caps_masked_exact_basin_caps_2026-09-24.csv   (A.7 caps after the locked mask)

Sections:
  C.1  Maclaurin table and minimum density
  C.2  Roche figure at 20,595 km (2,600 and 3,344 kg/m^3)
  C.3  pole/equator density ratio, caps of 30 deg vs |lat|<15 deg (1.24); spin alone (1.19)
  C.4  surface potential of the free release figure; energy released by rounding
  B.2  flattening of an already cratered surface: pole/equator = c/a
  B.3  point factors for stretching into the Roche figure
  B.4  centrifugal potential difference pole-equator on the attached body
  D.1  measured ratios with exact (Clopper-Pearson) intervals
  D.2  medians with the 9% shrink of the release figure, bootstrap intervals
  D.3  young-crater ratios: intervals and probabilities under 1.32 / 1.43
  D.4  south/north ratios at every cap after the mask, with intervals
"""
import sys, math
import numpy as np, pandas as pd
from scipy.integrate import quad
from scipy.optimize import brentq, fsolve
from scipy.stats import beta, binomtest

G=6.674e-11; R_MOON=1737.4; M_MOON=7.35e22; M_EARTH=5.972e24
ROBBINS=sys.argv[1] if len(sys.argv)>1 else 'Robbins_Dge20_selected.csv'
A7=sys.argv[2] if len(sys.argv)>2 else 'RERUN_A7_polar_caps_masked_exact_basin_caps_2026-09-24.csv'

def ratio_ci(n1,n2,k):
    """ratio of densities (n1/A1)/(n2/A2) with k=A2/A1; exact binomial-split interval"""
    lo=beta.ppf(0.025,n1,n2+1) if n1>0 else 0.0; hi=beta.ppf(0.975,n1+1,n2)
    f=lambda p: p/(1-p)*k
    return f(n1/(n1+n2)), f(lo), f(hi)

# ---------------- C.1 ----------------
print('\n== C.1 Maclaurin: a/c by spin and density')
mac=lambda e: 2*np.sqrt(1-e*e)*(3-2*e*e)*np.arcsin(e)/e**3-6*(1-e*e)/e**2
EMAX=0.9299
for T in (5.5,6.44,7.0):
    W=2*np.pi/(T*3600); row=[]
    for rho in (1000,1300,1500,3344):
        q=W*W/(np.pi*G*rho)
        row.append('none' if q>mac(EMAX) else round(1/np.sqrt(1-brentq(lambda e:mac(e)-q,1e-5,EMAX)**2),2))
    print(f'  {T} h', row)
W=2*np.pi/(5.5*3600); print('  rho_min at 5.5 h =', round(W*W/(0.4493*np.pi*G)), 'kg/m3')

# ---------------- C.2 ----------------
def Acoef(a,b,c):
    D=lambda u: np.sqrt((a*a+u)*(b*b+u)*(c*c+u))
    return [a*b*c*quad(lambda u,s=s:1/((s*s+u)*D(u)),0,np.inf)[0] for s in (a,b,c)]
def roche(r,rho,M=M_EARTH,m=M_MOON,guess=(0.65,0.6)):
    mu=G*M/r**3; W2=G*(M+m)/r**3; P=np.pi*G*rho
    def res(x):
        b,c=x; A1,A2,A3=Acoef(1,b,c)
        t1=(P*A1-0.5*W2-mu); t2=(P*A2-0.5*W2+0.5*mu)*b*b; t3=(P*A3+0.5*mu)*c*c
        return [t1-t2,t1-t3]
    return fsolve(res,guess)
print('\n== C.2 Roche figure')
print('  20,595 km, 2,600:', np.round(roche(20595e3,2600),3))
print('  20,595 km, 3,344:', np.round(roche(20595e3,3344,guess=(0.77,0.73)),3))

# ---------------- C.3 ----------------
def cap_band_ratio(a,b,c):
    Rs=(a*b*c)**(1/3)
    J=lambda la,lo: Rs*np.sqrt(np.cos(la)**2*(np.cos(lo)**2/a**2+np.sin(lo)**2/b**2)+np.sin(la)**2/c**2)
    lonavg=lambda la: quad(lambda lo:J(la,lo),-math.pi,math.pi)[0]/(2*math.pi)
    mean=lambda l1,l2: quad(lambda la:lonavg(la)*math.cos(la),l1,l2)[0]/(math.sin(l2)-math.sin(l1))
    cap=mean(math.radians(60),math.pi/2); band=mean(math.radians(-15),math.radians(15))
    return cap,band,cap/band
print('\n== C.3 pole/equator, caps of 30 deg vs band |lat|<15 deg')
cap,band,r=cap_band_ratio(1,0.637,0.601); print(f'  release figure: caps x{cap:.3f}, band x{band:.3f}, ratio {r:.4f}')
print(f'  spin alone 1:1:0.816: ratio {cap_band_ratio(1,1,0.816)[2]:.4f}')
a,b,c=np.array([1,0.637,0.601])*(1*0.637*0.601)**(-1/3)
print(f'  point factors: pole {a*b:.3f}, sides {a*c:.3f}, sub-Earth {b*c:.3f}; polar diameter factor 1/sqrt(ab) = {1/np.sqrt(a*b):.4f}')

# ---------------- C.4 ----------------
print('\n== C.4 free release figure (self-gravity only)')
A1,A2,A3=Acoef(1,0.637,0.601); rho=2600; R=(3*M_MOON/(4*np.pi*rho))**(1/3)
aa,bb,cc=np.array([a,b,c])*R; P=np.pi*G*rho; g=G*M_MOON/R**2
d_sub=P*(A1*aa**2-A3*cc**2); d_side=P*(A2*bb**2-A3*cc**2)
print(f'  A = {A1:.3f}, {A2:.3f}, {A3:.3f}; g = {g:.3f} m/s2')
print(f'  Phi(sub-Earth)-Phi(pole) = {d_sub:.3e} J/kg ({d_sub/g/1e3:.0f} km); Phi(side)-Phi(pole) = {d_side:.3e} J/kg ({d_side/g/1e3:.0f} km)')
I=quad(lambda u:1/np.sqrt((a*a+u)*(b*b+u)*(c*c+u)),0,np.inf)[0]
W_ell=-(3/10)*G*M_MOON**2/R*I; W_sph=-(3/5)*G*M_MOON**2/R
print(f'  I = {I:.3f}; energy released {W_ell-W_sph:.2e} J ({(W_ell-W_sph)/W_sph*-100:.1f}% of binding), {(W_ell-W_sph)/M_MOON:.2e} J/kg')

# ---------------- B ----------------
print('\n== B.2 flattening of a cratered surface: pole/equator = c/a')
for ac in (1.09,1.11,1.30,1.38): print(f'  a/c={ac}: {1/ac:.2f}')
print('== B.3 stretching into the Roche figure: point density factors')
print(f'  pole {1/(a*b):.2f}, sides {1/(a*c):.2f}, sub-Earth {1/(b*c):.2f}')
W=2*np.pi/(6.5853*3600); d=0.5*W*W*R**2
print(f'== B.4 attached body, 6.59 h: 0.5 Omega^2 R^2 = {d:.2e} J/kg = {d/g/1e3:.0f} km at g={g:.2f}')

# ---------------- D.1 ----------------
K=2*np.pi*R_MOON**2/1e6; Ac=2*K*(1-np.sin(np.radians(60))); Ae=2*K*np.sin(np.radians(15)); k=Ae/Ac
print('\n== D.1 caps of 30 deg vs |lat|<15 deg')
for lab,n1,n2 in (('>=20',1113,1634),('>=40',407,522)):
    r,lo,hi=ratio_ci(n1,n2,k); print(f'  {lab}: {r:.3f} ({lo:.2f}-{hi:.2f})')
for lab,n,ref in (('>=20 masked',882,166.435637277),('>=40 masked',318,53.169769069)):
    A=3.70633; print(f'  {lab}: {n/A/ref:.3f} ({(n-1.96*n**.5)/A/ref:.2f}-{(n+1.96*n**.5)/A/ref:.2f}), polar count only')

# ---------------- D.2 ----------------
print('\n== D.2 medians, 9% shrink of the release figure (1/sqrt(ab)=0.9098)')
try:
    d=pd.read_csv(ROBBINS); lat=d.LAT_CIRC_IMG; Dm=d.DIAM_CIRC_IMG
    pole=Dm[abs(lat)>=60].values; eq=Dm[abs(lat)<15].values; rng=np.random.default_rng(1)
    def boot(x,y,n=20000):
        rr=[np.median(rng.choice(x,len(x)))/np.median(rng.choice(y,len(y))) for _ in range(n)]
        return np.percentile(rr,[2.5,97.5])
    f=1/np.sqrt(a*b)
    for lab,pt,et in (('40 same',40,40),('40 shrink',40*f,40),('20 same',20,20),('20 shrink',20,20/f)):
        p=pole[pole>=pt]; e=eq[eq>=et]; lo,hi=boot(p,e)
        print(f'  {lab}: poles >={pt:.1f} N={len(p)} med={np.median(p):.1f}; equator >={et:.1f} N={len(e)} med={np.median(e):.1f}; ratio {np.median(p)/np.median(e):.3f} ({lo:.2f}-{hi:.2f})')
except FileNotFoundError: print('  (Robbins file not found)')

# ---------------- D.3 ----------------
print('\n== D.3 young craters: pole/equator, interval, P(ratio this low | 1.32), (| 1.43)')
for lab,n1,n2,rat in (('LPI Copernican',10,21,0.92),('Mazrouei all',18,35,1.12),('Mazrouei <1 Gyr',17,32,1.16)):
    kk=rat*n2/n1; r,lo,hi=ratio_ci(n1,n2,kk)
    ps=[binomtest(n1,n1+n2,H/(H+kk),alternative='less').pvalue for H in (1.32,1.43)]
    print(f'  {lab}: {r:.2f} ({lo:.2f}-{hi:.2f}); p={ps[0]:.2f}, {ps[1]:.2f}')

# ---------------- D.4 ----------------
print('\n== D.4 south/north after the mask')
try:
    r7=pd.read_csv(A7)
    for rd in (10,15,20,30,45,60):
        s=r7[(r7.pole=='South')&(r7.radius_deg==rd)].iloc[0]; n=r7[(r7.pole=='North')&(r7.radius_deg==rd)].iloc[0]
        kk=n.area_retained_Mkm2/s.area_retained_Mkm2
        r20=ratio_ci(s.N20,n.N20,kk); r40=ratio_ci(s.N40,n.N40,kk)
        print(f'  {rd} deg: N {n.N20} ({n.density20:.0f}) S {s.N20} ({s.density20:.0f}); S/N {r20[0]:.2f} ({r20[1]:.2f}-{r20[2]:.2f}); >=40 {r40[0]:.2f} ({r40[1]:.2f}-{r40[2]:.2f})')
except FileNotFoundError: print('  (A.7 file not found)')
