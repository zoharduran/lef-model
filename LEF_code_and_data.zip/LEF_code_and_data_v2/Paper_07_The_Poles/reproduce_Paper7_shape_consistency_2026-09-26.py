# Paper 7 shape-consistency audit, 2026-09-26.
# Computes D.1 and D.2 from ONE specified ellipsoid.
# It does NOT solve a two-layer shell-over-fluid equilibrium.
import numpy as np, math
from scipy.integrate import quad

def metrics(a,b,c):
    Rs=(a*b*c)**(1/3)
    def J(lat,lon):
        cl,sl=np.cos(lat),np.sin(lat); cp,sp=np.cos(lon),np.sin(lon)
        return Rs*np.sqrt(cl*cl*(cp*cp/a**2+sp*sp/b**2)+sl*sl/c**2)
    def lonavg(lat):
        return quad(lambda lo:J(lat,lo),-math.pi,math.pi)[0]/(2*math.pi)
    def mean(lat1,lat2):
        num=quad(lambda la:lonavg(la)*math.cos(la),lat1,lat2)[0]
        return num/(math.sin(lat2)-math.sin(lat1))
    polar=mean(math.radians(60),math.pi/2)
    equator=mean(math.radians(-15),math.radians(15))
    D1=polar/equator
    D2=(c/a)**(1/3)
    return D1,D2

for s in [(1,.637,.601),(1,.763,.726),(1,1,1/1.3),(1,1,.816)]:
    print(s, metrics(*s))

# Optional sensitivity family only (not a physical rheology):
full=np.array([1.,.637,.601])
for f in np.linspace(0,1,21):
    axes=np.exp(f*np.log(full))
    print(f,*axes,metrics(*axes))
