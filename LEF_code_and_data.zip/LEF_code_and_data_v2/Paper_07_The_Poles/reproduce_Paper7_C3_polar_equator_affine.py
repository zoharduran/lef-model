import numpy as np, math
from scipy.integrate import quad

a,b,c=1.0,0.637,0.601
Rs=(a*b*c)**(1/3)

# Affine ellipsoid -> equal-volume sphere:
# (x,y,z) -> (Rs*x/a, Rs*y/b, Rs*z/c)
# Density multiplier for a uniform record carried with the surface:
def J(lat,lon):
    cl,sl=np.cos(lat),np.sin(lat)
    cp,sp=np.cos(lon),np.sin(lon)
    return Rs*np.sqrt(cl*cl*(cp*cp/a**2+sp*sp/b**2)+sl*sl/c**2)

def lonavg(lat):
    return quad(lambda lon:J(lat,lon),-math.pi,math.pi,
                epsabs=1e-11,epsrel=1e-11,limit=300)[0]/(2*math.pi)

def area_weighted_mean(lat1,lat2):
    num=quad(lambda lat:lonavg(lat)*math.cos(lat),lat1,lat2,
             epsabs=1e-10,epsrel=1e-10,limit=300)[0]
    den=math.sin(lat2)-math.sin(lat1)
    return num/den

pole=area_weighted_mean(math.radians(60),math.pi/2)
equator=area_weighted_mean(math.radians(-15),math.radians(15))
print("Rs =",Rs)
print("point multipliers: pole",Rs/c,"sub-Earth",Rs/a,"leading/trailing",Rs/b)
print("30deg polar-cap mean =",pole)
print("|lat|<15deg equatorial-belt mean =",equator)
print("polar/equatorial =",pole/equator)
