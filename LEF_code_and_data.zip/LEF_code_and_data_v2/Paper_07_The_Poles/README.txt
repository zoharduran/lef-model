REPRODUCTION — 2026-09-23
Run: python calculate_young_belts.py
Dependencies: Python 3, numpy, pandas, pyshp, shapely, pyproj.
Unzip the reproduction bundle and run the script in its directory. Included GeoUnits components are original files from USGS v2; unrelated GIS layers are omitted.
USGS source: https://asc-astropedia.s3.us-west-2.amazonaws.com/Moon/Geology/Unified_Geologic_Map_of_the_Moon_GIS_v2.zip
Mazrouei authors' INPUT, NOT verified final Table S1: https://raw.githubusercontent.com/ghentr/Earth-Moon_flux/master/scripts/ABCr_scripts/RockyCraters_lg10_forBill.csv
Tai Udovicic source: https://zenodo.org/api/records/4345058/files/ds01.csv/content
Grier original: https://doi.org/10.1029/1999JE001160
Coverage discussion: https://doi.org/10.1029/2000JE001430
Mazrouei original: https://doi.org/10.1126/science.aar4058
Final S1 PDF located but full download failed: https://www2.boulder.swri.edu/~bottke/Reprints/Mazrouei_2019_Science_SM_For_Earth_Moon_Impact_Flux_Increase_End_Paleozoic.pdf
Werner & Medvedev: https://doi.org/10.1016/j.epsl.2010.03.036

IMPORTANT: USGS N counts geologic polygons, not identified individual craters. Equivalent diameter measures mapped unit area including any mapped ejecta. Ccc/Ecc are clusters. Thresholds are not Robbins rim-diameter thresholds. Main outputs include clusters, as requested by prefix selection; additional Cc-only/Ec-only variants exclude clusters.
Spherical areas use pyproj.Geod(a=b=1737400m). Centroid is the direction of the area-integrated unit normal, evaluated using the spherical boundary integral (geodesic segments), with holes subtracted. Original projected coordinates are equidistant cylindrical with zero standard parallel and central longitude. Source AREA_GEO is included for comparison, not used as the computational area.
No catalogue is certified spatially complete by this calculation. Poisson errors are descriptive counting errors only. Missing coverage is NaN, not zero.
Mazrouei rows labelled UNVERIFIED_S1 are provisional calculations on an author-posted input file. They must not be cited as reproduction of the published final S1 sample. Do not infer all 111 input ages are <1Ga: eight are not. The raw-age<1000 selection is provided separately.
Grier subset is a published secondary compilation (all ds labels retained), not a newly verified global rayed-crater catalogue. Its densities are restricted to |latitude|<=60 degrees; polar ratios are unavailable.
Near side is |longitude|<90; far side includes boundaries. Bands include lower bound and exclude upper except 90. Duplicate equator and 0-15 band rows appear intentionally in CSV. USGS coverage 90, Mazrouei 80, Grier 60 degrees.
Full precision is in CSV; presentation tables use 3 significant figures. All selections, code, original input files, and computed subsets are included.
