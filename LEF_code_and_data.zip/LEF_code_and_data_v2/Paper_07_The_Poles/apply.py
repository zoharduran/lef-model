import numpy as np,pandas as pd,re
F='Paper_7_Why_the_Poles_Are_Crowded_EN.tex'
s=open(F).read()
R=1737.4;E20,E40=166.435637277,53.169769069
K=2*np.pi*R**2/1e6
lo=np.array([0xFF,0xF9,0xCC]);hi=np.array([0xF8,0xB6,0xB6])
def col(v,vals):
    a,b=min(vals),max(vals);t=0 if b==a else (v-a)/(b-a)
    return '%02x%02x%02x'%tuple(np.round(lo+(hi-lo)*t).astype(int))
def pct(x):
    x=round(x,1); x=0.0 if x==0 else x
    return ('%+.1f'%x).replace('+-','-')+r'\%'
def rep(old,new,count=1):
    global s
    n=s.count(old); assert n==count,(n,old[:80]); s=s.replace(old,new)
def tabrows(key,prefix_cols,data):
    # data: list of dict with N20,d20,N40,d40,area,base20,base40
    d20=[x['d20'] for x in data];d40=[x['d40'] for x in data]
    c20=[(x['d20']/x['b20']-1)*100 for x in data];c40=[(x['d40']/x['b40']-1)*100 for x in data]
    out=[]
    for i,x in enumerate(data):
        k20=col(x['d20'],d20);k40=col(x['d40'],d40)
        out.append(prefix_cols[i]+' & %.3f & %d & \\cellcolor[HTML]{%s}%.0f & \\cellcolor[HTML]{%s}%.2f & \\cellcolor[HTML]{%s}%s & %d & \\cellcolor[HTML]{%s}%.0f & \\cellcolor[HTML]{%s}%.2f & \\cellcolor[HTML]{%s}%s \\\\'%(
            x['area'],x['N20'],k20,x['d20'],k20,x['d20']/E20,col(c20[i],c20),pct(c20[i]),x['N40'],k40,x['d40'],k40,x['d40']/E40,col(c40[i],c40),pct(c40[i])))
    return out
def replace_rows(key,start_marker,newrows):
    global s
    i=s.index(start_marker); lines=s[i:].split('\n')
    idx=[j for j,l in enumerate(lines) if l.startswith(key)][:12]
    assert len(idx)==12 and idx[-1]-idx[0]==11
    old='\n'.join(lines[idx[0]:idx[-1]+1])
    s=s[:i]+s[i:].replace(old,'\n'.join(newrows),1)
def prefixes(start_marker,key):
    i=s.index(start_marker); lines=s[i:].split('\n')
    rows=[l for l in lines if l.startswith(key)][:12]
    return [' & '.join(l.split(' & ')[:3]) for l in rows], rows
def cnt(rows,c):  # get int from original row column c
    return [int(re.sub(r'[^\d]','',r.split(' & ')[c])) for r in rows]
# ---------- A.3 ----------
bands=[(-90,-75),(-75,-60),(-60,-45),(-45,-30),(-30,-15),(-15,0),(0,15),(15,30),(30,45),(45,60),(60,75),(75,90)]
_,A1=prefixes('seclabel{A.1}','\\bandball'); n1_20=cnt(A1,4); n1_40=cnt(A1,7)
pre3,_=prefixes('seclabel{A.3}','\\bandball')
r3=pd.read_csv('/mnt/user-data/uploads/RERUN_A3_latitude_masked_exact_basin_caps_2026-09-24.csv')
d3=[]
for i,(a,b) in enumerate(bands):
    r=r3[(r3.lat_lo==a)&(r3.lat_hi==b)].iloc[0]; ar=K*abs(np.sin(np.radians(b))-np.sin(np.radians(a)))
    d3.append(dict(area=r.area_retained_Mkm2,N20=r.N20,d20=r.density20,N40=r.N40,d40=r.density40,b20=n1_20[i]/ar,b40=n1_40[i]/ar))
replace_rows('\\bandball','seclabel{A.3}',tabrows('\\bandball',pre3,d3))
fig3=' -- '.join('(%.2f,%.2f)'%(0.6+1.2*i,(x['d20']-100)/60) for i,x in enumerate(d3))
rep(r'\draw[lefred,thick] (0.60,3.42) -- (1.80,2.17) -- (3.00,2.43) -- (4.20,2.17) -- (5.40,1.80) -- (6.60,1.88) -- (7.80,1.70) -- (9.00,2.07) -- (10.20,2.33) -- (11.40,2.13) -- (12.60,1.82) -- (13.80,3.33);', r'\draw[lefred,thick] '+fig3+';')
i=s.index('seclabel{A.3}'); j=s.index('Figure 3.',i)
seg=s[i:j]; seg2=re.sub(r'\\fill\[lefred\] \(([\d.]+),[\d.]+\) circle \(0\.06\);',lambda m:'\\fill[lefred] (%s,%.2f) circle (0.06);'%(m.group(1),(d3[round((float(m.group(1))-0.6)/1.2)]['d20']-100)/60),seg)
s=s[:i]+seg2+s[j:]
# ---------- A.4 ----------
_,A2=prefixes('seclabel{A.2}','\\lonball'); n2_20=cnt(A2,4); n2_40=cnt(A2,7)
pre4,_=prefixes('seclabel{A.4}','\\lonball')
r4=pd.read_csv('/mnt/user-data/uploads/RERUN_A4_longitude_masked_locked_mask_2026-09-24.csv')
ab=R**2*np.radians(30)*2/1e6
d4=[dict(area=r.area_retained_Mkm2,N20=r.N20,d20=r.density20,N40=r.N40,d40=r.density40,b20=n2_20[i]/ab,b40=n2_40[i]/ab) for i,r in r4.iterrows()]
replace_rows('\\lonball','seclabel{A.4}',tabrows('\\lonball',pre4,d4))
i=s.index('seclabel{A.4}'); j=s.index('Figure 4.',i); seg=s[i:j]
y4=lambda v:0.016*v-0.8
seg=re.sub(r'\\draw\[lefred,thick\] \(0\.60.*?;', lambda m:'\\draw[lefred,thick] '+' -- '.join('(%.2f,%.2f)'%(0.6+1.2*k,y4(x['d20'])) for k,x in enumerate(d4))+';',seg,count=1)
seg=re.sub(r'\\fill\[lefred\] \(([\d.]+),[\d.]+\) circle \(0\.06\);',lambda m:'\\fill[lefred] (%s,%.2f) circle (0.06);'%(m.group(1),y4(d4[round((float(m.group(1))-0.6)/1.2)]['d20'])),seg)
s=s[:i]+seg+s[j:]
# ---------- A.7 ----------
caps=[('North',60),('North',45),('North',30),('North',20),('North',15),('North',10),('South',10),('South',15),('South',20),('South',30),('South',45),('South',60)]
pre6,A6=prefixes('seclabel{A.6}','\\bandball')
n6={}
for l in A6:
    c=l.split(' & '); n6[(c[1].split()[0],int(re.sub(r'\D','',c[2])))]=(int(c[4]),int(c[7]))
pre7,_=prefixes('seclabel{A.7}','\\bandball')
r7=pd.read_csv('/mnt/user-data/uploads/RERUN_A7_polar_caps_masked_exact_basin_caps_2026-09-24.csv')
d7=[]
for p,rd in caps:
    r=r7[(r7.pole==p)&(r7.radius_deg==rd)].iloc[0]; ar=K*(1-np.cos(np.radians(rd))); a,b=n6[(p,rd)]
    d7.append(dict(area=r.area_retained_Mkm2,N20=r.N20,d20=r.density20,N40=r.N40,d40=r.density40,b20=a/ar,b40=b/ar))
replace_rows('\\bandball','seclabel{A.7}',tabrows('\\bandball',pre7,d7))
south=[x['d20'] for x in d7[6:]]
ys=['%.2f'%((v-150)/40) for v in south]
xs=['0.80','2.70','4.60','6.50','8.40','10.30']
rep(r'\draw[lefred,thick] (0.80,3.55) -- (2.70,3.38) -- (4.60,3.00) -- (6.50,2.33) -- (8.40,2.35) -- (10.30,2.23);', r'\draw[lefred,thick] '+' -- '.join('(%s,%s)'%(a,b) for a,b in zip(xs,ys))+';')
rep(r'\fill[lefred] (0.80,3.55) circle (0.06);\fill[lefred] (2.70,3.38) circle (0.06);\fill[lefred] (4.60,3.00) circle (0.06);\fill[lefred] (6.50,2.33) circle (0.06);\fill[lefred] (8.40,2.35) circle (0.06);\fill[lefred] (10.30,2.23) circle (0.06);',
    ''.join('\\fill[lefred] (%s,%s) circle (0.06);'%(a,b) for a,b in zip(xs,ys)))
i=s.index('seclabel{A.7}'); j=s.index('Figure 6.',i); seg=s[i:j]
a=r"\draw[lefrule,thin] (0,0) -- (11.5,0); \draw[lefrule,thin] (0,0) -- (0,4.2);"
assert seg.count(a)==1; seg=seg.replace(a,r"\draw[lefrule,thin] (0,0) -- (11.5,0); \draw[lefrule,thin] (0,0) -- (0,5.2);")
a=r"\foreach \v in {150,200,250,300} { \pgfmathsetmacro{\yy}{(\v-150)/40}"
assert seg.count(a)==1; seg=seg.replace(a,r"\foreach \v in {150,200,250,300,350} { \pgfmathsetmacro{\yy}{(\v-150)/40}")
a=r"at (-1.1,2.1) {craters"
assert seg.count(a)==1; seg=seg.replace(a,r"at (-1.1,2.6) {craters")
s=s[:i]+seg+s[j:]
open(F,'w').write(s)
print('tables and figures done')
