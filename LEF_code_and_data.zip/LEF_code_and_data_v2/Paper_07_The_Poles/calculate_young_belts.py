"""Reproduce lunar region statistics. Python 3 + numpy,pandas,pyshp,shapely,pyproj.
USGS units are polygons, NOT a deduplicated catalogue of individual craters.
Run from this script's directory; raw/usgs contains the unzipped USGS v2 archive.
"""
from pathlib import Path
import math,json
import numpy as np
import pandas as pd
import shapefile
from shapely.geometry import shape
from pyproj import Geod
BASE=Path(__file__).resolve().parent
R=1737.4
GEOD=Geod(a=R*1000,b=R*1000)

def ring_values(coords):
    # Source equidistant cylindrical, metres, standard parallel and central longitude 0.
    xy=np.asarray(coords); lon=xy[:,0]/(R*1000); lat=xy[:,1]/(R*1000)
    area,_=GEOD.polygon_area_perimeter(np.degrees(lon),np.degrees(lat))
    v=np.column_stack((np.cos(lat)*np.cos(lon),np.cos(lat)*np.sin(lon),np.sin(lat)))
    cross=np.cross(v[:-1],v[1:]); norm=np.linalg.norm(cross,axis=1)
    angle=np.arctan2(norm,np.sum(v[:-1]*v[1:],axis=1))
    # Integral of unit surface normal over spherical polygon, from vector Stokes theorem.
    vec=(cross*(np.divide(angle,norm,out=np.zeros_like(angle),where=norm>0))[:,None]).sum(axis=0)/2
    return abs(area)/1e6,vec*np.sign(area)

def extract_usgs():
    reader=shapefile.Reader(str(next((BASE/'raw/usgs').rglob('GeoUnits.shp'))))
    rows=[]
    for rec in reader.iterShapeRecords():
        code=rec.record['FIRST_Unit']
        if code not in ('Cc','Ccc','Ec','Ecc'): continue
        g=shape(rec.shape.__geo_interface__)
        assert g.geom_type=='Polygon', (rec.record.oid,g.geom_type)
        area,vec=ring_values(g.exterior.coords)
        for hole in g.interiors:
            ha,hv=ring_values(hole.coords);area-=ha;vec-=hv
        vec/=np.linalg.norm(vec)
        lat=math.degrees(math.asin(vec[2]));lon=math.degrees(math.atan2(vec[1],vec[0]))
        rows.append(dict(fid=rec.record.oid,code=code,period=rec.record['FIRST_Un_1'],unit_name=rec.record['FIRST_Un_2'],
            lat=lat,lon=lon,area_km2=area,diameter_km=2*math.sqrt(area/math.pi),source_AREA_GEO_km2=rec.record['AREA_GEO']/1e6,
            hole_count=len(g.interiors)))
    df=pd.DataFrame(rows);df.to_csv(BASE/'USGS_selected_polygons.csv',index=False)
    return df

def region_stats(df,sample,dmin,coverage=90):
    df=df[(df.diameter_km>=dmin)&(df.lat.abs()<=coverage)].copy()
    lat=df.lat; ab=lat.abs(); lon=((df.lon+180)%360)-180
    full=4*math.pi*R*R
    def bandarea(lo,hi):return full*(math.sin(math.radians(min(hi,coverage)))-math.sin(math.radians(lo))) if coverage>lo else 0
    cap=bandarea(60,90)/2
    groups=[('North_cap30',lat>=60,cap),('South_cap30',lat<=-60,cap),('Both_caps30',ab>=60,2*cap),
        ('Equator_abs_lat_lt15',ab<15,bandarea(0,15))]
    for lo in range(0,90,15):groups.append((f'Abs_lat_{lo}_{lo+15}',(ab>=lo)&((ab<lo+15) if lo<75 else (ab<=90)),bandarea(lo,lo+15)))
    hemi=full*math.sin(math.radians(coverage))/2
    groups.extend([('Near_side',lon.abs()<90,hemi),('Far_side',lon.abs()>=90,hemi),('All_coverage',ab<=coverage,2*hemi)])
    rows=[]
    for region,mask,area in groups:
        n=int(mask.sum()) if area else float('nan');rows.append(dict(sample=sample,dmin_km=dmin,coverage_abs_lat_max=coverage,region=region,N=n,
            area_km2=area,density_per_million_km2=n*1e6/area if area else float('nan'),sqrt_N=math.sqrt(n),
            density_poisson_se=math.sqrt(n)*1e6/area if area else float('nan')))
    out=pd.DataFrame(rows)
    assert out[out.region.str.startswith('Abs_lat')].N.sum()==len(df)
    assert int(out[out.region.isin(['Near_side','Far_side'])].N.sum())==len(df)
    eq=out[out.region=='Equator_abs_lat_lt15'].iloc[0]
    ratios=[]
    for reg in ['North_cap30','South_cap30','Both_caps30']:
        caprow=out[out.region==reg].iloc[0]
        rat=caprow.density_per_million_km2/eq.density_per_million_km2 if eq.N else float('nan')
        err=rat*math.sqrt(1/caprow.N+1/eq.N) if caprow.N and eq.N else float('nan')
        ratios.append(dict(sample=sample,dmin_km=dmin,region=reg,pole_equator_ratio=rat,ratio_delta_method_se=err))
    return out,pd.DataFrame(ratios)

def main():
    usgs=extract_usgs();stats=[];ratios=[]
    for codes,label in [(['Cc','Ccc'],'USGS_Copernican_prefix_Cc'),(['Ec','Ecc'],'USGS_Eratosthenian_prefix_Ec'),
                       (['Cc'],'USGS_Copernican_Cc_only'),(['Ec'],'USGS_Eratosthenian_Ec_only')]:
        for d in [10,20]:
            s,r=region_stats(usgs[usgs.code.isin(codes)],label,d);stats.append(s);ratios.append(r)
    # Authors' GitHub input is NOT the verified final Table S1; preserve both selections.
    raw=pd.read_csv(BASE/'raw/RockyCraters_lg10_forBill.csv').dropna(subset=['Lat','Lon','Diam'])
    maz=raw.rename(columns={'Lat':'lat','Lon':'lon','Age':'age_Ma'}).copy()
    maz['diameter_km']=maz['Diam']/1000
    maz.to_csv(BASE/'Mazrouei_GitHub_input_111.csv',index=False)
    for subset,label in [(maz,'Mazrouei_GitHub_all111_UNVERIFIED_S1'),
                         (maz[maz.age_Ma<1000],'Mazrouei_GitHub_Age_lt1000_UNVERIFIED_S1')]:
        for d in [10,20]:
            st,ra=region_stats(subset,label,d,80);stats.append(st);ratios.append(ra)
    # Published secondary compilation: retain source classifications, coordinates and diameters.
    ray=pd.read_csv(BASE/'raw/Tai2021_ds01.csv')
    ray=ray[ray.Ref=='Grier et al. (2001)'].rename(columns={'Lat':'lat','Lon':'lon'}).copy()
    ray['diameter_km']=2*ray.Radius
    ray.to_csv(BASE/'Grier_via_Tai2021_ds01.csv',index=False)
    for d in [10,20]:
        st,ra=region_stats(ray,'Grier_via_Tai2021_ds01',d,60);stats.append(st);ratios.append(ra)
    pd.concat(stats).to_csv(BASE/'young_craters_region_statistics.csv',index=False)
    pd.concat(ratios).to_csv(BASE/'young_craters_pole_equator_ratios.csv',index=False)
    print(pd.concat(ratios).to_string(index=False))
if __name__=='__main__':main()
