F='Paper_7_Why_the_Poles_Are_Crowded_EN.tex'
s=open(F).read()
def rep(old,new,count=1):
    global s
    n=s.count(old); assert n==count,(n,old[:90]); s=s.replace(old,new)
# abstract
rep(r"With the South Pole--Aitken (SPA) basin set aside it rises further, to 1.43 at 20 km and 1.60 at 40 km.",
    r"After the exclusion of the large basins and the maria it rises further, to 1.43 at 20 km and 1.61 at 40 km.")
# A.3 status box -> method box ; footnote
a=s.index(r"\begin{paperbox}\lefTag{STATUS OF THE $\ge40$ KM DATA}"); b=s.index(r"\end{paperbox}",a)+len(r"\end{paperbox}")
s=s[:a]+r"""\begin{paperbox}\lefTag{THE MASK}\par\vspace{0.35em}
The mask is the union of the 20 basins with a main or outer rim diameter of 500 km or more in Table 1 of Neumann et al. (2015) and of the mare polygons of LROC\_GLOBAL\_MARE\_180. Each basin is represented as a spherical cap centred on its published coordinates, with angular radius $D/(2R_{\rm Moon})$; a crater is removed when its centre lies within at least one basin or mare polygon, and overlaps are removed once only. The remaining area is computed on a global midpoint grid of 0.05°$\times$0.05° with exact spherical cell areas; membership of a basin is computed directly from the great-circle distance and not from a polygon of the basin rim. The same mask and the same area computation are used in A.3, A.4 and A.7.
\end{paperbox}"""+s[b:]
rep(r"The $\ge20$ km data after the mask are kept from the existing output. The areas shown are rounded.",
    r"All values after the mask come from one run of the mask described above. The areas shown are rounded; densities, ratios and changes are computed from the unrounded values.")
# A.4 method box
rep(r"The file LROC\_GLOBAL\_MARE\_180.SHP supplied by the author was united with the 20 basin caps of Neumann from the original output. The area was computed on a 0.05°$\times$0.05° grid; overlaps were subtracted once, and craters were assigned by centre.",
    r"The same mask as A.3: the 20 Neumann basins of 500 km and more as spherical caps, united with the LROC\_GLOBAL\_MARE\_180 polygons; area on a 0.05°$\times$0.05° grid with exact cell areas; overlaps subtracted once; craters assigned by centre. Summed over the twelve bands, A.3 and A.4 give the same remaining area (21.570 million km²) and the same counts (4,848 and 1,599).")
# A.7 method box
rep(r"The same mask as A.3/A.4 --- the 20 Neumann basins $\ge500$ km + the LROC\_GLOBAL\_MARE\_180 polygons; area on a 0.05°$\times$0.05° grid; overlaps once; crater assigned by centre. The synthesis and its meaning are kept for A.8.",
    r"The same mask as A.3/A.4 --- the 20 Neumann basins $\ge500$ km as spherical caps + the LROC\_GLOBAL\_MARE\_180 polygons; area on a 0.05°$\times$0.05° grid; overlaps once; crater assigned by centre. Where a cap and a set of bands cover the same region (the 30° caps and the bands 60--90°), A.3 and A.7 give the same area and the same counts. The synthesis and its meaning are kept for A.8.")
# A.8.3
rep(r"The number of $\ge20$ craters falls from 72 to 36, but the available area shrinks enough for the density to rise from about 250 to about 292 per million km² --- a rise of about 17\%.",
    r"The number of $\ge20$ craters falls from 72 to 36, but the available area shrinks enough for the density to rise from about 250 to about 348 per million km² --- a rise of about 39\%.")
rep(r"After the mask 84 craters remain on an area of about 0.295 million km², and the density rises to about 285 per million km² --- a rise of about 33\%.",
    r"After the mask 84 craters remain on an area of about 0.275 million km², and the density rises to about 305 per million km² --- a rise of about 42\%.")
rep(r"the density rises from about 82 to about 115 per million km², a change of about 41\%.",
    r"the density rises from about 82 to about 124 per million km², a change of about 51\%.")
rep(r"$\ge20$ rises from about 207 to about 270 per million km², and $\ge40$ from about 73 to about 94. As the cap widens the effect of the mask weakens. At 30° the rise in $\ge20$ is about 15\%; at 45° and 60° it is about 10--11\%.",
    r"$\ge20$ rises from about 207 to about 280 per million km², and $\ge40$ from about 73 to about 98. As the cap widens the effect of the mask weakens. At 30° the rise in $\ge20$ is about 17\%; at 45° and 60° it is about 11--12\%.")
# A.8.4
rep(r"At $\ge20$ km, in the 15° cap, the north is at about 300 per million km² and the south at about 285. In the 20° cap the two poles are almost identical: about 270 in the north and about 270 in the south. Even in the 10° cap one obtains about 298 in the north and about 292 in the south.",
    r"At $\ge20$ km, in the 15° cap, the north is at about 300 per million km² and the south at about 305. In the 20° cap the two poles are close: about 270 in the north and about 280 in the south. In the 10° cap the south lies higher --- about 298 in the north against about 348 in the south --- on only 36 southern craters.")
rep(r"A.7 shows that the convergence is not confined to the mean of a whole band: at $\ge20$ km a closeness between north and south is obtained also in the inner caps of 10°, 15° and 20°.",
    r"A.7 shows that the convergence is not confined to the mean of a whole band: at $\ge20$ km a closeness between north and south is obtained also in the inner caps of 15° and 20°, while in the smallest cap, of 10°, the south lies above the north.")
rep(r"in the 15° cap one obtains about 101 per million km² in the north and about 115 in the south; at 10° about 108 in the north and about 114 in the south; and at 20° about 104 in the north and about 94 in the south.",
    r"in the 15° cap one obtains about 101 per million km² in the north and about 124 in the south; at 10° about 108 in the north and about 135 in the south; and at 20° about 104 in the north and about 98 in the south.")
# A.8 summary
rep(r"In the 15° cap, for example, the $\ge20$ density rises from about 215 to about 285 per million km², and the $\ge40$ density from about 82 to about 115 per million km². In the 20° cap the $\ge20$ density rises from about 207 to about 270 per million km².",
    r"In the 15° cap, for example, the $\ge20$ density rises from about 215 to about 305 per million km², and the $\ge40$ density from about 82 to about 124 per million km². In the 20° cap the $\ge20$ density rises from about 207 to about 280 per million km².")
rep(r"After the mask one obtains about 300 against about 285. In the 20° cap the difference that was about 270 in the north against about 207 in the south narrows after the mask to about 270 against roughly 270. In the 10° cap too close values are obtained after the mask --- about 298 in the north and about 292 in the south.",
    r"After the mask one obtains about 300 against about 305. In the 20° cap the difference that was about 270 in the north against about 207 in the south narrows after the mask to about 270 against about 280. In the 10° cap, the smallest, the south lies above the north after the mask --- about 348 against about 298, on 36 southern craters.")
# D.3 / E.1
rep(r"against 1.32 for the old population and 1.46 outside the basins and maria (A.3).",
    r"against 1.32 for the old population and 1.43 outside the basins and maria (A.3).")
rep(r"(1.34 against 1.32, and 1.46 outside basins and maria)",r"(1.34 against 1.32, and 1.43 outside basins and maria)")
# Orientale 163 -> 162
rep(r"& 163 with the Orientale floor excluded (Paper 6 §A.2) \\",r"& 162 with the Orientale floor excluded (C.3) \\")
rep(r"Trailing side & 163 & 58 &",r"Trailing side & 162 & 58 &")
rep(r"the sides less (253 and 163)",r"the sides less (253 and 162)")
open(F,'w').write(s); print('ok')
