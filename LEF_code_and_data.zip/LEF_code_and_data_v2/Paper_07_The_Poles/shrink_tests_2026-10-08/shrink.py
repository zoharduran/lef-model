import numpy as np, pandas as pd
rng=np.random.default_rng(7)
B='/home/claude/LEF_המוח/'
g=B+'מאמר_09_SPA/ג_נתונים_וקוד/B8_2026-10-04/'
M=np.load(g+'mare_grid.npy'); gla=np.load(g+'grid_lat.npy'); glo=np.load(g+'grid_lon.npy')
R=1737.4
LA,LO=np.meshgrid(gla,glo,indexing='ij')
cell=(R*np.deg2rad(0.25))**2*np.cos(np.deg2rad(LA))
def angd(lat1,lon1,lat2,lon2):
    p1,p2=np.deg2rad(lat1),np.deg2rad(lat2); dl=np.deg2rad(lon2-lon1)
    return np.rad2deg(np.arccos(np.clip(np.sin(p1)*np.sin(p2)+np.cos(p1)*np.cos(p2)*np.cos(dl),-1,1)))
SPAg=angd(LA,LO,-53,191)<39.57
okg=~M&~SPAg
def ismare(lat,lon):
    i=np.clip(((89.875-lat)/0.25).round().astype(int),0,719)
    lo=((lon+180)%360)-180
    j=np.clip(((lo+179.875)/0.25).round().astype(int),0,1439)
    return M[i,j]
far_g=np.abs(((LO-180)%360)-180)>=90   # |lon|>=90 -> far
REG={'caps':lambda la,lo:np.abs(la)>=60,
     'ring45-60':lambda la,lo:(np.abs(la)>=45)&(np.abs(la)<60),
     'belt<15':lambda la,lo:np.abs(la)<15,
     'far<60':lambda la,lo:(np.abs(la)<60)&(np.abs(((lo-180)%360)-180)>=90),
     'near<60':lambda la,lo:(np.abs(la)<60)&(np.abs(((lo-180)%360)-180)<90)}
AREA={k:cell[okg&f(LA,LO)].sum()/1e6 for k,f in REG.items()}

# ---------- predicted linear factors if craters shrank with surface (P8 rounding a/c=1.69, radial mapping) -----
q=1.69; c=1.0; a=q; Rs=(a*a*c)**(1/3)
def J(lat): l=np.deg2rad(lat); return Rs*np.sqrt(np.cos(l)**2/a**2+np.sin(l)**2/c**2)
pred={}
for k,f in REG.items():
    m=okg&f(LA,LO); w=cell[m]
    pred[k]=np.sum(w*J(LA[m])**-0.5)/w.sum()
print('== predicted mean linear factor (rounding, craters shrink with surface)')
for k,v in pred.items(): print(f'  {k:10s} {v:.3f}')
print('  caps/ring %.3f  caps/belt %.3f'%(pred['caps']/pred['ring45-60'],pred['caps']/pred['belt<15']))
print('  P3 dome closure: far side x0.58 vs near side')
print('areas (Mkm2):',{k:round(v,2) for k,v in AREA.items()})

# ---------- Robbins >=20 clean ----------
d=pd.read_csv(B+'06_נתונים_משותפים/Robbins_Dge20_selected.csv')
la=d.LAT_CIRC_IMG.values; lo=d.LON_CIRC_IMG.values; D=d.DIAM_CIRC_IMG.values
ok=~d.inside_mare.values & ~(angd(la,lo,-53,191)<39.57)
pop={k:np.sort(D[ok&f(la,lo)])[::-1] for k,f in REG.items()}
print('\n== CALC 1: largest craters per equal area (top q per Mkm2), clean')
def topn(x,A,qq): n=max(1,int(round(qq*A))); return x[:n]
for qq in (2,5,10,20):
    row=[]
    for k in REG:
        t=topn(pop[k],AREA[k],qq); row.append(f'{k}: n={len(t)} mean={t.mean():.1f} med={np.median(t):.1f}')
    print(f' q={qq}/Mkm2 | '+' | '.join(row))
# bootstrap ratio caps vs ring/belt (resample positions via Poisson-thinning of populations)
def bootratio(k1,k2,qq,nb=5000):
    out=[]
    for _ in range(nb):
        x1=np.sort(rng.choice(pop[k1],len(pop[k1])))[::-1]; x2=np.sort(rng.choice(pop[k2],len(pop[k2])))[::-1]
        out.append(topn(x1,AREA[k1],qq).mean()/topn(x2,AREA[k2],qq).mean())
    r=topn(pop[k1],AREA[k1],qq).mean()/topn(pop[k2],AREA[k2],qq).mean()
    return r,np.percentile(out,[2.5,97.5])
for qq in (5,10,20):
    for ref in ('ring45-60','belt<15'):
        r,ci=bootratio('caps',ref,qq); print(f'  caps/{ref} q={qq}: mean-ratio {r:.3f}  95% {ci.round(3)}')
    r,ci=bootratio('far<60','near<60',qq); print(f'  far/near q={qq}: mean-ratio {r:.3f}  95% {ci.round(3)}')
print('  expectation: kept size + crowding f -> ratio ~ f^(1/2) (f=1.20 -> 1.10); shrink with surface -> ~1.00')

print('\n== CALC 1b: shape of the family (R-plot) and best shift')
edges=20*2**(np.arange(0,9)/2)   # 20..320, sqrt2 bins
def Rplot(x,A):
    n,_=np.histogram(x,edges); Dm=np.sqrt(edges[:-1]*edges[1:])
    return Dm**3*n/((edges[1:]-edges[:-1])*A), n
for k in REG:
    r,n=Rplot(pop[k],AREA[k]); print(f'  {k:10s} N={n.tolist()}  R={np.round(r*1e-3,2).tolist()}')
# shift test: cumulative distribution in log D; find s minimizing KS distance between log(D) of caps and s*ref, within 20-200 km
def best_shift(x1,x2):
    ss=np.linspace(0.5,1.5,201); best=None
    for s in ss:
        y=x2*s; lo_=max(20,20*s); y=y[(y>=lo_)&(y<200)]; z=x1[(x1>=lo_)&(x1<200)]
        if len(y)<20 or len(z)<20: continue
        # compare shapes (normalized log-D distributions) by KS
        allv=np.sort(np.concatenate([np.log(z),np.log(y)]))
        cz=np.searchsorted(np.sort(np.log(z)),allv,'right')/len(z); cy=np.searchsorted(np.sort(np.log(y)),allv,'right')/len(y)
        ks=np.abs(cz-cy).max()
        if best is None or ks<best[1]: best=(s,ks)
    return best
for k1,k2 in [('caps','ring45-60'),('caps','belt<15'),('far<60','near<60')]:
    s,ks=best_shift(pop[k1],pop[k2])
    bs=[best_shift(rng.choice(pop[k1],len(pop[k1])),rng.choice(pop[k2],len(pop[k2])))[0] for _ in range(300)]
    print(f'  {k1} vs {k2}: best size factor s={s:.3f}  95% {np.percentile(bs,[2.5,97.5]).round(3)}')

# ---------- Wang & Wu depths ----------
ww=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',sep='\t',skiprows=17,header=None,usecols=[1,2,3,4],names=['lon','lat','D','d'])
ww=ww[(ww.D>=4000)&(ww.d>0)].copy(); ww['D']/=1000; ww['d']/=1000
wla=ww.lat.values; wlo=ww.lon.values%360
wok=~ismare(wla,wlo)&~(angd(wla,wlo,-53,191)<39.57)
ww=ww[wok]; wla=ww.lat.values; wlo=ww.lon.values%360; WD=ww.D.values; Wd=ww.d.values; dD=Wd/WD
print('\n== CALC 2: simple-to-complex transition (Wang & Wu depths, clean), N=',len(ww))
bins=np.exp(np.linspace(np.log(4),np.log(60),15)); bc=np.sqrt(bins[:-1]*bins[1:])
def env(k,p=90):
    m=REG[k](wla,wlo); out=[]
    for i in range(len(bins)-1):
        s=m&(WD>=bins[i])&(WD<bins[i+1]); out.append((np.percentile(dD[s],p) if s.sum()>=8 else np.nan, s.sum()))
    return out
for k in REG:
    e=env(k); print(f'  {k:10s} p90 d/D:',' '.join(f'{v:.3f}' if v==v else ' nan ' for v,_ in e),' n:',[n for _,n in e])
print('  bins D(km):',' '.join(f'{x:5.1f}' for x in bc))
# transition fit: piecewise in log: d/D = A for D<Dt ; A*(D/Dt)^(-beta) for D>Dt, on fresh envelope (top 10% per bin)
def fit_Dt(k,mask=None):
    m=REG[k](wla,wlo) if mask is None else mask
    x=[];y=[]
    for i in range(len(bins)-1):
        s=m&(WD>=bins[i])&(WD<bins[i+1])
        if s.sum()<8: continue
        th=np.percentile(dD[s],90); sel=s&(dD>=th); x+=list(np.log(WD[sel])); y+=list(np.log(dD[sel]))
    x=np.array(x);y=np.array(y); best=None
    for lDt in np.linspace(np.log(6),np.log(40),171):
        X=np.where(x<lDt,0,x-lDt)
        Am=np.vstack([np.ones_like(x),-X]).T; coef,res,_,_=np.linalg.lstsq(Am,y,rcond=None)
        r=((Am@coef-y)**2).sum()
        if best is None or r<best[1]: best=(np.exp(lDt),r,coef)
    return best,x,y
DT={}
for k in REG:
    b,x,y=fit_Dt(k)
    m=REG[k](wla,wlo); idx=np.where(m)[0]; bs=[]
    for _ in range(150):
        sm=np.zeros(len(WD),bool); sm[rng.choice(idx,len(idx))]=True
        bs.append(fit_Dt(k,sm)[0][0])
    DT[k]=b[0]
    print(f'  {k:10s} Dt={b[0]:.1f} km  95% {np.percentile(bs,[2.5,97.5]).round(1)}  plateau d/D={np.exp(b[2][0]):.3f} slope={b[2][1]:.2f}')
print('  ratios: caps/ring %.3f caps/belt %.3f far/near %.3f'%(DT['caps']/DT['ring45-60'],DT['caps']/DT['belt<15'],DT['far<60']/DT['near<60']))

print('\n== CALC 4: old vs fresh (freshness = d/D residual from one global d/D-D curve; thirds within each region), D>=20')
gm=WD>=20; co=np.polyfit(np.log(WD[gm]),np.log(dD[gm]),2); res=np.log(dD)-np.polyval(co,np.log(WD))
OR={}
for k in REG:
    m=REG[k](wla,wlo)&gm; r=res[m]; x=WD[m]; lo3,hi3=np.percentile(r,[100/3,200/3])
    old=x[r<=lo3]; fr=x[r>=hi3]; OR[k]=(old,fr)
    print(f'  {k:10s} n={m.sum()} old: mean {old.mean():.1f} med {np.median(old):.1f} | fresh: mean {fr.mean():.1f} med {np.median(fr):.1f} | old/fresh mean {old.mean()/fr.mean():.3f} med {np.median(old)/np.median(fr):.3f}')
def boot(k):
    o,f=OR[k]; return np.array([rng.choice(o,len(o)).mean()/rng.choice(f,len(f)).mean() for _ in range(5000)])
b={k:boot(k) for k in REG}
for k1,k2 in [('caps','ring45-60'),('caps','belt<15'),('far<60','near<60')]:
    dr=b[k1]/b[k2]; r0=(OR[k1][0].mean()/OR[k1][1].mean())/(OR[k2][0].mean()/OR[k2][1].mean())
    print(f'  double ratio {k1}/{k2}: {r0:.3f}  95% {np.percentile(dr,[2.5,97.5]).round(3)}')

print('\n== CALC 3: predicted ellipticity if craters deformed with the surface (radial mapping, a/c=1.69)')
for lat in (5,20,37,52,67,80):
    th=np.deg2rad(90-lat); r=lambda t: 1/np.sqrt(np.sin(t)**2/a**2+np.cos(t)**2/c**2)
    h=1e-6; rp=(r(th+h)-r(th-h))/(2*h); zon=Rs/r(th); mer=Rs/np.sqrt(r(th)**2+rp**2)
    print(f'  lat {lat:2d}: zonal x{zon:.3f} meridional x{mer:.3f} -> e={max(zon,mer)/min(zon,mer):.3f} long axis {"E-W" if zon>mer else "N-S"}')
