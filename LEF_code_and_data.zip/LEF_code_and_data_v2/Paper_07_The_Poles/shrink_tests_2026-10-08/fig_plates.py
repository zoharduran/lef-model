import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Wedge, Circle, Rectangle, FancyArrowPatch
NAVY='#1f2a44'; CREAM='#fbf6e9'; RED='#a8322d'; PLATE='#8a7a5c'; PLATE2='#6d5f45'; FRESH='#e6c98f'; CR='#2b2b2b'
T=110; L=900; NP=8; RC=55   # plate thickness, plate length (km), crater radius (km)
fig,axs=plt.subplots(1,4,figsize=(19,5.4),gridspec_kw={'width_ratios':[1.25,1.05,0.85,0.85]})
fig.patch.set_facecolor('white')
def plate(ax,R,a0,a1,col=PLATE,z=3):
    ax.add_patch(Wedge((0,0),R,a0,a1,width=T,facecolor=col,edgecolor=NAVY,lw=0.8,zorder=z))
def craters(ax,R,a0,a1,r=RC,n=2,z=5):
    for f in np.linspace(0.3,0.7,n):
        a=np.deg2rad(a0+(a1-a0)*f); ax.add_patch(Circle(((R-T*0.35)*np.cos(a),(R-T*0.35)*np.sin(a)),r,facecolor=CR,edgecolor='none',zorder=z))
def frame(ax,title,sub):
    ax.set_aspect('equal'); ax.axis('off')
    ax.set_title(title,fontsize=13,color=NAVY,fontweight='bold',family='monospace',loc='left')
    ax.text(0.0,-0.02,sub,transform=ax.transAxes,fontsize=9.5,color=NAVY,family='monospace',va='top')
# ---- A: dome R=3000, rigid plates with gaps
ax=axs[0]; R=3000; span=np.rad2deg(L/R); gap=(180-NP*span)/(NP+1)
ax.add_patch(Wedge((0,0),R-T,0,180,facecolor=CREAM,edgecolor='none',zorder=1))
ax.add_patch(Wedge((0,0),R,0,180,width=T,facecolor=FRESH,edgecolor='none',zorder=2))
a=gap
for i in range(NP):
    plate(ax,R,a,a+span); craters(ax,R,a,a+span); a+=span+gap
ax.plot([-R,R],[0,0],color=NAVY,lw=2)
ax.add_patch(Rectangle((-1500,-900),3000,900,facecolor='#d9d2c3',edgecolor=NAVY,lw=1))
ax.text(0,-450,'Earth (contact 3,000 km)',ha='center',va='center',fontsize=9,family='monospace',color=NAVY)
ax.annotate('gap: fresh material,\nfew craters',xy=(R*np.cos(np.deg2rad(gap/2+span+gap/2)),R*np.sin(np.deg2rad(span+gap))),xytext=(2300,3300),fontsize=9,family='monospace',color=RED,arrowprops=dict(arrowstyle='->',color=RED))
ax.annotate('rigid plate,\ncraters keep size',xy=(R*np.cos(np.deg2rad(90)),R),xytext=(-3300,3350),fontsize=9,family='monospace',color=NAVY,arrowprops=dict(arrowstyle='->',color=NAVY))
ax.text(0,1200,'dome surface\n5.65×10¹³ m²',ha='center',fontsize=10,family='monospace',color=NAVY)
ax.text(0,250,'base Ø 6,000 km  →  near side',ha='center',fontsize=9,family='monospace',color=NAVY)
ax.set_xlim(-3500,3500); ax.set_ylim(-1000,3800)
frame(ax,'A  Attached: hemisphere r = 3,000 km','1,300 kg/m³ · shell hardened early ·\nplates crack apart as the dome rises')
# ---- B: compaction, gaps close
ax=axs[1]; R=2380; span=np.rad2deg(L/R); gap=(180-NP*span)/(NP+1)
ax.add_patch(Wedge((0,0),R-T,0,180,facecolor=CREAM,edgecolor='none',zorder=1))
ax.add_patch(Wedge((0,0),R,0,180,width=T,facecolor=FRESH,edgecolor='none',zorder=2))
a=gap
for i in range(NP):
    plate(ax,R,a,a+span); craters(ax,R,a,a+span); a+=span+gap
ax.plot([-R,R],[0,0],color=NAVY,lw=2)
for s in (-1,1):
    ax.add_patch(FancyArrowPatch((s*2900,1900),(s*2300,1500),arrowstyle='-|>',mutation_scale=18,color=RED,lw=1.5))
ax.text(0,1000,'gaps close\nplates touch',ha='center',fontsize=10,family='monospace',color=RED)
ax.set_xlim(-3000,3000); ax.set_ylim(-1000,3800)
frame(ax,'B  Compaction','the whole body compacts ·\nplates do not shrink, the gaps do')
# ---- C: Moon r=1737, plates stacked on far side
ax=axs[2]; R=1737; span=np.rad2deg(L/R)
ax.add_patch(Circle((0,0),R,facecolor=CREAM,edgecolor=NAVY,lw=1.2,zorder=1))
ax.add_patch(Wedge((0,0),R,180,360,width=40,facecolor='#c9bfa6',edgecolor='none',zorder=2))
start=(180-6*span)/2; a=start; outer=[]
for i in range(6):
    plate(ax,R,a,a+span,z=4); craters(ax,R,a,a+span,z=6); outer.append(a); a+=span
for k in (1,4):  # under-plates
    pass
for k in (1,4):  # two plates pushed under
    ax.add_patch(Wedge((0,0),R-T,outer[k]+3,outer[k]+span-3,width=T*1.3,facecolor=RED,alpha=0.55,edgecolor=NAVY,lw=0.8,zorder=3))
ax.annotate('plate pushed under:\nthick far-side crust',xy=((R-1.5*T)*np.cos(np.deg2rad(outer[1]+span/2)),(R-1.5*T)*np.sin(np.deg2rad(outer[1]+span/2))),xytext=(-2650,2150),fontsize=9,family='monospace',color=RED,arrowprops=dict(arrowstyle='->',color=RED,connectionstyle='arc3,rad=0.25'))
ax.text(0,700,'FAR SIDE\n1.90×10¹³ m²\n(×0.34)',ha='center',fontsize=9.5,family='monospace',color=NAVY)
ax.text(0,-800,'NEAR SIDE\n(base, ×0.67)',ha='center',fontsize=9.5,family='monospace',color=NAVY)
ax.set_xlim(-2700,2700); ax.set_ylim(-2400,2700)
frame(ax,'C  The Moon r = 1,737 km','3,344 kg/m³ · same craters, same size ·\nexcess area stacked, not squeezed')
# ---- D: rejected soft shell
ax=axs[3]
ax.add_patch(Circle((0,0),R,facecolor=CREAM,edgecolor=NAVY,lw=1.2,zorder=1))
ax.add_patch(Wedge((0,0),R,0,180,width=T*0.8,facecolor=PLATE,edgecolor=NAVY,lw=0.8,zorder=3))
for ang in np.linspace(12,168,19):
    a=np.deg2rad(ang); ax.add_patch(Circle(((R-T*0.3)*np.cos(a),(R-T*0.3)*np.sin(a)),RC*0.58,facecolor=CR,zorder=5))
ax.text(0,-2150,'✗ REJECTED',ha='center',fontsize=14,family='monospace',color=RED,fontweight='bold',zorder=9)
ax.text(0,500,'soft shell:\ncraters ×0.58\ndensity ×3',ha='center',fontsize=9.5,family='monospace',color=NAVY)
ax.text(0,-900,'data: no shrink,\nfar/near density 1.27',ha='center',fontsize=9.5,family='monospace',color=RED)
ax.set_xlim(-2700,2700); ax.set_ylim(-2400,2400)
frame(ax,'D  Rejected reading','five crater tests, 2026-10-08')
plt.tight_layout(rect=(0,0.04,1,1))
fig.text(0.01,0.01,'Rigid plates: craters and their density on each plate are kept; the gaps close first, then plates stack. Crater size, plate thickness and gaps exaggerated; radii to scale (3,000 / 2,380 / 1,737 km).',fontsize=9,family='monospace',color=NAVY)
plt.savefig('/tmp/claude-0/p8/fig/rigid_plates_closure.png',dpi=170)
