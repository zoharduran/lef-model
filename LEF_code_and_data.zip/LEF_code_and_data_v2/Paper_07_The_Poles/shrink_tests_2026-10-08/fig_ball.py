import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle, Circle, FancyArrowPatch
NAVY='#1f2a44'; CREAM='#fbf6e9'; RED='#a8322d'; SAND='#d9a441'; POST='#cfc6b2'; LAVA='#7a2f1c'
RD=4000.; CXD=4000.   # post dome: circle centre (4000,0), radius 4000 -> tip at x=0
def dome_x(y): return CXD-np.sqrt(RD**2-y**2)
fig,axs=plt.subplots(1,5,figsize=(22,5.6))
def post(ax,gap=0):
    t=np.linspace(-np.pi/2+0.0,np.pi/2,200); y=np.linspace(-3700,3700,300)
    xs=dome_x(y)+gap; poly=np.vstack([np.c_[xs,y],[[6200+gap,3700],[6200+gap,-3700]]])
    ax.add_patch(Polygon(poly,closed=True,facecolor=POST,edgecolor=NAVY,lw=1.2,zorder=4))
    ax.text(4700+gap,0,'pear\n→ Earth',ha='center',va='center',fontsize=9,family='monospace',color=NAVY,zorder=5)
def ball(ax,ax_,ay_,h,old_h=None,crat=True,lava=False,label_peel=True):
    # place ellipse so that it meets the dome at y=±h
    xc=dome_x(h)-ax_*np.sqrt(max(0,1-(h/ay_)**2))
    t=np.linspace(0,2*np.pi,600); X=xc+ax_*np.cos(t); Y=ay_*np.sin(t)
    ax.add_patch(Polygon(np.c_[X,Y],closed=True,facecolor=CREAM,edgecolor=NAVY,lw=1.4,zorder=2))
    # contact arc
    y=np.linspace(-h,h,100); ax.plot(dome_x(y),y,color=RED,lw=4,zorder=6,solid_capstyle='butt')
    if old_h:
        m=(X>xc)&(np.abs(Y)>h)&(np.abs(Y)<=min(old_h,ay_))
        for s in (1,-1):
            mm=m&(np.sign(Y)==s); ax.plot(X[mm],Y[mm],color=SAND,lw=6,zorder=3,solid_capstyle='butt')
    if crat:
        for ang in np.deg2rad(np.linspace(110,250,9)):
            ax.add_patch(Circle((xc+0.93*ax_*np.cos(ang),0.93*ay_*np.sin(ang)),110,facecolor='#333',zorder=5))
    return xc
def frame(ax,title,sub,xl=(-6300,6300)):
    ax.set_aspect('equal'); ax.axis('off'); ax.set_xlim(*xl); ax.set_ylim(-5200,4800)
    ax.set_title(title,fontsize=12.5,color=NAVY,fontweight='bold',family='monospace',loc='left')
    ax.text(0.0,0.02,sub,transform=ax.transAxes,fontsize=9,color=NAVY,family='monospace',va='bottom')
# 1 squashed on the post, contact 6000 (curved lower dome)
ax=axs[0]; xc=ball(ax,2300,3400,3000)
post(ax)
ax.text(xc-200,0,'upper dome\n(small)',ha='center',fontsize=9.5,family='monospace',color=NAVY,zorder=7)
ax.annotate('lower dome:\ncontact 6,000 km,\ncurved on the\ntip of the pear',xy=(dome_x(2200),2200),xytext=(-6000,3300),fontsize=9,family='monospace',color=RED,arrowprops=dict(arrowstyle='->',color=RED),zorder=8)
frame(ax,'1  On the tip of the pear','two domes, one on the other;\nthe base hugs the tip of the pear,\nso the upper dome stays small')
# 2 rounding: lower dome peels from the rim inward
ax=axs[1]; xc=ball(ax,2900,3150,2200,old_h=3000)
post(ax)
ax.annotate('peeled annulus\n→ limb belt',xy=(dome_x(2200)-250,2750),xytext=(-6000,3900),fontsize=9,family='monospace',color='#9a6a10',arrowprops=dict(arrowstyle='->',color='#9a6a10'),zorder=8)
ax.text(xc,0,'rounding',ha='center',fontsize=10,family='monospace',color=NAVY,zorder=7)
frame(ax,'2  Rounding and peeling','the big body rounds; the lower\ndome peels from the rim inward\n(continuous, takes long)')
# 3 contact 3000, ball, then flattened, material comes out and settles
ax=axs[2]; xc=ball(ax,2750,2100,1500,old_h=3000,crat=True)
post(ax)
for ang in np.deg2rad([120,160,200,240,95,265]):
    ax.add_patch(Circle((xc+2750*np.cos(ang)*1.0,2100*np.sin(ang)*1.0),230,facecolor=LAVA,alpha=0.85,zorder=6))
ax.annotate('',xy=(xc,2100),xytext=(xc,3300),arrowprops=dict(arrowstyle='-|>',color=NAVY,lw=1.4))
ax.annotate('',xy=(xc,-2100),xytext=(xc,-3300),arrowprops=dict(arrowstyle='-|>',color=NAVY,lw=1.4))
ax.text(xc,3450,'spin axis',ha='center',fontsize=8.5,family='monospace',color=NAVY)
ax.text(xc,-300,'flattened\nmaterial out,\nsettles on it',ha='center',fontsize=9,family='monospace',color=LAVA,zorder=7)
ax.annotate('contact 3,000 km',xy=(dome_x(-900),-900),xytext=(2200,-3400),fontsize=9,family='monospace',color=RED,arrowprops=dict(arrowstyle='->',color=RED),zorder=8)
frame(ax,'3  Ball → flattened','contact 3,000 km held long;\nthe ball flattens with spin and\nmaterial comes out onto it')
# 4 release
ax=axs[3]; R=2400
ax.add_patch(Circle((-600,0),R,facecolor=CREAM,edgecolor=NAVY,lw=1.4,zorder=2))
from matplotlib.patches import Ellipse
ax.add_patch(Ellipse((-600,0),2*2750,2*2100,facecolor='none',edgecolor=NAVY,lw=1,ls='--',zorder=3))
for ang in np.deg2rad(np.linspace(110,250,9)):
    ax.add_patch(Circle((-600+0.93*R*np.cos(ang),0.93*R*np.sin(ang)),110,facecolor='#333',zorder=5))
for ang in np.deg2rad([120,160,200,240,95,265]):
    ax.add_patch(Circle((-600+R*np.cos(ang),R*np.sin(ang)),200,facecolor=LAVA,alpha=0.85,zorder=6))
for s in (1,-1):
    ax.add_patch(FancyArrowPatch((-600,s*3300),(-600,s*2500),arrowstyle='-|>',mutation_scale=15,color=RED,lw=1.4))
post(ax,gap=1500)
ax.text(-600,0,'release;\nflattening\nrelaxes,\nall contracts\na little',ha='center',va='center',fontsize=9,family='monospace',color=NAVY,zorder=7)
frame(ax,'4  Release','the 3,000 km contact lets go;\ndashed: the flattened figure')
# 5 Moon today
ax=axs[4]; R=1737
ax.add_patch(Circle((0,0),R,facecolor=CREAM,edgecolor=NAVY,lw=1.4,zorder=2))
for ang in np.deg2rad(np.r_[np.linspace(60,85,4),np.linspace(95,120,4),np.linspace(240,265,4),np.linspace(275,300,4),[150,180,210]]):
    ax.add_patch(Circle((0.92*R*np.cos(ang),0.92*R*np.sin(ang)),110,facecolor='#333',zorder=5))
ax.text(0,0,'craters kept\ntheir size;\npoles crowded\n(1.20)',ha='center',va='center',fontsize=9,family='monospace',color=NAVY)
ax.text(-R-300,-R-600,'far side',fontsize=9,family='monospace',color=NAVY)
ax.text(R-600,-R-600,'near side → Earth',fontsize=9,family='monospace',color=NAVY)
frame(ax,'5  The Moon','no ×0.58, no ×3:\nthe far side was small from the start',xl=(-6300,6300))
plt.tight_layout(rect=(0,0.05,1,1))
fig.text(0.01,0.012,'Schematic, not to scale. The 6,000 km base is curved on the tip of the pear, not flat; peeling from 6,000 to 3,000 km is one continuous process; the far side was a small dome from the start.',fontsize=9,family='monospace',color=NAVY)
plt.savefig('/tmp/claude-0/p8/fig/ball_on_post.png',dpi=160)
