#!/usr/bin/env python3
"""
p07_recompute_v2.py -- Paper 7 (The Poles), second pass of the stage recompute.
Builds in the author's answers of 18.10.2026:
  1. volume: the stretched body is larger (lighter) than the relaxed sphere; rounding = volume decrease
  2. shape: triaxial a (Earth line) > b (along the orbit) > c (polar) -- an egg combined with a pita
  3. what lets it round: net radial pull on the body (gravity minus centrifugal) vs the differential stretch
  4. geometry of relaxing a stretched/flattened body with a volume decrease

REPORT ONLY. Nothing in the paper is edited.  Run:  python3 p07_recompute_v2.py
Inputs: Robbins_Dge20_selected.csv and neumann_basins_ge500.csv (06_נתונים_משותפים),
        p07_v2_data/mare_grid_0p25.npy (LROC_GLOBAL_MARE_180 rasterised at 0.25 deg, from the
        shared LROC zip). Every number in p07_recompute_v2.md is printed here.
Conventions as in p07_recompute.py and Paper 7 (C.3 density factor; caps >=60 vs belt <15; A.9 caps of 30 deg).
"""
import csv, os
import numpy as np
from scipy.optimize import brentq, fsolve

HERE = os.path.dirname(os.path.abspath(__file__))
SHARED = os.path.join(HERE, '..', '..', '06_נתונים_משותפים')
G = 6.674e-11; M_E = 5.972e24; M_M = 7.342e22; HOUR = 3600.0
def omega(P): return 2*np.pi/(P*HOUR)
def R_of(rho): return (3*M_M/(4*np.pi*rho))**(1/3)
def g_of(rho): return G*M_M/R_of(rho)**2
def r_corot(P): return (G*(M_E+M_M)/omega(P)**2)**(1/3)      # m, two-body (paper: 16,398 km at 5.77 h)
def hr(t): print('\n' + '='*86 + '\n' + t + '\n' + '='*86)

# ------------------------------------------------------------------ data
rows = list(csv.DictReader(open(os.path.join(SHARED, 'Robbins_Dge20_selected.csv'))))
clat = np.array([float(r['LAT_CIRC_IMG']) for r in rows]); clon = np.array([float(r['LON_CIRC_IMG']) for r in rows])
cD = np.array([float(r['DIAM_CIRC_IMG']) for r in rows]); cmare = np.array([r['inside_mare'] == 'True' for r in rows])
basins = list(csv.DictReader(open(os.path.join(SHARED, 'neumann_basins_ge500.csv'))))
def xyz(la, lo):
    la, lo = np.radians(la), np.radians(lo)
    return np.stack([np.cos(la)*np.cos(lo), np.cos(la)*np.sin(lo), np.sin(la)])
def angdist(P, la, lo): return np.degrees(np.arccos(np.clip(np.tensordot(xyz(la, lo), P, 1), -1, 1)))
CP = xyz(clat, clon)
c_in20 = np.zeros(len(rows), bool); c_spa = np.zeros(len(rows), bool)
for b in basins:
    m = angdist(CP, float(b['lat']), float(b['lonE'])) <= float(b['angular_radius_deg'])
    c_in20 |= m
    if b['name'].startswith('South Pole'): c_spa = m
KEEP_A3 = ~(c_in20 | cmare)          # A.3 mask: 20 basins + LROC mare
KEEP_CLEAN = ~(c_spa | cmare)        # D.1 clean: maria + SPA

# grid (0.25 deg, same as the mare raster)
step = 0.25
glon = np.arange(-180+step/2, 180, step); glat = np.arange(-90+step/2, 90, step)
LO, LA = np.meshgrid(glon, glat)
W = np.cos(np.radians(LA))
GP = xyz(LA, LO)
gmare = np.load(os.path.join(HERE, 'p07_v2_data', 'mare_grid_0p25.npy'))
g_in20 = np.zeros(LA.shape, bool); g_spa = np.zeros(LA.shape, bool)
for b in basins:
    m = angdist(GP, float(b['lat']), float(b['lonE'])) <= float(b['angular_radius_deg'])
    g_in20 |= m
    if b['name'].startswith('South Pole'): g_spa = m
GKEEP_A3 = ~(g_in20 | gmare); GKEEP_CLEAN = ~(g_spa | gmare)
AREA = 4*np.pi*1737.4**2/W.sum()/1e6          # 1e6 km^2 per unit weight
CAPS = np.abs(LA) >= 60; BELT = np.abs(LA) < 15
SIX = {'sub': (0, 0), 'anti': (0, 180), 'lead': (0, -90), 'trail': (0, 90), 'N': (90, 0), 'S': (-90, 0)}
SIXC = {k: angdist(GP, *v) <= 30 for k, v in SIX.items()}
SIXCc = {k: angdist(CP, *v) <= 30 for k, v in SIX.items()}

def six_counts(dlo, dhi):
    sel = KEEP_A3 & (cD >= dlo) & (cD < dhi)
    n = {k: int((SIXCc[k] & sel).sum()) for k in SIX}
    A = {k: (W*(SIXC[k] & GKEEP_A3)).sum()*AREA for k in SIX}
    return n, A
def six_ratios(dens):
    po = (dens['N']+dens['S'])/2; si = (dens['lead']+dens['trail'])/2
    return dict(PS=po/si, PE=po/((dens['sub']+dens['anti'])/2), PA=po/dens['anti'], Psub=po/dens['sub'])
def clean_ratio(dlo, dhi):
    sel = KEEP_CLEAN & (cD >= dlo) & (cD < dhi)
    nc = (sel & (np.abs(clat) >= 60)).sum(); nb = (sel & (np.abs(clat) < 15)).sum()
    Ac = (W*(CAPS & GKEEP_CLEAN)).sum(); Ab = (W*(BELT & GKEEP_CLEAN)).sum()
    return (nc/Ac)/(nb/Ab), nc, nb

# ------------------------------------------------------------------ shape -> crowding (C.3 factor on the final sphere)
NX, NY, NZ = GP[0], GP[1], GP[2]
def J(a, b, c):
    Rs = (a*b*c)**(1/3); return Rs*np.sqrt(NX**2/a**2 + NY**2/b**2 + NZ**2/c**2)
def wmean(F, m): return (F*W)[m].sum()/W[m].sum()
def model_caps_belt(a, b, c, keep=None):
    F = J(a, b, c); k = np.ones_like(F, bool) if keep is None else keep
    return wmean(F, CAPS & k)/wmean(F, BELT & k)
def model_six(a, b, c):
    F = J(a, b, c); return six_ratios({k: wmean(F, SIXC[k] & GKEEP_A3) for k in SIX})
def fam(ac, f): return (ac, 1+f*(ac-1), 1.0)

def fit_shape(PS, PE):
    """a/c, b/c such that the masked 30-deg-cap model ratios equal the measured pole/side and pole/ends."""
    def eqs(p):
        a, b = np.exp(p); r = model_six(a, b, 1.0); return [np.log(r['PS']/PS), np.log(r['PE']/PE)]
    s, info, ok, msg = fsolve(eqs, [np.log(max(PE, 1.01)), np.log(max(PS, 1.01))], full_output=True)
    a, b = np.exp(s); return a, b, ok == 1

if __name__ == '__main__':
    P = 5.77; Om = omega(P); rc = r_corot(P)
    hr('0. Checks: the catalogue and mask reproduce Paper 7 (A.9 caps; D.1/D.2 clean ratios)')
    n, A = six_counts(20, 1e9)
    print(' A.9 >=20 km, counts / remaining area (1e6 km2):', '  '.join(f'{k} {n[k]}/{A[k]:.3f}' for k in SIX))
    print('   paper: sub 154/1.042  anti 368/1.668  lead 308/1.765  trail 370/1.468  N 560/2.399  S 322/1.308')
    for lo_, hi_, pap in ((20, 1e9, '1.20'), (20, 30, '1.09'), (30, 40, '1.15'), (40, 60, '1.26'), (60, 100, '1.53'), (100, 300, '1.84')):
        r, nc, nb = clean_ratio(lo_, hi_); print(f'   clean caps/belt {lo_}-{hi_ if hi_<1e8 else "":>4}: {r:.2f} (N {nc}/{nb})  paper {pap}')

    # ============================================================== 1. volume and density
    hr('1. Volume decrease in the rounding: what peak density is consistent')
    print(' rho_p  V_p/V_rel  R_p(km)  linear s=R_rel/R_p  mean area factor s^2  shell x thicker  energy of compaction (J, J/kg, ~K at 1 kJ/kg/K)')
    W0 = 0.6*G*M_M**2
    for rho in (1300, 1600, 2000, 2300, 2600):
        s = R_of(2600)/R_of(rho); dW = W0*(1/R_of(2600) - 1/R_of(rho))
        print(f' {rho:5d} {2600/rho:8.2f} {R_of(rho)/1e3:8,.0f} {s:12.3f} {s*s:14.3f} {1/s**2:12.2f}     {dW:9.2e}  {dW/M_M:9.2e}  {dW/M_M/1000:5.0f}')
    print('\n Can the 1,300 body stand at the peak (centre 100 km inside the line)?')
    for rho in (1300, 2600):
        r = rc - 100e3; R = R_of(rho); g = g_of(rho); mu = G*M_E/r**3
        dR = 10314e3*(2600/rho)**(1/3)
        print(f'  rho {rho}: R {R/1e3:,.0f} km, g {g:.2f}; rigid Roche {dR/1e3:,.0f} km (< {r/1e3:,.0f}: holds itself);'
              f' tide/g {2*mu*R/g:.2f}; k {M_E/(np.pi*rho*r**3):.2f}; eff. g poles {g+mu*R:.2f} sides {g:.2f} ends {g-3*mu*R:.2f} m/s2')
    q = omega(5.5)**2/(np.pi*G*1300)
    print(f'  spin measure at 5.5 h, 1,300: Om^2/piGrho = {q:.3f} (< 0.449, a spin figure exists; Maclaurin a/c 1.69)')

    # ============================================================== 2. shape
    hr('2. Triaxial shape a > b > c fitted to the six caps (A.3 mask), by crater size')
    print(' Measured masked 30-deg caps (density per 1e6 km2) and ratios. PS = poles/sides, PE = poles/(mean of the two ends),')
    print(' PA = poles/anti-Earth end only, Psub = poles/sub-Earth end only.')
    classes = ((20, 1e9, '>=20'), (40, 1e9, '>=40'), (20, 40, '20-40'), (40, 60, '40-60'), (60, 100, '60-100'), (60, 300, '60-300'), (100, 300, '100-300'))
    meas = {}
    for lo_, hi_, lab in classes:
        n, A = six_counts(lo_, hi_); d = {k: n[k]/A[k] for k in SIX}; r = six_ratios(d); meas[lab] = (n, A, r)
        print(f'  {lab:7s} ' + ' '.join(f'{k}:{n[k]:3d}/{d[k]:4.0f}' for k in SIX) +
              f' | PS {r["PS"]:.2f}  PE {r["PE"]:.2f}  PA {r["PA"]:.2f}  Psub {r["Psub"]:.2f}')
    print('\n Fit: a/c, b/c so that the model, averaged over the same masked caps, gives the measured PS and PE (both ends)')
    print(' or PS and PA (far end only, the end that carries no contact disc). Then the model caps(>=60)/belt(<15) on the')
    print(' D.1 clean mask, against the measured clean ratio.')
    print('  class   ends  | a/c   b/c   a/b  (b-c)/(a-c) | predicted caps/belt clean | measured clean')
    rng = np.random.default_rng(7)
    for lo_, hi_, lab in classes:
        n, A, r = meas[lab]; cr = clean_ratio(lo_, hi_)[0]
        for ends, PEv in (('both', r['PE']), ('far', r['PA'])):
            a, b, ok = fit_shape(r['PS'], PEv)
            pred = model_caps_belt(a, b, 1.0, GKEEP_CLEAN)
            print(f'  {lab:7s} {ends:5s} | {a:4.2f}  {b:4.2f}  {a/b:4.2f}  {(b-1)/(a-1) if a>1.001 else float("nan"):8.2f}    |'
                  f' {pred:10.2f}               | {cr:.2f}' + ('' if ok else '  (fit not converged)'))
    print('\n Counting scatter of the fit (Poisson resampling of the six cap counts, 300 draws; 16-84% range):')
    for lab in ('>=20', '60-100', '60-300'):
        n, A, r = meas[lab]; out = []
        for _ in range(300):
            d = {k: rng.poisson(n[k])/A[k] for k in SIX}
            if min(d.values()) <= 0: continue
            rr = six_ratios(d)
            if rr['PE'] <= 1.0 or rr['PS'] <= 0.8: continue
            a, b, ok = fit_shape(rr['PS'], rr['PE'])
            if ok: out.append((a, b, model_caps_belt(a, b, 1.0, GKEEP_CLEAN)))
        o = np.array(out); q16, q84 = np.percentile(o, [16, 84], axis=0)
        print(f'  {lab:7s} a/c {q16[0]:.2f}-{q84[0]:.2f}  b/c {q16[1]:.2f}-{q84[1]:.2f}  predicted caps/belt {q16[2]:.2f}-{q84[2]:.2f}  (n={len(o)})')

    print('\n Family a:b:c = a/c : 1+f(a/c-1) : 1 -- the a/c that gives a clean caps/belt of 1.53 (60-100 km), 1.84, 1.20,')
    print(' with the model averaged on the same clean mask (like for like):')
    print('   f      a/c(1.20)  a/c(1.53)  b/c at 1.53   a:b:c at 1.53')
    for f in (0.19, 0.25, 0.35, 0.5, 0.7, 1.0):
        def inv(t): return brentq(lambda x: model_caps_belt(*fam(x, f), GKEEP_CLEAN)-t, 1.0001, 6)
        x1, x2 = inv(1.20), inv(1.53); a, b, c = fam(x2, f)
        print(f'  {f:4.2f}   {x1:8.2f}  {x2:9.2f}  {b:10.2f}      {a:.2f}:{b:.2f}:1')
    print('\n Linear-theory proportion of the forcing, f = Om^2/(Om^2+3mu), along the approach (5.77 h):')
    for dr in (-3000, -2000, -1000, -500, 0, 210):
        r = rc + dr*1e3; mu = G*M_E/r**3; print(f'   centre {dr:+6d} km from the line ({r/1e3:,.0f} km): f = {Om**2/(Om**2+3*mu):.2f}')

    hr('2b. Like for like at the Earth end: the sub-Earth 30-deg cap (contact disc) removed from the belt, data and model alike')
    SUBg = angdist(GP, 0, 0) <= 30; SUBc = angdist(CP, 0, 0) <= 30
    BK = GKEEP_CLEAN & ~SUBg
    def clean_ratio_x(dlo, dhi):
        sel = KEEP_CLEAN & (cD >= dlo) & (cD < dhi)
        nc = (sel & (np.abs(clat) >= 60)).sum(); nb = (sel & (np.abs(clat) < 15) & ~SUBc).sum()
        return (nc/(W*(CAPS & GKEEP_CLEAN)).sum())/(nb/(W*(BELT & BK)).sum()), nc, nb
    def mcb_x(a, b, c):
        F = J(a, b, c); return wmean(F, CAPS & GKEEP_CLEAN)/wmean(F, BELT & BK)
    print('  class     clean caps/belt: full belt | belt without the sub-Earth cap')
    for lo_, hi_, lab in ((20, 1e9, '>=20'), (20, 30, '20-30'), (30, 40, '30-40'), (40, 60, '40-60'), (60, 100, '60-100'), (100, 300, '100-300')):
        rx = clean_ratio_x(lo_, hi_)
        print(f'  {lab:8s} {clean_ratio(lo_, hi_)[0]:22.2f} | {rx[0]:.2f} (N {rx[1]}/{rx[2]})')
    t = clean_ratio_x(60, 100)[0]
    print(f'\n  Family inversion for the 60-100 km class on the belt without the sub-Earth cap (target {t:.2f}):')
    print('    f     a:b:c          six-cap model PS / PE (measured 60-100: 1.19 / 1.78; 60-300: 1.28 / 1.73)')
    for f in (0.19, 0.35, 0.5, 0.6, 0.7, 1.0):
        x = brentq(lambda x: mcb_x(*fam(x, f))-t, 1.0001, 6); a, b, c = fam(x, f); r = model_six(a, b, c)
        print(f'   {f:4.2f}   {a:.2f}:{b:.2f}:1      {r["PS"]:.2f} / {r["PE"]:.2f}')
    print('\n  D.2 read-back with the triaxial family (belt without the sub-Earth cap, like for like), a:b:c at formation:')
    print('   class     f=0.5             f=0.6             f=0.7')
    for lo_, hi_, lab in ((20, 30, '20-30'), (30, 40, '30-40'), (40, 60, '40-60'), (60, 100, '60-100'), (100, 300, '100-300'), (20, 1e9, '>=20')):
        t = clean_ratio_x(lo_, hi_)[0]; cells = []
        for f in (0.5, 0.6, 0.7):
            try:
                x = brentq(lambda x: mcb_x(*fam(x, f))-t, 1.0001, 6); a, b, c = fam(x, f); cells.append(f'{a:.2f}:{b:.2f}:1')
            except ValueError: cells.append('~1 (round)')
        print(f'   {lab:8s} ' + '   '.join(f'{c_:15s}' for c_ in cells))
    print('\n  Predicted crowding of the proposed peak shape, its neighbours, and the >=20 km six-cap shape:')
    for sh in ((1.75, 1.45, 1.0), (1.64, 1.45, 1.0), (1.95, 1.33, 1.0), (1.37, 1.15, 1.0)):
        r = model_six(*sh)
        print(f'   {sh[0]:.2f}:{sh[1]:.2f}:1  caps/belt full {model_caps_belt(*sh, GKEEP_CLEAN):.2f}, without sub-Earth cap {mcb_x(*sh):.2f};'
              f' six caps PS {r["PS"]:.2f} PE {r["PE"]:.2f} PA {r["PA"]:.2f} Psub {r["Psub"]:.2f}')

    hr('2c. The pita part (b/c) read as a spin figure: Maclaurin density for the measured b/c')
    def macl_rhs(e): return 2*np.sqrt(1-e*e)*(3-2*e*e)/e**3*np.arcsin(e) - 6*(1-e*e)/e**2
    for P_ in (5.5, 5.77):
        cells = []
        for bc in (1.15, 1.33, 1.39, 1.42, 1.45, 1.69):
            e = np.sqrt(1-1/bc**2); cells.append(f'b/c {bc}: {omega(P_)**2/(np.pi*G*macl_rhs(e)):,.0f}')
        print(f'  {P_} h  ' + ' | '.join(cells))
    print(f'  spin measure Om^2/piGrho: 5.5 h at 1,650 = {omega(5.5)**2/(np.pi*G*1650):.2f};  5.77 h at 2,600 = {omega(5.77)**2/(np.pi*G*2600):.2f}')

    # ============================================================== 3. what lets it round
    hr('3. Stretch (gradient) against the net radial pull on the body (centre), 1,000 km inside the line to release')
    rho = 2600; R = R_of(rho); Abase = np.pi*1.5e6**2
    Fbind = 3*G*M_M**2/(16*R**2)
    print(f' Line {rc/1e3:,.0f} km (5.77 h). Base 3,000 km wide: area {Abase:.2e} m2.  rho {rho}, R {R/1e3:,.0f} km, g {g_of(rho):.2f} m/s2.')
    print(f' Self-gravity holding the two halves together: {Fbind:.2e} N  ({Fbind/Abase/1e9:.2f} GPa over the base area).')
    print('  dr(km)   net pull at centre  base load      base     | stretch at the surface  stretch across mid-plane  | ends of body: near / far')
    print('           (m/s2, + = inward)  (N)          (GPa)    | (2mu+Om^2)R  (m/s2)     (N)          (GPa)        | net pull (m/s2, + inward)')
    for dr in (-1000, -750, -500, -250, -100, 0, 100, 210):
        r = rc + dr*1e3; mu = G*M_E/r**3
        an = G*(M_E+M_M)/r**2 - Om**2*r
        st = (2*mu+Om**2)*R; Fst = (2*mu+Om**2)*M_M*3*R/16
        near = G*(M_E+M_M)/(r-R)**2 - Om**2*(r-R); far = G*(M_E+M_M)/(r+R)**2 - Om**2*(r+R)
        print(f'  {dr:+6d} {an:14.3f} {an*M_M:13.2e} {an*M_M/Abase/1e9:8.2f}   | {st:9.3f} {Fst:18.2e} {Fst/Abase/1e9:9.2f}       | {near:6.2f} / {far:6.2f}')
    r1, r2 = rc-1000e3, rc+210e3
    a1 = G*(M_E+M_M)/r1**2-Om**2*r1; a2 = G*(M_E+M_M)/r2**2-Om**2*r2
    s1 = (2*G*M_E/r1**3+Om**2); s2 = (2*G*M_E/r2**3+Om**2)
    print(f'\n Change from -1,000 to +210 km: net pull {a1:.3f} -> {a2:.3f} m/s2 (change {a1-a2:.3f}; sign reverses at the line);')
    print(f'   stretch gradient {s1:.3e} -> {s2:.3e} s^-2 ({100*(1-s2/s1):.1f}% weaker); from the line to +210 km: '
          f'{100*(1-(2*G*M_E/r2**3+Om**2)/(2*G*M_E/rc**3+Om**2)):.1f}% weaker')
    print(f'   change of base load {(a1-a2)*M_M/Abase/1e9:.2f} GPa, against the change of the mid-plane stretch load '
          f'{(s1-s2)*M_M*3*R/16/Abase/1e9:.3f} GPa  (ratio {(a1-a2)/((s1-s2)*3*R/16):.0f})')
    print('\n Stress needed to hold a flattened figure out of round (order of magnitude rho*g*(a_long - c), whole body):')
    for (a, b, c), lab in (((1.69, 1.69, 1.0), 'oblate 1.69'), ((1.75, 1.45, 1.0), 'triaxial 1.75:1.45:1'), ((1.37, 1.15, 1.0), 'triaxial 1.37:1.15:1')):
        for rho_ in (1300, 2600):
            Rs = R_of(rho_); k = Rs/(a*b*c)**(1/3)
            print(f'   {lab:22s} rho {rho_}: a-c = {(a-c)*k/1e3:5,.0f} km,  rho g (a-c) = {rho_*g_of(rho_)*(a-c)*k/1e9:.2f} GPa')
    print('   (shell strength ~0.1 GPa)')

    # ============================================================== 4. geometry of relaxation
    hr('4. Relaxation of a triaxial body to the sphere with a volume decrease: which surface shrinks, which grows')
    print(' Area factor (final / flattened) at a point = s^2 / J, s = R_rel/R_p, J the C.3 density factor.  <1 shrinks, >1 grows.')
    print(' Radius change along each axis: end of a, end of b, pole (km; negative = moves inward).')
    for shape in ((1.75, 1.45, 1.0), (1.37, 1.15, 1.0), (1.69, 1.69, 1.0)):
        a, b, c = shape; Rn = (a*b*c)**(1/3)
        print(f'\n  shape a:b:c = {a}:{b}:{c}   (no part grows if rho_p <= {2600*(Rn/a)**1.5:,.0f})')
        print('   rho_p | area factor pole  side  end   caps-avg  belt-avg | caps/belt (any rho) | surface that grows | radius change a / b / c (km)')
        for rho in (1300, 1600, 2000, 2600):
            Rp = R_of(rho); s = R_of(2600)/Rp
            Jd = J(a, b, c); F = s*s/Jd          # area factor (sphere / flattened) at each point of the final sphere
            grow = (W*(F > 1)).sum()/W.sum()
            k = Rp/Rn
            print(f'   {rho:5d} | {s*s*c/Rn:14.2f} {s*s*b/Rn:5.2f} {s*s*a/Rn:5.2f} {wmean(F, CAPS):8.2f} {wmean(F, BELT):8.2f} |'
                  f' {wmean(Jd, CAPS)/wmean(Jd, BELT):10.2f}          | {100*grow:8.0f}%          |'
                  f' {(R_of(2600)-a*k)/1e3:6,.0f} / {(R_of(2600)-b*k)/1e3:5,.0f} / {(R_of(2600)-c*k)/1e3:5,.0f}')
