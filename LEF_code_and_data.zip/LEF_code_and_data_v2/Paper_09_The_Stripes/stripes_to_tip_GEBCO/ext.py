import numpy as np
R=6371
def v(lon,lat):
    lo,la=np.radians(lon),np.radians(lat);return np.array([np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)])
def ll(p): p=p/np.linalg.norm(p);return np.degrees(np.arctan2(p[1],p[0])),np.degrees(np.arcsin(p[2]))
def dist(a,b): return R*np.arccos(np.clip(np.dot(a,b),-1,1))
foot=v(167.7,8.7); tip=v(-179.5,6.0)
S={'N1 Mendocino':[(-150,39.67),(-160,39.5)],'N2 Murray':[(-150,30.4),(-160,28.8)],'N3 Molokai':[(-150,22.3),(-154,21.9)],
 'N4 Clarion':[(-145,14.9),(-154,14.0)],'N5 Clipperton':[(-144,4.8),(-152,3.8)],
 'C1 Marquesas FZ':[(-128,-9.2),(-141,-11.7)],'C2 Tuamotu chain*':[(-136,-22.8),(-151,-12.8)],'S1 Eltanin-type':[(-130,-53.9),(-162,-48.9)]}
print(f"{'stripe':20s} {'min to footprint':>16s} {'min to tip':>11s}  verdict   passes nearest footprint at")
for k,(e,w) in S.items():
    A=v(*e);B=v(*w);n=np.cross(A,B);n/=np.linalg.norm(n)
    best=(1e9,None);bt=1e9
    for s in np.linspace(0,12000,2401):   # march west from B along great circle
        ang=s/R; t=np.cross(n,B); p=B*np.cos(ang)+t*np.sin(ang)
        d1=dist(p,foot);d2=dist(p,tip)
        if d1<best[0]: best=(d1,ll(p))
        bt=min(bt,d2)
    ver='footprint' if best[0]<=1500 else ('tip' if bt<=3000 else 'misses')
    print(f"{k:20s} {best[0]:13.0f} km {bt:8.0f} km  {ver:9s} ({best[1][1]:.1f}, {best[1][0]:.1f})")
