import numpy as np, math
from PIL import Image, ImageDraw, ImageFont
Image.MAX_IMAGE_PIXELS=None
D='/tmp/claude-0/-home-claude/823d745d-d585-5e62-ab3b-cc648f681ccc/scratchpad/stripes/'
PPD=30; LON0=150.0; LAT0=45.0  # mosaic: lon 150..290 (0-360), lat 45..-65
W=140*PPD; H=110*PPD
def to360(lon): return lon%360
def lon180(l): l=l%360; return l-360 if l>180 else l
def ll2px(lon,lat): return ((to360(lon)-LON0)*PPD, (LAT0-lat)*PPD)
def px2ll(x,y): return lon180(LON0+x/PPD), LAT0-y/PPD
def mosaic():
    try: return np.load(D+'tr/mosaic.npy')
    except Exception: pass
    M=np.full((H,W),np.nan,np.float32)
    for f,lo,la in [('B_small.png',180,0),('A_small.png',180,45),('C_small.png',150,25)]:
        a=np.array(Image.open(D+f).convert('L')).astype(np.float32)
        x0=int((lo-LON0)*PPD); y0=int((LAT0-la)*PPD)
        M[y0:y0+a.shape[0],x0:x0+a.shape[1]]=a
    np.save(D+'tr/mosaic.npy',M); return M
R=6371.
def vec(lon,lat):
    lo,la=np.radians(lon),np.radians(lat);return np.array([np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)])
def unvec(p): p=p/np.linalg.norm(p);return float(np.degrees(np.arctan2(p[1],p[0]))),float(np.degrees(np.arcsin(p[2])))
def gdist(a,b):
    return R*math.acos(max(-1,min(1,float(np.dot(vec(*a),vec(*b))))))
FOOT=(167.7,8.7); TIP=(-179.5,6.0)
def crop(M,lon0,lon1,lat1,lat0,paths=(),out='crop.png',grid=2,scale=2,circles=True):
    """lon0<lon1 (any convention, east of lon0), lat1>lat0"""
    x0,y0=ll2px(lon0,lat1); x1,y1=ll2px(lon1,lat0)
    x0,y0,x1,y1=[int(round(v)) for v in (x0,y0,x1,y1)]
    sub=M[max(y0,0):y1,max(x0,0):x1].copy()
    sub=np.nan_to_num(sub,nan=128)
    lo,hi=np.percentile(sub,1),np.percentile(sub,99)
    sub=np.clip((sub-lo)/(hi-lo+1e-6)*255,0,255).astype(np.uint8)
    im=Image.fromarray(sub).convert('RGB').resize((sub.shape[1]*scale,sub.shape[0]*scale),Image.BILINEAR)
    d=ImageDraw.Draw(im)
    def P(lon,lat):
        x,y=ll2px(lon,lat); return ((x-x0)*scale,(y-y0)*scale)
    g0=math.ceil(lat0/grid)*grid
    for la in np.arange(g0,lat1+1e-9,grid):
        _,y=P(lon0,la); d.line([(0,y),(im.size[0],y)],fill=(255,255,0),width=1); d.text((2,y+1),f'{la:g}',fill=(255,255,0))
    L0=to360(lon0); L1=L0+((to360(lon1)-L0)%360)
    for lo in np.arange(math.ceil(L0/grid)*grid,L1+1e-9,grid):
        x,_=P(lo,lat0); d.line([(x,0),(x,im.size[1])],fill=(255,255,0),width=1); d.text((x+2,2),f'{lon180(lo):g}',fill=(255,255,0))
    cols=[(255,0,0),(0,255,255),(255,0,255),(0,255,0),(255,128,0),(80,160,255)]
    for i,p in enumerate(paths):
        pts=[P(*q) for q in p]
        if len(pts)>1: d.line(pts,fill=cols[i%len(cols)],width=2)
        for q in pts: d.ellipse([q[0]-2,q[1]-2,q[0]+2,q[1]+2],outline=cols[i%len(cols)])
    im.save(D+'tr/'+out); return im.size
