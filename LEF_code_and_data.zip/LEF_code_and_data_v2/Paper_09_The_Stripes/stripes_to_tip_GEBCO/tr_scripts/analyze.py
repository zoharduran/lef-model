import sys,json,csv;import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import *
F=json.load(open(D+'tr/final.json'))
SUP=('cont','weak')
def seglen(r):
    return sum(gdist((r[i]['lon'],r[i]['lat']),(r[i+1]['lon'],r[i+1]['lat'])) for i in range(len(r)-1))
def seg_stats(r):
    st=[d['status'] for d in r[1:]] if r and r[0]['status'] in ('anchor','start') else [d['status'] for d in r]
    st=[s for s in st if s!='start']
    n=len(st); sup=sum(s in SUP for s in st)/max(n,1)
    # gaps: runs of >=4 bridged steps
    gaps=[];i=0
    while i<len(r):
        if r[i]['status']=='bridge':
            j=i
            while j<len(r) and r[j]['status']=='bridge': j+=1
            if j-i>=4:
                a=r[max(i-1,0)];b=r[min(j,len(r)-1)]
                gaps.append(((a['lon'],a['lat']),(b['lon'],b['lat']),gdist((a['lon'],a['lat']),(b['lon'],b['lat']))))
            i=j
        else: i+=1
    return sup,gaps
def gc_fit(pts):
    V=np.array([vec(*p) for p in pts]); n=np.linalg.svd(V)[2][-1]
    # orient so that motion from first to last is positive
    if np.dot(np.cross(V[0],V[-1]),n)<0: n=-n
    return n
def extend(n,p0,maxkm=12000,step=10):
    P=vec(*p0); P=P-np.dot(P,n)*n; P/=np.linalg.norm(P)
    t=np.cross(n,P)
    best_f=(1e9,None); best_t=(1e9,None); end=None
    for s in np.arange(0,maxkm+1,step):
        a=s/R; q=P*math.cos(a)+t*math.sin(a); ll=unvec(q)
        df=gdist(ll,FOOT); dt=gdist(ll,TIP)
        if df<best_f[0]: best_f=(df,ll,s)
        if dt<best_t[0]: best_t=(dt,ll,s)
    return best_f,best_t,unvec(P),unvec(t)
def azimuth(p,q):
    a=vec(*p); b=vec(*q); north=np.array([0,0,1.]); 
    e=np.cross(north,a); e/=np.linalg.norm(e); nn=np.cross(a,e)
    d=b-a; return (math.degrees(math.atan2(np.dot(d,e),np.dot(d,nn))))%360
def analyse(name,segs_use=None,frac=1/3):
    segs=F[name]
    if segs_use is not None: segs=[s for s in segs if s[0] in segs_use]
    allr=[d for sn,k,r in segs for d in r]
    sup=[(d['lon'],d['lat']) for d in allr if d['status'] in SUP]
    if len(sup)<4: return None
    # cumulative length along supported pts
    cum=[0]
    for i in range(1,len(sup)): cum.append(cum[-1]+gdist(sup[i-1],sup[i]))
    L=cum[-1]; last=[p for p,c in zip(sup,cum) if c>=L*(1-frac)]
    if len(last)<3: last=sup[-3:]
    # last reliable: last supported point with >=3 supported among previous 6 steps
    lr=None
    for i in range(len(allr)-1,-1,-1):
        if allr[i]['status'] in SUP:
            win=allr[max(0,i-6):i+1]
            if sum(w['status'] in SUP for w in win)>=3: lr=(allr[i]['lon'],allr[i]['lat']); break
    n=gc_fit(last)
    bf,bt,start,tang=extend(n,lr)
    sv=vec(*start); tv=vec(*tang); tv=tv-np.dot(tv,sv)*sv; tv/=np.linalg.norm(tv)
    az=azimuth(start,unvec(sv*math.cos(0.001)+tv*math.sin(0.001)))
    path_f=min(gdist((d['lon'],d['lat']),FOOT) for d in allr)
    path_t=min(gdist((d['lon'],d['lat']),TIP) for d in allr)
    verdict='footprint' if bf[0]<=1500 else ('tip' if bt[0]<=3000 else 'misses')
    return dict(name=name,last_reliable=lr,az=az,fit_from=last[0],fit_to=last[-1],fit_len=L*frac,
                ext_foot=bf[0],ext_foot_at=bf[1],ext_foot_s=bf[2],ext_tip=bt[0],ext_tip_s=bt[2],path_foot=path_f,path_tip=path_t,verdict=verdict)
if __name__=='__main__':
    out={}
    for k in F:
        for sn,kind,r in F[k]:
            if not r: continue
            sup,g=seg_stats(r)
            print('%-40s %-32s len %5.0f km  supported %3.0f%%  gaps>=200km: %s'%(k,sn,seglen(r),100*sup,'; '.join('(%.1f,%.1f)->(%.1f,%.1f) %.0f km'%(a[0],a[1],b[0],b[1],L) for a,b,L in g)))
    print()
    for k in F:
        a=analyse(k)
        if a is None: print(k,'too few supported points'); continue
        out[k]=a
        sens=[]
        for fr in (0.25,0.5):
            b=analyse(k,frac=fr); sens.append(b['ext_foot']); a['sens_%g'%fr]=(b['ext_foot'],b['ext_tip'],b['verdict'])
        print('%-40s last reliable (%.1f,%.1f) az %3.0f | fit %.0f km | ext->foot %5.0f km at (%.1f,%.1f) after %5.0f km | ext->tip %5.0f km | path min foot %5.0f tip %5.0f | %s | sens 1/4: %s 1/2: %s'%(
            k,a['last_reliable'][0],a['last_reliable'][1],a['az'],a['fit_len'],a['ext_foot'],a['ext_foot_at'][0],a['ext_foot_at'][1],a['ext_foot_s'],a['ext_tip'],a['path_foot'],a['path_tip'],a['verdict'],'%.0f/%.0f %s'%a['sens_0.25'],'%.0f/%.0f %s'%a['sens_0.5']))
    json.dump(out,open(D+'tr/analysis.json','w'),default=float)
