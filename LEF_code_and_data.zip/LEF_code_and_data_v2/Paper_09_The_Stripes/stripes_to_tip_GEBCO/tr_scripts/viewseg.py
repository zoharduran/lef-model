import sys,json;import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)));from common import *
from PIL import ImageDraw
M=np.load(D+'tr/mosaic.npy'); F=json.load(open(D+'tr/final.json'))
def view(keys,box,out,grid=1,scale=2):
    lon0,lon1,lat1,lat0=box
    x0,y0=ll2px(lon0,lat1); x1,y1=ll2px(lon1,lat0)
    crop(M,lon0,lon1,lat1,lat0,[],out,grid=grid,scale=scale)
    im=Image.open(D+'tr/'+out); d=ImageDraw.Draw(im)
    col={'cont':(0,255,0),'weak':(255,200,0),'bridge':(255,0,0),'anchor':(0,200,255),'start':(0,200,255)}
    for k in keys:
        for sn,kind,r in F[k]:
            for q in r:
                x,y=ll2px(q['lon'],q['lat']); x=(x-x0)*scale; y=(y-y0)*scale
                d.ellipse([x-3,y-3,x+3,y+3],outline=col.get(q['status'],(255,255,255)))
    im.save(D+'tr/'+out)
if __name__=='__main__':
    import ast
    view(ast.literal_eval(sys.argv[1]),ast.literal_eval(sys.argv[2]),sys.argv[3],int(sys.argv[4]),int(sys.argv[5]))
