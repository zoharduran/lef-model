import sys,json,csv;import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from analyze import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from guides import CENTRAL,S_UP,S_LOW
A=json.load(open(D+'tr/analysis.json'))
STAT={'cont':'continuous','weak':'continuous_weak','bridge':'bridged','anchor':'anchor','start':'start'}
def ext_points(name):
    a=A[name]; segs=F[name]
    allr=[d for sn,k,r in segs for d in r]
    sup=[(d['lon'],d['lat']) for d in allr if d['status'] in SUP]
    cum=[0]
    for i in range(1,len(sup)): cum.append(cum[-1]+gdist(sup[i-1],sup[i]))
    last=[p for p,c in zip(sup,cum) if c>=cum[-1]*2/3]
    n=gc_fit(last); P=vec(*a['last_reliable']); P=P-np.dot(P,n)*n; P/=np.linalg.norm(P); t=np.cross(n,P)
    smax=min(12000,a['ext_foot_s']+800)
    return [unvec(P*math.cos(s/R)+t*math.sin(s/R)) for s in np.arange(0,smax+1,50)]
rows=[]
for k in F:
    for sn,kind,r in F[k]:
        for d in r:
            rows.append([k,sn,'%.3f'%d['lon'],'%.3f'%d['lat'],STAT.get(d['status'],d['status']),'' if d['ratio'] is None else '%.2f'%d['ratio']])
    if k in A:
        for lo,la in ext_points(k):
            rows.append([k,'great-circle extension (last 1/3)','%.3f'%lo,'%.3f'%la,'gc_extension',''])
with open(D+'traced_paths.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['name','segment','lon','lat','status','line_contrast_ratio']); w.writerows(rows)
# ---------------- map ----------------
M=np.load(D+'tr/mosaic.npy')[::3,::3]
lo,hi=np.nanpercentile(M,1),np.nanpercentile(M,99)
fig,ax=plt.subplots(figsize=(16,12.6),dpi=110)
ax.imshow(np.nan_to_num(np.clip((M-lo)/(hi-lo),0,1),nan=0.55),cmap='gray',extent=[150,290,-65,45],origin='upper',interpolation='bilinear')
def L(lon): return np.asarray(lon)%360
def circle(c,rkm):
    C=vec(*c); e=np.cross([0,0,1],C); e/=np.linalg.norm(e); nn=np.cross(C,e); a=rkm/R
    pts=[unvec(C*math.cos(a)+math.sin(a)*(math.cos(b)*e+math.sin(b)*nn)) for b in np.linspace(0,2*np.pi,361)]
    return [p[0] for p in pts],[p[1] for p in pts]
for c,rk,col,lab in [(FOOT,1500,'#ffd400','final-contact footprint (r 1,500 km)'),(TIP,3000,'#ff7a00','tip of the pear (r 3,000 km)')]:
    x,y=circle(c,rk); ax.plot(L(x),y,color=col,lw=2.2,label=lab); ax.plot(L(c[0]),c[1],'+',color=col,ms=14,mew=2.5)
cols={'CENTRAL Easter-Tuamotu-Line':'#e6194b','CENTRAL alt: W branch at 11N':'#e6194b','S_UP Eltanin-N + Louisville':'#3cb4ff','S_UP alt east: FZ at 48-51S':'#3cb4ff',
 'S_UP north dash: Tuvalu-Gilbert-Ratak':'#3cb4ff','S_LOW Eltanin-S + NW limb':'#b45cff','N1 Mendocino':'#3cff6e','N2 Murray':'#3cff6e','N3 Molokai':'#3cff6e','N4 Clarion':'#3cff6e','N5 Clipperton':'#3cff6e',
 'CTRL Pioneer FZ':'#ffffff','CTRL Marquesas FZ':'#ffffff','CTRL Galapagos FZ':'#ffffff'}
for k in F:
    col=cols[k]
    for sn,kind,r in F[k]:
        if 'Line Islands to 11N'==sn: continue
        for i in range(len(r)-1):
            a,b=r[i],r[i+1]
            if abs(a['lon']-b['lon'])>20 and (L(a['lon'])-L(b['lon']))>180: continue
            sup=b['status'] in SUP
            ax.plot(L([a['lon'],b['lon']]),[a['lat'],b['lat']],color=col,lw=2.4 if sup else 1.2,ls='-' if sup else (0,(2,2)),alpha=1 if sup else 0.9)
    if k in A and not k.startswith('CENTRAL alt'):
        e=ext_points(k); ax.plot(L([p[0] for p in e]),[p[1] for p in e],color=col,lw=1.0,ls=':',alpha=0.9)
        lr=A[k]['last_reliable']; ax.plot(L(lr[0]),lr[1],'o',mfc='none',mec=col,ms=7,mew=1.6)
# connect S_UP bridge Louisville -> Tuvalu
ax.plot(L([-175.2,179.4]),[-26.0,-10.0],color='#3cb4ff',lw=1.0,ls=(0,(1,3)))
for g,ls in [(CENTRAL,'-'),(S_UP,'-'),(S_LOW,'-')]:
    ax.plot(L([p[0] for p in g]),[p[1] for p in g],color='#ffd400',lw=0.8,ls=(0,(6,4)),alpha=0.55)
from matplotlib.lines import Line2D
h=[Line2D([],[],color='#e6194b',lw=2.4,label='central curve (Sala y Gomez - Easter - Tuamotu - Line Is.)'),
   Line2D([],[],color='#3cb4ff',lw=2.4,label='southern upper (Eltanin-N FZ + Louisville; Tuvalu-Gilbert-Ratak dash)'),
   Line2D([],[],color='#b45cff',lw=2.4,label='southern lower (Eltanin-S FZ; drawn NW limb)'),
   Line2D([],[],color='#3cff6e',lw=2.4,label='northern FZs (Mendocino, Murray, Molokai, Clarion, Clipperton)'),
   Line2D([],[],color='#ffffff',lw=2.4,label='controls (Pioneer, Marquesas, Galapagos FZ)'),
   Line2D([],[],color='#aaaaaa',lw=2.4,label='solid: data-supported step'),
   Line2D([],[],color='#aaaaaa',lw=1.2,ls=(0,(2,2)),label='dashed: bridged (no line contrast)'),
   Line2D([],[],color='#aaaaaa',lw=1.0,ls=':',label='dotted: great-circle extension of last 1/3'),
   Line2D([],[],color='#ffd400',lw=0.8,ls=(0,(6,4)),label="author's drawn curves (georeferenced, +-2 deg)"),
   Line2D([],[],color='#ffd400',lw=2.2,label='footprint circle (8.7N 167.7E, 1,500 km)'),
   Line2D([],[],color='#ff7a00',lw=2.2,label='tip circle (6N 179.5W, 3,000 km)')]
ax.legend(handles=h,loc='lower left',fontsize=8.5,framealpha=0.85)
ax.set_xlim(150,290); ax.set_ylim(-65,45)
xt=np.arange(150,291,10); ax.set_xticks(xt); ax.set_xticklabels([('%dE'%x if x<=180 else '%dW'%(360-x)) if x not in (180,) else '180' for x in xt])
yt=np.arange(-60,46,10); ax.set_yticks(yt); ax.set_yticklabels(['%d%s'%(abs(y),'N' if y>0 else ('S' if y<0 else '')) for y in yt])
ax.grid(color='#888',lw=0.4,alpha=0.5)
ax.set_title('Traced Pacific lineaments over GEBCO 2026 hillshade (plate carree) with great-circle extensions and target circles',fontsize=11)
plt.tight_layout(); plt.savefig(D+'traced_map.png'); print('ok',len(rows))
