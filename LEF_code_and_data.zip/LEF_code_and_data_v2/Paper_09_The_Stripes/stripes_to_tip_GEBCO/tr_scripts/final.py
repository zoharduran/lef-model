import sys;import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from guided import *
import json
CURVES={}   # name -> list of (segment_name, kind, rec)
def auto(st,hd,eastlim=None,nw=200,ne=80,maxgap=16,westlim=None):
    r=both(st,hd,nw=nw,ne=ne,eastlim=eastlim,maxgap=maxgap)
    if westlim is not None:
        r=[d for d in r if not (d['lon']<westlim and d['lon']<0)]
    return r
def G(anchors): return gtrace(anchors)
def bridge(a,b):
    return [dict(lon=a[0],lat=a[1],ratio=np.nan,status='bridge',hd=np.nan),dict(lon=b[0],lat=b[1],ratio=np.nan,status='bridge',hd=np.nan)]
# ---------------- CENTRAL (Easter - Sala y Gomez - Tuamotu - Line Islands) -------------
c=[]
c.append(('coast->SalaYGomez','guided',G([(-71.8,-25.3),(-76,-25.4),(-80,-25.6),(-82.0,-25.0)])))
c.append(('SalaYGomez-Easter','guided',G([(-82.0,-25.0),(-86,-25.2),(-90,-25.1),(-95,-25.3),(-100,-25.6),(-105,-26.3),(-109.4,-27.0)])))
c.append(('Easter microplate / EPR','guided',G([(-109.4,-27.0),(-114.2,-26.5)])))
c.append(('west of EPR -> Gambier','guided',G([(-114.2,-26.5),(-118,-25.6),(-122,-24.6),(-125,-24.8),(-128.7,-24.3),(-133.3,-23.2),(-136,-22.6)])))
c.append(('Tuamotu','guided',G([(-136,-22.6),(-140,-20.5),(-145,-17.2),(-149.5,-14.3)])))
c.append(('Line Islands','guided',G([(-149.5,-14.3),(-149.7,-10.7),(-151.3,-8),(-152.3,-6),(-155,-4),(-157.7,1.5),(-160,5),(-162,7),(-164,9.5),(-166,11),(-168,14),(-169.5,16.7)])))
CURVES['CENTRAL Easter-Tuamotu-Line']=c
_li=[d for d in c[-1][2] if d['lat']<=11.05]
CURVES['CENTRAL alt: W branch at 11N']=c[:-1]+[('Line Islands to 11N','guided',_li),('Line Is. W branch','guided',G([(-166,11),(-169,11.3),(-172.5,11.5)]))]
# ---------------- S_UP (Eltanin-N FZ + Louisville chain) ---------------------------
s=[]
s.append(('Eltanin-N FZ','auto',auto((-130,-54.6),165,eastlim=-108,nw=160,ne=60)))
s.append(('Louisville chain','guided',G([(-148.8,-48.2),(-154.3,-46.0),(-157.7,-45.4),(-161.3,-43.5),(-166,-40.3),(-168,-38.3),(-170,-35),(-172,-32),(-173,-30),(-174,-27.3),(-175.2,-26.0)])))
CURVES['S_UP Eltanin-N + Louisville']=s
CURVES['S_UP alt east: FZ at 48-51S']=[('FZ 48-51S','auto',auto((-114,-49.8),170,eastlim=-100,nw=160,ne=60))]
CURVES['S_UP north dash: Tuvalu-Gilbert-Ratak']=[('Tuvalu-Gilbert-Marshall','guided',G([(179.4,-10),(178,-7.5),(176.3,-5),(175.3,-2.5),(174,-1),(173,2),(172.7,4),(171.7,6.3),(171,7.7),(170,9),(168,11)]))]
# ---------------- S_LOW (Eltanin-S + drawn NW limb) -----------------------------------
l=[]
l.append(('Eltanin-S FZ','auto',[d for d in auto((-130,-58.8),168,eastlim=-108,nw=160,ne=60) if d['lat']>-62]))
l.append(('drawn NW limb to Kermadec','guided',G([(-159.5,-51.4),(-165.7,-43.9),(-167.2,-42.6),(-175.5,-33.9)])))
CURVES['S_LOW Eltanin-S + NW limb']=l
# ---------------- NORTH FZs -----------------------------------------------------------
CURVES['N1 Mendocino']=[('Mendocino','auto',auto((-140,40.0),180,eastlim=-125.5,maxgap=16)),
                        ('Mendocino W (SW-trending strand)','guided',G([(-153,40.4),(-156.7,38.8),(-163,37.8),(-169,36.8),(-173.5,35.8)]))]
CURVES['N2 Murray']=[('Murray','auto',auto((-140,32.0),190,eastlim=-119,maxgap=16,westlim=-171))]
CURVES['N3 Molokai']=[('Molokai','auto',auto((-140,22.4),190,eastlim=-116,maxgap=16))]
CURVES['N4 Clarion']=[('Clarion','auto',auto((-140,15.8),192,eastlim=-114,maxgap=16)),
                      ('Clarion W','guided',G([(-150.3,13.8),(-156,13.9),(-161.7,14.2)]))]
CURVES['N5 Clipperton']=[('Clipperton','auto',auto((-144,4.8),187,eastlim=-108,maxgap=16)),
                         ('Clipperton W to Line Is.','guided',G([(-144,4.8),(-150,3.9),(-156,2.3),(-157.4,1.8)])),
                         ('beyond Line Is. (ridge WSW)','guided',G([(-157.4,1.8),(-160,1.0),(-163,0.5),(-166,0.0)]))]
# ---------------- CONTROLS -----------------------------------------------------------
CURVES['CTRL Pioneer FZ']=[('Pioneer','auto',auto((-140,38.4),180,eastlim=-124,maxgap=16))]
CURVES['CTRL Marquesas FZ']=[('Marquesas','auto',auto((-130,-8.9),196,eastlim=-110,maxgap=16))]
CURVES['CTRL Galapagos FZ']=[('Galapagos','auto',auto((-139.7,-3.2),195,eastlim=-100,maxgap=16))]
def clean(d): return {kk:(None if (isinstance(v,float) and np.isnan(v)) else (float(v) if not isinstance(v,str) else v)) for kk,v in d.items()}
json.dump({k:[(sn,kind,[clean(d) for d in r]) for sn,kind,r in v] for k,v in CURVES.items()},open(D+'tr/final.json','w'))
for k,v in CURVES.items():
    print('==',k)
    for sn,kind,r in v:
        if not r: print('  ',sn,'EMPTY'); continue
        print('   %-34s %-6s n=%3d  %s'%(sn,kind,len(r),s2(r) if kind=='auto' else ''.join({'cont':'C','weak':'w','bridge':'-','anchor':'A'}[d['status']] for d in r)))
        print('      from %.1f,%.1f to %.1f,%.1f'%(r[0]['lon'],r[0]['lat'],r[-1]['lon'],r[-1]['lat']))
