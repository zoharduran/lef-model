import sys; import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import *
F=np.load(D+'tr/feat.npz'); COH=F['coh']; LANG=F['lang']; EN=F['energy']; NAN=F['nan']
def samp(A,x,y):
    xi=int(round(x)); yi=int(round(y))
    if xi<0 or yi<0 or xi>=A.shape[1] or yi>=A.shape[0]: return np.nan
    return A[yi,xi]
def seg_score(p,q,n=6):
    ang=math.atan2(q[1]-p[1],q[0]-p[0]); tot=0; al=0; co=0; en=0
    for t in np.linspace(0,1,n):
        x=p[0]+t*(q[0]-p[0]); y=p[1]+t*(q[1]-p[1])
        c=samp(COH,x,y); l=samp(LANG,x,y); e=samp(EN,x,y)
        if np.isnan(c) or samp(NAN,x,y): return 0,0,0,0
        a=math.cos(l-ang)**2
        tot+=c*min(e,1.5)*a; al+=a; co+=c; en+=e
    return tot/n, al/n, co/n, en/n
def trace(start,heading_deg,nsteps,step=15,off=7,lam=0.004,maxturn=8,guide=None,gw=0.0,gtol=2.0,stop=None):
    """start lon,lat; heading in map degrees: 0=east,90=north,180=west. returns list of dicts"""
    x,y=ll2px(*start); th=math.radians(-heading_deg)  # pixel angle (y down)
    out=[dict(lon=start[0],lat=start[1],score=np.nan,al=np.nan,coh=np.nan,en=np.nan,hd=heading_deg)]
    G=None
    if guide is not None:
        G=np.array([ll2px(*g) for g in guide])
    for k in range(nsteps):
        best=None
        for o in range(-off,off+1):
            for dth in (-4,0,4):
                t2=th+math.radians(dth)
                qx=x+step*math.cos(t2)-o*math.sin(t2); qy=y+step*math.sin(t2)+o*math.cos(t2)
                sc,al,co,en=seg_score((x,y),(qx,qy))
                v=sc-lam*abs(o)
                if G is not None and gw>0:
                    dmin=np.min(np.hypot(G[:,0]-qx,G[:,1]-qy))/PPD
                    v-=gw*max(0,dmin-gtol)
                if best is None or v>best[0]: best=(v,qx,qy,sc,al,co,en)
        _,qx,qy,sc,al,co,en=best
        ang=math.atan2(qy-y,qx-x)
        l=samp(LANG,qx,qy)
        # choose branch of l closest to ang
        d=(l-ang+math.pi/2)%math.pi-math.pi/2
        newth=ang+0.5*d
        dt=(newth-th+math.pi)%(2*math.pi)-math.pi
        dt=max(-math.radians(maxturn),min(math.radians(maxturn),dt))
        th=th+dt; x,y=qx,qy
        lon,lat=px2ll(x,y)
        out.append(dict(lon=lon,lat=lat,score=sc,al=al,coh=co,en=en,hd=-math.degrees(th)%360))
        if stop and stop(lon,lat): break
    return out
