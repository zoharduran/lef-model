import sys; import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import *
from scipy import ndimage as nd
def build():
    M=mosaic(); nan=np.isnan(M)
    A=M.copy(); A[nan]=np.nanmean(M)
    hp=A-nd.gaussian_filter(A,12)
    gx=nd.sobel(nd.gaussian_filter(hp,1.0),1); gy=nd.sobel(nd.gaussian_filter(hp,1.0),0)
    s=5
    Jxx=nd.gaussian_filter(gx*gx,s); Jyy=nd.gaussian_filter(gy*gy,s); Jxy=nd.gaussian_filter(gx*gy,s)
    tr=Jxx+Jyy; det=np.sqrt((Jxx-Jyy)**2+4*Jxy**2)
    coh=det/(tr+1e-6)
    # dominant gradient angle; lineament orientation is perpendicular
    gang=0.5*np.arctan2(2*Jxy,Jxx-Jyy)
    lang=gang+np.pi/2   # in pixel coords (x right, y down)
    energy=np.sqrt(tr)
    energy=energy/np.nanpercentile(energy,90)
    coh[nan]=0; energy[nan]=0
    np.savez_compressed(D+'tr/feat.npz',coh=coh.astype(np.float32),lang=lang.astype(np.float32),energy=energy.astype(np.float32),nan=nan)
if __name__=='__main__': build()
