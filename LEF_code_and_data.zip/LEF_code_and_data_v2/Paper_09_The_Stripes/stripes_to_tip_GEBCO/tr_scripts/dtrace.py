import sys; import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from common import *
from scipy import ndimage as nd
try:
    HP=np.load(D+'tr/HP.npy'); NAN=np.load(D+'tr/NAN.npy'); RG=None; NANF=NAN.astype(np.float32)
except Exception:
    M=mosaic(); NAN=np.isnan(M); A=M.copy(); A[NAN]=np.nanmean(M)
    HP=(A-nd.gaussian_filter(A,15)).astype(np.float32)
    RG=nd.gaussian_filter(np.abs(HP),4).astype(np.float32)   # roughness (seamount chains)
    np.savez_compressed(D+'tr/hp.npz',hp=HP,rg=RG,nan=NAN)
def lineprof(cx,cy,th,offs,L,img):
    """along-line mean of img for lines centred at (cx,cy)+o*n, direction th, length L px"""
    t=np.linspace(-L/2,L/2,int(L)+1)
    ux,uy=math.cos(th),math.sin(th); nx,ny=-uy,ux
    X=cx+offs[:,None]*nx+t[None,:]*ux; Y=cy+offs[:,None]*ny+t[None,:]*uy
    v=nd.map_coordinates(img,[Y.ravel(),X.ravel()],order=1,mode='nearest').reshape(X.shape)
    nn=nd.map_coordinates(NANF,[Y.ravel(),X.ravel()],order=0,mode='nearest').reshape(X.shape)
    return v.mean(1), nn.mean(1)
def dtrace(start,heading,nsteps,step=15,W=18,L=36,mode='fz',dturn=(-6,-3,0,3,6),lam=0.02,fitn=4,stop=None,thr=2.0,guide=None,gtol=2.5,gw=0.0):
    x,y=ll2px(*start); th=math.radians(-heading)
    pts=[(x,y)]; rec=[dict(lon=start[0],lat=start[1],ratio=np.nan,hd=heading,off=0)]
    offs=np.arange(-W,W+1,1.0)
    G=None if guide is None else np.array([ll2px(*g) for g in guide])
    for k in range(nsteps):
        qx=x+step*math.cos(th); qy=y+step*math.sin(th)
        best=None
        for d in dturn:
            t2=th+math.radians(d)
            if mode=='fz':
                p,nn=lineprof(qx,qy,t2,offs,L,HP)
                e=np.abs(np.gradient(p))
                e=nd.uniform_filter1d(e,3)
            else:
                p,nn=lineprof(qx,qy,t2,offs,L,RG); e=p.copy()
            e[nn>0.2]=0
            base=np.median(e)+1e-6
            r=e/base
            sc=r-lam*np.abs(offs)
            if G is not None and gw>0:
                nxv,nyv=-math.sin(t2),math.cos(t2)
                for i,o in enumerate(offs):
                    px_,py_=qx+o*nxv,qy+o*nyv
                    dm=np.min(np.hypot(G[:,0]-px_,G[:,1]-py_))/PPD
                    sc[i]-=gw*max(0,dm-gtol)
            i=int(np.argmax(sc))
            if best is None or sc[i]>best[0]: best=(sc[i],r[i],offs[i],t2)
        _,ratio,o,t2=best
        nxv,nyv=-math.sin(t2),math.cos(t2)
        if ratio<thr:   # no feature: continue straight (bridge)
            nx_,ny_=qx,qy
        else:
            nx_,ny_=qx+o*nxv,qy+o*nyv
        pts.append((nx_,ny_)); x,y=nx_,ny_
        # heading from last fitn points
        P=np.array(pts[-(fitn+1):])
        if len(P)>=3:
            v=P[-1]-P[0]; th_new=math.atan2(v[1],v[0])
            dt=(th_new-th+math.pi)%(2*math.pi)-math.pi
            th+=max(-math.radians(6),min(math.radians(6),dt))
        lon,lat=px2ll(x,y)
        rec.append(dict(lon=lon,lat=lat,ratio=ratio,hd=-math.degrees(th)%360,off=o if ratio>=thr else 0))
        if stop and stop(lon,lat): break
    return rec
def runs(rec,thr=2.0):
    s=''.join('C' if r['ratio']>=thr else ('-' if not np.isnan(r['ratio']) else 'S') for r in rec); return s
def cont_metric(rec,L=60,half=40,near=5):
    P=np.array([ll2px(d['lon'],d['lat']) for d in rec])
    # smooth path
    if len(P)>=5:
        Ps=np.c_[nd.uniform_filter1d(P[:,0],5,mode='nearest'),nd.uniform_filter1d(P[:,1],5,mode='nearest')]
    else: Ps=P
    offs=np.arange(-half,half+1,1.0); out=[]
    for i in range(len(P)):
        a=Ps[max(i-2,0)]; b=Ps[min(i+2,len(P)-1)]
        th=math.atan2(b[1]-a[1],b[0]-a[0])
        p,nn=lineprof(Ps[i,0],Ps[i,1],th,offs,L,HP)
        e=nd.uniform_filter1d(np.abs(np.gradient(p)),3)
        if nn.max()>0.3: out.append(np.nan); continue
        c=e[half-near:half+near+1].max(); out.append(c/np.median(e))
    return np.array(out)
