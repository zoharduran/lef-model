import sys;import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)));from t3 import *
import json
def label(r):
    for d in r:
        if d['status']=='cont': d['status']='cont' if d['ratio']>=4.5 else 'weak'
    return r
def s2(r): return ''.join({'cont':'C','weak':'w','bridge':'-','start':'S','nodata':'X'}[d['status']] for d in r)
def clean(d): return {kk:(None if (isinstance(v,float) and np.isnan(v)) else (float(v) if not isinstance(v,str) else v)) for kk,v in d.items()}
def both(st,hd,nw=200,ne=80,eastlim=None,**kw):
    w=label(t3trace(st,hd,nw,**kw))
    e=label(t3trace(st,(hd+180)%360,ne,stop=(lambda lo,la: eastlim is not None and lo>eastlim),**kw))
    return e[::-1][:-1]+w
