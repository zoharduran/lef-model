import sys;import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)));from lab import *
def gtrace(anchors,step=15,dmax=10,omax=12,L=75,pull=0.08):
    """follow lineament through visually chosen anchors (lon,lat). At each 0.5deg step the position snaps
    to the strongest line in a fan of look-ahead lines around the bearing to the next anchor.
    status: cont (ratio>=4.5), weak (4-4.5), bridge (<4: position kept on the straight anchor line)"""
    A=[ll2px(*a) for a in anchors]
    x,y=A[0]; rec=[dict(lon=anchors[0][0],lat=anchors[0][1],ratio=np.nan,status='anchor',hd=np.nan)]
    j=1
    while j<len(A):
        tx,ty=A[j]; dist=math.hypot(tx-x,ty-y)
        if dist<step*0.8:
            j+=1; continue
        th=math.atan2(ty-y,tx-x)
        b=fan(x,y,th,L=L,dmax=dmax,omax=omax)
        st='bridge'; ratio=np.nan if b is None else b[1]
        nx_=x+step*math.cos(th); ny_=y+step*math.sin(th)
        if b is not None and b[1]>=4.0:
            _,r,o,t2=b
            cx=x-o*math.sin(t2)+step*math.cos(t2); cy=y+o*math.cos(t2)+step*math.sin(t2)
            # keep within a corridor around the anchor line (pull limits drift)
            nx_=cx*(1-pull)+nx_*pull; ny_=cy*(1-pull)+ny_*pull
            st='cont' if r>=4.5 else 'weak'
        x,y=nx_,ny_
        lon,lat=px2ll(x,y)
        rec.append(dict(lon=lon,lat=lat,ratio=ratio,status=st,hd=-math.degrees(th)%360))
    return rec
def gaps(rec,stepdeg=0.5):
    """list bridged runs: (start lon,lat, end lon,lat, length km)"""
    out=[];i=0
    while i<len(rec):
        if rec[i]['status']=='bridge':
            j=i
            while j<len(rec) and rec[j]['status']=='bridge': j+=1
            a=rec[i-1] if i>0 else rec[i]; b=rec[j] if j<len(rec) else rec[j-1]
            out.append(((a['lon'],a['lat']),(b['lon'],b['lat']),gdist((a['lon'],a['lat']),(b['lon'],b['lat'])),j-i))
            i=j
        else: i+=1
    return out
