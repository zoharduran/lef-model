import sys;import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)));from lab import *
from guides import *
starts={'Eltanin-N (-54.6 @130W)':((-130,-54.6),165,-108),'Eltanin-S (-58.8 @130W)':((-130,-58.8),168,-108),'LineA (-49.8 @114W)':((-114,-49.8),170,-100)}
out={}
for k,(st,hd,el) in starts.items():
    r=both(st,hd,nw=160,ne=60,eastlim=el,maxgap=16); out[k]=r
    print(k,len(r),s2(r))
    print('   ',' '.join('%.1f,%.1f'%(d['lon'],d['lat']) for d in r[::8]),' WEST END %.1f,%.1f hd %.0f'%(r[-1]['lon'],r[-1]['lat'],r[-1]['hd']))
json.dump({k:[clean(d) for d in r] for k,r in out.items()},open(D+'tr/S_auto.json','w'))
M=np.load(D+'tr/mosaic.npy')
crop(M,-180,-100,-20,-62,[[(d['lon'],d['lat']) for d in r] for r in out.values()]+[S_UP,S_LOW],'S_auto.png',grid=5,scale=1)
