import sys; import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from dtrace import *
def fan(x,y,th,L=75,dmax=10,dstep=1,omax=6,half=30):
    """look-ahead lines from (x,y): return best (ratio,offset,heading)"""
    offs=np.arange(-(half+omax),half+omax+1,1.0); best=None
    t=np.linspace(0,L,int(L)+1)
    for d in np.arange(-dmax,dmax+0.01,dstep):
        t2=th+math.radians(d); ux,uy=math.cos(t2),math.sin(t2); nx,ny=-uy,ux
        X=x+offs[:,None]*nx+t[None,:]*ux; Y=y+offs[:,None]*ny+t[None,:]*uy
        v=nd.map_coordinates(HP,[Y.ravel(),X.ravel()],order=1,mode='nearest').reshape(X.shape)
        nn=nd.map_coordinates(NANF,[Y.ravel(),X.ravel()],order=0,mode='nearest').reshape(X.shape)
        p=v.mean(1); e=nd.uniform_filter1d(np.abs(np.gradient(p)),3); bad=nn.mean(1)
        c0=half+omax
        for o in range(-omax,omax+1):
            i=c0+o
            if bad[i-half:i+half+1].max()>0.3: continue
            r=e[i-2:i+3].max()/np.median(e[i-half:i+half+1])
            sc=r-0.02*abs(o)-0.01*abs(d)
            if best is None or sc>best[0]: best=(sc,r,o,t2)
    return best
def t3trace(start,heading,nsteps,step=15,thr=4.0,maxgap=10,stop=None,L=75,dmax=10,omax=6,maxturn=5):
    x,y=ll2px(*start); th=math.radians(-heading)
    rec=[dict(lon=start[0],lat=start[1],ratio=np.nan,status='start',hd=heading)]; gap=0
    for k in range(nsteps):
        b=fan(x,y,th,L=L,dmax=dmax,omax=omax)
        if b is None:
            st='nodata'; ratio=np.nan; x+=step*math.cos(th); y+=step*math.sin(th)
        else:
            _,ratio,o,t2=b
            if ratio>=thr:
                dt=(t2-th+math.pi)%(2*math.pi)-math.pi
                dt=max(-math.radians(maxturn),min(math.radians(maxturn),dt)); th2=th+dt
                x=x-o*math.sin(t2)+step*math.cos(th2); y=y+o*math.cos(t2)+step*math.sin(th2); th=th2
                st='cont'; gap=0
            else:
                x+=step*math.cos(th); y+=step*math.sin(th); st='bridge'; gap+=1
        lon,lat=px2ll(x,y)
        rec.append(dict(lon=lon,lat=lat,ratio=ratio,status=st,hd=-math.degrees(th)%360))
        if gap>=maxgap or st=='nodata' or (stop and stop(lon,lat)): break
    while rec and rec[-1]['status'] in ('bridge','nodata'): rec.pop()
    return rec
def summ(rec):
    return ''.join({'cont':'C','bridge':'-','start':'S','nodata':'X'}[r['status']] for r in rec)
