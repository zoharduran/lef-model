import sys;import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)));from lab import *
starts={'N1 Mendocino':((-140,40.0),180,-125.5),'N2 Murray':((-140,32.0),190,-119),'N3 Molokai':((-140,22.4),190,-116),'N4 Clarion':((-140,15.8),192,-114),'N5 Clipperton':((-144,4.8),187,-108)}
out={}
for k,(st,hd,el) in starts.items():
    r=both(st,hd,eastlim=el,maxgap=16,ne=120); out[k]=r
    print(k,len(r),s2(r))
    print('   ',' '.join('%.1f,%.1f'%(d['lon'],d['lat']) for d in r[::8]),' WEST END %.1f,%.1f hd %.0f'%(r[-1]['lon'],r[-1]['lat'],r[-1]['hd']))
json.dump({k:[clean(d) for d in r] for k,r in out.items()},open(D+'tr/N_auto.json','w'))
M=np.load(D+'tr/mosaic.npy')
crop(M,150,-110,44,-6,[[(d['lon'],d['lat']) for d in r] for r in out.values()],'N_auto.png',grid=5,scale=1)
