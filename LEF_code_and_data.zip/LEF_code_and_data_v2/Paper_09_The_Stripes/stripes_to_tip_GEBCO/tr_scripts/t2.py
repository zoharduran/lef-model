import sys; import os;sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from dtrace import *
HALF=40
def score_at(qx,qy,th,W=12,L=60,dturn=(-6,-4,-2,0,2,4,6),img=None):
    img=HP if img is None else img
    offs=np.arange(-HALF,HALF+1,1.0); best=None
    for d in dturn:
        t2=th+math.radians(d)
        p,nn=lineprof(qx,qy,t2,offs,L,img)
        if nn.max()>0.3: continue
        e=nd.uniform_filter1d(np.abs(np.gradient(p)),3); r=e/np.median(e)
        sub=r[HALF-W:HALF+W+1]-0.03*np.abs(offs[HALF-W:HALF+W+1])
        i=int(np.argmax(sub))
        if best is None or sub[i]>best[0]: best=(sub[i],r[HALF-W+i],offs[HALF-W+i],t2)
    return best
def t2trace(start,heading,nsteps,step=15,thr=4.0,maxgap=8,fitn=6,stop=None,W=12,L=60,maxdev=6):
    x,y=ll2px(*start); th=math.radians(-heading)
    pts=[(x,y)]; rec=[dict(lon=start[0],lat=start[1],ratio=np.nan,status='start',hd=heading)]
    gap=0
    for k in range(nsteps):
        qx=x+step*math.cos(th); qy=y+step*math.sin(th)
        b=score_at(qx,qy,th,W=W,L=L)
        if b is None:
            st='nodata'; nx_,ny_=qx,qy; ratio=np.nan
        else:
            _,ratio,o,t2=b
            if ratio>=thr:
                nx_,ny_=qx-o*math.sin(t2),qy+o*math.cos(t2); st='cont'; gap=0
            else:
                nx_,ny_=qx,qy; st='bridge'; gap+=1
        pts.append((nx_,ny_)); x,y=nx_,ny_
        if st=='cont':
            P=np.array(pts[-(fitn+1):])
            v=P[-1]-P[0]; th_new=math.atan2(v[1],v[0])
            dt=(th_new-th+math.pi)%(2*math.pi)-math.pi
            th+=max(-math.radians(maxdev),min(math.radians(maxdev),dt))
        lon,lat=px2ll(x,y)
        rec.append(dict(lon=lon,lat=lat,ratio=ratio,status=st,hd=-math.degrees(th)%360))
        if gap>=maxgap or st=='nodata' or (stop and stop(lon,lat)): break
    # trim trailing bridge steps
    while rec and rec[-1]['status'] in ('bridge','nodata'): rec.pop()
    return rec
def summ(rec):
    return ''.join({'cont':'C','bridge':'-','start':'S','nodata':'X'}[r['status']] for r in rec)
