Paper 12 - The Rings (LEF series)
p12_rings_calculations.py reproduces every number computed in the paper (standard library only); its output is in p12_rings_calculations_output.txt.
fig.py draws Figure A.1; fig_A2_ring_map.py, fig_B1_what_keeps_a_ring.py and fig_B2_two_conditions.py write the HTML of Figures A.2, B.1 and B.2 (rendered to PNG in a browser).

p12_line_then.py (11.11.2026) - the corotation line then and today, planet by planet (Paper 11, Table L.1 and Figure L.1):
  angular-momentum reconstruction with gravity, spin, birth radius and density, moment-of-inertia factor
  (compressibility), rotational flattening (Darwin-Radau), regular moons' orbital momentum, solar tide (Earth),
  and the mass that had to leave through the line (gradual estimate and upper bound); Mercury and Venus.
  Output: p12_line_then_output.txt.  Figure: fig_moon_map_then_now.py [he|en] (run from this folder).
