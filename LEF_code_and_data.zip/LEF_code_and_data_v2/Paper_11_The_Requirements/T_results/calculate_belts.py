"""Reproduce lunar belt statistics. Python 3; numpy pandas shapely pyshp.

Run from this directory: python calculate_belts.py
Original GRAIL 0.25 degree node grid: drop duplicate 360E column;
weight by cos(latitude), with zero polar-node weights.
No coordinate-frame transformation: use supplied lat/lon and requested axis.
Crater counts are counts of centres, NOT cos(latitude)-weighted counts.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import shapefile
import shapely

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
R_KM = 1737.4
NAMES = ['cap', 'limb', 'far']

def belts(lat, lon):
    c = np.cos(np.deg2rad(lat)) * np.cos(np.deg2rad(lon))
    theta = np.rad2deg(np.arccos(np.clip(c, -1, 1)))
    # Snap floating-point values at the specified boundaries.
    theta = np.where(np.abs(theta - 90) < 1e-10, 90, theta)
    theta = np.where(np.abs(theta - 41) < 1e-10, 41, theta)
    return np.searchsorted([41., 90.], theta, side='right')

reader = shapefile.Reader(str(DATA/'mare/LROC_GLOBAL_MARE_180.SHP'))
geoms = [shapely.make_valid(shapely.geometry.shape(s.__geo_interface__))
         for s in reader.shapes()]
mare = shapely.union_all(geoms)
shapely.prepare(mare)

def in_mare(lat, lon):
    lon = (np.asarray(lon) + 180) % 360 - 180
    # Include centres on the boundary in the mare exclusion.
    return shapely.intersects_xy(mare, lon, lat)

def thickness():
    path = DATA/'grail/GRAILCrustalThicknessArchive/Data/Model1_thick.dat'
    full = np.loadtxt(path).reshape(721, 1441)
    assert np.allclose(full[:,0], full[:,-1])
    grid = full[:,:-1]  # km, per archive documentation
    lon, lat = np.meshgrid(np.arange(1440)*.25, 90-np.arange(721)*.25)
    w = np.cos(np.deg2rad(lat)); w[[0,-1],:] = 0
    b = belts(lat,lon)
    mask = in_mare(lat,lon)
    assert np.isfinite(grid).all()
    rows=[]
    for selection, allowed in [('all',np.ones(grid.shape,bool)),('nonmare',~mask)]:
        means=[]
        for j,name in enumerate(NAMES):
            take = (b==j)&allowed&(w>0)
            mean = np.average(grid[take],weights=w[take])
            means.append(mean)
            rows.append(dict(selection=selection,belt=name,mean_thickness_km=mean,
                             positive_weight_nodes=int(take.sum())))
        for row in rows[-3:]:row['difference_from_cap_km']=row['mean_thickness_km']-means[0]
    result=pd.DataFrame(rows)
    result.to_csv(OUT/'T1_crustal_thickness.csv',index=False)
    print(result.to_string(index=False))
    print('Global mean km:',np.average(grid,weights=w))

def areas(step=.05):
    # Exact whole-belt areas; subtract numerically integrated mare areas.
    bounds=np.deg2rad([0,41,90,180])
    whole=2*np.pi*R_KM**2*(np.cos(bounds[:-1])-np.cos(bounds[1:]))
    mare_area=np.zeros(3)
    lon=np.arange(-180+step/2,180,step)
    for lo in np.arange(-90,90,5):
        lat1=np.arange(lo+step/2,lo+5,step)
        xx,yy=np.meshgrid(lon,lat1)
        # Exact cell areas, proportional to cos(lat) for uniform spacing.
        weights=R_KM**2*np.deg2rad(step)*2*np.sin(np.deg2rad(step/2))*np.cos(np.deg2rad(yy))
        b=belts(yy,xx); m=in_mare(yy,xx)
        for j in range(3):mare_area[j]+=weights[(b==j)&m].sum()
    result=pd.DataFrame(dict(belt=NAMES,whole_area_km2=whole,mare_area_km2=mare_area,
                             nonmare_area_km2=whole-mare_area))
    result.to_csv(OUT/'belt_areas.csv',index=False)
    print(result.to_string(index=False))
    return result

def craters(area):
    path=DATA/'robbins2018.csv'
    if not path.exists():
        path=OUT/'Robbins_Dge20_selected.csv'  # lossless D>=20 extract supplied in bundle
    if not path.exists():
        print('ROBBINS INPUT NOT AVAILABLE: no T2 result generated.')
        return
    columns=['CRATER_ID','LAT_CIRC_IMG','LON_CIRC_IMG','DIAM_CIRC_IMG']
    selected=[]; total=0
    for chunk in pd.read_csv(path,usecols=columns,chunksize=100000):
        total+=len(chunk)
        selected.append(chunk.loc[chunk.DIAM_CIRC_IMG>=20].copy())
    df=pd.concat(selected,ignore_index=True)
    assert not df[columns].isna().any().any()
    assert df.CRATER_ID.is_unique
    df['belt_index']=belts(df.LAT_CIRC_IMG,df.LON_CIRC_IMG)
    df['belt']=np.array(NAMES)[df.belt_index]
    df['inside_mare']=in_mare(df.LAT_CIRC_IMG,df.LON_CIRC_IMG)
    df.to_csv(OUT/'Robbins_Dge20_selected.csv',index=False)
    rows=[]
    for selection, keep, acol in [('all',np.ones(len(df),bool),'whole_area_km2'),
                                  ('nonmare',~df.inside_mare,'nonmare_area_km2')]:
        for j,name in enumerate(NAMES):
            count=int(((df.belt_index==j)&keep).sum())
            a=float(area.iloc[j][acol])
            rows.append(dict(selection=selection,belt=name,count=count,area_km2=a,
                             count_per_1e6_km2=count/a*1e6,
                             count_per_1e6_whole_belt_km2=count/area.iloc[j].whole_area_km2*1e6))
    result=pd.DataFrame(rows);result.to_csv(OUT/'T2_crater_counts.csv',index=False)
    print('Input rows:',total,'D>=20:',len(df));print(result.to_string(index=False))

if __name__=='__main__':
    thickness()
    a=areas()
    craters(a)
