# Independent recomputation (Claude, 14 Sep 2026) on Wieczorek 2013 Model1_thick.dat (721x1441, N->S, 0..360E, km)
import numpy as np; from scipy.stats import spearmanr
g=np.loadtxt('Model1_thick.dat').reshape(721,1441)[:,:-1]
lon,lat=np.meshgrid(np.arange(1440)*.25, 90-np.arange(721)*.25); w=np.cos(np.deg2rad(lat)); w[[0,-1],:]=0
def trend(clat,clon):
    c=np.sin(np.deg2rad(clat))*np.sin(np.deg2rad(lat))+np.cos(np.deg2rad(clat))*np.cos(np.deg2rad(lat))*np.cos(np.deg2rad(lon-clon))
    th=np.rad2deg(np.arccos(np.clip(c,-1,1))); means=[]
    for k in range(12):
        m=(th>=15*k)&(th<15*(k+1)+(0.001 if k==11 else 0))&(w>0); means.append(np.average(g[m],weights=w[m]))
    return spearmanr(range(12),means).statistic, means
for name,(a,b) in {'sub-Earth':(0,0),'Procellarum':(23,-40),'north pole':(90,0),'south pole':(-90,0),'east limb':(0,90)}.items():
    r,m=trend(a,b); print(name, round(r,2), np.round(m,1))
