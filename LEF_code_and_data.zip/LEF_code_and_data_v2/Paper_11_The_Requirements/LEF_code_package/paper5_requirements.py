"""Paper 5 — The Seven Requirements. Reproduces:
  A.2  eq (1): X_met*eps_core for f_core=1.4%, f_int=0.78 -> 1.79%
  B.3  crust masses at 34/43/55 km; shell mass (18 km); far-side crust mass
  B.7  centre-of-mass offset, thin shell and finite thickness, for drho=300/500/750
  B.7  angular distance (23N,320E) from (0,0): 45.16 deg
  B.8  belt areas: cap 0-41 (12.5%), limb 41-90 (37.5%), far 90-180 (50%)
  D.2  Hf-W: 2^(-600/8.9) = 5.1e-21
"""
import numpy as np
ML=7.35e22; RL=1.7374e6
print(f"A.2  X_met*eps = {0.014/0.78:.2%}")
for h in (34e3,43e3,55e3):
    Mc=4*np.pi/3*2550*(RL**3-(RL-h)**3); print(f"B.3  crust {h/1e3:.0f} km: {Mc:.3e} kg = {Mc/ML:.2%}; far hemisphere alone {2*np.pi*RL**2*h*2550:.2e}")
A_dome=2*np.pi*3.0e6**2; print(f"B.3  shell 18 km on dome: {2800*18e3*A_dome:.3e} kg = {2800*18e3*A_dome/ML:.1%}")
h0=45e3; A=15e3; b=RL-h0; rho_bar=ML/(4/3*np.pi*RL**3)
for d in (300,500,750):
    thin=d/rho_bar*A; fin=4*np.pi*d/ML*(b**3*A/3+b*A**3/5); print(f"B.7  drho={d}: thin {thin/1e3:.3f} km  finite {fin/1e3:.3f} km")
print(f"B.7  gamma = {np.degrees(np.arccos(np.cos(np.radians(23))*np.cos(np.radians(40)))):.2f} deg")
band=lambda a,c: (np.cos(np.radians(a))-np.cos(np.radians(c)))/2
print(f"B.8  cap {band(0,41):.3f}  limb {band(41,90):.3f}  far {band(90,180):.3f}")
print(f"D.2  Hf-W remaining after 600 Myr: {2**(-600/8.9):.1e}")
