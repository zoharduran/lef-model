import numpy as np, gzip
L=449; R0=1737.4e3
C=np.zeros((L+1,L+1)); S=np.zeros((L+1,L+1))
with gzip.open('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/משלוח_7/Paper8_SPA_materials/9_chatgpt_research_bundle/data/T2015_449.sh.gz','rt') as f:
    f.readline()
    for line in f:
        l,m,c,s=line.split(); C[int(l),int(m)]=float(c); S[int(l),int(m)]=float(s)
def schmidt(x,L):
    # Schmidt semi-normalised P_lm(x) and dP/dtheta, x=cos(theta)
    s=np.sqrt(max(1-x*x,1e-30)); P=np.zeros((L+1,L+1)); dP=np.zeros((L+1,L+1))
    P[0,0]=1
    for m in range(1,L+1):
        P[m,m]=P[m-1,m-1]*s*np.sqrt((2*m-1)/(2*m)) if m>1 else s
    for m in range(0,L):
        P[m+1,m]=x*np.sqrt(2*m+1)*P[m,m]
    for m in range(0,L+1):
        for l in range(m+2,L+1):
            a=np.sqrt((l-m)*(l+m)); b=np.sqrt((l-m-1)*(l+m-1))
            P[l,m]=((2*l-1)*x*P[l-1,m]-b*P[l-2,m])/a
    # derivative wrt theta: dP_lm/dtheta = (l*x*P_lm - sqrt((l-m)(l+m)) P_{l-1,m})/s
    for l in range(1,L+1):
        for m in range(0,l+1):
            prev=P[l-1,m] if m<=l-1 else 0
            dP[l,m]=(l*x*P[l,m]-np.sqrt((l-m)*(l+m))*prev)/s
    return P,dP
def field(lat,lons,alt_km):
    r=R0+alt_km*1e3; th=np.radians(90-lat); x=np.cos(th)
    P,dP=schmidt(x,L); l=np.arange(L+1)[:,None]; a=(R0/r)**(l+2)
    lam=np.radians(np.atleast_1d(lons)); m=np.arange(L+1)
    cm=np.cos(np.outer(m,lam)); sm=np.sin(np.outer(m,lam))
    G=C@cm + S@sm; H=C@sm*0  # placeholder
    A=(a*(l+1)*P)  # Br = sum (l+1)(R/r)^(l+2) P (g cos + h sin)
    Br=np.einsum('lm,lm k->k'.replace(' ',''),A*1,(C[:,:,None]*cm[None]+S[:,:,None]*sm[None])) if False else None
    T=C[:,:,None]*cm[None,:,:]+S[:,:,None]*sm[None,:,:]
    Br=np.einsum('lm,lmk->k',(l+1)*a*P,T)
    Bt=-np.einsum('lm,lmk->k',a*dP,T)
    Tp=-C[:,:,None]*sm[None,:,:]*m[None,:,None]+S[:,:,None]*cm[None,:,:]*m[None,:,None]
    Bp=-np.einsum('lm,lmk->k',a*P,Tp)/max(np.sin(th),1e-9)
    return np.sqrt(Br**2+Bt**2+Bp**2)*1e9, Br*1e9
