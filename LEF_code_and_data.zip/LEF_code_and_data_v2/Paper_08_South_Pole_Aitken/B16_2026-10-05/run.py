import numpy as np, sys
from field import field
lats=np.arange(-89.75,-0.0,0.5); lons=np.arange(120,270,0.5)
part=int(sys.argv[1]); idx=np.array_split(np.arange(len(lats)),4)[part]
G=np.zeros((len(idx),len(lons)))
for k,i in enumerate(idx): G[k],_=field(lats[i],lons,25)
np.savez(f'B25_part{part}.npz',idx=idx,B=G)
