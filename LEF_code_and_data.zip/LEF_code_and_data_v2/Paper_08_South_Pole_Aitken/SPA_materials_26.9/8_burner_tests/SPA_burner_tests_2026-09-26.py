#!/usr/bin/env python3
"""Paper 8 (SPA) — first tests of the 'internal burner' reading (Zohar, 26.9.2026).
1) Location of the crater-density minimum (test 6) against the antipodes of Imbrium and Serenitatis.
2) Depth/diameter of craters inside SPA by ring (Wang & Wu 2021), with and without craters on LROC mare polygons.
Inputs: WangWu2021_LU1319373_raw.txt, LROC_GLOBAL_MARE_180.SHP (both in the Paper 5 rebuild kit)."""
import struct, math, numpy as np, pandas as pd
from matplotlib.path import Path
from scipy.stats import mannwhitneyu
R=1737.4
def ang(la1,lo1,la2,lo2):
    la1,lo1,la2,lo2=map(np.radians,(la1,lo1,la2,lo2))
    return np.degrees(np.arccos(np.clip(np.sin(la1)*np.sin(la2)+np.cos(la1)*np.cos(la2)*np.cos(lo1-lo2),-1,1)))
def dest(lat,lon,x_e,y_n):
    d=math.hypot(x_e,y_n)/R; az=math.atan2(x_e,y_n); la1,lo1=map(math.radians,(lat,lon))
    la2=math.asin(math.sin(la1)*math.cos(d)+math.cos(la1)*math.sin(d)*math.cos(az))
    lo2=lo1+math.atan2(math.sin(az)*math.sin(d)*math.cos(la1),math.cos(d)-math.sin(la1)*math.sin(la2))
    return math.degrees(la2),math.degrees(lo2)%360
mn=dest(-53,191,160,240)   # test 6: minimum 160 km east, 240 km north of the nominal centre
print('minimum at %.1f, %.1f E'%mn)
for n,la,lo in [('SPA centre',-53,191),('Imbrium antipode',-37,161.5),('Serenitatis antipode',-25.4,198.8)]:
    print(f'  {n}: {ang(mn[0],mn[1],la,lo)*math.pi/180*R:.0f} km from the minimum')
def read_shp(fn):
    b=open(fn,'rb').read(); pos=100; polys=[]
    while pos<len(b):
        _,cl=struct.unpack('>ii',b[pos:pos+8]); pos+=8; rec=b[pos:pos+cl*2]; pos+=cl*2
        if struct.unpack('<i',rec[:4])[0] not in (5,15,25): continue
        np_,npt=struct.unpack('<ii',rec[36:44]); parts=list(struct.unpack('<%di'%np_,rec[44:44+4*np_]))+[npt]
        pts=np.frombuffer(rec[44+4*np_:44+4*np_+16*npt],dtype='<f8').reshape(-1,2)
        polys+= [pts[parts[i]:parts[i+1]] for i in range(np_)]
    return polys
w=pd.read_csv('WangWu2021_LU1319373_raw.txt',sep='\t',skiprows=15,usecols=[1,2,3,4],names=['lon','lat','D','d'],header=0).apply(pd.to_numeric,errors='coerce').dropna()
w['D']/=1000; w['d']/=1000; w=w[(w.D>=10)&(w.D<80)]; w['dD']=w.d/w.D
w['r']=ang(w.lat,w.lon%360,-53,191); w=w[w.r<50].copy()
pts=np.c_[((w.lon+180)%360)-180,w.lat]; inm=np.zeros(len(w),bool)
for p in read_shp('LROC_GLOBAL_MARE_180.SHP'):
    if len(p)<3: continue
    bb=(pts[:,0]>=p[:,0].min())&(pts[:,0]<=p[:,0].max())&(pts[:,1]>=p[:,1].min())&(pts[:,1]<=p[:,1].max())
    if bb.any(): inm[bb]|=Path(p).contains_points(pts[bb])
w['mare']=inm
rows=[]
for label,sub in [('all',w),('off-mare',w[~w.mare])]:
    for Dlo,Dhi in [(10,20),(20,40),(40,80)]:
        s=sub[(sub.D>=Dlo)&(sub.D<Dhi)]
        rings=[('0-10',s.r<10),('10-20',(s.r>=10)&(s.r<20)),('20-30',(s.r>=20)&(s.r<30)),('30-39.57',(s.r>=30)&(s.r<39.57)),('39.57-50',s.r>=39.57)]
        p=mannwhitneyu(s[s.r<10].dD,s[s.r>=39.57].dD).pvalue
        for rl,m in rings: rows.append(dict(sample=label,D_bin=f'{Dlo}-{Dhi}',ring_deg=rl,N=int(m.sum()),median_dD=round(float(s[m].dD.median()),4),p_core_vs_outside=round(p,4)))
out=pd.DataFrame(rows); out.to_csv('SPA_dD_by_ring_WangWu_2026-09-26.csv',index=False); print(out.to_string())
