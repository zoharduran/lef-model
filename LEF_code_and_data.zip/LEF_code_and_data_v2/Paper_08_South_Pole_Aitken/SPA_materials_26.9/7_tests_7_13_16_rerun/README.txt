Paper 8 / SPA reproduction bundle — 2026-09-26

- A9_test13_velocity_transit_RERUN_2026-09-26.csv: Historical 57° lag sensitivity. Reconstructs the simple angular-momentum-conservation calculation; 57° is explicitly NOT an observed required lag.
- A9_test14_energy_pressure_RERUN_2026-09-26.csv: Kinetic energy and ideal pressure equivalent for Test-13 velocities, rho=3000 kg/m^3; excludes gravitational/effective-potential barrier.
- A9_test15_effective_potential_barrier_RERUN_2026-09-26.csv: Earth-only rotating-frame effective-potential barrier for T=4.90, 5.50, 5.54 h and targets 15,818/17,570 km. Uses r0=6371 km from adjacent Test 17.
- A9_test16_forming_body_gravity_METHOD_GAP_2026-09-26.csv: Preserves the old Test-16 numbers but explicitly records that the two-body calculation cannot be uniquely rerun from the handoff because essential geometry/equation details are missing. No invented replacement.
- A9_test16B_sign_test_RERUN_2026-09-26.csv: Coriolis sign test and Serenitatis/Imbrium antipode-to-SPA longitude sign checks.
- reproduce_A9_tests13_16B_2026-09-26.py: Reproduction code for Tests 13, 14, 15 and 16B; Test 16 is intentionally not fabricated.
- A9_test7_SPA_verified_literature_2026-09-26.md: Verified literature actually opened during this audit: Garrick-Bethell & Zuber 2009; Ohtake et al. 2014; Moriarty & Pieters 2018; James et al. 2019; Nakamura et al. 2009.
- README.txt: This file.

Important comparison with 2026-09-23 handoff:
Test 13 rerun reproduces the recorded ~1.8–2.6 km/s and ~1.2–1.5 h range.
Test 15 rerun gives 24.317–26.964 MJ/kg and 72.95–80.89 GPa, versus the old rounded ~23–27 MJ/kg and ~69–81 GPa. The exact reason for the lower-end difference cannot be established because the original code/constants were not preserved; the rerun uses G=6.67430e-11, M_E=5.9722e24 kg, r0=6371 km, rho=3000 kg/m^3, and the maximum Phi_eff encountered between r0 and the target.
Test 16 old values are NOT claimed reproduced.
