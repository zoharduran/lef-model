# Reproduction code for SPA Tests 13-16B, 2026-09-26.
# Test 16 is intentionally NOT numerically reconstructed because the 2026-09-23
# handoff does not record enough geometry/equations for a unique two-body result.
import math
G=6.67430e-11
M_E=5.9722e24
MU=G*M_E
R0=6371e3
RHO=3000.0
TARGETS=[15818e3,17570e3]
PERIODS=[4.90,5.54]
LAG=math.radians(57.0)

def omega(T_h): return 2*math.pi/(T_h*3600.0)
def phi_eff(r,T_h): return -MU/r - 0.5*omega(T_h)**2*r*r
def r_corot(T_h): return (MU/omega(T_h)**2)**(1/3)

def test13(T_h, rt):
    Om=omega(T_h)
    I=Om*((rt-R0)+R0**2*(1/rt-1/R0))
    vr=I/LAG
    return vr,(rt-R0)/vr

def test14(vr):
    e=0.5*vr**2
    return e,RHO*e

def test15(T_h,rt):
    rc=r_corot(T_h)
    rb=min(rt,rc) if rc>=R0 else R0
    barrier=max(0.0,phi_eff(rb,T_h)-phi_eff(R0,T_h))
    return rc,rb,barrier,RHO*barrier

# Test 16 recorded values are preserved in CSV but not recomputed:
# missing exact two-body potential, body centre/radius/endpoint geometry,
# rotation period mapping, and rotating-frame barycentric treatment.
# Test 16B: a_C=-2 Omega x v_r; outward radial flow in a prograde frame
# lags westward relative to the rotating frame.
