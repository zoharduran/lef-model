import struct
import numpy as np, pandas as pd, math, json
from matplotlib.path import Path
exec(open('/tmp/common.py').read())
R=1737.4
op=json.load(open('/tmp/zohar_openings_sized.json'))
def ang(a1,o1,a2,o2):
    a1,o1,a2,o2=map(np.radians,(a1,o1,a2,o2)); return np.degrees(np.arccos(np.clip(np.sin(a1)*np.sin(a2)+np.cos(a1)*np.cos(a2)*np.cos(o1-o2),-1,1)))
def bearing(la1,lo1,la2,lo2):
    la1,lo1,la2,lo2=map(np.radians,(la1,lo1,la2,lo2)); return np.degrees(np.arctan2(np.sin(lo2-lo1)*np.cos(la2),np.cos(la1)*np.sin(la2)-np.sin(la1)*np.cos(la2)*np.cos(lo2-lo1)))%360
def mare_only(lat,lon):
    lat=np.asarray(lat,float); lon=np.asarray(lon,float); m=np.zeros(lat.shape,bool); p2=np.c_[((lon+180)%360)-180,lat]
    for p in polys:
        if len(p)<3: continue
        bb=(p2[:,0]>=p[:,0].min())&(p2[:,0]<=p[:,0].max())&(p2[:,1]>=p[:,1].min())&(p2[:,1]<=p[:,1].max())
        if bb.any(): m[bb]|=Path(p).contains_points(p2[bb])
    return m
lg,og=LA.ravel(),LO.ravel(); lc,oc=d.LAT_CIRC_IMG.values,d.LON_CIRC_IMG.values%360
def zm(lat,lon):
    m=np.zeros(np.shape(lat),bool)
    for la,lo,r,_ in op: m|=ang(lat,lon,la,lo)<=r
    return m
GM=mare_only(lg,og)|zm(lg,og); CM=mare_only(lc,oc)|zm(lc,oc)
bins=[(0,100),(100,200),(200,300),(300,500)]
# 1) all 36 openings, whole Moon: density vs distance from the opening's edge
print('ALL 36 openings, craters >=20 km per 1e6 km2 on cleaned ground, by distance beyond the opening edge (km):')
tot={b:[0,0.0] for b in bins}
for la,lo,r,_ in op:
    eg=(ang(lg,og,la,lo)-r)*math.pi/180*R; ec=(ang(lc,oc,la,lo)-r)*math.pi/180*R
    for a,b in bins:
        g=(eg>=a)&(eg<b)&~GM; c=(ec>=a)&(ec<b)&~CM; tot[(a,b)][0]+=c.sum(); tot[(a,b)][1]+=A[g].sum()
print('  '+'  '.join(f'{a}-{b}: {tot[(a,b)][0]/tot[(a,b)][1]:.0f}' for a,b in bins))
# 2) openings inside/at SPA: toward-centre half vs away half
ins=[(i+1,o) for i,o in enumerate(op) if ang(o[0],o[1],-53,191)<45]
print('\nOpenings within 45 deg of the SPA centre:',[i for i,_ in ins])
T={b:[0,0.0] for b in bins}; Aw={b:[0,0.0] for b in bins}
for i,(la,lo,r,_) in ins:
    bc=bearing(la,lo,-53,191)
    eg=(ang(lg,og,la,lo)-r)*math.pi/180*R; ec=(ang(lc,oc,la,lo)-r)*math.pi/180*R
    tg=np.abs(((bearing(la,lo,lg,og)-bc+180)%360)-180)<90; tcr=np.abs(((bearing(la,lo,lc,oc)-bc+180)%360)-180)<90
    row=[]
    for a,b in bins:
        g=(eg>=a)&(eg<b)&~GM; c=(ec>=a)&(ec<b)&~CM
        T[(a,b)][0]+=(c&tcr).sum(); T[(a,b)][1]+=A[g&tg].sum(); Aw[(a,b)][0]+=(c&~tcr).sum(); Aw[(a,b)][1]+=A[g&~tg].sum()
        dt=(c&tcr).sum()/max(A[g&tg].sum(),1e-9); da=(c&~tcr).sum()/max(A[g&~tg].sum(),1e-9)
        row.append(f'{a}-{b}: toward {dt:.0f} ({(c&tcr).sum()}) / away {da:.0f} ({(c&~tcr).sum()})')
    print(f' opening {i} ({la},{lo}, r={r*math.pi/180*R:.0f} km): '+' | '.join(row))
print('\n pooled SPA openings: '+' | '.join(f'{a}-{b}: toward {T[(a,b)][0]/T[(a,b)][1]:.0f} (N={T[(a,b)][0]}) / away {Aw[(a,b)][0]/Aw[(a,b)][1]:.0f} (N={Aw[(a,b)][0]})' for a,b in bins))
