import numpy as np, math, matplotlib, json
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.signal import find_peaks
z=np.load('/home/claude/gd/SPA8_GRAIL/data/grail_compact.npz'); step=.25
dem=np.fromfile('/mnt/user-data/uploads/ldem_4.img',dtype='<i2').reshape(720,1440).astype(float)*0.5/1000
lat=np.arange(90,-90-step/2,-step); lon=np.arange(0,360,step); LA,LO=np.meshgrid(lat,lon,indexing='ij'); W=np.cos(np.radians(LA))
p,l=np.radians(LA),np.radians(LO); la0,lo0=math.radians(-53),math.radians(191)
cc=np.degrees(np.arccos(np.clip(np.sin(la0)*np.sin(p)+np.cos(la0)*np.cos(p)*np.cos(l-lo0),-1,1)))
az=np.degrees(np.arctan2(np.sin(l-lo0)*np.cos(p),math.cos(la0)*np.sin(p)-math.sin(la0)*np.cos(p)*np.cos(l-lo0)))%360
# elevation on 0.25 grid (nearest from 4ppd)
iyd=np.clip(((90-LA)*4).astype(int),0,719); ixd=((LO*4).astype(int))%1440; E=dem[iyd,ixd]
res={}
for m in (1,4):
    t=z[f'Model{m}_thick'].astype(float); rows=[]
    for a in range(0,360,15):
        s=((az-a+7.5)%360)<15; xs=np.arange(20,50.5,1.0)
        prof=np.array([np.average(t[s&(cc>=x-0.75)&(cc<x+0.75)],weights=W[s&(cc>=x-0.75)&(cc<x+0.75)]) for x in xs])
        pk,pr=find_peaks(prof,prominence=1.0); cand=[(xs[i],pr['prominences'][k],prof[i]) for k,i in enumerate(pk) if 28<=xs[i]<=44]
        floor=np.average(t[s&(cc<15)],weights=W[s&(cc<15)])
        if cand: d,prm,val=max(cand,key=lambda q:q[1])
        else: d,prm,val=np.nan,0,np.nan
        ep=np.array([np.average(E[s&(cc>=x-0.75)&(cc<x+0.75)],weights=W[s&(cc>=x-0.75)&(cc<x+0.75)]) for x in xs])
        rows.append((a,d,prm,val,floor,ep[np.nanargmax(ep)] if True else np.nan, xs[np.nanargmax(ep)]))
    res[m]=rows
json.dump({str(k):[list(map(float,r)) for r in v] for k,v in res.items()},open('/tmp/b5_rows.json','w'))
# Figure: inner-ring distance vs azimuth, with the ellipse and circle
A=np.arange(0,360,1.0)
def ell(orient):
    ph=np.radians(A-orient); r=1/np.sqrt((np.cos(ph)/1200)**2+(np.sin(ph)/1025)**2); return np.degrees(r/1737.4)
fig,ax=plt.subplots(figsize=(13,6))
for m,mk,c in [(1,'o','#d00000'),(4,'s','#1d3557')]:
    r=np.array(res[m]); ok=np.isfinite(r[:,1])
    sc=ax.scatter(r[ok,0],r[ok,1],s=20+8*np.clip(r[ok,2],0,25),marker=mk,c=c,alpha=0.75,edgecolors='k',label=f'inner-ring peak, GRAIL Model {m} (size = prominence)')
ax.plot(A,np.full_like(A,39.57),'k--',lw=1.3,label='SPA rim as a circle (39.6°)')
ax.plot(A,ell(18.8),color='#2d6a4f',lw=2,label='SPA ellipse 2,400×2,050 km, long axis +18.8°')
ax.plot(A,ell(-18.8),color='#2d6a4f',lw=2,ls=':',label='SPA ellipse, long axis −18.8°')
for lab,x in [('N',0),('NE',45),('E',90),('SE',135),('S',180),('SW',225),('W',270),('NW',315)]: ax.text(x,45.3,lab,ha='center',fontsize=11,weight='bold')
ax.set_xlim(-5,350); ax.set_ylim(26,46.5); ax.set_xlabel('direction from the SPA centre (azimuth, °)'); ax.set_ylabel('distance from the SPA centre (°)')
ax.grid(alpha=0.3); ax.legend(fontsize=9,loc='lower right')
ax.set_title('B5 · Where the inner ring lies, direction by direction — compared with the rim as a circle and as an ellipse',fontsize=11.5)
plt.savefig('/mnt/user-data/outputs/Figure_B5_inner_ring_vs_ellipse_2026-09-30.png',dpi=105,bbox_inches='tight')
for m in (1,4):
    print('Model',m)
    for a,d,prm,val,floor,emax,epos in res[m]: print(f'  az {a:3.0f}: peak {d if np.isfinite(d) else "-":>4} deg, prominence {prm:4.1f}, crust at peak {val:5.1f}, floor {floor:5.1f}, highest ground {emax:+.2f} km at {epos:.0f} deg')
