import numpy as np, math
from scipy.special import sph_harm_y
z=np.load('data/grail_compact.npz'); step=.25
lat=np.arange(90,-90-step/2,-step); lon=np.arange(0,360,step)
# 1-degree subsample for fitting
sub=(slice(0,None,4),slice(0,None,4))
LA,LO=np.meshgrid(lat,lon,indexing='ij'); W=np.cos(np.radians(LA))
p,l=np.radians(LA),np.radians(LO); la0,lo0=math.radians(-53),math.radians(191)
cc=np.degrees(np.arccos(np.clip(np.sin(la0)*np.sin(p)+np.cos(la0)*np.cos(p)*np.cos(l-lo0),-1,1)))
az=np.degrees(np.arctan2(np.sin(l-lo0)*np.cos(p),math.cos(la0)*np.sin(p)-math.sin(la0)*np.cos(p)*np.cos(l-lo0)))%360
def basis(LAi,LOi,L):
    th=np.radians(90-LAi).ravel(); ph=np.radians(LOi).ravel(); cols=[]
    for n in range(L+1):
        for m in range(0,n+1):
            Y=sph_harm_y(n,m,th,ph)
            cols.append(Y.real)
            if m>0: cols.append(Y.imag)
    return np.stack(cols,-1)
def harm(res,k):
    A=np.radians(az[k]); w=W[k]; X=np.stack([np.ones_like(A),np.cos(A),np.sin(A),np.cos(2*A),np.sin(2*A)],-1)
    c=np.linalg.lstsq(X*np.sqrt(w)[:,None],res[k]*np.sqrt(w),rcond=None)[0]
    return c[0],math.hypot(c[1],c[2]),math.degrees(math.atan2(c[2],c[1]))%360,math.hypot(c[3],c[4])
ring=(cc>=45)&(cc<60)
for m in (1,4):
    t=z[f'Model{m}_thick'].astype(float)
    for L in (4,6,8):
        for excl in (65,75):
            fitmask=(cc[sub]>excl)
            B=basis(LA[sub][fitmask],LO[sub][fitmask],L); w=np.sqrt(W[sub][fitmask])
            coef=np.linalg.lstsq(B*w[:,None],t[sub][fitmask]*w,rcond=None)[0]
            # evaluate baseline on ring cells only (full res)
            Bk=basis(LA[ring],LO[ring],L); base=Bk@coef
            res=np.zeros_like(t); res[ring]=t[ring]-base
            mean,a1,d1,a2=harm(res,ring)
            print(f'Model {m}, SH degree {L}, fit outside {excl} deg: ring mean {mean:+.2f} km; E-W (first harmonic) {a1:.2f} km toward {d1:.0f} deg; second {a2:.2f} km')
