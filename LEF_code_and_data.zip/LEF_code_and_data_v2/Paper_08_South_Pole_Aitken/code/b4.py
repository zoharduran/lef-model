import numpy as np, pandas as pd, math
from numpy.polynomial.legendre import legval
from scipy.stats import spearmanr
z=np.load('data/grail_compact.npz'); step=.25
lat=np.arange(90,-90-step/2,-step); lon=np.arange(0,360,step)
LA,LO=np.meshgrid(lat,lon,indexing='ij'); p,l=np.radians(LA),np.radians(LO)
U=np.stack([np.cos(p)*np.cos(l),np.cos(p)*np.sin(l),np.sin(p)],-1); W=np.cos(p)
def v(la,lo): la,lo=map(math.radians,(la,lo)); return np.array([math.cos(la)*math.cos(lo),math.cos(la)*math.sin(lo),math.sin(la)])
dS=np.degrees(np.arccos(np.clip(U@v(-53,191),-1,1))); beta=np.degrees(np.arccos(np.clip(U@v(0,0),-1,1)))
cf=pd.read_csv('results/baseline_coefficients.csv')
ring=(dS>=39.57)&(dS<70)
rng=np.random.default_rng(7)
idx=np.flatnonzero(ring.ravel()); idx=rng.choice(idx,25000,replace=False,p=W.ravel()[idx]/W.ravel()[idx].sum())
Uu=U.reshape(-1,3)[idx]
a,b,c=np.array([1,0.637,0.601])*(0.637*0.601)**(-1/3)
def pred(P,C):
    P=P/np.linalg.norm(P); C=C-(C@P)*P; C/=np.linalg.norm(C); B=np.cross(P,C)
    n=np.stack([(Uu@C)/a,(Uu@B)/b,(Uu@P)/c],-1); f=1/(a*b*c*np.linalg.norm(n,axis=-1)); return 1/f-1
res={}
for m in (1,2,3,4):
    t=z[f'Model{m}_thick'].astype(float); co=cf[(cf.model==m)&(cf.baseline=='earth_legendre4')].sort_values('order').coefficient_km.values
    res[m]=(t-legval(np.cos(np.radians(beta)),co)).ravel()[idx]
obs={m:spearmanr(pred(v(41.04,208.32),v(23,320)),res[m]).correlation for m in (1,2,3,4)}
print('frame of the rounding:',{m:round(x,3) for m,x in obs.items()})
# null: random rounding frames (random pole, random long axis perpendicular)
null=[]
for k in range(2000):
    P=rng.normal(size=3); P/=np.linalg.norm(P); C=rng.normal(size=3)
    null.append(spearmanr(pred(P,C),res[1]).correlation)
null=np.array(null)
print('null (2000 random frames), Model 1: mean %.3f, 95th %.3f, 99th %.3f, max %.3f; share >= observed %.4f'%(null.mean(),np.percentile(null,95),np.percentile(null,99),null.max(),(null>=obs[1]).mean()))
# azimuthal harmonic of residual thickness at 45-60 deg ring (Model 1)
def az(la,lo):
    la0,lo0=math.radians(-53),math.radians(191); la,lo=np.radians(la),np.radians(lo)
    return np.degrees(np.arctan2(np.sin(lo-lo0)*np.cos(la),math.cos(la0)*np.sin(la)-math.sin(la0)*np.cos(la)*np.cos(lo-lo0)))%360
k=(dS>=45)&(dS<60); A=np.radians(az(LA[k],LO[k])); t=z['Model1_thick'].astype(float); co=cf[(cf.model==1)&(cf.baseline=='earth_legendre4')].sort_values('order').coefficient_km.values
r=(t-legval(np.cos(np.radians(beta)),co))[k]; w=W[k]
X=np.stack([np.ones_like(A),np.cos(A),np.sin(A),np.cos(2*A),np.sin(2*A)],-1)
coef=np.linalg.lstsq(X*np.sqrt(w)[:,None],r*np.sqrt(w),rcond=None)[0]
amp1=math.hypot(coef[1],coef[2]); dir1=math.degrees(math.atan2(coef[2],coef[1]))%360
amp2=math.hypot(coef[3],coef[4]); dir2=(math.degrees(math.atan2(coef[4],coef[3]))/2)%180
print('ring 45-60 deg, Model 1: mean %.2f km; first harmonic %.2f km toward azimuth %.0f deg (0=N,90=E); second harmonic %.2f km, axis %.0f/%.0f deg'%(coef[0],amp1,dir1,amp2,dir2,dir2+180))
