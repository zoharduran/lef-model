import numpy as np, math, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from scipy.signal import find_peaks
z=np.load('/home/claude/gd/SPA8_GRAIL/data/grail_compact.npz'); step=.25; t=z['Model1_thick'].astype(float)
lat=np.arange(90,-90-step/2,-step); lon=np.arange(0,360,step); LA,LO=np.meshgrid(lat,lon,indexing='ij'); W=np.cos(np.radians(LA))
p,l=np.radians(LA),np.radians(LO); la0,lo0=math.radians(-53),math.radians(191)
cc=np.degrees(np.arccos(np.clip(np.sin(la0)*np.sin(p)+np.cos(la0)*np.cos(p)*np.cos(l-lo0),-1,1)))
az=np.degrees(np.arctan2(np.sin(l-lo0)*np.cos(p),math.cos(la0)*np.sin(p)-math.sin(la0)*np.cos(p)*np.cos(l-lo0)))%360
azs=np.arange(0,360,5); ds=np.arange(20,76,1.0); inner=[];outer=[]
for a in azs:
    s=((az-a+7.5)%360)<15
    prof=np.array([np.average(t[s&(cc>=x-0.75)&(cc<x+0.75)],weights=W[s&(cc>=x-0.75)&(cc<x+0.75)]) for x in ds])
    pk,pr=find_peaks(prof,prominence=1.0)
    ii=[(ds[i],pr['prominences'][k]) for k,i in enumerate(pk) if 28<=ds[i]<=43]; oo=[(ds[i],pr['prominences'][k]) for k,i in enumerate(pk) if 45<=ds[i]<=65]
    inner.append(max(ii,key=lambda q:q[1]) if ii else (np.nan,0.0)); outer.append(max(oo,key=lambda q:q[1]) if oo else (np.nan,0.0))
def smooth_ring(vals,default):
    d=np.array([v[0] for v in vals]); s=np.array([v[1] for v in vals])
    ok=np.isfinite(d); dd=np.interp(azs,np.r_[azs[ok]-360,azs[ok],azs[ok]+360],np.r_[d[ok],d[ok],d[ok]])
    dd=np.convolve(np.r_[dd[-2:],dd,dd[:2]],np.ones(5)/5,'valid'); return dd,s
din,sin_=smooth_ring(inner,36); dout,sout=smooth_ring(outer,55)
n=1100; X,Y=np.meshgrid(np.linspace(-1,1,n),np.linspace(1,-1,n)); rho=np.hypot(X,Y); c=np.arcsin(np.clip(rho,0,1))
LAT=np.degrees(np.arcsin(np.clip(np.cos(c)*math.sin(la0)+np.where(rho>0,Y*np.sin(c)*math.cos(la0)/np.where(rho>0,rho,1),0),-1,1)))
LON=(np.degrees(lo0+np.arctan2(X*np.sin(c),rho*np.cos(c)*math.cos(la0)-Y*np.sin(c)*math.sin(la0))))%360
img=t[np.clip(np.round((90-LAT)/step).astype(int),0,720),np.round(LON/step).astype(int)%1440]; img[rho>0.999]=np.nan
def pt(azd,dd):
    d=math.radians(dd); b=math.radians(azd)
    la2=math.asin(math.sin(la0)*math.cos(d)+math.cos(la0)*math.sin(d)*math.cos(b)); lo2=lo0+math.atan2(math.sin(b)*math.sin(d)*math.cos(la0),math.cos(d)-math.sin(la0)*math.sin(la2))
    return math.cos(la2)*math.sin(lo2-lo0), math.cos(la0)*math.sin(la2)-math.sin(la0)*math.cos(la2)*math.cos(lo2-lo0)
fig,ax=plt.subplots(figsize=(11,10.5))
im=ax.imshow(img,extent=(-1,1,-1,1),cmap='viridis',vmin=0,vmax=65)
cb=fig.colorbar(im,ax=ax,fraction=0.035,pad=0.02); cb.set_label('crust thickness, GRAIL Model 1 (km) — dark = thin, yellow = thick')
def draw(dd,ss,color,maxw,label):
    A=np.r_[azs,360]; D=np.r_[dd,dd[0]]; S=np.r_[ss,ss[0]]
    P=np.array([pt(a,d) for a,d in zip(A,D)]); segs=np.stack([P[:-1],P[1:]],1)
    wid=0.8+np.clip((S[:-1]+S[1:])/2,0,25)/25*maxw
    lc=LineCollection(segs,linewidths=wid,colors=color,capstyle='round',label=label); ax.add_collection(lc)
draw(din,sin_,'#ff3b3b',11,'inner ring')
draw(dout,sout,'#ffffff',11,'outer ring')
th=np.linspace(0,360,361); r=np.array([pt(q,39.57) for q in th]); ax.plot(r[:,0],r[:,1],color='#ffd60a',ls='--',lw=1.3)
for lab,azd in [('N',0),('NE',45),('E',90),('SE',135),('S',180),('SW',225),('W',270),('NW',315)]:
    ax.text(*pt(azd,73),lab,ha='center',va='center',fontsize=13,weight='bold',color='white',bbox=dict(boxstyle='round,pad=0.15',fc='k',alpha=0.55,lw=0))
ax.text(0,0.02,'SPA',ha='center',va='center',fontsize=15,weight='bold',color='white')
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([0],[0],color='#ff3b3b',lw=6,label='inner ring — line width = how much it stands out'),Line2D([0],[0],color='white',lw=6,label='outer ring — line width = how much it stands out'),Line2D([0],[0],color='#ffd60a',ls='--',label='SPA rim (circle 39.6°)')],loc='lower left',fontsize=10,facecolor='#333',labelcolor='white')
ax.set_xlim(-1.02,1.02); ax.set_ylim(-1.02,1.02); ax.set_aspect('equal'); ax.axis('off'); ax.set_facecolor('k')
ax.set_title('The basin and its two rings of thickened crust\n(each ring drawn where the crust peaks; the thicker the line, the more the ring stands out)',fontsize=11.5)
plt.savefig('/mnt/user-data/outputs/Figure_B4B5_basin_two_rings_2026-09-30.png',dpi=105,bbox_inches='tight'); print('ok')
