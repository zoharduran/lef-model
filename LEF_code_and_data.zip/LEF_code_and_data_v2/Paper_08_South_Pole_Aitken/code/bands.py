import numpy as np, math, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from scipy.signal import find_peaks
z=np.load('/home/claude/gd/SPA8_GRAIL/data/grail_compact.npz'); step=.25; t=z['Model1_thick'].astype(float)
lat=np.arange(90,-90-step/2,-step); lon=np.arange(0,360,step); LA,LO=np.meshgrid(lat,lon,indexing='ij'); W=np.cos(np.radians(LA))
p,l=np.radians(LA),np.radians(LO); la0,lo0=math.radians(-53),math.radians(191)
cc=np.degrees(np.arccos(np.clip(np.sin(la0)*np.sin(p)+np.cos(la0)*np.cos(p)*np.cos(l-lo0),-1,1)))
az=np.degrees(np.arctan2(np.sin(l-lo0)*np.cos(p),math.cos(la0)*np.sin(p)-math.sin(la0)*np.cos(p)*np.cos(l-lo0)))%360
azs=np.arange(0,360,5); ds=np.arange(15,86,1.0)
M=np.full((len(ds),len(azs)),np.nan); inner=[];outer=[]
for j,a in enumerate(azs):
    s=((az-a+7.5)%360)<15
    prof=np.array([np.average(t[s&(cc>=x-0.75)&(cc<x+0.75)],weights=W[s&(cc>=x-0.75)&(cc<x+0.75)]) for x in ds])
    far=s&(cc>=70)&(cc<90); tf=np.average(t[far],weights=W[far]); M[:,j]=prof-tf
    pk,pr=find_peaks(prof,prominence=1.5)
    ii=[(ds[i],pr['prominences'][k]) for k,i in enumerate(pk) if 28<=ds[i]<=43]; oo=[(ds[i],pr['prominences'][k]) for k,i in enumerate(pk) if 45<=ds[i]<=65]
    inner.append(max(ii,key=lambda q:q[1]) if ii else (np.nan,0)); outer.append(max(oo,key=lambda q:q[1]) if oo else (np.nan,0))
inner=np.array(inner); outer=np.array(outer)
# --- Figure 1: unwrapped view
fig,ax=plt.subplots(figsize=(16,6.5))
im=ax.imshow(M,aspect='auto',origin='lower',extent=(-2.5,357.5,14.5,85.5),cmap='RdBu_r',vmin=-20,vmax=20)
cb=fig.colorbar(im,ax=ax,fraction=0.025,pad=0.01); cb.set_label('crust relative to the crust 70–90° out in the same direction (km)')
ax.axhline(39.57,color='k',ls='--',lw=1); ax.text(359,40.3,'rim',ha='right',fontsize=9)
ax.plot(azs,inner[:,0],'o',color='#ffd166',mec='k',ms=6,label='inner-ring peak')
ax.plot(azs,outer[:,0],'s',color='#80ffdb',mec='k',ms=6,label='outer-ring peak')
for lab,x in [('N',0),('NE',45),('E',90),('SE',135),('S',180),('SW',225),('W',270),('NW',315),('N',357)]:
    ax.text(x,86.5,lab,ha='center',fontsize=11,weight='bold')
ax.set_xlabel('direction from the SPA centre (azimuth, °)'); ax.set_ylabel('distance from the SPA centre (°)')
ax.set_ylim(14.5,88); ax.legend(loc='lower right',fontsize=9)
ax.set_title('SPA "unrolled": every direction side by side — the two rings appear as horizontal ridges (red); GRAIL Model 1',fontsize=11.5)
plt.savefig('/mnt/user-data/outputs/Figure_B4B5_unrolled_2026-09-30.png',dpi=105,bbox_inches='tight')
# --- Figure 2: map with bands of variable width and colour
n=1000; X,Y=np.meshgrid(np.linspace(-1,1,n),np.linspace(1,-1,n)); rho=np.hypot(X,Y); c=np.arcsin(np.clip(rho,0,1))
LAT=np.degrees(np.arcsin(np.clip(np.cos(c)*math.sin(la0)+np.where(rho>0,Y*np.sin(c)*math.cos(la0)/np.where(rho>0,rho,1),0),-1,1)))
LON=(np.degrees(lo0+np.arctan2(X*np.sin(c),rho*np.cos(c)*math.cos(la0)-Y*np.sin(c)*math.sin(la0))))%360
img=t[np.clip(np.round((90-LAT)/step).astype(int),0,720),np.round(LON/step).astype(int)%1440]; img[rho>0.999]=np.nan
def pt(azd,dd):
    d=math.radians(dd); b=math.radians(azd)
    la2=math.asin(math.sin(la0)*math.cos(d)+math.cos(la0)*math.sin(d)*math.cos(b)); lo2=lo0+math.atan2(math.sin(b)*math.sin(d)*math.cos(la0),math.cos(d)-math.sin(la0)*math.sin(la2))
    return math.cos(la2)*math.sin(lo2-lo0), math.cos(la0)*math.sin(la2)-math.sin(la0)*math.cos(la2)*math.cos(lo2-lo0)
fig,ax=plt.subplots(figsize=(10.5,10))
ax.imshow(img,extent=(-1,1,-1,1),cmap='Greys_r',vmin=5,vmax=65,alpha=0.6)
def band(vals,cmap,maxpr):
    for j,a in enumerate(azs):
        d,pr=vals[j]
        if not np.isfinite(d) or pr<=0: continue
        w=0.6+min(pr,25)/25*4.5    # half-width in degrees, grows with strength
        A=np.linspace(a-2.5,a+2.5,6); P=[pt(q,d-w) for q in A]+[pt(q,d+w) for q in A[::-1]]
        ax.add_patch(Polygon(P,closed=True,fc=cmap(0.25+0.75*min(pr,maxpr)/maxpr),ec='none',alpha=0.95))
band(inner,plt.cm.Reds,25); band(outer,plt.cm.Blues,30)
th=np.linspace(0,360,361); r=np.array([pt(q,39.57) for q in th]); ax.plot(r[:,0],r[:,1],'k--',lw=1.2)
for lab,azd in [('N',0),('NE',45),('E',90),('SE',135),('S',180),('SW',225),('W',270),('NW',315)]:
    ax.text(*pt(azd,74),lab,ha='center',va='center',fontsize=12,weight='bold')
ax.text(0,0,'SPA',ha='center',va='center',fontsize=13,weight='bold',color='#333')
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([0],[0],color=plt.cm.Reds(0.8),lw=8,label='inner ring (30–43°)'),Line2D([0],[0],color=plt.cm.Blues(0.8),lw=8,label='outer ring (48–62°)'),Line2D([0],[0],color='k',ls='--',label='SPA rim (39.6°)')],loc='lower left',fontsize=10)
ax.set_xlim(-1.02,1.02); ax.set_ylim(-1.02,1.02); ax.set_aspect('equal'); ax.axis('off')
ax.set_title('The two rings as bands — the wider and darker the band, the more the ring stands out (5° steps; GRAIL Model 1)',fontsize=11)
plt.savefig('/mnt/user-data/outputs/Figure_B4B5_bands_2026-09-30.png',dpi=105,bbox_inches='tight'); print('ok')
