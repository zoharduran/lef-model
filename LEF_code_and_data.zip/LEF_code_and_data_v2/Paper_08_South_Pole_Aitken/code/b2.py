import numpy as np, math, json, struct
from matplotlib.path import Path
dem=np.fromfile('/mnt/user-data/uploads/ldem_4.img',dtype='<i2').reshape(720,1440).astype(float)*0.5/1000  # km
lat=90-(np.arange(720)+0.5)/4; lon=(np.arange(1440)+0.5)/4
LA,LO=np.meshgrid(lat,lon,indexing='ij'); W=np.cos(np.radians(LA))
print('elevation range km',dem.min().round(2),dem.max().round(2))
def v(la,lo): la,lo=np.radians(la),np.radians(lo); return np.stack([np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)],-1)
V=v(LA,LO)
def dist(a,b): return np.degrees(np.arccos(np.clip(V@v(a,b),-1,1)))
# masks
def read_shp(fn):
    b=open(fn,'rb').read(); pos=100; polys=[]
    while pos<len(b):
        _,cl=struct.unpack('>ii',b[pos:pos+8]); pos+=8; rec=b[pos:pos+cl*2]; pos+=cl*2
        if struct.unpack('<i',rec[:4])[0] not in (5,15,25): continue
        np_,npt=struct.unpack('<ii',rec[36:44]); parts=list(struct.unpack('<%di'%np_,rec[44:44+4*np_]))+[npt]
        pts=np.frombuffer(rec[44+4*np_:44+4*np_+16*npt],dtype='<f8').reshape(-1,2)
        polys+=[pts[parts[i]:parts[i+1]] for i in range(np_)]
    return polys
polys=read_shp('/home/claude/kit/lroc/LROC_GLOBAL_MARE_180.SHP')
pts=np.c_[(((LO+180)%360)-180).ravel(),LA.ravel()]; mare=np.zeros(len(pts),bool)
for p in polys:
    if len(p)<3: continue
    bb=(pts[:,0]>=p[:,0].min())&(pts[:,0]<=p[:,0].max())&(pts[:,1]>=p[:,1].min())&(pts[:,1]<=p[:,1].max())
    if bb.any(): mare[bb]|=Path(p).contains_points(pts[bb])
mare=mare.reshape(LA.shape)
op=json.load(open('/tmp/zohar_openings_sized.json')); opm=np.zeros(LA.shape,bool)
for la,lo,r,_ in op: opm|=dist(la,lo)<=r
masks={'all':np.ones(LA.shape,bool),'no LROC':~mare,'cleaned':~mare&~opm}
# GRAIL crust on same grid (0.25 deg -> sample at nearest)
z=np.load('/home/claude/gd/SPA8_GRAIL/data/grail_compact.npz')
iy=np.clip(np.round((90-LA)/0.25).astype(int),0,720); ix=(np.round(LO/0.25).astype(int))%1440
rings=[(0,5),(5,10),(10,15),(15,20),(20,25),(25,30),(30,35),(35,39.57),(39.57,45),(45,50),(50,55),(55,60)]
out={}
for cname,(cla,clo) in {'centre':(-53,191),'minimum':(-44.5,198.5)}.items():
    d=dist(cla,clo)
    for mname,M in masks.items():
        ref=(d>=39.57)&(d<50)&M; eref=np.average(dem[ref],weights=W[ref])
        rows=[]
        for a,b in rings:
            k=(d>=a)&(d<b)&M
            if k.sum()<5: rows.append((a,b,np.nan,np.nan,[np.nan]*4)); continue
            e=np.average(dem[k],weights=W[k])-eref; med=np.median(dem[k])-np.median(dem[ref])
            pr=[]
            for m in (1,2,3,4):
                t=z[f'Model{m}_thick'].astype(float)[iy,ix]
                dt=np.average(t[k],weights=W[k])-np.average(t[ref],weights=W[ref])
                pr.append(dt*(3220-2550)/3220)
            rows.append((a,b,e,med,pr))
        out[(cname,mname)]=rows
for key in [('centre','all'),('centre','cleaned'),('minimum','cleaned')]:
    print('\n==',key,' ring | observed mean | median | crust-only (M1..M4) | residual (M1..M4)')
    for a,b,e,med,pr in out[key]:
        res=[e-p for p in pr]
        print(f'{a:>5}-{b:<5} {e:6.2f} {med:6.2f} | '+' '.join(f'{p:5.2f}' for p in pr)+' | '+' '.join(f'{r:5.2f}' for r in res))
# depth definitions
d=dist(-53,191); k0=(d<10)&masks['cleaned']; kr=(d>=35)&(d<45)
print('\nfloor (0-10 deg, cleaned) mean elevation %.2f km; rim zone 35-45 deg mean %.2f km, 95th pct %.2f km'%(np.average(dem[k0],weights=W[k0]),np.average(dem[kr],weights=W[kr]),np.percentile(dem[kr],95)))
print('lowest point in SPA (<39.57): %.2f km at'%dem[d<39.57].min(), LA[d<39.57][np.argmin(dem[d<39.57])], LO[d<39.57][np.argmin(dem[d<39.57])])
# sensitivity: crust density
t1=z['Model1_thick'].astype(float)[iy,ix]; dc=(d<10); dr=(d>=39.57)&(d<50)
dt=np.average(t1[dc],weights=W[dc])-np.average(t1[dr],weights=W[dr]); obs=np.average(dem[dc],weights=W[dc])-np.average(dem[dr],weights=W[dr])
for rc in (2550,2700,2800,2900,3000):
    p=dt*(3220-rc)/3220; print(f'rho_c {rc}: crust-only {p:.2f} km; observed {obs:.2f}; residual {obs-p:.2f}')
np.save('/tmp/b2_out.npy',out,allow_pickle=True)
