import numpy as np, pandas as pd, math, json, struct
from matplotlib.path import Path
exec(open('/tmp/common.py').read())
R=1737.4
op=json.load(open('/tmp/zohar_openings_sized.json'))
def ang(a1,o1,a2,o2):
    a1,o1,a2,o2=map(np.radians,(a1,o1,a2,o2)); return np.degrees(np.arccos(np.clip(np.sin(a1)*np.sin(a2)+np.cos(a1)*np.cos(a2)*np.cos(o1-o2),-1,1)))
def mare_only(lat,lon):
    lat=np.asarray(lat,float); lon=np.asarray(lon,float); m=np.zeros(lat.shape,bool); p2=np.c_[((lon+180)%360)-180,lat]
    for p in polys:
        if len(p)<3: continue
        bb=(p2[:,0]>=p[:,0].min())&(p2[:,0]<=p[:,0].max())&(p2[:,1]>=p[:,1].min())&(p2[:,1]<=p[:,1].max())
        if bb.any(): m[bb]|=Path(p).contains_points(p2[bb])
    return m
def zm(lat,lon):
    m=np.zeros(np.shape(lat),bool)
    for la,lo,r,_ in op: m|=ang(lat,lon,la,lo)<=r
    return m
lg,og=LA.ravel(),LO.ravel(); lc,oc=d.LAT_CIRC_IMG.values,d.LON_CIRC_IMG.values%360; D=d.DIAM_CIRC_IMG.values
GM=mare_only(lg,og)|zm(lg,og); CM=mare_only(lc,oc)|zm(lc,oc)
ref_g=(ang(lg,og,-53,191)>=39.57)&(ang(lg,og,-53,191)<50)&~GM; ref_c=(ang(lc,oc,-53,191)>=39.57)&(ang(lc,oc,-53,191)<50)&~CM
dens_out=ref_c.sum()/A[ref_g].sum()
print('outside ring density (>=20 km, cleaned): %.1f per 1e6 km2'%dens_out)
for name,(la,lo) in {'crater minimum':(-44.5,198.5),'SPA centre':(-53,191),'SPA thinnest crust (south)':(-61.2,184.2)}.items():
    for rkm in (150,250):
        rdeg=math.degrees(rkm/R)
        g=(ang(lg,og,la,lo)<=rdeg)&~GM; c=(ang(lc,oc,la,lo)<=rdeg)&~CM
        area=A[g].sum(); n=c.sum(); exp=dens_out*area/1e6*1e6/1e6
        exp=dens_out*area
        nb=((c)&(D>=20)&(D<40)).sum(); nl=((c)&(D>=40)).sum()
        print(f'{name}, radius {rkm} km: cleaned area {area:.3f} Mkm2; craters >=20 km: {n} (expected at outside density: {exp:.1f}); ratio {n/exp:.2f}; of them 20-40 km: {nb}, >=40 km: {nl}')
