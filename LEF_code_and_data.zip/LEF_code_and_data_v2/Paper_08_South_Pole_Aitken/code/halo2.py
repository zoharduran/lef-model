import struct, numpy as np, pandas as pd, math, json
from matplotlib.path import Path
exec(open('/tmp/common.py').read())
R=1737.4
op=json.load(open('/tmp/zohar_openings_sized.json'))
def ang(a1,o1,a2,o2):
    a1,o1,a2,o2=map(np.radians,(a1,o1,a2,o2)); return np.degrees(np.arccos(np.clip(np.sin(a1)*np.sin(a2)+np.cos(a1)*np.cos(a2)*np.cos(o1-o2),-1,1)))
def mare_only(lat,lon):
    lat=np.asarray(lat,float); lon=np.asarray(lon,float); m=np.zeros(lat.shape,bool); p2=np.c_[((lon+180)%360)-180,lat]
    for p in polys:
        if len(p)<3: continue
        bb=(p2[:,0]>=p[:,0].min())&(p2[:,0]<=p[:,0].max())&(p2[:,1]>=p[:,1].min())&(p2[:,1]<=p[:,1].max())
        if bb.any(): m[bb]|=Path(p).contains_points(p2[bb])
    return m
lg,og=LA.ravel(),LO.ravel(); lc,oc=d.LAT_CIRC_IMG.values,d.LON_CIRC_IMG.values%360; D=d.DIAM_CIRC_IMG.values
GMm=mare_only(lg,og); CMm=mare_only(lc,oc)
tg=ang(lg,og,-53,191); tc=ang(lc,oc,-53,191)
V=GV; Vc=CV
for halo in (0,100,200):
    def zm(lat,lon):
        m=np.zeros(np.shape(lat),bool)
        for la,lo,r,_ in op: m|=ang(lat,lon,la,lo)<=r+math.degrees(halo/R)
        return m
    GM=GMm|zm(lg,og); CM=CMm|zm(lc,oc)
    dens=lambda c,g: c.sum()/A[g].sum()
    insg,insc=tg<=39.57,tc<=39.57
    print(f'\n===== openings removed with a halo of {halo} km; share of SPA kept {100*A[insg&~GM].sum()/A[insg].sum():.0f}%')
    print(' SPA vs rest of Moon: %.1f vs %.1f (%.2f)'%(dens(insc&~CM,insg&~GM),dens(~insc&~CM,~insg&~GM),dens(insc&~CM,insg&~GM)/dens(~insc&~CM,~insg&~GM)))
    rv=[]
    for a,b in [(0,10),(10,20),(20,30),(30,39.57),(39.57,50)]:
        g=(tg>=a)&(tg<b)&~GM; c=(tc>=a)&(tc<b)&~CM; rv.append((dens(c,g),c.sum()))
    print(' rings (>=20 km):',' '.join(f'{x:.0f}(N={n})' for x,n in rv),' | centre/outside %.2f'%(rv[0][0]/rv[-1][0]))
    rv40=[]
    for a,b in [(0,10),(39.57,50)]:
        g=(tg>=a)&(tg<b)&~GM; c=(tc>=a)&(tc<b)&~CM&(D>=40); rv40.append(dens(c,g))
    print(' >=40 km centre/outside %.2f'%(rv40[0]/rv40[1]))
    cand=np.flatnonzero((tg<20)&~GM); near=np.flatnonzero(tg<40); nearc=np.flatnonzero(tc<45)
    for h in (150,200,250):
        vals=[]
        for i in cand:
            dg=R*np.arccos(np.clip(V[near]@V[i],-1,1)); wg=np.exp(-dg**2/(2*h*h))*A[near]*~GM[near]
            dc=R*np.arccos(np.clip(Vc[nearc]@V[i],-1,1)); wc=np.exp(-dc**2/(2*h*h))*~CM[nearc]
            vals.append(wc.sum()/wg.sum())
        j=cand[int(np.argmin(vals))]
        dd=R*math.radians(float(ang(lg[j],og[j],-44.5,198.5)))
        print(f'  minimum (kernel {h} km): {lg[j]:.1f}, {og[j]:.1f}; {R*math.radians(float(ang(lg[j],og[j],-53,191))):.0f} km from centre; {dd:.0f} km from the previous minimum; density there {min(vals)*1:.0f} vs outside {rv[-1][0]:.0f}')
