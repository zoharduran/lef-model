import numpy as np, math, json, struct, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.path import Path
exec(open('/tmp/b2plains.py').read().split("rings=[")[0])   # reuse data, masks
CM=crater_mask(1.5); G=clean&~CM
ref=(d>=39.57)&(d<50)&G; eref=np.average(dem[ref],weights=W[ref])
edges=np.arange(0,62.5,2.5); mids=[];obs=[];p1=[];p4=[];pd_=[]
t1=z['Model1_thick'].astype(float)[iy,ix]; t4=z['Model4_thick'].astype(float)[iy,ix]
r1=np.average(t1[ref],weights=W[ref]); r4=np.average(t4[ref],weights=W[ref])
for a,b in zip(edges[:-1],edges[1:]):
    k=(d>=a)&(d<b)&G
    if k.sum()<30: continue
    mids.append((a+b)/2); obs.append(np.average(dem[k],weights=W[k])-eref)
    p1.append((np.average(t1[k],weights=W[k])-r1)*670/3220); p4.append((np.average(t4[k],weights=W[k])-r4)*670/3220)
    pd_.append((np.average(t1[k],weights=W[k])-r1)*(3220-2900)/3220)
mids,obs,p1,p4,pd_=map(np.array,(mids,obs,p1,p4,pd_))
fig,(a1,a2)=plt.subplots(2,1,figsize=(9.5,8.5),sharex=True,gridspec_kw={'height_ratios':[2,1.2]})
a1.plot(mids,obs,'o-',color='#1f3a5f',lw=2.4,label='observed elevation (LOLA), intercrater plains')
a1.fill_between(mids,p1,p4,color='#e8743b',alpha=0.35,label='thin crust alone, crust 2,550 kg/m³ (GRAIL Models 1–4)')
a1.plot(mids,pd_,'--',color='#b5452c',lw=1.6,label='thin crust alone, dense crust 2,900 kg/m³ (Model 1)')
a1.axvline(39.57,color='k',lw=1,ls=':'); a1.text(40,-6.5,'rim',fontsize=10)
a1.set_ylabel('elevation relative to the ring 39.6–50° (km)'); a1.legend(fontsize=9,loc='lower right'); a1.grid(alpha=0.3)
a1.set_title('B2 · The depth of SPA against what its thin crust alone predicts\n(intercrater plains: craters ≥ 20 km removed with a 1.5-radius margin; lava plains and openings removed)',fontsize=11)
res=obs-(p1+p4)/2; cols=plt.cm.Reds(np.clip(-res/1.8,0,1)*0.85+0.1)
a2.bar(mids,res,width=2.2,color=cols,edgecolor='k',lw=0.4)
a2.errorbar(mids,res,yerr=np.abs(p1-p4)/2,fmt='none',ecolor='k',lw=0.8,capsize=2)
a2.bar(mids,obs-pd_,width=0.8,color='none',edgecolor='#b5452c',lw=1.2,ls='--',label='residual with dense crust (2,900)')
a2.axhline(0,color='k',lw=0.8); a2.axvline(39.57,color='k',lw=1,ls=':')
a2.set_ylabel('residual: observed − crust alone (km)'); a2.set_xlabel('angular distance from the SPA centre (°)'); a2.grid(alpha=0.3); a2.legend(fontsize=9,loc='lower right')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/Figure_B2_depth_profile_2026-09-30.png',dpi=120)
for m,o,x,y,q in zip(mids,obs,p1,p4,pd_): print(f'{m:5.2f} obs {o:6.2f} crust {x:6.2f}/{y:6.2f} res {o-(x+y)/2:6.2f} dense-res {o-q:6.2f}')
