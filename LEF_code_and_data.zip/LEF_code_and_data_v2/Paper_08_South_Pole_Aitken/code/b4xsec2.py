import numpy as np, math, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
dem=np.fromfile('/mnt/user-data/uploads/ldem_4.img',dtype='<i2').reshape(720,1440).astype(float)*0.5/1000
z=np.load('/home/claude/gd/SPA8_GRAIL/data/grail_compact.npz'); T=z['Model1_thick'].astype(float)
lat=90-(np.arange(720)+0.5)/4; lon=(np.arange(1440)+0.5)/4; LA,LO=np.meshgrid(lat,lon,indexing='ij')
p,l=np.radians(LA),np.radians(LO); la0,lo0=math.radians(-53),math.radians(191)
cc=np.degrees(np.arccos(np.clip(np.sin(la0)*np.sin(p)+np.cos(la0)*np.cos(p)*np.cos(l-lo0),-1,1)))
az=np.degrees(np.arctan2(np.sin(l-lo0)*np.cos(p),math.cos(la0)*np.sin(p)-math.sin(la0)*np.cos(p)*np.cos(l-lo0)))%360
t=T[np.clip(np.round((90-LA)/0.25).astype(int),0,720),(np.round(LO/0.25).astype(int))%1440]
def section(b,half=7.5):
    d=np.radians(az-b); s=cc*np.cos(d); x=cc*np.sin(d); xs=np.arange(-90,91,2); top=[];thk=[]
    for c0 in xs:
        k=(np.abs(x)<=half)&(s>=c0-1)&(s<c0+1)
        top.append(np.median(dem[k]) if k.sum()>10 else np.nan); thk.append(np.median(t[k]) if k.sum()>10 else np.nan)
    return xs,np.array(top),np.array(thk)
secs=[(90,'W','E'),(0,'S','N'),(45,'SW','NE'),(135,'NW','SE')]
fig,axs=plt.subplots(4,1,figsize=(15,16),sharex=True)
for ax,(b,L,Rr) in zip(axs,secs):
    xs,top,thk=section(b); moho=top-thk
    ax.fill_between(xs,-80,moho,color='#b8c4d6',label='mantle')
    ax.fill_between(xs,moho,top,color='#f2c46d',label='crust')
    ax.plot(xs,top,color='k',lw=2.2,label='surface')
    ax.plot(xs,moho,color='#d00000',lw=3.2,label='base of the crust')
    for x0,x1 in [(-60,-45),(45,60)]: ax.annotate('',xy=(x0,-76),xytext=(x1,-76),arrowprops=dict(arrowstyle='<->',lw=1.5)); ax.text((x0+x1)/2,-73.5,'ring',ha='center',fontsize=10,weight='bold')
    for x0,x1 in [(-90,-70),(70,90)]: ax.annotate('',xy=(x0,-76),xytext=(x1,-76),arrowprops=dict(arrowstyle='<->',lw=1.2,color='#555')); ax.text((x0+x1)/2,-73.5,'farther out',ha='center',fontsize=9,color='#555')
    for sg in (-1,1): ax.axvline(sg*39.57,color='k',ls=':',lw=1)
    ax.text(0,-73.5,'SPA',ha='center',fontsize=11,weight='bold')
    for xx in (-80,-52,-20,0,20,52,80):
        i=np.argmin(abs(xs-xx))
        if np.isfinite(thk[i]): ax.text(xx,moho[i]-5.5,f'{thk[i]:.0f}',ha='center',fontsize=10,color='#d00000',weight='bold')
    ax.text(-89,6,L,fontsize=15,weight='bold'); ax.text(87,6,Rr,fontsize=15,weight='bold',ha='right')
    ax.set_ylim(-80,12); ax.set_ylabel('km'); ax.grid(alpha=0.2)
axs[0].legend(loc='upper center',ncol=4,fontsize=10,framealpha=0.95)
axs[-1].set_xlabel('distance from the SPA centre along the section (°) — dotted: SPA rim')
fig.suptitle('Cross-sections through SPA — yellow: crust; blue-grey: mantle; black line: surface; red line: base of the crust (numbers: crust thickness, km)',fontsize=12.5,weight='bold')
plt.tight_layout(rect=[0,0,1,0.98]); plt.savefig('/mnt/user-data/outputs/Figure_B4_cross_sections_2026-09-30.png',dpi=95); print('ok')
