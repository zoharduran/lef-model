import numpy as np, math, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
z=np.load('data/grail_compact.npz'); step=.25; t=z['Model1_thick'].astype(float)
lat=np.arange(90,-90-step/2,-step); lon=np.arange(0,360,step); LA,LO=np.meshgrid(lat,lon,indexing='ij'); W=np.cos(np.radians(LA))
p,l=np.radians(LA),np.radians(LO); la0,lo0=math.radians(-53),math.radians(191)
cc=np.degrees(np.arccos(np.clip(np.sin(la0)*np.sin(p)+np.cos(la0)*np.cos(p)*np.cos(l-lo0),-1,1)))
az=np.degrees(np.arctan2(np.sin(l-lo0)*np.cos(p),math.cos(la0)*np.sin(p)-math.sin(la0)*np.cos(p)*np.cos(l-lo0)))%360
# bump per 10-degree azimuth bin
bins=np.arange(0,360,10); bump=[]
for a in bins:
    s=((az-a)%360)<10
    r=s&(cc>=45)&(cc<60); f=s&(cc>=70)&(cc<90)
    bump.append(np.average(t[r],weights=W[r])-np.average(t[f],weights=W[f]))
bump=np.array(bump)
for a,b in zip(bins,bump): print(f'{a:3d}-{a+10:3d}: {b:+.1f}')
# map
n=1000; xs=np.linspace(-1,1,n); X,Y=np.meshgrid(xs,xs[::-1]); rho=np.hypot(X,Y); c=np.arcsin(np.clip(rho,0,1))
LAT=np.degrees(np.arcsin(np.clip(np.cos(c)*math.sin(la0)+np.where(rho>0,Y*np.sin(c)*math.cos(la0)/np.where(rho>0,rho,1),0),-1,1)))
LON=(np.degrees(lo0+np.arctan2(X*np.sin(c),rho*np.cos(c)*math.cos(la0)-Y*np.sin(c)*math.sin(la0))))%360
iy=np.clip(np.round((90-LAT)/step).astype(int),0,720); ix=np.round(LON/step).astype(int)%1440
img=t[iy,ix]; img[rho>0.999]=np.nan
def pt(azd,dd):
    d=math.radians(dd); b=math.radians(azd)
    la2=math.asin(math.sin(la0)*math.cos(d)+math.cos(la0)*math.sin(d)*math.cos(b)); lo2=lo0+math.atan2(math.sin(b)*math.sin(d)*math.cos(la0),math.cos(d)-math.sin(la0)*math.sin(la2))
    return math.cos(la2)*math.sin(lo2-lo0), math.cos(la0)*math.sin(la2)-math.sin(la0)*math.cos(la2)*math.cos(lo2-lo0)
fig,ax=plt.subplots(figsize=(10.5,10))
im=ax.imshow(img,extent=(-1,1,-1,1),cmap='viridis',vmin=0,vmax=70,alpha=0.85)
cb=fig.colorbar(im,ax=ax,fraction=0.035,pad=0.02); cb.set_label('crust thickness, GRAIL Model 1 (km)')
cmap=plt.cm.RdBu_r; norm=plt.Normalize(-8,8)
for a,b in zip(bins,bump):
    azs=np.linspace(a,a+10,12); P=[pt(q,45) for q in azs]+[pt(q,60) for q in azs[::-1]]
    ax.add_patch(Polygon(P,closed=True,fc=cmap(norm(b)),ec='k',lw=0.4,alpha=0.95))
    xm,ym=pt(a+5,52.5); ax.text(xm,ym,f'{b:+.0f}',ha='center',va='center',fontsize=8,weight='bold',color='k')
th=np.linspace(0,360,361); r=np.array([pt(q,39.57) for q in th]); ax.plot(r[:,0],r[:,1],'w',lw=2)
for lab,azd in [('N',0),('NE',45),('E',90),('SE',135),('S',180),('SW',225),('W',270),('NW',315)]:
    ax.text(*pt(azd,66),lab,ha='center',va='center',fontsize=12,weight='bold',color='white',bbox=dict(boxstyle='round,pad=0.15',fc='k',alpha=0.5,lw=0))
sm=plt.cm.ScalarMappable(cmap=cmap,norm=norm); cb2=fig.colorbar(sm,ax=ax,fraction=0.035,pad=0.08,location='left'); cb2.set_label('bump of the ring (km): ring 45–60° minus crust 70–90° in the same direction')
ax.set_xlim(-1.02,1.02); ax.set_ylim(-1.02,1.02); ax.set_aspect('equal'); ax.axis('off')
ax.set_title('Where the ring stands above its surroundings, and where it does not\n(10° segments; red = bump, blue = no bump; white circle = SPA rim)',fontsize=11)
plt.savefig('/mnt/user-data/outputs/Figure_B4_bump_map_2026-09-30.png',dpi=105,bbox_inches='tight')
# eight small graphs
names=['N','NE','E','SE','S','SW','W','NW']; edges=np.arange(0,92,3)
fig,axs=plt.subplots(2,4,figsize=(17,8),sharex=True,sharey=True)
for k,nm in enumerate(names):
    s=((az-45*k+22.5)%360)<45; prof=[]
    for a,b in zip(edges[:-1],edges[1:]):
        m=s&(cc>=a)&(cc<b); prof.append(np.average(t[m],weights=W[m]))
    prof=np.array(prof); x=edges[:-1]+1.5
    ax=axs[k//4,k%4]
    ax.axvspan(45,60,color='#ffd166',alpha=0.3); ax.axvspan(70,90,color='#a8dadc',alpha=0.3); ax.axvline(39.57,color='r',ls=':')
    ax.plot(x,prof,'o-',color='#1f3a5f',ms=3,lw=2)
    rv=prof[(x>=45)&(x<60)].mean(); fv=prof[(x>=70)&(x<90)].mean()
    ax.hlines(rv,45,60,colors='#d62828',lw=2.5); ax.hlines(fv,70,90,colors='#1d3557',lw=2.5)
    ax.set_title(f'{nm}: bump {rv-fv:+.1f} km',fontsize=12,weight='bold',color='#d62828' if rv-fv>2 else ('#1d3557' if rv-fv<0 else 'k'))
    ax.grid(alpha=0.3); ax.set_ylim(10,62)
    if k//4==1: ax.set_xlabel('distance from the SPA centre (°)')
    if k%4==0: ax.set_ylabel('crust (km), Model 1')
fig.suptitle('Crust from the SPA centre outward in eight directions — yellow: ring (45–60°), blue: farther out (70–90°), dotted red: rim',fontsize=12,weight='bold')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/Figure_B4_eight_profiles_2026-09-30.png',dpi=105); print('ok')
