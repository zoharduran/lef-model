import numpy as np, math, json, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.ndimage import uniform_filter
z=np.load('/home/claude/gd/SPA8_GRAIL/data/grail_compact.npz'); step=.25; t=z['Model1_thick'].astype(float)
la0,lo0=math.radians(-53),math.radians(191)
n=900; xs=np.linspace(-0.85,0.85,n); X,Y=np.meshgrid(xs,xs[::-1]); rho=np.hypot(X,Y); c=np.arcsin(np.clip(rho,0,1))
LAT=np.degrees(np.arcsin(np.clip(np.cos(c)*math.sin(la0)+np.where(rho>0,Y*np.sin(c)*math.cos(la0)/np.where(rho>0,rho,1),0),-1,1)))
LON=(np.degrees(lo0+np.arctan2(X*np.sin(c),rho*np.cos(c)*math.cos(la0)-Y*np.sin(c)*math.sin(la0))))%360
iy=np.clip(np.round((90-LAT)/step).astype(int),0,720); ix=np.round(LON/step).astype(int)%1440
img=t[iy,ix].copy(); img[rho>0.98]=np.nan
def ortho(la,lo):
    la,lo=np.radians(la),np.radians(lo); return np.cos(la)*np.sin(lo-lo0), np.cos(la0)*np.sin(la)-np.sin(la0)*np.cos(la)*np.cos(lo-lo0)
def circ(la,lo,r,n=361):
    la_,lo_,d=map(math.radians,(la,lo,r)); az=np.linspace(0,2*np.pi,n)
    la2=np.arcsin(np.sin(la_)*np.cos(d)+np.cos(la_)*np.sin(d)*np.cos(az)); lo2=lo_+np.arctan2(np.sin(az)*np.sin(d)*np.cos(la_),np.cos(d)-np.sin(la_)*np.sin(la2)); return np.degrees(la2),np.degrees(lo2)
def dist(a,b,c_,dd):
    a,b,c_,dd=map(math.radians,(a,b,c_,dd)); return math.degrees(math.acos(max(-1,min(1,math.sin(a)*math.sin(c_)+math.cos(a)*math.cos(c_)*math.cos(b-dd)))))
op=json.load(open('/tmp/zohar_openings_sized.json'))
MIN=(-47.5,193.5)
def base(ax,image,title):
    im=ax.imshow(image,extent=(-0.85,0.85,-0.85,0.85),cmap='viridis',vmin=0,vmax=70)
    L,O=circ(-53,191,39.57); x,y=ortho(L,O); ax.plot(x,y,color='#ff6b6b',lw=2.2)
    xn,yn=ortho(-20,191); ax.annotate('',xy=(xn,yn),xytext=ortho(-30,191),arrowprops=dict(arrowstyle='->',lw=2,color='white')); ax.text(xn+0.01,yn,'north',fontsize=10,color='white')
    ax.axis('off'); ax.set_title(title,fontsize=10.5); return im
def mark(ax,items):
    for name,(la,lo),mk,col,off in items:
        x,y=ortho(la,lo); ax.plot(x,y,mk,color=col,ms=16 if mk=='*' else 11,mec='k',mew=1,zorder=5)
        ax.annotate(name,(x,y),xytext=off,textcoords='offset points',fontsize=9.5,weight='bold',bbox=dict(boxstyle='round,pad=0.2',fc='white',alpha=0.88,lw=0),arrowprops=dict(arrowstyle='-',lw=0.6))
# Figure B3-a: as measured
fig,axs=plt.subplots(1,2,figsize=(17,8.4),gridspec_kw={'width_ratios':[1.2,1]})
ax=axs[0]; im=base(ax,img,'B3-a · Crust thickness around SPA, as measured\nred: SPA rim · dashed black: 30 km · white: 20 km · orange: openings inside SPA')
fig.colorbar(im,ax=ax,fraction=0.035,pad=0.02).set_label('crust thickness, GRAIL Model 1 (km)')
ax.contour(X,Y,np.where(np.isnan(img),99,img),levels=[20,30],colors=['white','k'],linewidths=[1.0,1.5],linestyles=['-','--'])
for i,(la,lo,r,src) in enumerate(op,1):
    if dist(la,lo,-53,191)<42:
        L,O=circ(la,lo,r); x,y=ortho(L,O); ax.plot(x,y,color='#ffb703',lw=1.8); xx,yy=ortho(la,lo); ax.text(xx,yy-0.035,f'opening {i}',color='#ffb703',fontsize=9,weight='bold',ha='center')
mark(ax,[('SPA centre',(-53,191),'o','#ff6b6b',(10,6)),('weakest crater record',MIN,'*','#ffd23f',(-150,10))])
a2=axs[1]
def dest(la,lo,brg,dd):
    la,lo,brg,dd=map(math.radians,(la,lo,brg,dd)); la2=math.asin(math.sin(la)*math.cos(dd)+math.cos(la)*math.sin(dd)*math.cos(brg)); lo2=lo+math.atan2(math.sin(brg)*math.sin(dd)*math.cos(la),math.cos(dd)-math.sin(la)*math.sin(la2)); return math.degrees(la2),math.degrees(lo2)%360
rs=np.arange(0,60.5,0.5); cols=['#1b9e77','#d95f02','#7570b3','#e7298a','#66a61e','#e6ab02','#a6761d','#666666']
for k,nm in enumerate(['N','NE','E','SE','S','SW','W','NW']):
    prof=[t[int(round((90-dest(-53,191,45*k,r)[0])/step)),int(round(dest(-53,191,45*k,r)[1]/step))%1440] for r in rs]
    a2.plot(rs,prof,color=cols[k],lw=1.8,label=nm)
a2.axhline(30,color='k',ls='--',lw=1); a2.axvline(39.57,color='#ff6b6b',lw=1.5); a2.text(40,3,'rim',color='#ff6b6b')
a2.annotate('Apollo (opening 5)',xy=(19.5,3),xytext=(4,7),arrowprops=dict(arrowstyle='->'),fontsize=9)
a2.set_xlabel('angular distance from the SPA centre (°)'); a2.set_ylabel('crust thickness, Model 1 (km)'); a2.grid(alpha=0.3); a2.legend(title='direction',ncol=2,fontsize=9)
a2.set_title('Crust along eight directions from the SPA centre (Model 1)',fontsize=10.5)
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/Figure_B3a_thin_crust_as_measured.png',dpi=110)
# Figure B3-b: SPA only
keep=np.load('/tmp/b3_keep_op.npy'); kp=keep[iy,ix]
fig,ax=plt.subplots(figsize=(10.5,10))
im=base(ax,np.where(kp,img,np.nan),"B3-b · SPA's own thin crust — openings and lava plains removed (grey)\nred: SPA rim · dashed black: 30 km · white: 20 km (smoothed over the kept ground, GRAIL Model 1)")
ax.imshow(np.where(~kp&np.isfinite(img),1.0,np.nan),extent=(-0.85,0.85,-0.85,0.85),cmap='Greys',vmin=0,vmax=2,alpha=0.9)
fig.colorbar(im,ax=ax,fraction=0.035,pad=0.02).set_label('crust thickness, GRAIL Model 1 (km)')
num=uniform_filter(np.where(keep,t,0),(12,12),mode='wrap'); den=uniform_filter(keep.astype(float),(12,12),mode='wrap'); ts=np.where(den>0.3,num/np.maximum(den,1e-9),np.nan)
cont=ts[iy,ix]; cont[rho>0.98]=np.nan
ax.contour(X,Y,np.nan_to_num(cont,nan=99),levels=[20,30],colors=['white','k'],linewidths=[1.3,1.6],linestyles=['-','--'])
mark(ax,[('SPA centre',(-53,191),'o','#ff6b6b',(10,6)),('weakest crater record',MIN,'*','#ffd23f',(10,8)),
    ('thinnest SPA crust',(-61.2,184.2),'D','#e8743b',(-120,-20)),('thin-zone centroid',(-57.5,187.5),'s','white',(-150,8)),
    ('lowest intercrater ground',(-61.2,199.3),'v','#003049',(10,-14)),('dense mass (James)',(-62,200),'X','#b5452c',(10,6))])
plt.savefig('/mnt/user-data/outputs/Figure_B3b_thin_crust_SPA_only.png',dpi=110,bbox_inches='tight'); print('ok')
