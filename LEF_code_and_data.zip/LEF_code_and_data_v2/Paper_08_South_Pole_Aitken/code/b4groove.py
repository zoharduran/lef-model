import numpy as np, math, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
dem=np.fromfile('/mnt/user-data/uploads/ldem_4.img',dtype='<i2').reshape(720,1440).astype(float)*0.5/1000
z=np.load('/home/claude/gd/SPA8_GRAIL/data/grail_compact.npz')
lat=90-(np.arange(720)+0.5)/4; lon=(np.arange(1440)+0.5)/4; LA,LO=np.meshgrid(lat,lon,indexing='ij')
p,l=np.radians(LA),np.radians(LO); la0,lo0=math.radians(-53),math.radians(191)
cc=np.degrees(np.arccos(np.clip(np.sin(la0)*np.sin(p)+np.cos(la0)*np.cos(p)*np.cos(l-lo0),-1,1)))
az=np.degrees(np.arctan2(np.sin(l-lo0)*np.cos(p),math.cos(la0)*np.sin(p)-math.sin(la0)*np.cos(p)*np.cos(l-lo0)))%360
iy=np.clip(np.round((90-LA)/0.25).astype(int),0,720); ix=(np.round(LO/0.25).astype(int))%1440
t1=z['Model1_thick'].astype(float)[iy,ix]
# signed distance along an axis: + toward bearing b, - toward b+180; strip half-width w (deg) measured as cross-track angle
def profile(field,b,half=12):
    # along-track coordinate s = cc*cos(az-b); cross-track x = cc*sin(az-b)
    d=np.radians(az-b); s=cc*np.cos(d); x=cc*np.sin(d)
    out=[]
    for c0 in np.arange(-55,56,2.5):
        k=(np.abs(x)<=half)&(s>=c0-1.25)&(s<c0+1.25)
        out.append(np.median(field[k]) if k.sum()>20 else np.nan)
    return np.arange(-55,56,2.5),np.array(out)
fig,axs=plt.subplots(2,2,figsize=(15,9),sharex=True)
for j,(b,name,rng) in enumerate([(180,'N → S axis (new hypothesis): negative = north (up-range), positive = south (down-range)',None),(315,'SE → NW axis (old hypothesis): negative = south-east (up-range), positive = north-west (down-range)',None)]):
    s,e=profile(dem,b); s2,tt=profile(t1,b)
    ax=axs[0,j]; ax.plot(s,e,'o-',color='#1f3a5f',lw=2); ax.axvline(0,color='k',lw=0.8); ax.axvline(-39.57,color='r',ls=':'); ax.axvline(39.57,color='r',ls=':')
    ax.set_ylabel('elevation, median in a strip ±12° wide (km)'); ax.grid(alpha=0.3); ax.set_title(name,fontsize=10)
    ax=axs[1,j]; ax.plot(s2,tt,'o-',color='#b5452c',lw=2); ax.axvline(0,color='k',lw=0.8); ax.axvline(-39.57,color='r',ls=':'); ax.axvline(39.57,color='r',ls=':')
    ax.set_ylabel('crust thickness, Model 1 (km)'); ax.set_xlabel('distance along the axis from the SPA centre (°); red dotted: rim'); ax.grid(alpha=0.3)
    for arr,lab in [(s,e),(s2,tt)]:
        pass
    print(name[:12], 'elev:',' '.join(f'{a:.0f}:{v:.1f}' for a,v in zip(s,e) if abs(a)<=45))
    print(name[:12], 'crust:',' '.join(f'{a:.0f}:{v:.0f}' for a,v in zip(s2,tt) if abs(a)<=45))
fig.suptitle('B4 · Is there a groove that deepens along the impact track? Profiles of elevation and crust along the two proposed impact axes',fontsize=12,weight='bold')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/Figure_B4_groove_profiles_2026-09-30.png',dpi=105); print('ok')
