import numpy as np, pandas as pd, math, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Wedge, Polygon
from numpy.polynomial.legendre import legval
z=np.load('data/grail_compact.npz'); step=.25; t=z['Model1_thick'].astype(float)
cf=pd.read_csv('results/baseline_coefficients.csv'); co=cf[(cf.model==1)&(cf.baseline=='earth_legendre4')].sort_values('order').coefficient_km.values
R=1737.4; la0,lo0=math.radians(-53),math.radians(191)
n=1000; xs=np.linspace(-1,1,n); X,Y=np.meshgrid(xs,xs[::-1]); rho=np.hypot(X,Y); c=np.arcsin(np.clip(rho,0,1))
LAT=np.degrees(np.arcsin(np.clip(np.cos(c)*math.sin(la0)+np.where(rho>0,Y*np.sin(c)*math.cos(la0)/np.where(rho>0,rho,1),0),-1,1)))
LON=(np.degrees(lo0+np.arctan2(X*np.sin(c),rho*np.cos(c)*math.cos(la0)-Y*np.sin(c)*math.sin(la0))))%360
iy=np.clip(np.round((90-LAT)/step).astype(int),0,720); ix=np.round(LON/step).astype(int)%1440
beta=np.degrees(np.arccos(np.clip(np.cos(np.radians(LAT))*np.cos(np.radians(LON)),-1,1)))
res=t[iy,ix]-legval(np.cos(np.radians(beta)),co)
ang=np.degrees(np.arcsin(np.clip(rho,0,1)))
img=np.where((ang<=72)&(rho<=1),res,np.nan)
def pt(az,dd):  # point at bearing az (deg from N), distance dd (deg) from SPA centre -> map xy
    la_r,lo_r=la0,lo0; d=math.radians(dd); b=math.radians(az)
    la2=math.asin(math.sin(la_r)*math.cos(d)+math.cos(la_r)*math.sin(d)*math.cos(b)); lo2=lo_r+math.atan2(math.sin(b)*math.sin(d)*math.cos(la_r),math.cos(d)-math.sin(la_r)*math.sin(la2))
    return math.cos(la2)*math.sin(lo2-lo0), math.cos(la0)*math.sin(la2)-math.sin(la0)*math.cos(la2)*math.cos(lo2-lo0)
def sector(ax,a1,a2,r1,r2,**kw):
    az=np.linspace(a1,a2,60); P=[pt(a,r2) for a in az]+[pt(a,r1) for a in az[::-1]]; ax.add_patch(Polygon(P,closed=True,**kw))
fig,axs=plt.subplots(1,2,figsize=(18,9.2))
for k,(ax,title,mode) in enumerate(zip(axs,['Old hypothesis: impact from the SE toward the NW (Melosh et al. 2017)','New hypothesis: impact from the N toward the S (Andrews-Hanna 2025; Wakita 2026)'],['old','new'])):
    im=ax.imshow(img,extent=(-1,1,-1,1),cmap='RdBu_r',vmin=-14,vmax=14)
    th=np.linspace(0,360,400)
    rim=np.array([pt(a,39.57) for a in th]); ax.plot(rim[:,0],rim[:,1],'k',lw=2.2,label='SPA rim (circle 39.6°)')
    o70=np.array([pt(a,70) for a in th]); ax.plot(o70[:,0],o70[:,1],'k--',lw=1)
    # ellipse 2400 x 2050 km, long axis along azimuth +/-18.8 from N (two published orientations)
    for orient,ls in [(18.8,'-'),(-18.8,':')]:
        E=[]
        for a in th:
            phi=math.radians(a-orient); r_km=1/math.sqrt((math.cos(phi)/1200)**2+(math.sin(phi)/1025)**2)
            E.append(pt(a,math.degrees(r_km/R)))
        E=np.array(E); ax.plot(E[:,0],E[:,1],color='#2d6a4f',lw=1.8,ls=ls,label=f'SPA ellipse 2,400×2,050 km, long axis {orient:+.1f}°')
    if mode=='old':
        sector(ax,280,350,40,70,fc='none',ec='#6a0dad',lw=2.5,hatch='//',label='predicted ejecta excess (down-range)')
        a,b=pt(135,55),pt(315,25); ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='-|>',lw=4,color='#6a0dad'))
        ax.text(*pt(140,60),'impactor\ncame from here',color='#6a0dad',fontsize=10,weight='bold',ha='center')
    else:
        sector(ax,150,210,40,70,fc='none',ec='#6a0dad',lw=2.5,hatch='//',label='predicted excess: down-range (S)')
        sector(ax,60,120,40,70,fc='none',ec='#e76f51',lw=2.2,hatch='\\\\',label='predicted excess: cross-range lobes (E and W)')
        sector(ax,240,300,40,70,fc='none',ec='#e76f51',lw=2.2,hatch='\\\\')
        a,b=pt(0,55),pt(180,22); ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='-|>',lw=4,color='#6a0dad'))
        ax.text(*pt(8,60),'impactor\ncame from here',color='#6a0dad',fontsize=10,weight='bold',ha='center')
    for lab,az in [('N',0),('E',90),('S',180),('W',270),('NE',45),('SE',135),('SW',225),('NW',315)]:
        ax.text(*pt(az,75),lab,ha='center',va='center',fontsize=12,weight='bold')
    ax.set_xlim(-1.05,1.05); ax.set_ylim(-1.05,1.05); ax.set_aspect('equal'); ax.axis('off'); ax.set_title(title,fontsize=11.5)
    ax.legend(loc='upper center',bbox_to_anchor=(0.5,-0.02),ncol=2,fontsize=9,framealpha=0.95)
cb=fig.colorbar(im,ax=axs,fraction=0.02,pad=0.01); cb.set_label('crust relative to the regional trend (km) — red thicker, blue thinner (GRAIL Model 1)')
fig.suptitle('B4 · The measured crust around SPA against what each impact direction predicts',fontsize=13,weight='bold')
plt.savefig('/mnt/user-data/outputs/Figure_B4_impact_directions_2026-09-30.png',dpi=105,bbox_inches='tight'); print('ok')
