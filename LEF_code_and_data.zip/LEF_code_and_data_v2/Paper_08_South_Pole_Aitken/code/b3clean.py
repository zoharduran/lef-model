import numpy as np, math, json, struct, pandas as pd
from matplotlib.path import Path
from scipy.ndimage import uniform_filter
z=np.load('/home/claude/gd/SPA8_GRAIL/data/grail_compact.npz'); step=.25
lat=np.arange(90,-90-step/2,-step); lon=np.arange(0,360,step); LA,LO=np.meshgrid(lat,lon,indexing='ij'); W=np.cos(np.radians(LA)); R=1737.4
def v(la,lo): la,lo=np.radians(la),np.radians(lo); return np.stack([np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)],-1)
V=v(LA,LO); d=np.degrees(np.arccos(np.clip(V@v(-53,191),-1,1))); near=d<62; Vn=V[near]
def km(p,q): return R*math.acos(float(np.clip(v(*p)@v(*q),-1,1)))
# openings
op=json.load(open('/tmp/zohar_openings_sized.json')); m_op=np.zeros(near.sum(),bool)
for la,lo,r,_ in op: m_op|=np.degrees(np.arccos(np.clip(Vn@v(la,lo),-1,1)))<=r
# LROC
def read_shp(fn):
    b=open(fn,'rb').read(); pos=100; polys=[]
    while pos<len(b):
        _,cl=struct.unpack('>ii',b[pos:pos+8]); pos+=8; rec=b[pos:pos+cl*2]; pos+=cl*2
        if struct.unpack('<i',rec[:4])[0] not in (5,15,25): continue
        np_,npt=struct.unpack('<ii',rec[36:44]); parts=list(struct.unpack('<%di'%np_,rec[44:44+4*np_]))+[npt]
        pts=np.frombuffer(rec[44+4*np_:44+4*np_+16*npt],dtype='<f8').reshape(-1,2); polys+=[pts[parts[i]:parts[i+1]] for i in range(np_)]
    return polys
polys=read_shp('/home/claude/kit/lroc/LROC_GLOBAL_MARE_180.SHP')
pts=np.c_[(((LO[near]+180)%360)-180),LA[near]]; m_mare=np.zeros(len(pts),bool)
for p in polys:
    if len(p)<3: continue
    bb=(pts[:,0]>=p[:,0].min())&(pts[:,0]<=p[:,0].max())&(pts[:,1]>=p[:,1].min())&(pts[:,1]<=p[:,1].max())
    if bb.any(): m_mare[bb]|=Path(p).contains_points(pts[bb])
# craters >=20 km (<300 km), margin 1.5 radii
cr=pd.read_csv('/home/claude/kit/Robbins_Dge20_selected.csv'); cv=v(cr.LAT_CIRC_IMG.values,cr.LON_CIRC_IMG.values%360); cd=np.degrees(np.arccos(np.clip(cv@v(-53,191),-1,1)))
cr=cr[(cd<66)&(cr.DIAM_CIRC_IMG<300)]; m_cr=np.zeros(near.sum(),bool)
for la,lo,D in zip(cr.LAT_CIRC_IMG.values,cr.LON_CIRC_IMG.values%360,cr.DIAM_CIRC_IMG.values):
    m_cr|=np.degrees(np.arccos(np.clip(Vn@v(la,lo),-1,1)))<=math.degrees(1.5*D/2/R)
keep=np.zeros(LA.shape,bool); keep[near]=~(m_op|m_mare|m_cr)
keep_op=np.zeros(LA.shape,bool); keep_op[near]=~(m_op|m_mare)
np.save('/tmp/b3_keep.npy',keep); np.save('/tmp/b3_keep_op.npy',keep_op)
print('share of SPA kept: openings+maria removed %.0f%%; +craters %.0f%%'%(100*keep_op[d<39.57].mean(),100*keep[d<39.57].mean()))
def ll(vec): vec=vec/np.linalg.norm(vec); return (round(math.degrees(math.asin(vec[2])),1),round(math.degrees(math.atan2(vec[1],vec[0]))%360,1))
for label,K in [('without openings and maria',keep_op),('without openings, maria and craters >=20 km',keep)]:
    print('\n==',label)
    for m in (1,2,3,4):
        t=z[f'Model{m}_thick'].astype(float)
        row=[]
        for thr in (20,25,30):
            sel=K&(d<45)&(t<thr); cen=ll((W[sel][:,None]*V[sel]).sum(0)); row.append((thr,cen,km(cen,(-53,191)),km(cen,(-44.5,198.5))))
        num=uniform_filter(np.where(K,t,0),(24,24),mode='wrap'); den=uniform_filter(K.astype(float),(24,24),mode='wrap')
        sm=np.where(den>0.3,num/np.maximum(den,1e-9),np.nan); kk=(d<39.57)&np.isfinite(sm)
        i=np.unravel_index(np.nanargmin(np.where(kk,sm,np.nan)),sm.shape); tp=(float(LA[i]),float(LO[i]))
        print(f' Model {m}: thinnest (smoothed, kept ground) {tp} {sm[i]:.1f} km; from centre {km(tp,(-53,191)):.0f} km, from crater min {km(tp,(-44.5,198.5)):.0f} km')
        for thr,cen,dc,dm in row: print(f'    <{thr} km centroid {cen}: from centre {dc:.0f} km, from crater min {dm:.0f} km')
# sector medians: radius where the sector-median crust (kept ground) first exceeds 30 km, Model 1 and 4
def az(la,lo):
    la0,lo0=math.radians(-53),math.radians(191); la,lo=np.radians(la),np.radians(lo)
    return np.degrees(np.arctan2(np.sin(lo-lo0)*np.cos(la),math.cos(la0)*np.sin(la)-math.sin(la0)*np.cos(la)*np.cos(lo-lo0)))%360
A=az(LA,LO)
for m in (1,4):
    t=z[f'Model{m}_thick'].astype(float); out=[]
    for k,nm in enumerate(['N','NE','E','SE','S','SW','W','NW']):
        s=((A-45*k+22.5)%360)<45
        rr=None
        for r in np.arange(0,50,1.0):
            sel=keep&s&(d>=r)&(d<r+2)
            if sel.sum()<20: continue
            if np.median(t[sel])>30: rr=r+1; break
        out.append(f'{nm} {rr}')
    print(f'Model {m}, sector-median crust exceeds 30 km at (deg):',', '.join(out))
