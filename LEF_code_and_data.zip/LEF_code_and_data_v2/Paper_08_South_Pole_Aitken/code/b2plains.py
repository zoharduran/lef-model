import numpy as np, math, json, struct, pandas as pd
from matplotlib.path import Path
from scipy.ndimage import uniform_filter
dem=np.fromfile('/mnt/user-data/uploads/ldem_4.img',dtype='<i2').reshape(720,1440).astype(float)*0.5/1000
lat=90-(np.arange(720)+0.5)/4; lon=(np.arange(1440)+0.5)/4
LA,LO=np.meshgrid(lat,lon,indexing='ij'); W=np.cos(np.radians(LA)); R=1737.4
def v(la,lo): la,lo=np.radians(la),np.radians(lo); return np.stack([np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)],-1)
V=v(LA,LO)
def dist(a,b): return np.degrees(np.arccos(np.clip(V@v(a,b),-1,1)))
d=dist(-53,191); near=d<65
# craters (Robbins >=20 km) near SPA
cr=pd.read_csv('/home/claude/kit/Robbins_Dge20_selected.csv')
cv=v(cr.LAT_CIRC_IMG.values,cr.LON_CIRC_IMG.values%360); cd=np.degrees(np.arccos(np.clip(cv@v(-53,191),-1,1)))
cr=cr[(cd<70)&(cr.DIAM_CIRC_IMG<300)].copy(); print('craters >=20 km within 70 deg:',len(cr))
Vn=V[near]
def crater_mask(buf):
    m=np.zeros(near.sum(),bool)
    for la,lo,D in zip(cr.LAT_CIRC_IMG.values,cr.LON_CIRC_IMG.values%360,cr.DIAM_CIRC_IMG.values):
        r=math.degrees(buf*D/2/R)
        m|=np.degrees(np.arccos(np.clip(Vn@v(la,lo),-1,1)))<=r
    M=np.zeros(LA.shape,bool); M[near]=m; return M
# mare + openings (cleaned ground)
def read_shp(fn):
    b=open(fn,'rb').read(); pos=100; polys=[]
    while pos<len(b):
        _,cl=struct.unpack('>ii',b[pos:pos+8]); pos+=8; rec=b[pos:pos+cl*2]; pos+=cl*2
        if struct.unpack('<i',rec[:4])[0] not in (5,15,25): continue
        np_,npt=struct.unpack('<ii',rec[36:44]); parts=list(struct.unpack('<%di'%np_,rec[44:44+4*np_]))+[npt]
        pts=np.frombuffer(rec[44+4*np_:44+4*np_+16*npt],dtype='<f8').reshape(-1,2); polys+=[pts[parts[i]:parts[i+1]] for i in range(np_)]
    return polys
polys=read_shp('/home/claude/kit/lroc/LROC_GLOBAL_MARE_180.SHP')
pts=np.c_[(((LO+180)%360)-180).ravel(),LA.ravel()]; mare=np.zeros(len(pts),bool)
for p in polys:
    if len(p)<3: continue
    bb=(pts[:,0]>=p[:,0].min())&(pts[:,0]<=p[:,0].max())&(pts[:,1]>=p[:,1].min())&(pts[:,1]<=p[:,1].max())
    if bb.any(): mare[bb]|=Path(p).contains_points(pts[bb])
mare=mare.reshape(LA.shape)
op=json.load(open('/tmp/zohar_openings_sized.json')); opm=np.zeros(LA.shape,bool)
for la,lo,r,_ in op: opm|=dist(la,lo)<=r
clean=~mare&~opm
z=np.load('/home/claude/gd/SPA8_GRAIL/data/grail_compact.npz'); iy=np.clip(np.round((90-LA)/0.25).astype(int),0,720); ix=(np.round(LO/0.25).astype(int))%1440
rings=[(0,5),(5,10),(10,15),(15,20),(20,25),(25,30),(30,35),(35,39.57),(39.57,50)]
for buf in (1.0,1.5,2.0):
    CM=crater_mask(buf); G=clean&~CM
    ref=(d>=39.57)&(d<50)&G; frac=G[d<39.57].mean()
    print(f'\n== intercrater plains, craters>=20 km masked to {buf} radii; share of SPA floor kept {frac*100:.0f}%')
    eref=np.average(dem[ref],weights=W[ref])
    for a,b in rings:
        k=(d>=a)&(d<b)&G
        if k.sum()<10: print(f'{a}-{b}: too few ({k.sum()})'); continue
        e=np.average(dem[k],weights=W[k])-eref; pr=[]
        for m in (1,4):
            t=z[f'Model{m}_thick'].astype(float)[iy,ix]
            dt=np.average(t[k],weights=W[k])-np.average(t[ref],weights=W[ref]); pr.append(dt*(3220-2550)/3220)
        print(f'{a:>5}-{b:<5} N={k.sum():5d} observed {e:6.2f}  crust-only M1 {pr[0]:6.2f} M4 {pr[1]:6.2f}  residual {e-pr[0]:6.2f} / {e-pr[1]:6.2f}')
    # lowest intercrater ground (smoothed over kept cells only)
    num=uniform_filter(np.where(G,dem,0),(12,12),mode='wrap'); den=uniform_filter(G.astype(float),(12,12),mode='wrap')
    sm=np.where(den>0.3,num/np.maximum(den,1e-9),np.nan)
    k=(d<39.57)&np.isfinite(sm); i=np.unravel_index(np.nanargmin(np.where(k,sm,np.nan)),sm.shape)
    t1=z['Model1_thick'].astype(float)[iy,ix]; airy=(t1-np.average(t1[ref],weights=W[ref]))*(3220-2550)/3220
    rn=uniform_filter(np.where(G,dem-eref-airy,0),(12,12),mode='wrap'); rs=np.where(den>0.3,rn/np.maximum(den,1e-9),np.nan)
    j=np.unravel_index(np.nanargmin(np.where(k,rs,np.nan)),rs.shape)
    print(f'   lowest intercrater ground {LA[i]:.1f},{LO[i]:.1f} ({sm[i]:.2f} km); deepest below isostasy (M1) {LA[j]:.1f},{LO[j]:.1f} ({rs[j]:.2f} km)')
