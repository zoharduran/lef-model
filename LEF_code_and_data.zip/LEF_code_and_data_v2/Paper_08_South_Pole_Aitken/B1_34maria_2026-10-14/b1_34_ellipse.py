import numpy as np, pandas as pd, math, json
exec(open('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/מחקרים_על_ימות_זוהר_2026-10-13/maria_def.py').read())
R=1737.4; C0=(-53,191)
def mask(la,lo,halo=200):
    st,_=O.classify(lo,la); m=st!=''
    d=np.arccos(np.clip(O.xyz(la,lo)@O.xyz(M.clat,M.clon).T,-1,1))*R
    return m|(d<(M.radius_km.values+halo)[None,:]).any(1)
def local(la,lo):  # azimuthal equidistant about C0: x east, y north (km)
    p1,l1=np.radians(C0[0]),np.radians(C0[1]); p2,l2=np.radians(la),np.radians(lo)
    c=np.arccos(np.clip(np.sin(p1)*np.sin(p2)+np.cos(p1)*np.cos(p2)*np.cos(l2-l1),-1,1))
    az=np.arctan2(np.sin(l2-l1)*np.cos(p2),np.cos(p1)*np.sin(p2)-np.sin(p1)*np.cos(p2)*np.cos(l2-l1))
    return R*c*np.sin(az),R*c*np.cos(az)
step=0.25; la,lo=np.meshgrid(np.arange(-90+step/2,0,step),np.arange(step/2,360,step),indexing='ij'); la=la.ravel(); lo=lo.ravel()
A=np.cos(np.radians(la))*(step*np.pi/180*R)**2; GM=mask(la,lo)
rob=pd.read_csv('/home/claude/LEF_המוח/06_נתונים_משותפים/Robbins_Dge20_selected.csv'); rla,rlo=rob.LAT_CIRC_IMG.values,rob.LON_CIRC_IMG.values%360
rob=rob[rla<0]; rla,rlo=rob.LAT_CIRC_IMG.values,rob.LON_CIRC_IMG.values%360; CM=mask(rla,rlo)
for th in (18.8,-18.8):
    out=[]
    for (x,y) in [local(la,lo),local(rla,rlo)]:
        t=np.radians(th); xr=x*np.cos(t)-y*np.sin(t); yr=x*np.sin(t)+y*np.cos(t)
        out.append(np.sqrt((xr/1025)**2+(yr/1200)**2))
    rg,rc=out
    den=lambda c,g: c.sum()/A[g].sum()*1e6
    core=den((rc<0.25)&~CM,(rg<0.25)&~GM); half=den((rc>=0.5)&(rc<1)&~CM,(rg>=0.5)&(rg<1)&~GM); outr=den((rc>=1)&(rc<1.27)&~CM,(rg>=1)&(rg<1.27)&~GM)
    print('tilt',th,'core %.0f (n=%d) outer half %.0f outside %.0f'%(core,((rc<0.25)&~CM).sum(),half,outr))
def gc(a,b,c,d): 
    a,b,c,d=map(math.radians,(a,b,c,d)); return R*math.acos(math.sin(a)*math.sin(c)+math.cos(a)*math.cos(c)*math.cos(b-d))
mn=(-45.38,197.88)
for nm,p in {'Serenitatis antipode':(-25.4,198.8),'Imbrium antipode':(-37,161.5),'Chang-e 6':(-41.625,206.022),'James mass':(-62,200),'SPA centre':(-53,191),'old minimum':(-44.5,198.5)}.items(): print(nm,round(gc(*mn,*p)))
