# SPA B1 sizes and depths on the 34-maria mask (+200 km halo), Wang & Wu 2021.
import numpy as np, pandas as pd, math, json
exec(open('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/מחקרים_על_ימות_זוהר_2026-10-13/maria_def.py').read())
R=1737.4; C0=(-53,191); rng=np.random.default_rng(7)
def ang(la,lo,a,b): return np.degrees(np.arccos(np.clip(O.xyz(la,lo)@O.xyz(a,b)[0],-1,1)))
def mask(la,lo,halo=200):
    st,_=O.classify(lo,la); m=st!=''
    d=np.arccos(np.clip(O.xyz(la,lo)@O.xyz(M.clat,M.clon).T,-1,1))*R
    return m|(d<(M.radius_km.values+halo)[None,:]).any(1)
step=0.25
la,lo=np.meshgrid(np.arange(-90+step/2,0,step),np.arange(step/2,360,step),indexing='ij'); la=la.ravel(); lo=lo.ravel()
A=np.cos(np.radians(la))*(step*np.pi/180*R)**2; GM=mask(la,lo); tg=ang(la,lo,*C0)
w=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3,4]); w.columns=['lon','lat','D','d']
w=w[(w.lat<0)&(w.D>=10000)].reset_index(drop=True); w['D']/=1000; w['lon']%=360
cla,clo=w.lat.values,w.lon.values; CM=mask(cla,clo); tc=ang(cla,clo,*C0)
# rim touches mask: test 8 rim points
rim=np.zeros(len(w),bool)
for az in range(0,360,45):
    a=np.radians(az); dr=(w.D.values/2)/R
    p1=np.radians(cla); l1=np.radians(clo)
    p2=np.arcsin(np.sin(p1)*np.cos(dr)+np.cos(p1)*np.sin(dr)*np.cos(a)); l2=l1+np.arctan2(np.sin(a)*np.sin(dr)*np.cos(p1),np.cos(dr)-np.sin(p1)*np.sin(p2))
    rim|=mask(np.degrees(p2),np.degrees(l2)%360)
den=lambda c,g: c.sum()/A[g].sum()*1e6
rings=[(0,10),(10,20),(20,30),(30,39.57),(39.57,50)]; bins=[(10,20),(20,40),(40,60),(60,1e4)]
T={f'{a}-{b}':[round(den((tc>=r0)&(tc<r1)&~CM&(w.D>=a)&(w.D<b),(tg>=r0)&(tg<r1)&~GM),1) for r0,r1 in rings] for a,b in bins}
print('sizes',json.dumps(T))
# small/large ratio central 10 deg vs same latitudes outside SPA
def ratio(sel): s=(sel&(w.D>=10)&(w.D<20)).sum(); l=(sel&(w.D>=20)&(w.D<80)).sum(); return s/l,s,l
def boot(sel):
    i=np.flatnonzero(sel); v=[]
    for _ in range(2000):
        j=rng.choice(i,len(i)); s=((w.D.values[j]>=10)&(w.D.values[j]<20)).sum(); l=((w.D.values[j]>=20)&(w.D.values[j]<80)).sum(); v.append(s/max(l,1))
    return np.percentile(v,[2.5,97.5]).round(2)
cen=(tc<10)&~CM; outl=(tc>39.57)&(cla<=-13.4)&~CM
print('ratio centre',[round(x,2) if isinstance(x,float) else x for x in ratio(cen)],boot(cen),' outside same lat',[round(x,2) if isinstance(x,float) else x for x in ratio(outl)],boot(outl))
print('ratio rings',[round(ratio((tc>=a)&(tc<b)&~CM)[0],2) for a,b in rings[1:]])
# depth/diameter: centre 0-10 vs outside ring, by size, all and rim-clean
dd=w.d.values/1000/w.D.values
for lab,cl in [('centre-only mask',~CM),('rim-clean',~CM&~rim)]:
    for a,b in [(10,20),(20,40),(40,80)]:
        s=(w.D>=a)&(w.D<b)&cl; c=s&(tc<10); o=s&(tc>=39.57)&(tc<50)
        print(lab,a,b,'centre %.3f (n=%d) outside %.3f (n=%d)'%(np.median(dd[c]),c.sum(),np.median(dd[o]),o.sum()))
# strict: 40-80 km, central 20 deg vs outside ring, rim-clean, bootstrap of median contrast
s=(w.D>=40)&(w.D<80)&~CM&~rim; c=np.flatnonzero(s&(tc<20)); o=np.flatnonzero(s&(tc>=39.57)&(tc<50))
v=[1-np.median(dd[rng.choice(c,len(c))])/np.median(dd[rng.choice(o,len(o))]) for _ in range(4000)]
print('strict 40-80 central 20: shallower by %.0f%% [%.0f, %.0f], n=%d vs %d'%(100*(1-np.median(dd[c])/np.median(dd[o])),*np.percentile(np.array(v)*100,[2.5,97.5]),len(c),len(o)))
