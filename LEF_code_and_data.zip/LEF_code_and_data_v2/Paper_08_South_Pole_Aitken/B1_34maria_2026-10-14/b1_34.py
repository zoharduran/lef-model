# SPA B1 rerun on Zohar's 34 maria (14.10.2026). Clean ground = LROC basalt + 34 mare footprints (dome core) + 200 km halo
# around each footprint (the 30.9 rule, now on the 34 maria). Robbins >=20 km; Wang for sizes and depths.
import numpy as np, pandas as pd, math, json, sys
exec(open('/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/מחקרים_על_ימות_זוהר_2026-10-13/maria_def.py').read())
R=1737.4; C0=(-53,191)
def ang(la,lo,a,b): return np.degrees(np.arccos(np.clip(O.xyz(la,lo)@O.xyz(a,b)[0],-1,1)))
def mask(la,lo,halo=200):
    st,_=O.classify(lo,la); m=st!=''
    X=O.xyz(la,lo); MC=O.xyz(M.clat,M.clon)
    d=np.arccos(np.clip(X@MC.T,-1,1))*R
    return m|(d<(M.radius_km.values+halo)[None,:]).any(1)
step=0.25
la,lo=np.meshgrid(np.arange(-90+step/2,90,step),np.arange(step/2,360,step),indexing='ij'); la=la.ravel(); lo=lo.ravel()
A=np.cos(np.radians(la))*(step*np.pi/180*R)**2
res={}
for halo in (0,200):
  GM=mask(la,lo,halo)
  rob=pd.read_csv('/home/claude/LEF_המוח/06_נתונים_משותפים/Robbins_Dge20_selected.csv'); rla,rlo,rD=rob.LAT_CIRC_IMG.values,rob.LON_CIRC_IMG.values%360,rob.DIAM_CIRC_IMG.values
  CM=mask(rla,rlo,halo)
  tg=ang(la,lo,*C0); tc=ang(rla,rlo,*C0)
  den=lambda c,g: c.sum()/A[g].sum()*1e6
  ins_g,ins_c=tg<=39.57,tc<=39.57
  out=dict(halo=halo,kept_SPA=round(A[ins_g&~GM].sum()/A[ins_g].sum(),3))
  out['SPA']=den(ins_c&~CM,ins_g&~GM); out['rest']=den(~ins_c&~CM,~ins_g&~GM)
  lat_g=(la<=-13.4)&~ins_g; lat_c=(rla<=-13.4)&~ins_c
  out['samelat']=den(lat_c&~CM,lat_g&~GM)
  rings=[(0,10),(10,20),(20,30),(30,39.57),(39.57,50)]
  out['rings20']=[(round(den((tc>=a)&(tc<b)&~CM,(tg>=a)&(tg<b)&~GM),1),int(((tc>=a)&(tc<b)&~CM).sum())) for a,b in rings]
  out['rings40']=[(round(den((tc>=a)&(tc<b)&~CM&(rD>=40),(tg>=a)&(tg<b)&~GM),1),int(((tc>=a)&(tc<b)&~CM&(rD>=40)).sum())) for a,b in rings]
  # sectors in central 20 deg: azimuth from centre
  def az(la_,lo_):
      p1,l1=np.radians(C0[0]),np.radians(C0[1]); p2,l2=np.radians(la_),np.radians(lo_)
      return (np.degrees(np.arctan2(np.sin(l2-l1)*np.cos(p2),np.cos(p1)*np.sin(p2)-np.sin(p1)*np.cos(p2)*np.cos(l2-l1)))+360)%360
  azg,azc=az(la,lo),az(rla,rlo); sec=[]
  for k,nm in enumerate(['N','NE','E','SE','S','SW','W','NW']):
      a0=(k*45-22.5)%360; inr=lambda x: ((x-a0)%360)<45
      g=(tg<20)&inr(azg)&~GM; c=(tc<20)&inr(azc)&~CM; sec.append((nm,int(c.sum()),round(den(c,g),0)))
  out['sectors']=sec
  # kernel minimum
  V=O.xyz(la,lo); Vc=O.xyz(rla,rlo); near=np.flatnonzero(tg<45); nearc=np.flatnonzero(tc<50)
  cand=np.flatnonzero((tg<22)&~GM&(np.isclose((la*2)%1,0.25)|True)); cand=cand[::4]
  mins={}
  for h in (150,200,250):
      best=(1e9,None)
      for i in cand:
          dg=R*np.arccos(np.clip(V[near]@V[i],-1,1)); wg=np.exp(-dg**2/(2*h*h))*A[near]*~GM[near]
          dc=R*np.arccos(np.clip(Vc[nearc]@V[i],-1,1)); wc=np.exp(-dc**2/(2*h*h))*~CM[nearc]
          v=wc.sum()/wg.sum()*1e6
          if wg.sum()>0.15*np.sum(np.exp(-dg**2/(2*h*h))*A[near]) and v<best[0]: best=(v,i)
      i=best[1]; mins[h]=(round(la[i],2),round(lo[i],2),round(float(ang(la[i:i+1],lo[i:i+1],*C0)[0])*math.pi/180*R),round(best[0],0))
  out['minimum']=mins
  res[halo]=out
  print(json.dumps(out,indent=0))
json.dump(res,open('b1_34_result.json','w'),indent=1)
