"""Full Robbins catalogue screening, including unnamed craters.
Archive retrieved through Kaggle mirror after official USGS/PDS download failed.
Uses original CRATER_ID and circular fits, not a relabelled derivative.
Run after analysis.py. The bundle includes all global D=40-120 km records.
"""
import analysis as a
from pathlib import Path
import pandas as pd,numpy as np
P=Path(__file__).parent;D=P/'data';full=D/'robbins/lunar_crater_database_robbins_2018.csv';subset=D/'Robbins_global_40_120km.csv'
if full.exists():
 d=pd.read_csv(full);print('Robbins rows',len(d));d=d[d.DIAM_CIRC_IMG.between(40,120)].copy();d.to_csv(subset,index=False)
else:d=pd.read_csv(subset)
d['distance_SPA']=a.distance(d.LAT_CIRC_IMG,d.LON_CIRC_IMG,a.SPA);d['azimuth_SPA']=a.bearing(d.LAT_CIRC_IMG,d.LON_CIRC_IMG)
q=d[d.distance_SPA.between(12,32)&(d.azimuth_SPA>=270)].copy()
q['distance_central']=a.distance(q.LAT_CIRC_IMG,q.LON_CIRC_IMG,a.CENTRAL)
rows=[]
for _,r in q.iterrows():
 dis=a.distance(a.names.center_lat,a.names.center_lon,(r.LAT_CIRC_IMG,r.LON_CIRC_IMG))*np.pi/180*a.R
 j=np.argmin(dis);n=a.names.iloc[j];km=float(dis.iloc[j]);name=n['name'] if km<.2*r.DIAM_CIRC_IMG and abs(n.diameter/r.DIAM_CIRC_IMG-1)<.4 else 'unmatched'
 vals={}
 for ap,lo,hi in [('inner',0,.5),('exterior',1,1.5),('background',2,3)]:
  th,fe=a.aperture(r.LAT_CIRC_IMG,r.LON_CIRC_IMG,lo*r.DIAM_CIRC_IMG/2,hi*r.DIAM_CIRC_IMG/2);vals.update({f'Th_{ap}_ppm':th,f'FeO_{ap}_wtpct':fe})
 rows.append(dict(id=r.CRATER_ID,name=name,lat=r.LAT_CIRC_IMG,lon=r.LON_CIRC_IMG,diameter_km=r.DIAM_CIRC_IMG,distance_SPA=r.distance_SPA,azimuth_SPA=r.azimuth_SPA,name_match_offset_km=km,**vals))
f=pd.DataFrame(rows).sort_values(['name','id']);f.to_csv(P/'all_crater_apertures.csv',index=False)
print(f.round(2).to_string(index=False));print('N',len(f),'inner>3',sum(f.Th_inner_ppm>3),'exterior>3',sum(f.Th_exterior_ppm>3));dc=a.distance(d.LAT_CIRC_IMG,d.LON_CIRC_IMG,a.CENTRAL);bc=a.bearing(d.LAT_CIRC_IMG,d.LON_CIRC_IMG,a.CENTRAL);print('N alternative center',sum((dc>=12)&(dc<=32)&(bc>=270)))
