"""Reproduce SPA geometry, cryptomare intersections, DHC counts and LP aperture summaries.
Python 3; numpy pandas matplotlib scipy pyshp shapely pyproj.
Inputs and provenance: README and sources.json. All longitudes east-positive.
GRS values are blurred map-aperture summaries, NOT independent floor/ejecta assays.
"""
from pathlib import Path
import json, numpy as np, pandas as pd, shapefile
from scipy.spatial import cKDTree
from shapely.geometry import shape, Polygon
from shapely.ops import transform, unary_union
from pyproj import CRS,Transformer
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as PlotPolygon
P=Path(__file__).resolve().parent; D=P/'data'; R=1737.4
SPA=(-53.,191.); CENTRAL=(-51.4,196.8)
def distance(lat,lon,center):
 a,b=np.radians(lat),np.radians(center[0]);dl=np.radians(np.asarray(lon)-center[1])
 return np.degrees(np.arccos(np.clip(np.sin(a)*np.sin(b)+np.cos(a)*np.cos(b)*np.cos(dl),-1,1)))
def bearing(lat,lon,center=SPA):
 a,b=np.radians(lat),np.radians(center[0]);dl=np.radians(np.asarray(lon)-center[1])
 return np.degrees(np.arctan2(np.sin(dl)*np.cos(a),np.cos(b)*np.sin(a)-np.sin(b)*np.cos(a)*np.cos(dl)))%360
geo=CRS.from_proj4('+proj=longlat +R=1737400');laea=CRS.from_proj4('+proj=laea +lat_0=-53 +lon_0=191 +R=1737400 +units=m')
project=Transformer.from_crs(geo,laea,always_xy=True)
def dest(center,az,dist):
 a,b,c=np.radians(center[0]),np.radians(az),np.radians(dist)
 lat=np.arcsin(np.sin(a)*np.cos(c)+np.cos(a)*np.sin(c)*np.cos(b))
 lon=np.radians(center[1])+np.arctan2(np.sin(b)*np.sin(c)*np.cos(a),np.cos(c)-np.sin(a)*np.sin(lat))
 return np.degrees(lat),np.degrees(lon)%360
def circle(center,r,n=3601):
 lat,lon=dest(center,np.linspace(0,360,n),r);return Polygon(np.c_[*project.transform(lon,lat)])
# Read and union the actual archived Wang polygons; source CRS comes from .prj.
polys={};cover=[];cap=circle(CENTRAL,15)
for label,prefix in [('minimum','Min'),('maximum','Max')]:
 f=D/'cryptomare'/f'{prefix}Ext_SPACC.shp';src=CRS.from_wkt(f.with_suffix('.prj').read_text());tr=Transformer.from_crs(src,laea,always_xy=True)
 g=unary_union([transform(tr.transform,shape(s.__geo_interface__)) for s in shapefile.Reader(str(f)).shapes()]);polys[label]=g
 cover.append(dict(extent=label,total_km2=g.area/1e6,inside_central15_km2=g.intersection(cap).area/1e6,central15_percent=100*g.intersection(cap).area/cap.area))
pd.DataFrame(cover).to_csv(P/'cryptomare_overlap.csv',index=False)
# Preserve archive exactly; its 300 rows do not reproduce the article's 258 count.
dhc=pd.read_csv(D/'DHC_Mapped.csv');dhc['Longitude']=dhc.Longitude%360
rings=[]
for label,c in [('SPA',SPA),('central',CENTRAL)]:
 dhc['distance_'+label]=distance(dhc.Latitude,dhc.Longitude,c)
 for lo,hi in [(0,15),(15,25),(25,39.57)]:
  m=(dhc['distance_'+label]>=lo)&(dhc['distance_'+label]<hi);area=2*np.pi*R**2*(np.cos(np.radians(lo))-np.cos(np.radians(hi)));n=int((m&(dhc.Diameter>=1)).sum())
  rings.append(dict(center=label,ring=f'{lo}-{hi}',area_km2=area,N_archive_all=int(m.sum()),N_D_ge1=n,N_per_million_km2=n/area*1e6))
pd.DataFrame(rings).to_csv(P/'DHC_rings.csv',index=False)
dhc.to_csv(P/'DHC_archive_with_distances.csv',index=False)
# Nomenclature is a named-feature census, not a complete crater catalogue.
names=pd.DataFrame([q.as_dict() for q in shapefile.Reader(str(D/'names/MOON_nomenclature_center_pts.shp')).records()]);names=names[names.type.isin(['Crater, craters','Satellite Feature'])].copy()
names['distance_SPA']=distance(names.center_lat,names.center_lon,SPA);names['distance_central']=distance(names.center_lat,names.center_lon,CENTRAL);names['azimuth_SPA']=bearing(names.center_lat,names.center_lon)
sel=names[(names.diameter>=40)&(names.diameter<=120)&names.distance_SPA.between(12,32)&(names.azimuth_SPA>=270)].copy().sort_values('name')
# Direct LP low-altitude special products. ASCII Th retains full precision.
th=np.loadtxt(D/'thoriumhd.txt',delimiter=',',comments='#')[:,4].reshape(360,720)
fe=np.fromfile(D/'ironhd.dat',dtype='>i2').reshape(360,720)/10.
# Mean of piecewise-constant native map in equal-area subpixels, 8x8/native cell.
# This refines mask edges only; it does not increase the instrument resolution.
latgrid=np.arange(-89.75,90,.5);longrid=np.arange(-179.75,180,.5)
def aperture(lat,lon,rlo,rhi,nsub=8):
 row=np.where(abs(latgrid-lat)<rhi/R*180/np.pi+1)[0]
 cols=np.where(abs((longrid-lon+180)%360-180)<(rhi/R*180/np.pi+1)/max(.1,np.cos(np.radians(lat))))[0]
 iy,ix=np.meshgrid(row,cols,indexing='ij');iy=iy.ravel();ix=ix.ravel();weights=np.zeros(len(iy));sub=(np.arange(nsub)+.5)/nsub
 sinlo=np.sin(np.radians(latgrid[iy]-.25));sinhi=np.sin(np.radians(latgrid[iy]+.25))
 for u in sub:
  la=np.degrees(np.arcsin(sinlo+u*(sinhi-sinlo)))
  for v in sub:
   lo=longrid[ix]-.25+v*.5;dr=distance(la,lo,(lat,lon))*np.pi/180*R
   weights+=((dr>=rlo)&(dr<rhi))
 weights*=sinhi-sinlo
 return [float(np.sum(arr[iy,ix]*weights)/weights.sum()) for arr in [th,fe]]
rows=[]
for _,q in sel.iterrows():
 cr=q.diameter/2;vals={}
 for ap,lo,hi in [('inner',0,.5),('exterior',1,1.5),('background',2,3)]:
  tv,fv=aperture(q.center_lat,q.center_lon,lo*cr,hi*cr);vals.update({f'Th_{ap}_ppm':tv,f'FeO_{ap}_wtpct':fv})
 rows.append(dict(name=q['name'],lat=q.center_lat,lon=q.center_lon,diameter_km=q.diameter,distance_SPA=q.distance_SPA,azimuth_SPA=q.azimuth_SPA,**vals))
craters=pd.DataFrame(rows);craters.to_csv(P/'named_crater_apertures.csv',index=False)
names[names.name.isin(['Birkeland','Oresme V','Dewar'])][['name','center_lat','center_lon','diameter','distance_SPA','distance_central','azimuth_SPA','link']].to_csv(P/'verified_coordinates.csv',index=False)
# Published fitted retention fractions: Zhu et al. 2019, Extended Data Table 1.
ret=[]
for v,theta,a,b in [(15,20,.234,20.120),(15,45,.671,7.049),(15,80,.833,.254),(20,20,.216,21.880),(20,45,.678,7.822),(20,80,.883,.397)]:
 ret.append(dict(speed_kms=v,angle_deg=theta,projectile_D_km=10,retained_fraction=a*np.exp(-b*10/(2*R))))
pd.DataFrame(ret).to_csv(P/'retention_Zhu2019.csv',index=False)
# One geographic figure in lunar Lambert azimuthal equal area. Th is measured map.
fig,ax=plt.subplots(figsize=(11,10));lng,ltg=np.meshgrid(np.arange(-180,180.001,.5),np.arange(-90,90.001,.5));x,y=project.transform(lng,ltg)
# Limit rendering to region near SPA to avoid antipodal projection artefacts.
lats,lons=np.meshgrid(latgrid,longrid,indexing='ij');mask=distance(lats,lons,SPA)>61
x=np.nan_to_num(x,nan=0,posinf=0,neginf=0);y=np.nan_to_num(y,nan=0,posinf=0,neginf=0)
im=ax.pcolormesh(x/1000,y/1000,np.ma.array(th,mask=mask),cmap='magma',vmin=0,vmax=6,rasterized=True,shading='flat')
for label,g in polys.items():
 for poly in (g.geoms if g.geom_type=='MultiPolygon' else [g]):
  ar=np.array(poly.exterior.coords)/1000;ax.add_patch(PlotPolygon(ar,facecolor='#46efdb' if label=='minimum' else 'none',edgecolor='#46efdb',lw=.9,alpha=.8,label='Wang minimum / maximum' if label=='minimum' else None))
for cent,r,color,ls,lbl in [(SPA,39.57,'white','-','SPA rim: 39.57°'),(CENTRAL,15,'#51df55','-','Proposed central region: 15°')]:
 ar=np.array(circle(cent,r).exterior.coords)/1000;ax.plot(ar[:,0],ar[:,1],color=color,ls=ls,lw=1.8,label=lbl)
lat1,lon1=dest(SPA,np.linspace(270,360,301),12);lat2,lon2=dest(SPA,np.linspace(360,270,301),32);xx,yy=project.transform(np.r_[lon1,lon2],np.r_[lat1,lat2]);ax.fill(xx/1000,yy/1000,facecolor='none',edgecolor='#82cfff',hatch='///',lw=1.4,label='Test crescent: 12–32°, NW azimuth')
for la in [-70,-50,-30,-10]:
 xx,yy=project.transform(np.linspace(120,260,400),np.full(400,la));ax.plot(xx/1000,yy/1000,color='white',alpha=.15,lw=.6)
for lo in [140,160,180,200,220,240]:
 xx,yy=project.transform(np.full(400,lo),np.linspace(-88,0,400));ax.plot(xx/1000,yy/1000,color='white',alpha=.15,lw=.6)
q=dhc[dhc.distance_SPA<60];xx,yy=project.transform(q.Longitude,q.Latitude);ax.scatter(xx/1000,yy/1000,s=55,facecolor='none',edgecolor='#00ffff',marker='s',lw=1.5,label='Archived dark-halo crater')
mapcat=sel.copy()
if (D/'Robbins_global_40_120km.csv').exists():
 rc=pd.read_csv(D/'Robbins_global_40_120km.csv');rr=distance(rc.LAT_CIRC_IMG,rc.LON_CIRC_IMG,SPA);bb=bearing(rc.LAT_CIRC_IMG,rc.LON_CIRC_IMG);rc=rc[(rr>=12)&(rr<=32)&(bb>=270)];mlat,mlon=rc.LAT_CIRC_IMG,rc.LON_CIRC_IMG
else: mlat,mlon=sel.center_lat,sel.center_lon
xx,yy=project.transform(mlon,mlat);ax.scatter(xx/1000,yy/1000,s=15,facecolor='none',edgecolor='white',label='Catalogue 40–120 km crater')
for name,offset in [('Birkeland',(18,12)),('Oresme V',(-75,-18)),('Dewar',(10,12)),('Apollo',(10,12))]:
 q=names[names.name==name].iloc[0];xx,yy=project.transform(q.center_lon,q.center_lat);ax.scatter(xx/1000,yy/1000,c='white',s=25);ax.annotate(name,(xx/1000,yy/1000),xytext=offset,textcoords='offset points',color='white',fontsize=10,arrowprops=dict(arrowstyle='-',color='white',lw=.6))
for c,lbl in [(SPA,'SPA centre'),(CENTRAL,'Central-region centre')]:
 xx,yy=project.transform(c[1],c[0]);ax.scatter(xx/1000,yy/1000,marker='+',s=80,c='white');ax.annotate(lbl,(xx/1000,yy/1000),xytext=(15,-20 if c==SPA else 12),textcoords='offset points',color='white',fontsize=8)
ax.set(xlim=(-1450,1350),ylim=(-1300,1750),aspect='equal',xlabel='Projected east (km)',ylabel='Projected north (km)',title='SPA: measured thorium, mapped cryptomaria and test geometry');ax.set_facecolor('#181523')
handles,labels=ax.get_legend_handles_labels();unique=dict(zip(labels,handles));ax.legend(unique.values(),unique.keys(),loc='lower left',fontsize=8,facecolor='white',framealpha=.95)
fig.colorbar(im,ax=ax,shrink=.65,pad=.02,label='LP special-product Th (ppm); effective FWHM ~62 km')
fig.text(.1,.025,'Cyan fill / outlines: published minimum / maximum cryptomare extents, not a new interpretation.\nDHC squares show catalogue detections; an unmarked location is not proof of absence.',fontsize=9)
fig.subplots_adjust(bottom=.1);fig.savefig(P/'SPA_cryptomare_Th_map.png',dpi=210);plt.close(fig)
print(pd.DataFrame(cover).to_string(index=False));print(pd.DataFrame(rings).to_string(index=False));print(craters.round(2).to_string(index=False));print(pd.DataFrame(ret).to_string(index=False))
