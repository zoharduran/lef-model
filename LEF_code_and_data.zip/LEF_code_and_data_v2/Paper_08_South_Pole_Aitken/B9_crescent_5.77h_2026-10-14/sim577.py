# Crescent simulation rerun (14.10.2026) for the adopted release state: Earth day 5.77 h, Moon centre at 16,400 km.
import numpy as np, sys
src=open('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/B9_crescent_rotation_2026-10-04/sim2.py').read()
def stats(P,v,D):
    g={}; exec(src.replace('D=20.6e6','D=%g'%D),g)
    az,ang,bear,tl=g['run'](P,v*1e3)
    ok=~np.isnan(tl)
    if ok.sum()==0: return 0,np.nan,np.nan,np.nan,np.nan
    b=np.radians(bear[ok]); Rr=np.hypot(np.cos(b).mean(),np.sin(b).mean())
    west=((bear[ok]>180)&(bear[ok]<360)).mean()
    return ok.sum(),np.nanmedian(ang[ok]),Rr,west,np.nanmedian(tl[ok])/60
print('P v landed dist R westshare flight_min  (D=16,400 km)')
for P in [5.5,5.77,6.0,6.2,6.4,6.6,7.0,8.0]:
    for v in [0.6,0.7,0.8,0.9]:
        n,d,R,w,f=stats(P,v,16.4e6)
        print(P,v,n,round(d,1),round(R,2),round(w,2),round(f,0))
print('check old state D=20.6e6 P=6.6 v=0.7:',[round(x,2) for x in stats(6.6,0.7,20.6e6)])
