exec(open('sim577.py').read().split("print('P v")[0])
print('P v landed dist R westshare flight (D=16,400 km)')
for P in [5.6,5.77,5.9]:
    for v in [0.85,0.9,0.95,1.0,1.05,1.1]:
        n,d,R,w,f=stats(P,v,16.4e6); print(P,v,n,round(d,1),round(R,2),round(w,2),round(f,0))
