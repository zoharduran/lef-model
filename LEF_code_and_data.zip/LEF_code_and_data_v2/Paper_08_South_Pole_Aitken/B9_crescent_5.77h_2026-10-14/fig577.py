import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
rows=[l.split() for l in open('grid577.txt').read().splitlines()[1:] if l[:1].isdigit()]+[l.split() for l in open('grid577b.txt').read().splitlines()[1:] if l[:1].isdigit()]
d={}
for P,v,n,dist,R,w,f in rows: d[(float(P),float(v))]=(float(R),float(w),float(dist))
fig,ax=plt.subplots(1,2,figsize=(10,4))
for P,c in [(5.5,'#9e2c20'),(5.6,'#c46a2e'),(5.77,'#2a3e5c'),(5.9,'#6c8db5'),(6.0,'#9a9a9a')]:
    vs=sorted(v for (p,v) in d if p==P); 
    ax[0].plot(vs,[d[(P,v)][0] for v in vs],'o-',color=c,label=f'{P} h',lw=2.2 if P==5.77 else 1.2)
    ax[1].plot(vs,[d[(P,v)][2] for v in vs],'o-',color=c,lw=2.2 if P==5.77 else 1.2)
ax[0].set_xlabel('ejection speed (km/s), 45°'); ax[0].set_ylabel('one-sidedness of landing (0 ring, 1 one side)'); ax[0].legend(title="Earth's day",fontsize=8)
ax[1].axhspan(12,32,color='#f0d9a8',alpha=.6,label='observed crescent, 12–32°'); ax[1].set_xlabel('ejection speed (km/s)'); ax[1].set_ylabel('median landing distance from the mare (°)'); ax[1].legend(fontsize=8)
fig.suptitle('Ejecta from the far end of the attached Moon, centre at 16,400 km',fontsize=11); fig.tight_layout()
fig.savefig('/home/claude/LEF_המוח/מאמר_09_SPA/א_מאמר/fig/SPA_B9_4_577.png',dpi=150)
