"""Reproducible SPA analysis: archived mantle grid + independent Bouguer synthesis.
Run in this folder after fetch.py. Python numpy scipy matplotlib pyshtools pyproj.
All harmonic fields are PA; the sub-km ME/PA offset is not resolved here.
"""
from pathlib import Path
import json, numpy as np, pyshtools as sh
from scipy.io import netcdf_file
from scipy.interpolate import RegularGridInterpolator, RectBivariateSpline
from scipy.optimize import minimize
from scipy.ndimage import label
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pyproj import Proj
P=Path(__file__).resolve().parent
R=1737.4 # km for angular distances and map
G=6.67430e-11
r0=1738e3; obs=1748e3; gm=4902.8001224453e9
points={'SPA':(-53,191),'Dome':(-51.4,196.8),'Thin crust':(-56,190),'Crater minimum':(-47.5,193.5),"Chang\u2019e-6":(-41.6385,206.0148)}
def separation(a,b):
 p1,l1=np.radians(a);p2,l2=np.radians(b);dl=l2-l1
 d=np.arccos(np.clip(np.sin(p1)*np.sin(p2)+np.cos(p1)*np.cos(p2)*np.cos(dl),-1,1))
 az=np.arctan2(np.sin(dl)*np.cos(p2),np.cos(p1)*np.sin(p2)-np.sin(p1)*np.cos(p2)*np.cos(dl))
 return np.degrees(d),d*R,np.degrees(az)%360

def angular(lat,lon,clat=-53,clon=191):
 la,lo,ca,co=np.radians([lat,lon,clat,clon]) if np.ndim(lat)==0 else (np.radians(lat),np.radians(lon),np.radians(clat),np.radians(clon))
 return np.degrees(np.arccos(np.clip(np.sin(la)*np.sin(ca)+np.cos(la)*np.cos(ca)*np.cos(lo-co),-1,1)))
def coeff(file,L,header):
 a=np.zeros((2,L+1,L+1))
 for line in (P/file).read_text().splitlines()[header:]:
  v=line.replace(',',' ').split();l,m=map(int,v[:2])
  if l>L:continue
  a[:,l,m]=list(map(float,v[2:4]))
 return a
f=next(P.glob('*MantleMass*.grd'))
with netcdf_file(f,'r',mmap=False) as nc:
 ml=nc.variables['y'].data.copy();mo=nc.variables['x'].data.copy();mv=nc.variables['z'].data.copy()
ll,pp=np.meshgrid(mo,ml);mask=angular(pp,ll)<39.57
idx=np.unravel_index(np.argmax(np.where(mask,mv,-np.inf)),mv.shape)
ms=RectBivariateSpline(ml,mo,mv)
opt=minimize(lambda v:-ms.ev(*v)/1e6,[ml[idx[0]],mo[idx[1]]],bounds=[(-85,-25),(145,240)],method='Nelder-Mead')
peak=opt.x;peakval=float(ms.ev(*peak))
# Exact radial spherical Bouguer correction through ninth order, shape bandlimited at 80.
h=coeff('shape.tab',80,0)*1000;h[0,0,0]+=1738e3
hgrid=sh.expand.MakeGridDH(h,lmax=720,lmax_calc=80,sampling=2)
bc,d=sh.gravmag.CilmPlusDH(hgrid,9,gm/G,2500,lmax=40)
for l in range(41):bc[:,l,:]*=(d/r0)**l
c=coeff('gravity.tab',40,1);pub=coeff('bouguer.tab',40,1)
res=c-bc
np.savez_compressed(P/'harmonics.npz',gravity=c,topography=h,bouguer_independent=res,bouguer_pds=pub)
# Synthesize the inward radial gravity disturbance (l+1), not classical anomaly (l-1).
def synthesis(c,lmin,lmax):
 a=c.copy();a[:,:lmin,:]=0;a[:,lmax+1:,:]=0
 for l in range(a.shape[1]):a[:,l,:]*=gm/obs**2*(l+1)*(r0/obs)**l*1e5
 grid=sh.SHCoeffs.from_array(a,normalization='4pi',csphase=1).expand(grid='DH2',lmax=359,extend=True)
 return grid.lats()[::-1],grid.lons(),grid.data[::-1]
results={'archive_native_peak':{'lat':float(ml[idx[0]]),'lon':float(mo[idx[1]]),'kg_m2':float(mv[idx])},'archive_interpolated_peak':{'lat':float(peak[0]),'lon':float(peak[1]),'kg_m2':peakval},'distance_to_published':separation((-62,200),peak),'bands':[]}
for low,high in [(2,15),(2,20),(2,30),(3,30),(2,40)]:
 lat,lon,z=synthesis(res,low,high);ll,pp=np.meshgrid(lon,lat);m=angular(pp,ll)<39.57
 i=np.unravel_index(np.argmax(np.where(m,z,-np.inf)),z.shape)
 results['bands'].append({'lmin':low,'lmax':high,'lat':float(lat[i[0]]),'lon':float(lon[i[1]]),'mGal':float(z[i]),'distance_to_published_km':separation((-62,200),(lat[i[0]],lon[i[1]]))[1]})
 if (low,high)==(2,30):base=(lat,lon,z);bi=i
lat,lon,z=base
_,_,pz=synthesis(pub,2,30)
ll,pp=np.meshgrid(lon,lat);spa=angular(pp,ll)<39.57
results['finite_amplitude_check']={'SPA_rms_difference_mGal':float(np.sqrt(np.mean((z[spa]-pz[spa])**2))),'SPA_max_abs_difference_mGal':float(np.max(abs(z[spa]-pz[spa])))}
# Map in equal-area coordinates; connected half-max contour, zero datum defined explicitly.
proj=Proj(proj='laea',lat_0=-53,lon_0=191,R=R)
coords=np.linspace(-1450,1450,1161);xx,yy=np.meshgrid(coords,coords);qlon,qlat=proj(xx,yy,inverse=True);qlon%=360
q=np.column_stack([qlat.ravel(),qlon.ravel()])
zmap=RegularGridInterpolator((lat,lon),z,bounds_error=False)(q).reshape(xx.shape)
mmap=ms.ev(qlat,qlon)
def boundary(field,level,location,name):
 labs,n=label(field>=level);px,py=proj(location[1],location[0]);ij=(np.argmin(abs(coords-py)),np.argmin(abs(coords-px)));reg=labs==labs[ij]
 cs=plt.contour(xx,yy,np.where(reg,1.,0.),levels=[.5]);paths=cs.allsegs[0];plt.close()
 area=reg.sum()*(coords[1]-coords[0])**2
 x,y=np.concatenate(paths).T;lo,la=proj(x,y,inverse=True);lo%=360
 np.savetxt(P/(name+'_contour.csv'),np.column_stack([la,lo,x,y]),delimiter=',',header='latitude,longitude_E,x_LAEA_km,y_LAEA_km',comments='')
 rad=np.degrees(np.arccos(1-area/(2*np.pi*R*R)))
 return paths,{'level':float(level),'area_km2':float(area),'equivalent_angular_radius_deg':float(rad),'equivalent_surface_radius_km':float(np.radians(rad)*R),'lat_range':[float(la.min()),float(la.max())],'lon_range':[float(lo.min()),float(lo.max())],'touches_map_edge':bool(np.any(reg[0]) or np.any(reg[-1]) or np.any(reg[:,0]) or np.any(reg[:,-1]))}
mpaths,results['mantle_half_max']=boundary(mmap,peakval/2,peak,'mantle_half_max')
bpeak=(lat[bi[0]],lon[bi[1]])
bpaths,results['bouguer_half_max']=boundary(zmap,float(z[bi])/2,bpeak,'bouguer_half_max')
results['distances']={k:{'coordinates':v,'published':separation(v,(-62,200)),'grid_peak':separation(v,peak)} for k,v in points.items()}
results['archive_grid_units_note']='kg/m2 inferred from publication and numerical range; netCDF has no unit attribute.'
(P/'results.json').write_text(json.dumps(results,indent=2))
np.savez_compressed(P/'map_grids.npz',x=coords,y=coords,bouguer_mGal=zmap,mantle_kg_m2=mmap)
print(json.dumps(results,indent=2))
# Area- and anomaly-weighted spherical centroid of the half-maximum component.
labs,n=label(mmap>=peakval/2);px,py=proj(peak[1],peak[0]);i,j=np.argmin(abs(coords-py)),np.argmin(abs(coords-px));reg=labs==labs[i,j]
la,lo=np.radians(qlat),np.radians(qlon);w=mmap*reg
vec=np.array([(w*np.cos(la)*np.cos(lo)).sum(),(w*np.cos(la)*np.sin(lo)).sum(),(w*np.sin(la)).sum()]);vec/=np.linalg.norm(vec)
results['halfmax_mass_centroid']={'lat':float(np.degrees(np.arcsin(vec[2]))),'lon_E':float(np.degrees(np.arctan2(vec[1],vec[0]))%360),'mass_kg':float(w.sum()*(coords[1]-coords[0])**2*1e6)}
rt=R-30;rb=R-800
results['illustrative_depth_centroid_km']=R-.75*(rt**4-rb**4)/(rt**3-rb**3)
(P/'results.json').write_text(json.dumps(results,indent=2))
