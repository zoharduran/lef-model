"""Archived mapped-feature counts, lengths and orientations, not causal dates.
Inputs: Thompson/LROC ridges, LROC lobate scarps, Lu 2021 graben, LROC mare.
Requires numpy pandas scipy matplotlib pyshp shapely. Spherical R=1737.4 km.
"""
from pathlib import Path
import json,csv,warnings
import numpy as np,pandas as pd,shapefile
from shapely.geometry import shape
from shapely.ops import unary_union
from shapely import contains_xy,make_valid
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection,PolyCollection
P=Path(__file__).resolve().parent;D=P/'data';R=1737.4
def vec(lon,lat):
 lo,la=np.deg2rad(lon),np.deg2rad(lat);return np.stack([np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)],axis=-1)
def ll(v):
 v=v/np.linalg.norm(v,axis=-1,keepdims=True);return np.rad2deg(np.arctan2(v[...,1],v[...,0])),np.rad2deg(np.arcsin(np.clip(v[...,2],-1,1)))
def basis(lon,lat):
 lo,la=np.deg2rad([lon,lat]);return np.array([-np.sin(lo),np.cos(lo),0]),np.array([-np.sin(la)*np.cos(lo),-np.sin(la)*np.sin(lo),np.cos(la)])
def geog(lon,lat,centre):
 v=vec(lon,lat);c=vec(*centre);e,n=basis(*centre);co=np.clip(v@c,-1,1);ang=np.arccos(co);bear=np.arctan2(v@e,v@n);return np.rad2deg(ang),np.rad2deg(bear)%360
def laea(lon,lat,centre):
 v=vec(lon,lat);c=vec(*centre);e,n=basis(*centre);k=np.sqrt(2/np.maximum(1+v@c,1e-12));return np.stack([R*k*(v@e),R*k*(v@n)],axis=-1)
def circle(centre,rad):
 c=vec(*centre);e,n=basis(*centre);a=np.linspace(0,2*np.pi,361);v=np.cos(np.deg2rad(rad))*c+np.sin(np.deg2rad(rad))*(np.cos(a[:,None])*n+np.sin(a[:,None])*e);return ll(v)
def getshp(folder):return next(f for f in (D/folder).rglob('*') if f.suffix.lower()=='.shp')
mareR=shapefile.Reader(str(getshp('mare')));polys=[]
for sh in mareR.shapes():
 try:g=make_valid(shape(sh.__geo_interface__));polys.append(g)
 except Exception:pass
mare=unary_union(polys)
# Explicit geometry masks; not asserted to equal true basin ejecta/tectonic bounds.
basins=[('Imbrium',345.09,34.72,21),('Serenitatis',18.36,27.29,12),('Humorum',321.4,-24.4,9),('Nectaris',35.5,-15.2,11),('Crisium',59.1,17,10),('Orientale',265,-19.4,16),('Apollo',208.3,-36.1,9)]
def basinmask(lon,lat):
 m=np.zeros(np.shape(lon),bool)
 for name,lo,la,rad in basins:m|=geog(lon,lat,(lo,la))[0]<rad
 return m
features=[];segments=[];trace={}
for typ,folder in [('Graben','graben'),('Wrinkle ridge','ridges'),('Lobate scarp','scarps')]:
 reader=shapefile.Reader(str(getshp(folder)))
 for idx,sr in enumerate(reader.iterShapeRecords()):
  sh=sr.shape;xy=np.array(sh.points);parts=list(sh.parts)+[len(xy)];pieces=[];total=0;vc=np.zeros(3);sid=[]
  for start,end in zip(parts[:-1],parts[1:]):
   pts=xy[start:end];pieces.append(pts)
   for p0,p1 in zip(pts[:-1],pts[1:]):
    v0,v1=vec(*p0),vec(*p1);ang=np.arccos(np.clip(v0@v1,-1,1));length=R*ang
    if length<=1e-7:continue
    # Densify to <= 2 km for spherical boundary/sector clipping accuracy.
    num=max(1,int(np.ceil(length/2)));q=(np.arange(num)+.5)/num
    vs=np.sin((1-q)*ang)[:,None]/np.sin(ang)*v0+np.sin(q*ang)[:,None]/np.sin(ang)*v1
    los,las=ll(vs);dper=length/num
    for lo,la in zip(los,las):
     _,az=geog(p1[0],p1[1],(lo,la));sid.append(len(segments));segments.append([typ,idx,lo,la,dper,float(az)])
    vc+=length*(v0+v1)/np.linalg.norm(v0+v1);total+=length
  if total==0:continue
  lon,lat=ll(vc);fields=sr.record.as_dict();era=fields.get('Era','not supplied')
  features.append([typ,idx,lon,lat,total,era]);trace[(typ,idx)]=pieces
f=pd.DataFrame(features,columns=['type','id','lon','lat','full_length_km','mapped_era']);s=pd.DataFrame(segments,columns=['type','id','lon','lat','length_km','azimuth'])
for df in [f,s]:
 df['mare']=contains_xy(mare,((df.lon.to_numpy()+180)%360)-180,df.lat.to_numpy());df['basin_cap']=basinmask(df.lon.to_numpy(),df.lat.to_numpy())
# Area-weighted mare centroid from spherical quadrature; near hemisphere |lon|<90.
step=.2;lons=np.arange(-179.9,180,step);lats=np.arange(-89.9,90,step);lo,la=np.meshgrid(lons,lats);lo=lo.ravel();la=la.ravel();area=R**2*np.deg2rad(step)*(np.sin(np.deg2rad(la+step/2))-np.sin(np.deg2rad(la-step/2)))
ismare=contains_xy(mare,lo,la);near=np.cos(np.deg2rad(lo))>0;vv=vec(lo,la);cent=np.sum(vv[ismare&near]*area[ismare&near,None],axis=0);clon,clat=ll(cent)
metadata={'near_mare_centroid_lat':float(clat),'near_mare_centroid_lonE':float(clon%360),'near_mare_antipode_lat':float(-clat),'near_mare_antipode_lonE':float((clon+180)%360),'near_mare_area_km2':float(area[ismare&near].sum()),'area_grid_deg':step,'catalogue_counts':f.groupby('type').size().to_dict(),'basin_caps':basins,'warning':'Present-day mare outlines. Geometric basin caps label proximity, not genetic origin/age. Scarps lack full polar coverage. Counts are catalogue objects, not independent geological events.'}
out=[];centres=[('Attachment',(320,23)),('SPA',(191,-53))]
for cname,centre in centres:
 fd,fb=geog(f.lon.to_numpy(),f.lat.to_numpy(),centre);sd,sb=geog(s.lon.to_numpy(),s.lat.to_numpy(),centre);gd,gb=geog(lo,la,centre)
 # Orientation of segment axis relative to geodesic from local point to reference.
 vcent=vec(*centre);vpoint=vec(s.lon.to_numpy(),s.lat.to_numpy());localE=np.column_stack([-np.sin(np.deg2rad(s.lon)),np.cos(np.deg2rad(s.lon)),np.zeros(len(s))]);localN=np.cross(vpoint,localE)
 rb=np.rad2deg(np.arctan2(localE@vcent,localN@vcent));delta=np.abs((s.azimuth.to_numpy()-rb+90)%180-90)
 for cap in ([15,30,39.57,45] if cname=='SPA' else [15,30,45]):
  for region in ['all','mare','outside_basin_caps','common_latitude_55']:
   fm=np.ones(len(f),bool);sm=np.ones(len(s),bool);gm=np.ones(len(lo),bool)
   if region=='mare':fm=f.mare.to_numpy();sm=s.mare.to_numpy();gm=ismare
   if region=='outside_basin_caps':fm=~f.basin_cap.to_numpy();sm=~s.basin_cap.to_numpy();gm=~basinmask(lo,la)
   if region=='common_latitude_55':fm=abs(f.lat.to_numpy())<55;sm=abs(s.lat.to_numpy())<55;gm=abs(la)<55
   for side in ['West','East']:
    fs=(np.sin(np.deg2rad(fb))<0) if side=='West' else (np.sin(np.deg2rad(fb))>=0)
    ss=(np.sin(np.deg2rad(sb))<0) if side=='West' else (np.sin(np.deg2rad(sb))>=0)
    gs=(np.sin(np.deg2rad(gb))<0) if side=='West' else (np.sin(np.deg2rad(gb))>=0)
    ar=area[(gd<cap)&gs&gm].sum()
    for typ in ['Graben','Wrinkle ridge','Lobate scarp']:
     fc=(f.type==typ).to_numpy()&(fd<cap)&fs&fm;sc=(s.type==typ).to_numpy()&(sd<cap)&ss&sm
     length=s.length_km.to_numpy()[sc].sum();radial=s.length_km.to_numpy()[sc&(delta<30)].sum();concen=s.length_km.to_numpy()[sc&(delta>60)].sum()
     out.append([cname,cap,region,side,typ,int(fc.sum()),float(length),ar,int(fc.sum())/ar*1e6,length/ar*1e6,radial/length if length else np.nan,concen/length if length else np.nan])
stats=pd.DataFrame(out,columns=['centre','cap_deg','selection','side','type','centroid_count','clipped_length_km','area_km2','count_per_million_km2','length_km_per_million_km2','length_fraction_radial_within30deg','length_fraction_concentric_within30deg'])
stats.to_csv(P/'tectonic_sectors.csv',index=False);f.to_csv(P/'mapped_features.csv',index=False);metadata['graben_era_counts']=f[f.type=='Graben'].mapped_era.value_counts().to_dict();(P/'tectonic_metadata.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False))
colors={'Graben':'#247ac5','Wrinkle ridge':'#cc5a30','Lobate scarp':'#704796'}
fig,axs=plt.subplots(1,2,figsize=(13,6))
for ax,(cname,centre) in zip(axs,centres):
 for sh in mareR.shapes():
  pts=np.array(sh.points);parts=list(sh.parts)+[len(pts)]
  for a,b in zip(parts[:-1],parts[1:]):
   piece=pts[a:b]
   if np.any(geog(piece[:,0],piece[:,1],centre)[0]<50):
    xy=laea(piece[:,0],piece[:,1],centre);ax.fill(xy[:,0],xy[:,1],color='#e0e3e5',zorder=0)
 for typ in colors:
  lines=[]
  for (ty,idx),pieces in trace.items():
   if ty!=typ:continue
   for piece in pieces:
    if np.any(geog(piece[:,0],piece[:,1],centre)[0]<48):lines.append(laea(piece[:,0],piece[:,1],centre))
  ax.add_collection(LineCollection(lines,colors=colors[typ],linewidths=.65,label=typ))
 for rad in [15,30,45]:
  xx,yy=circle(centre,rad);xy=laea(xx,yy,centre);ax.plot(*xy.T,'k:',lw=.8);ax.text(0,R*2*np.sin(np.deg2rad(rad)/2),f'{rad}°',fontsize=8)
 for name,blo,bla,rad in basins:
  if geog(blo,bla,centre)[0]<50:
   xx,yy=circle((blo,bla),rad);xy=laea(xx,yy,centre);ax.plot(*xy.T,color='#888888',ls='--',lw=.7);x,y=laea(blo,bla,centre);ax.text(x,y,name,fontsize=7,color='#555555')
 ax.axvline(0,c='k',lw=.5);ax.plot(0,0,'k+',ms=10);ax.set(xlim=(-1400,1400),ylim=(-1400,1400),xlabel='Local east (km)',ylabel='Local north (km)',title=cname+' • Lambert equal-area');ax.set_aspect('equal')
 ax.text(-1250,-1330,'West',fontsize=9);ax.text(1100,-1330,'East',fontsize=9)
axs[0].legend(fontsize=8,loc='upper left');fig.suptitle('Published surface tectonic traces; dashed basin caps are geometric labels\nSubsurface Procellarum GRAIL border dikes are a different observable, not counted as graben',fontsize=11);fig.tight_layout(rect=[0,0,1,.93]);fig.savefig(P/'tectonic_maps.png',dpi=200);plt.close(fig)
fig,axs=plt.subplots(2,3,figsize=(12,7))
for i,(cname,_) in enumerate(centres):
 for j,typ in enumerate(colors):
  ax=axs[i,j]
  for k,side in enumerate(['West','East']):
   a=stats[(stats.centre==cname)&(stats.type==typ)&(stats.selection=='all')&(stats.side==side)&stats.cap_deg.isin([15,30,45])]
   ax.bar(np.arange(3)+(k-.5)*.32,a.length_km_per_million_km2,width=.32,label=side)
  ax.set(xticks=np.arange(3),xticklabels=['15°','30°','45°'],title=cname+': '+typ,ylabel='Mapped km / million km²');ax.legend(fontsize=8)
fig.suptitle('Raw mapped-length densities; different ages/coverage prevent a hinge-causation test',fontsize=12);fig.tight_layout(rect=[0,0,1,.94]);fig.savefig(P/'tectonic_histograms.png',dpi=180);plt.close(fig)
print(json.dumps(metadata,indent=2,ensure_ascii=False));print(stats[(stats.selection=='all')].to_string(index=False))
