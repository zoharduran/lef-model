"""Conditional BMO scaling + independently reproduced Nichols 2026 pulse eqs.
Not a reproduction of Scheinberg's mantle convection simulation or an MHD run.
"""
from pathlib import Path
import numpy as np,pandas as pd,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;Y=365.25*86400;mu0=4*np.pi*1e-7;G=6.67430e-11
RM=1737.4e3;rc=330e3;rho=4000.;rhoc=6500.;cp=1200.;alpha=2e-5;latent=3e5;Leff=latent+cp*500
Mcore=4*np.pi/3*rhoc*rc**3
def fields(D,q,fdip=1.):
 ro=rc+D;volume=4*np.pi/3*(ro**3-rc**3);mass=rho*volume
 g=G*(Mcore+mass)/ro**2
 # Nonrotating mixing-length buoyancy velocity and energy-flux field scale.
 U=(alpha*g*q*D/(rho*cp))**(1/3)
 B=np.sqrt(2*mu0*rho)*U*(ro/RM)**3*fdip*1e6
 return U,B,g
rows=[]
for D in [100e3,200e3,300e3,400e3]:
 for q in [.001,.01,.1,1]:
  u,bb,g=fields(D,q)
  for sig in [78,1e3,1e4,2e4]:
   Rm=mu0*sig*u*D;rows.append([D/1e3,q,sig,u,Rm,bb,bb if Rm>=40 else 0,D*rho*Leff/q/Y/1e9])
tab=pd.DataFrame(rows,columns=['thickness_km','net_heat_flux_W_m2','conductivity_S_m','U_m_s','Rm','formal_surface_B_uT_d1','threshold_screened_B_uT','freeze_Gyr_no_replenishment']);tab.to_csv(P/'bmo_parameter_grid.csv',index=False)
requirements=[]
for D in [100e3,200e3,300e3,400e3]:
 for fdip in [1,1/7]:
  _,B1,_=fields(D,1,fdip)
  for target in [13,40,70]:
   q=(target/B1)**3;U,B,g=fields(D,q,fdip);sigmin=40/(mu0*U*D);lifetime=D*rho*Leff/q/Y/1e9
   requirements.append([D/1e3,fdip,target,q,4*np.pi*(rc+D)**2*q,lifetime,sigmin])
pd.DataFrame(requirements,columns=['thickness_km','dipole_amplitude_fraction','target_B_uT','required_heat_flux_W_m2','required_heat_loss_W','freeze_Gyr_if_no_replenishment','sigma_min_Rm40_S_m']).to_csv(P/'bmo_field_requirements.csv',index=False)
# Energy-conserving illustrative freezing, q_net constant per evolving outer area.
# rho*Leff*dD/dt=-q_net. No radioactive/core/tidal replenishment.
age0=4.249;times=np.linspace(0,age0,1800);fig,axs=plt.subplots(2,1,figsize=(11,9),sharex=True)
curves=[]
for D0,q,sig in [(100e3,.01,2e4),(300e3,.01,2e4),(400e3,.01,2e4),(400e3,.1,2e4),(400e3,1,2e4)]:
 D=np.maximum(D0-q*times*1e9*Y/(rho*Leff),0);U,B,g=fields(D,q);Rm=mu0*sig*U*D;screen=np.where(Rm>=40,B,np.nan)
 lab=f'{D0/1e3:.0f} km, q={q:g} W/m²';l,=axs[0].plot(age0-times,np.where(D>0,B,np.nan),ls=':',lw=1,label=lab+' (formal)');axs[0].plot(age0-times,screen,c=l.get_color(),lw=2.5);axs[1].plot(age0-times,Rm,c=l.get_color(),label=lab)
 for ag,dd,uu,rm,bb in zip(age0-times,D,U,Rm,B):curves.append([D0/1e3,q,sig,ag,dd/1e3,uu,rm,bb,bb if rm>=40 else 0])
# Deliberately tuned heat-supported illustration. Its change at 3.56 Ga is an
# INPUT, not a prediction. Show the heat supply required rather than asserting
# that radiogenic/terrestrial heat actually provides it.
from scipy.integrate import cumulative_trapezoid
qstrong=(70/fields(400e3,1)[1])**3
qout=np.where(times<=age0-3.56,qstrong,.003+(qstrong-.003)*np.exp(-(times-(age0-3.56))/.2))
qnet=np.minimum(.005,qout);Dh=400e3-cumulative_trapezoid(qnet,times*1e9*Y,initial=0)/(rho*Leff)
Uh,Bh,gh=fields(Dh,qout);Rmh=mu0*2e4*Uh*Dh;Hneed=4*np.pi*(rc+Dh)**2*(qout-qnet)
axs[0].plot(age0-times,Bh,'--',c='#9f1778',lw=1,label='Heat-supported example; 3.56 Ga break imposed')
axs[0].plot(age0-times,np.where(Rmh>=40,Bh,np.nan),c='#9f1778',lw=2)
axs[1].plot(age0-times,Rmh,'--',c='#9f1778')
pd.DataFrame({'age_Ga':age0-times,'D_km':Dh/1e3,'qout_W_m2':qout,'qnet_W_m2':qnet,'required_heat_supply_W':Hneed,'formal_B_uT':Bh,'Rm_sigma20000':Rmh}).to_csv(P/'bmo_heat_supported_ASSUMED.csv',index=False)
data=pd.read_csv(P/'data/paleointensity_37.csv')
for _,r in data.iterrows():
 ag=r.acquisition_age_Ga
 if r.result_type=='upper_limit':
  b=r.upper_limit_uT;axs[0].errorbar(ag,b,yerr=.3*b,uplims=True,fmt='v',c='gray',ms=3,alpha=.65)
 else:axs[0].plot(ag,r.paleointensity_uT,'ko',ms=3,alpha=.65)
axs[0].set(yscale='log',ylim=(.02,300),ylabel='Surface field (µT)',title='Conditional BMO energy-flux scaling, d=1, σ=20,000 S/m\nDotted: formal field; solid portions: Rm ≥ 40. Not an MHD prediction');axs[0].legend(fontsize=7,loc='lower right')
axs[1].set(yscale='log',ylim=(.01,2000),xlabel='Age (Ga)',ylabel='Mixing-length Rm');axs[1].axhline(40,c='k',ls='--');axs[1].text(.1,45,'Illustrative necessary-condition threshold 40',fontsize=8,ha='right')
for ax in axs:ax.set_xlim(4.55,0);ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(P/'basal_ocean_vs_record.png',dpi=180);plt.close(fig)
pd.DataFrame(curves,columns=['initial_D_km','q_W_m2','sigma_S_m','age_Ga','D_km','U_m_s','Rm','formal_B_uT','screened_B_uT']).to_csv(P/'bmo_histories.csv',index=False)
# Nichols et al. 2026 equations 11-12 and published Ti_dynamo_code.py.
# Latent heat assumed entirely extracted from core, 350 km core, d=1/7.
RC=350e3;rhoD=4000;L=300e3;Area=4*np.pi*RC**2
prows=[]
for Vkm in [1.8e6,520e6]:
 E=Vkm*1e9*rhoD*L
 for B in [3,13,40,53,70]:
  q=(B/(20/7))**3;Q=Area*q;duration=E/Q/Y;prows.append([Vkm,E,B,q,Q,duration])
pulses=pd.DataFrame(prows,columns=['melt_volume_km3','latent_energy_J','surface_field_uT','CMB_flux_W_m2','CMB_power_W','maximum_melting_years']);pulses.to_csv(P/'nichols_pulse_reproduction.csv',index=False)
fig,ax=plt.subplots(figsize=(9,5));dur=np.logspace(0,6,300)
for Vkm in [1.8e6,520e6]:
 E=Vkm*1e9*rhoD*L;q=E/(Area*dur*Y);B=20/7*q**(1/3);ax.loglog(dur,B,label=f'{Vkm:g} km³ melted')
for B in [40,53,70]:ax.axhline(B,c='gray',ls=':',lw=.7);ax.text(2e5,B*1.04,f'{B} µT',fontsize=8)
ax.set(xlabel='Pulse duration (years)',ylabel='Surface field (µT)',title='Recalculation of Nichols et al. (2026), equations 11–12');ax.legend();ax.grid(alpha=.2);fig.tight_layout();fig.savefig(P/'nichols_pulses.png',dpi=180);plt.close(fig)
# Attached-stage hypothetical initial differential rotation, not orbital law for core.
w=2*np.pi/(6.59*3600);n=2*np.pi/(8.12144942*3600);dw=w-n;C=8*np.pi/15*rhoc*rc**5;Ediff=.5*C*dw**2;U=rc*dw
attached={'mantle_spin_rad_s':w,'hypothetical_core_spin_rad_s':n,'delta_spin_rad_s':dw,'CMB_differential_speed_m_s':U,'initial_differential_energy_J':Ediff,'Ekman_spinup_years_nu1e6':rc/np.sqrt(1e-6*w)/Y,'Rm_sigma1e6':mu0*1e6*U*rc,'warning':'Orbital mean motion does not determine fluid-core axial spin. Assumed mismatch only; no persistent source specified.'}
for B in [40,70]:
 Q=4.7e9+3e11*(B/(6*(rc/350e3)**3))**3;attached[f'reservoir_duration_years_B{B}_old_optimistic_scaling']=Ediff/Q/Y
(P/'dynamo_results.json').write_text(json.dumps({'attached':attached,'BMO_assumptions':{'start_age_Ga':age0,'rho':rho,'cp':cp,'alpha':alpha,'effective_enthalpy_J_kg':Leff,'reference_core_radius_km':rc/1e3,'criterion_Rm':40,'dipole_fraction':1,'replenishment_W':0}},indent=2))
supported={'initial_B_uT':float(Bh[0]),'B_at_3p56_uT':float(np.interp(age0-3.56,times,Bh)),'initial_required_supply_W':float(Hneed[0]),'heat_supply_integral_to_3p56_J':float(np.interp(age0-3.56,times,cumulative_trapezoid(Hneed,times*1e9*Y,initial=0))),'present_remaining_melt_thickness_km':float(Dh[-1]/1e3),'warning':'Tuned illustration: the break at 3.56 Ga, high conductivity and heat resupply are ASSUMED, not explained.'}
(P/'bmo_heat_supported_results.json').write_text(json.dumps(supported,indent=2))
# Preserve authors' table, do not silently substitute revised dates into old audit.
nt=pd.read_csv(P/'data/Table_S1.csv',encoding='cp1252');nt.to_csv(P/'nichols_sample_table_transcribed.csv',index=False)
print('BMO target requirements');print(pd.DataFrame(requirements,columns=['D_km','d','B','q','Q','lifetime_Gyr','sigma_min']).query('d==1').to_string(index=False));print(pulses.to_string(index=False));print(json.dumps(attached,indent=2))
