"""LEF conditional geometry/contact audit. SI units except labelled degrees/km.
Python: numpy scipy matplotlib. This is not an elastic fracture/FEM solution.
"""
from pathlib import Path
import json,csv
import numpy as np
from scipy.optimize import brentq
from numpy.polynomial.legendre import leggauss
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
G=6.67430e-11; ME=5.972e24; MM=7.3477e22;RE=6371e3;RM=1737.4e3;Rbody=1890e3
yr=365.25*86400;w=2*np.pi/(6.59*3600);mu=G*ME;muorb=G*(ME+MM)
b=1500e3;h=np.sqrt(Rbody**2-b**2);Ic=.4*MM*Rbody**2;Ih=Ic+MM*h*h
def vec(lat,lon):
 lat,lon=np.deg2rad(lat),np.deg2rad(lon)
 return np.array([np.cos(lat)*np.cos(lon),np.cos(lat)*np.sin(lon),np.sin(lat)])
def ll(v):
 v=v/np.linalg.norm(v);return np.array([np.rad2deg(np.arcsin(v[2])),np.rad2deg(np.arctan2(v[1],v[0]))%360])
def basis(lat,lon):
 la,lo=np.deg2rad([lat,lon]);return np.array([-np.sin(lo),np.cos(lo),0]),np.array([-np.sin(la)*np.cos(lo),-np.sin(la)*np.sin(lo),np.cos(la)])
def offset(a,b):
 va,vb=vec(*a),vec(*b);ang=np.arccos(np.clip(va@vb,-1,1));ee,nn=basis(*a)
 if ang<1e-10:return [0,0,0,0,0]
 tangent=(vb-va*np.cos(ang))/np.sin(ang);E,N=np.rad2deg(ang)*np.array([tangent@ee,tangent@nn]);L=vec(0,270);L-=va*(L@va);L/=np.linalg.norm(L)
 return [np.rad2deg(ang),np.rad2deg(np.arctan2(E,N))%360,E,N,np.rad2deg(ang)*(tangent@L)]
attach=(23,320);anti=(-23,140);dome=(-51.4,196.8);ellipse=(-53,191)
refs={'Attachment antipode':anti,'Author maria antipode':(-19.4,167.2),'Imbrium mare antipode':(-34.72,165.09),'Serenitatis mare antipode':(-27.29,198.36)}
if (P/'tectonic_metadata.json').exists():
 md=json.loads((P/'tectonic_metadata.json').read_text());refs['Computed maria antipode']=(md['near_mare_antipode_lat'],md['near_mare_antipode_lonE'])
# Affine material relaxation; long axis through the attachment-antipode line.
# y=east and z=north at anti. Axis assignment/orientation is ASSUMED.
E,N=basis(*anti);A=np.column_stack([vec(*anti),E,N]);D=np.array([1,.637,.601])
def affine(point,inverse=True):
 v=A.T@vec(*point);v=v*D if inverse else v/D
 return ll(A@v)
rows=[]
for name,ref in refs.items():
 for target,pt in [('Dome',dome),('Ellipse',ellipse)]:
  rows.append([name,target,*ref,*offset(ref,pt),*affine(ref),*affine(pt),*offset(affine(ref),affine(pt))])
with (P/'offsets.csv').open('w') as f:
 z=csv.writer(f);z.writerow(['reference','target','reference_lat','reference_lon','angle_deg','bearing_deg','east_deg','north_deg','toward_leading_apex_deg','pre_ref_lat','pre_ref_lon','pre_target_lat','pre_target_lon','pre_angle_deg','pre_bearing_deg','pre_east_deg','pre_north_deg','pre_leading_projection_deg']);z.writerows(rows)
# Exact affine round-trip check, and local-to-finite-angle mapping.
for pt in [dome,ellipse,*refs.values()]:assert np.linalg.norm(vec(*pt)-vec(*affine(affine(pt),False)))<1e-12
fig,axs=plt.subplots(1,2,figsize=(12,5))
for name,ref in refs.items():
 if name=='Author maria antipode':continue
 x,y=offset(anti,ref)[2:4];axs[0].plot(x,y,'o')
 label=name.replace('Computed maria','Maria').replace(' mare','')
 offs=(-100,8) if 'Serenitatis' in name else ((4,-15) if 'Imbrium' in name else (4,4))
 axs[0].annotate(label,(x,y),xytext=offs,textcoords='offset points',fontsize=8)
for name,pt in [('Dome',dome),('Ellipse',ellipse)]:
 off=offset(anti,pt);axs[0].arrow(0,0,*off[2:4],width=.2,length_includes_head=True);axs[0].annotate(name,(off[2],off[3]),xytext=((6,0) if name=='Dome' else (-42,-13)),textcoords='offset points',fontsize=8);pre=offset(anti,affine(pt));axs[0].plot(pre[2],pre[3],'x',ms=9);axs[0].annotate('pre '+name,(pre[2],pre[3]),xytext=((6,3) if name=='Dome' else (-53,7)),textcoords='offset points',fontsize=8)
axs[0].set(xlabel='Local eastward angular component (deg)',ylabel='Local northward angular component (deg)',title='Azimuthal-equidistant map about attachment antipode');axs[0].set_aspect('equal');axs[0].set_xlim(-3,51);axs[0].set_ylim(-44,9);axs[0].grid(alpha=.3);axs[0].set_title('Offsets about attachment antipode',fontsize=11)
t=np.linspace(0,70,200)
for ratio in [.637,.601]:axs[1].plot(t,np.rad2deg(np.arctan(np.tan(np.deg2rad(t))/ratio)),label=f'transverse/long={ratio}')
axs[1].plot(t,t,'k:',label='No deformation');axs[1].set(xlabel='Pre-release offset angle (deg)',ylabel='Post-affine angle (deg)',title='Finite affine mapping; not a constant angular multiplier');axs[1].legend();axs[1].grid(alpha=.3)
fig.tight_layout();fig.savefig(P/'offset_rounding.png',dpi=180);plt.close(fig)
# Deterministic volume quadrature for finite sphere or ellipsoid.
xr,wr=leggauss(10);ct,wct=leggauss(14);rr=(xr+1)/2;wr=wr/2*rr**2
phi=np.arange(28)*2*np.pi/28
rad,c,p=np.meshgrid(rr,ct,phi,indexing='ij');weights=(wr[:,None,None]*wct[None,:,None]*np.ones((1,1,len(phi)))) .ravel();weights/=weights.sum()
unit=np.column_stack([(rad*np.sqrt(1-c*c)*np.cos(p)).ravel(),(rad*np.sqrt(1-c*c)*np.sin(p)).ravel(),(rad*c).ravel()])
def earth_g(x,day):
 r=np.linalg.norm(x,axis=1);z2=(x[:,2]/r)**2;J=1.08263e-3*(23.9344696/day)**2;k=1.5*J*(RE/r)**2
 out=-mu*x/r[:,None]**3;out[:,:2]*=(1+k*(1-5*z2))[:,None];out[:,2]*=1+k*(3-5*z2)
 return out
def balance(r=20596e3,lat=0,tilt=0,axis='east',day=6.59,shape='sphere',jday=None):
 la=np.deg2rad(lat);er=np.array([np.cos(la),0,np.sin(la)]);ee=np.array([0,1,0]);en=np.array([-np.sin(la),0,np.cos(la)])
 v=ee if axis=='east' else en;third=np.cross(er,v);t=np.deg2rad(tilt)
 rot=np.column_stack([np.cos(t)*er+np.sin(t)*v,-np.sin(t)*er+np.cos(t)*v,third])
 dims=np.array([Rbody]*3)
 if shape=='ellipsoid':dims=Rbody/(.637*.601)**(1/3)*np.array([1,.637,.601])
 pivot=(r-h)*er;centre=pivot+h*rot[:,0];rel=(unit*dims)@rot.T+h*rot[:,0];x=rel+pivot
 om=2*np.pi/(day*3600);acc=earth_g(x,jday or day)+om**2*x*np.array([1,1,0]);force=MM*np.sum(weights[:,None]*acc,axis=0);torque=MM*np.sum(weights[:,None]*np.cross(rel,acc),axis=0)
 return force@er,force@ee,force@en,torque@third
br=[]
for lat in [0,10,15,25]:
 for r in np.linspace(18e6,22e6,101):
  for shape in ['sphere','ellipsoid']:
   F=balance(r,lat,shape=shape,axis='north');br.append([r/1e3,lat,shape,*F])
with (P/'force_distance.csv').open('w') as f:
 z=csv.writer(f);z.writerow(['distance_km','latitude_deg','shape','outward_force_N','east_force_N','north_force_N','northward_torque_Nm']);z.writerows(br)
fig,axs=plt.subplots(1,2,figsize=(11,4.7))
for lat in [0,10,15,25]:
 rows=np.array([x[:2]+x[3:] for x in br if x[1]==lat and x[2]=='sphere'],float)
 axs[0].plot(rows[:,0],rows[:,2]/1e22,label=f'{lat}°');axs[1].plot(rows[:,0],rows[:,5]/1e28,label=f'{lat}°')
axs[0].set(xlabel='Geocentric distance (km)',ylabel='Outward effective body force (10²² N)',title='Earth J₂ + centrifugal force; finite spherical Moon')
axs[1].set(xlabel='Geocentric distance (km)',ylabel='Northward torque about contact (10²⁸ N m)',title='Zero eastward torque at steady radial alignment')
for ax in axs:ax.grid(alpha=.3);ax.legend(title='Earth source latitude')
fig.tight_layout();fig.savefig(P/'force_torque.png',dpi=180);plt.close(fig)
# Contact as bonded layer in normal extension/compression, not torsional shear.
# Elastic bending K = E_eff A2/thickness; Newtonian normal viscosity C=3 eta A2/thickness.
A2=np.pi*b**4/4
rad=20596e3
Kgeo=-(balance(rad,0,.01)[3]-balance(rad,0,-.01)[3])/np.deg2rad(.02)
# Construction cases: radial rise 14000 km and spin-down 5.5 -> 6.59 h.
duration=1e5*yr;v=14e6/duration;wdot=(w-2*np.pi/(5.5*3600))/duration
tau_rise=-2*MM*w*v*h;tau_spin=-(MM*rad*h+Ic)*wdot
tau_comb=tau_rise+tau_spin
cr=[]
for Eeff in [10e9,30e9,60e9]:
 for thick in [20e3,50e3]:
  Kel=Eeff*A2/thick
  angle=np.rad2deg(tau_comb/(Kel+Kgeo));nangle=brentq(lambda ang:balance(rad,25,ang,axis='north')[3]-Kel*np.deg2rad(ang),-45,45)
  cr.append([Eeff,thick,angle,nangle])
with (P/'elastic_contact.csv').open('w') as f:
 z=csv.writer(f);z.writerow(['effective_normal_modulus_Pa','thickness_m','EW_tilt_deg_100kyr_construction','NS_tilt_deg_lat25']);z.writerows(cr)
eta=np.logspace(18,23,100);fig,axs=plt.subplots(1,2,figsize=(11,4.7));vr=[]
for years in [1e5,1e6,1e8]:
 for thick in [20e3,50e3]:
  tm=years*yr;C=3*eta*A2/thick;tor=tau_comb*1e5/years
  theta=tor/Kgeo*(-np.expm1(-Kgeo*tm/C));unrest=tor*tm/C
  axs[0].loglog(eta,np.maximum(abs(np.rad2deg(theta)),1e-20),label=f'{years:.0e} yr, {thick/1e3:.0f} km')
  if years==1e5:axs[1].loglog(eta,abs(np.rad2deg(unrest)),label=f'No geometric restoring; {thick/1e3:.0f} km')
  for et,th,un in zip(eta,theta,unrest):vr.append([years,thick,et,np.rad2deg(th),np.rad2deg(un)])
axs[1].axhline(20,color='k',ls='--',label='20° target')
for ax in axs:ax.set(xlabel='Contact shear viscosity (Pa s)',ylabel='Absolute east–west tilt (degrees)');ax.grid(alpha=.2);ax.legend(fontsize=7)
axs[0].set_title('Rise + spin-down forcing, radial load retained');axs[1].set_title('Counterfactual: radial restoring removed')
fig.tight_layout();fig.savefig(P/'contact_tilt.png',dpi=180);plt.close(fig)
with (P/'viscous_contact.csv').open('w') as f:
 z=csv.writer(f);z.writerow(['construction_years','thickness_m','viscosity_Pas','tilt_deg_with_radial_restoring','tilt_deg_no_restoring']);z.writerows(vr)
# Geometry of heating: a line through the contact along the original radial ray
# intersects the tilted sphere at a material angular distance about 2*tilt for a
# tangent point contact (h=R). For a finite disc, derivative is 1+h/R.
beta=np.deg2rad(20);yp=h*np.sin(beta);xhit=h*np.cos(beta)+np.sqrt(Rbody**2-yp**2)
body_ray_angle=np.rad2deg(np.arctan2(-np.sin(beta)*xhit,np.cos(beta)*xhit-h))
result={'release':{'a_km':27433,'e_given':.2492,'rp_from_ae_km':27433*(1-.2492),'ra_from_ae_km':27433*(1+.2492),'e_from_a_rp':1-20595.5/27433,'circular_period_at_release_h':2*np.pi*np.sqrt(rad**3/muorb)/3600,'orbit_period_at_a_h':2*np.pi*np.sqrt((27433e3)**3/muorb)/3600},'geometry_dome':dict(zip(['angle','bearing','E','N','toward_leading'],offset(anti,dome))),'pre_dome':affine(dome).tolist(),'pre_dome_offset':offset(anti,affine(dome)),'leading_bearing_from_antipode':offset(anti,(0,270))[1],'leading_bearing_from_SPA':offset(dome,(0,270))[1],'contact':{'centre_to_disc_plane_m':h,'area_m2':np.pi*b*b,'K_geometric_Nm_per_rad':Kgeo,'tau_radial_rise_100kyr_Nm':tau_rise,'tau_spindown_100kyr_Nm':tau_spin,'tau_combined_Nm':tau_comb,'sphere_20deg_bodytilt_heat_hit_material_offset_deg':body_ray_angle,'edge_displacement_20deg_km':b*np.tan(beta)/1e3,'linear_elastic_strain_20km_50km':[b*beta/20e3,b*beta/50e3]},'baseline_balance':balance(),'elastic_cases':cr}
(P/'geometry_mechanics_results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
# Independent source-day/J2 sensitivity, holding attached angular speed fixed.
sens=[]
for jd in [5.5,6.59]:
 for lat in [0,10,25]:
  for radx in [18e6,20596e3,22e6]:
   sens.append([jd,lat,radx/1e3,*balance(radx,lat,axis='north',jday=jd)])
with (P/'J2_sensitivity.csv').open('w') as f:
 z=csv.writer(f);z.writerow(['Earth_J2_equivalent_day_h','source_lat','distance_km','Fout','Feast','Fnorth','M_north']);z.writerows(sens)
# Nonlinear northward contact response: time to equatorward 20 degrees, where
# the meridional centrifugal force supplies a steady torque. Not a geographic
# prediction for a particular lunar surface point (Euler orientation unknown).
from scipy.integrate import quad
ns=[]
for lat in [10,15,25]:
 for thick in [20e3,50e3]:
  for eta0 in [1e18,1e20,1e23]:
   C=3*eta0*A2/thick
   vals=[balance(rad,lat,ang,axis='north')[3] for ang in np.linspace(-20,0,41)]
   if np.max(vals)<0:
    tt=C*quad(lambda theta:1/balance(rad,lat,np.rad2deg(theta),axis='north')[3],0,np.deg2rad(-20))[0]/yr
   else:tt=float('nan')
   ns.append([lat,thick,eta0,tt])
with (P/'meridional_viscous_contact.csv').open('w') as f:
 z=csv.writer(f);z.writerow(['Earth_source_lat_deg','thickness_m','viscosity_Pas','years_to_equatorward20deg']);z.writerows(ns)
# Point-contact/finite-disc heating geometry at requested pre-affine angle.
preEW=np.deg2rad(result['pre_dome_offset'][2]);needed=brentq(lambda beta: beta+np.arcsin((h/Rbody)*np.sin(beta))-preEW,0,np.pi/3)
(P/'extra_mechanics.json').write_text(json.dumps({'body_hinge_angle_for_26deg_material_EW_offset_deg':np.rad2deg(needed),'required_min_external_hinge_moment_20deg_Nm':-balance(20596e3,0,20)[3],'required_radial_rise_speed_for_20deg_m_s':-balance(20596e3,0,20)[3]/(2*MM*w*h),'normal_contact_stress_baseline_Pa':balance()[0]/(np.pi*b*b)},indent=2))
