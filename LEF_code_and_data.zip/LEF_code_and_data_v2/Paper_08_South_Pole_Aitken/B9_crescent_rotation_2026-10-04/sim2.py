import numpy as np
G=6.674e-11; ME=5.97e24; MM=7.35e22; Rm=1.89e6; D=20.6e6
def run(P_hours, v, elev=45, naz=72, dt=4.0, tmax=4*3600):
    Om=0.0 if P_hours is None else 2*np.pi/(P_hours*3600)
    xE=-D*MM/(ME+MM); xM=D*ME/(ME+MM)
    E=np.array([xE,0,0]); M=np.array([xM,0,0]); W=np.array([0,0,Om])
    up=np.array([1.,0,0]); north=np.array([0,0,1.]); east=np.cross(north,up)
    az=np.linspace(0,2*np.pi,naz,endpoint=False)
    hdir=np.outer(np.cos(az),north)+np.outer(np.sin(az),east)
    u=v*(np.cos(np.radians(elev))*hdir+np.sin(np.radians(elev))*up)
    r=np.tile(M+Rm*up,(naz,1)); alive=np.ones(naz,bool); land=np.full((naz,3),np.nan); tl=np.full(naz,np.nan)
    def acc(r,u):
        rm=r-M; re=r-E
        a=-G*MM*rm/np.linalg.norm(rm,axis=1)[:,None]**3-G*ME*re/np.linalg.norm(re,axis=1)[:,None]**3
        a+= -np.cross(W,np.cross(W,r)) - 2*np.cross(W,u)
        return a
    t=0
    while t<tmax and alive.any():
        k1v=acc(r,u); k1r=u
        k2v=acc(r+dt/2*k1r,u+dt/2*k1v); k2r=u+dt/2*k1v
        k3v=acc(r+dt/2*k2r,u+dt/2*k2v); k3r=u+dt/2*k2v
        k4v=acc(r+dt*k3r,u+dt*k3v); k4r=u+dt*k3v
        rn=r+dt/6*(k1r+2*k2r+2*k3r+k4r); un=u+dt/6*(k1v+2*k2v+2*k3v+k4v); t+=dt
        hit=alive&(np.linalg.norm(rn-M,axis=1)<Rm)
        land[hit]=rn[hit]; tl[hit]=t; alive&=~hit
        r=np.where(alive[:,None],rn,r); u=np.where(alive[:,None],un,u)
    p=(land-M); p/=np.linalg.norm(p,axis=1)[:,None]
    ang=np.degrees(np.arccos(np.clip(p@up,-1,1)))
    bear=np.degrees(np.arctan2(p@east,p@north))%360
    return az,ang,bear,tl
