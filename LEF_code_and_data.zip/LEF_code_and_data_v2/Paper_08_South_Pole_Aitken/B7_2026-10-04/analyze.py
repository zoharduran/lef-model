"""SPA composition, PDS LP_9001; Python 3 + numpy + matplotlib.
Run from any directory: python analyze.py. Downloads missing raw inputs.
Pixel values constant within each native cell. Equal-area subcell quadrature.
No geological masks: every valid surface cell in the prescribed geometry.
"""
from pathlib import Path
import numpy as np, json, csv, urllib.request, hashlib
ROOT=Path(__file__).resolve().parent; DATA=ROOT/'data';DATA.mkdir(exist_ok=True)
BASE='https://pds-geosciences.wustl.edu/lunar/lp-l-grs-5-elem-abundance-v1/lp_9001/data/'
POINTS={'SPA':(-53,191),'Inner':(-51.4,196.8),'Apollo':(-36.1,208.3),'Thin_crust':(-56,190),'Crater_minimum':(-47.5,193.5)}
EDGES=np.array([0,10,20,30,39.57,50]);R=1737.4

def geometry(lat,lon,center):
 p,l=np.deg2rad(lat),np.deg2rad(lon);p0,l0=np.deg2rad(center);dl=l-l0
 c=np.sin(p0)*np.sin(p)+np.cos(p0)*np.cos(p)*np.cos(dl)
 d=np.rad2deg(np.arccos(np.clip(c,-1,1)))
 az=np.rad2deg(np.arctan2(np.sin(dl)*np.cos(p),np.cos(p0)*np.sin(p)-np.sin(p0)*np.cos(p)*np.cos(dl)))%360
 return d,az

def run(deg=2,n=12):
 fn=f'lpgrs_high1_elem_abundance_{deg}deg.tab';p=DATA/fn
 if not p.exists():urllib.request.urlretrieve(BASE+fn,p)
 a=np.loadtxt(p);N=len(a); assert a.shape[1]==61
 # Exact native spherical rectangle areas; do not multiply by cos(latitude) again.
 lo,hi=np.sin(np.deg2rad(a[:,1])),np.sin(np.deg2rad(a[:,2]));dl=np.deg2rad(a[:,4]-a[:,3]);area=(hi-lo)*dl
 assert abs(area.sum()-4*np.pi)<1e-10
 t=(np.arange(n)+.5)/n
 lat=np.rad2deg(np.arcsin(lo[:,None]+(hi-lo)[:,None]*t))
 lon=a[:,3,None]+(a[:,4]-a[:,3])[:,None]*t
 lat=np.broadcast_to(lat[:,:,None],(N,n,n)).reshape(N,-1);lon=np.broadcast_to(lon[:,None,:],(N,n,n)).reshape(N,-1)
 vals={'FeO':a[:,12]*100,'TiO2':a[:,11]*100,'Th':a[:,14],'K':a[:,13]}
 var={'FeO':a[:,51]*1e4,'TiO2':a[:,46]*1e4,'Th':a[:,58],'K':a[:,55]};cov=a[:,56]
 assert all(np.isfinite(v).all() for v in vals.values())
 def stats(mask):
  w=area*mask.mean(axis=1);w/=w.sum();out={}
  for k,v in vals.items():
   mean=float(w@v);out[k]=mean;out[k+'_spatial_sd']=float(np.sqrt(w@(v-mean)**2));out[k+'_formal_se']=float(np.sqrt((w*w)@var[k]))
  K,T=out['K'],out['Th'];out['K_Th']=K/T
  out['K_Th_formal_se']=float(np.sqrt(max(0,((w*w)@var['K'])/T**2+K*K*((w*w)@var['Th'])/T**4-2*K*((w*w)@cov)/T**3)))
  out['area_km2']=float((area*mask.mean(axis=1)).sum()*R**2)
  out['native_cells']=int((w>0).sum());return out
 dspa,_=geometry(lat,lon,POINTS['SPA']);dh,_=geometry(lat,lon,(45,180));df,_=geometry(lat,lon,(0,0))
 controls={'Highlands_cap':stats(dh<20),'Farside_outside_SPA':stats((df>90)&(dspa>=39.57)),'Global_surface':stats(np.ones_like(lat,dtype=bool)),'SPA_inside_rim':stats(dspa<39.57)}
 out={'grid_degrees':deg,'quadrature_n':n,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'controls':controls,'rings':{},'sectors':{},'harmonics':{},'centroids':{},'profile_metrics':{},'zero_counts':{k:int((v<=0).sum()) for k,v in vals.items()}}
 for name in ['SPA','Inner']:
  d,az=geometry(lat,lon,POINTS[name]);rings=[]
  for l,h in zip(EDGES[:-1],EDGES[1:]):rings.append({'inner':float(l),'outer':float(h),**stats((d>=l)&(d<h))})
  out['rings'][name]=rings
  ss=[];sector=((az+22.5)%360//45).astype(int)
  for j in range(8):ss.append({'azimuth':j*45,**stats((d<30)&(sector==j))})
  out['sectors'][name]=ss;out['harmonics'][name]={}
  azmid=np.deg2rad(np.arange(8)*45);X=np.column_stack([np.ones(8),np.cos(azmid),np.sin(azmid)])
  # Correct for finite 45-degree sector averaging of a sinusoid.
  sinc=np.sin(np.pi/8)/(np.pi/8)
  for k in ['FeO','Th','K','K_Th']:
   y=np.array([x[k] for x in ss]);b=np.linalg.lstsq(X,y,rcond=None)[0];amp=np.hypot(b[1],b[2])/sinc
   out['harmonics'][name][k]={'mean':float(b[0]),'amplitude':float(amp),'percent':float(100*amp/b[0]),'maximum_azimuth_deg':float(np.rad2deg(np.arctan2(b[2],b[1]))%360),'fit_r2':float(1-np.sum((y-X@b)**2)/np.sum((y-y.mean())**2))}
  out['profile_metrics'][name]={}
  for k in ['FeO','Th','K','K_Th']:
   # First four rings, within 39.57 deg. Area-weighted linear slope of ring means.
   rr=rings[:4];y=np.array([r[k] for r in rr]);w=np.array([r['area_km2'] for r in rr]);xx=(EDGES[:4]+EDGES[1:5])/2
   Xr=np.column_stack([np.ones(4),xx]);b=np.linalg.lstsq(Xr*np.sqrt(w[:,None]),y*np.sqrt(w),rcond=None)[0]
   metric={'slope_per_degree':float(b[1]),'inner_minus_outer':float(y[0]-y[-1]),'monotonic_decreasing':bool(np.all(np.diff(y)<0))}
   if k!='K_Th':metric['within_ring_rms']=float(np.sqrt(np.average([r[k+'_spatial_sd']**2 for r in rr],weights=w)))
   out['profile_metrics'][name][k]=metric
  # Top decile by AREA within each 40-degree cap, ties shared fractionally.
  cap=d<40;wcap=area*cap.mean(axis=1);target=.1*wcap.sum()
  for k in ['FeO','Th']:
   v=vals[k];order=np.argsort(v)[::-1];cs=np.cumsum(wcap[order]);threshold=v[order[np.searchsorted(cs,target)]]
   f=np.where(v>threshold,1.,0.);tie=(v==threshold);f[tie]=(target-wcap[v>threshold].sum())/wcap[tie].sum()
   phi=np.deg2rad(lat);lam=np.deg2rad(lon);ww=area[:,None]*cap*f[:,None]/(n*n)
   xyz=np.array([np.sum(ww*np.cos(phi)*np.cos(lam)),np.sum(ww*np.cos(phi)*np.sin(lam)),np.sum(ww*np.sin(phi))]);xyz/=np.linalg.norm(xyz)
   pt=(float(np.rad2deg(np.arcsin(xyz[2]))),float(np.rad2deg(np.arctan2(xyz[1],xyz[0]))%360))
   dist={pn:float(geometry(*pt,pc)[0]*np.pi/180*R) for pn,pc in POINTS.items()}
   out['centroids'][name+'_'+k]={'lat':pt[0],'lon':pt[1],'threshold':float(threshold),'area_km2':float(target*R**2),'distances_km':dist}
 # OLS slope is reported separately from global ratio of means.
 X=np.column_stack([np.ones(N),vals['Th']]);b=np.linalg.lstsq(X*np.sqrt(area[:,None]),vals['K']*np.sqrt(area),rcond=None)[0]
 out['global_K_vs_Th_OLS']={'intercept_ppm':float(b[0]),'slope':float(b[1])}
 return out

if __name__=='__main__':
 outputs={}
 for deg,n in [(2,12),(2,24),(5,24)]:
  print('Computing',deg,n,flush=True);outputs[f'{deg}deg_n{n}']=run(deg,n)
 (ROOT/'results.json').write_text(json.dumps(outputs,indent=2))
 base=outputs['2deg_n24']
 for kind in ['rings','sectors']:
  rows=[{'centre':c,**r} for c,rr in base[kind].items() for r in rr]
  with (ROOT/(kind+'.csv')).open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 with (ROOT/'controls.csv').open('w',newline='') as f:
  rows=[{'region':k,**r} for k,r in base['controls'].items()];w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 print(json.dumps({k:base[k] for k in ['controls','rings','harmonics','centroids','profile_metrics','global_K_vs_Th_OLS','zero_counts']},indent=2))
