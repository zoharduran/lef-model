import numpy as np, pandas as pd
rng=np.random.default_rng(3)
B='/home/claude/LEF_המוח/'
g=B+'מאמר_09_SPA/ג_נתונים_וקוד/B8_2026-10-04/'
M=np.load(g+'mare_grid.npy'); gla=np.load(g+'grid_lat.npy'); glo=np.load(g+'grid_lon.npy')
R=1737.4; LA,LO=np.meshgrid(gla,glo,indexing='ij'); cell=(R*np.deg2rad(0.25))**2*np.cos(np.deg2rad(LA))
def angd(a1,o1,a2,o2):
    p1,p2=np.deg2rad(a1),np.deg2rad(a2); dl=np.deg2rad(o2-o1)
    return np.rad2deg(np.arccos(np.clip(np.sin(p1)*np.sin(p2)+np.cos(p1)*np.cos(p2)*np.cos(dl),-1,1)))
nb=pd.read_csv(B+'06_נתונים_משותפים/neumann_basins_ge500.csv')
d=pd.read_csv(B+'06_נתונים_משותפים/Robbins_Dge20_selected.csv')
la=d.LAT_CIRC_IMG.values; lo=d.LON_CIRC_IMG.values; D=d.DIAM_CIRC_IMG.values; mare=d.inside_mare.values
spa_g=angd(LA,LO,-53,191)<39.57; spa_c=angd(la,lo,-53,191)<39.57
bas_g=np.zeros_like(M); bas_c=np.zeros(len(d),bool)
for _,b in nb.iterrows():
    bas_g|=angd(LA,LO,b.lat,b.lonE)<b.angular_radius_deg; bas_c|=angd(la,lo,b.lat,b.lonE)<b.angular_radius_deg
caps={'90E (trailing)':(0,90),'90W (leading)':(0,270),'180 (far)':(0,180),'0 (near)':(0,0)}
masks={'maria+SPA':(~M&~spa_g, ~mare&~spa_c),'maria+SPA+basins':(~M&~spa_g&~bas_g, ~mare&~spa_c&~bas_c)}
edges=20*2**(np.arange(0,9)/2); Dm=np.sqrt(edges[:-1]*edges[1:])
out={}
for mk,(okg,okc) in masks.items():
    print(f'\n===== mask: {mk}')
    for k,(a,o) in caps.items():
        cg=okg&(angd(LA,LO,a,o)<=30); cc=okc&(angd(la,lo,a,o)<=30)
        A=cell[cg].sum()/1e6; x=D[cc]; n=len(x)
        x100=x[x<100]; b=len(x100)/np.sum(np.log(x100/20))
        n_,_=np.histogram(x,edges); Rp=Dm**3*n_/((edges[1:]-edges[:-1])*A)
        out[(mk,k)]=x
        print(f'{k:15s} area {A:5.2f} Mkm2  N {n:4d}  density {n/A:6.1f}  slope b(20-100) {b:4.2f}  frac 20-30 {np.mean(x<30):.3f}  median {np.median(x):5.1f}')
        print(f'{"":15s} R-plot x1e-3: {np.round(Rp*1e-3,2).tolist()}   N/bin {n_.tolist()}')
print('bins:',np.round(Dm,1).tolist())
def best_shift(x1,x2):
    ss=np.linspace(0.6,1.6,201); best=None
    for s in ss:
        y=x2*s; lo_=max(20,20*s); y=y[(y>=lo_)&(y<200)]; z=x1[(x1>=lo_)&(x1<200)]
        if len(y)<20 or len(z)<20: continue
        al=np.sort(np.r_[np.log(z),np.log(y)])
        ks=np.abs(np.searchsorted(np.sort(np.log(z)),al,'right')/len(z)-np.searchsorted(np.sort(np.log(y)),al,'right')/len(y)).max()
        if best is None or ks<best[1]: best=(s,ks)
    return best[0]
for mk in masks:
    a=out[(mk,'90E (trailing)')]; b_=out[(mk,'90W (leading)')]; c=out[(mk,'180 (far)')]
    for nm,x1,x2 in (('90E vs 90W',a,b_),('90E vs 180',a,c),('90W vs 180',b_,c)):
        s=best_shift(x1,x2); bs=[best_shift(rng.choice(x1,len(x1)),rng.choice(x2,len(x2))) for _ in range(300)]
        print(f'{mk:18s} {nm}: size scale of first relative to second = {s:.3f}  95% {np.percentile(bs,[2.5,97.5]).round(3)}')
    for nm,x1,x2 in (('90E vs 90W',a,b_),):
        r=np.median(x1)/np.median(x2); bs=[np.median(rng.choice(x1,len(x1)))/np.median(rng.choice(x2,len(x2))) for _ in range(5000)]
        print(f'{mk:18s} median ratio {nm}: {r:.3f} {np.percentile(bs,[2.5,97.5]).round(3)}')
