# Density of large craters (centres outside maria; mare area removed) on a lat/lon grid, with the visible maria and the feed domes overlaid.
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
R=1737.4
U='/home/claude/LEF_המוח/מאמר_07_הימות/ג_נתונים_וקוד/'
u=pd.read_csv(U+'צט_רצפות_הימות_2026-10-09/per_unit_measurements.csv'); mm=u[u.area_polygon_km2>=300]
dm=pd.read_csv(U+'צט_פקקים_קבורים_2026-10-09/per_mascon_measurements.csv'); dm=dm[dm.band.astype(str).str.contains('660')]
def V(lat,lon): la,lo=np.radians(lat),np.radians(lon); return np.c_[np.cos(la)*np.cos(lo),np.cos(la)*np.sin(lo),np.sin(la)]
MV=V(mm.lat.values,mm.lonE.values); MR=mm.equiv_radius_km.values
def in_mare(X):
    o=np.zeros(len(X),bool)
    for i in range(0,len(X),20000): o[i:i+20000]=((np.arccos(np.clip(X[i:i+20000]@MV.T,-1,1))*R-MR)<0).any(1)
    return o
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3]); c.columns=['lon','lat','D']; c['D']/=1000
c=c[c.D>=20]; CV=V(c.lat.values,c.lon.values%360); k=~in_mare(CV); CV=CV[k]; D=c.D.values[k]
lats=np.arange(-87.5,90,2.5); lons=np.arange(-178.75,180,2.5)
G=np.array([[a,o] for a in lats for o in lons]); GV=V(G[:,0],G[:,1]%360)
rng=np.random.default_rng(5); z=rng.uniform(-1,1,600000); pp=rng.uniform(0,2*np.pi,600000)
S=np.c_[np.sqrt(1-z*z)*np.cos(pp),np.sqrt(1-z*z)*np.sin(pp),z]; S=S[~in_mare(S)]; A1=4*np.pi*R**2/600000
rad=300.0; th=np.cos(rad/R)
dens={}
for lab,(lo,hi) in {'20-50':(20,50),'50-300':(50,300)}.items():
    sel=(D>=lo)&(D<hi); Cs=CV[sel]; out=np.zeros(len(GV))
    for i in range(0,len(GV),500):
        g=GV[i:i+500]; n=(Cs@g.T>th).sum(0); a=(S@g.T>th).sum(0)*A1
        out[i:i+500]=np.where(a>0.2*np.pi*rad**2,n/np.maximum(a,1)*1e6,np.nan)
    dens[lab]=out.reshape(len(lats),len(lons))
np.savez('big_crater_density.npz',lats=lats,lons=lons,**dens)
fig,axs=plt.subplots(2,1,figsize=(16,15))
for ax,(lab,M) in zip(axs,dens.items()):
    vmax=np.nanpercentile(M,98)
    im=ax.pcolormesh(lons,lats,M,cmap='YlOrRd',vmin=0,vmax=vmax,shading='auto')
    for _,r in mm.iterrows():
        rd=np.degrees(r.equiv_radius_km/R); lo=(r.lonE+180)%360-180
        ax.add_patch(Ellipse((lo,r.lat),2*rd/max(np.cos(np.radians(r.lat)),0.2),2*rd,fc='#3d3d4a',ec='none',alpha=0.55))
    for _,r in dm.iterrows():
        rd=np.degrees(r.diameter_km/2/R); lo=(r.lonE+180)%360-180
        col={'buried':'#1565c0','under mare':'k','partial':'#6a1b9a'}[r['class']]
        ax.add_patch(Ellipse((lo,r.lat),2*rd/max(np.cos(np.radians(r.lat)),0.2),2*rd,fill=False,ec=col,lw=1.6,ls='-' if r['class']=='buried' else '--'))
    for x0,t in [(0,'near side (0°)'),(90,'90°E trailing'),(-90,'90°W leading'),(178,'far side (180°)')]:
        ax.text(x0,92,t,ha='center',fontsize=11,fontweight='bold')
    ax.set_xlim(-180,180); ax.set_ylim(-90,96); ax.set_aspect('equal'); ax.set_xticks(range(-180,181,30)); ax.set_xlabel('longitude (°E)'); ax.set_ylabel('latitude')
    cb=plt.colorbar(im,ax=ax,fraction=0.025,pad=0.01); cb.set_label('craters per million km² (within 300 km; mare ground removed)')
    ax.set_title(f'Craters {lab} km: density, with the visible maria (dark patches) and the feed domes (blue circles buried, dashed black under a mare)',fontsize=12)
plt.tight_layout(); plt.savefig('big_crater_density_map.png',dpi=110)
for lab,M in dens.items():
    print(lab,'max',np.nanmax(M).round(0),'median',np.nanmedian(M).round(0))
