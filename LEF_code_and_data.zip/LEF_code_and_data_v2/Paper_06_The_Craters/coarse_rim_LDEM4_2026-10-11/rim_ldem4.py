# Coarse rim test on LOLA LDEM_4 (4 px/deg, ~7.6 km): craters >=60 km on near-side mare floors vs highland craters of the same size.
import numpy as np, pandas as pd
from scipy.ndimage import map_coordinates
R=1737.4
dem=np.fromfile('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/data/ldem_4.img',dtype='<i2').reshape(720,1440).astype(float)*0.5/1000  # km
def h(lon,lat):
    col=((lon%360)*4-0.5); row=(90-lat)*4-0.5
    return map_coordinates(dem,[row,col],order=1,mode='wrap')
fm=pd.read_csv('../גודל_ומצב_על_הימות_2026-10-11/near_mare_floor_craters_ge3.csv'); fm=fm[fm.D>=60].copy(); fm['grp']='mare_'+fm.cls
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3,4]); c.columns=['lon','lat','D','d']; c['D']/=1000
hl=c[(c.D>=60)&(c.D<400)&(c.lat.abs()<60)].copy()
key=set(zip(fm.lon.round(3),fm.lat.round(3)))
# highland: centre not on any mare (use the floor file of all mare craters >=10)
allm=pd.read_csv('../מכתשים_קבורים_בימות_2026-10-11/mare_floor_craters_ge10.csv')
mk=set(zip(allm.lon.round(3),allm.lat.round(3)))
hl=hl[[ (round(a,3),round(b,3)) not in mk for a,b in zip(hl.lon,hl.lat)]]
def angd(lo1,la1,lo2,la2):
    a,b,cc,d=map(np.radians,(lo1,la1,lo2,la2)); return np.degrees(np.arccos(np.clip(np.sin(b)*np.sin(d)+np.cos(b)*np.cos(d)*np.cos(a-cc),-1,1)))
hl=hl[angd(hl.lon,hl.lat,-169,-53)>1000/R*180/np.pi]; hl['grp']='highland'
def measure(lon,lat,D):
    r=D/2; az=np.radians(np.arange(0,360,10)); out={}
    def ring(f0,f1,n=8):
        fr=np.linspace(f0,f1,n); rr=fr[:,None]*r; 
        dl=rr*np.cos(az)[None,:]/R; dn=rr*np.sin(az)[None,:]/R
        la=lat+np.degrees(dn); lo=lon+np.degrees(dl)/np.cos(np.radians(lat))
        return h(lo.ravel(),la.ravel()).reshape(lo.shape)
    rim=ring(0.85,1.2).max(0)            # per azimuth
    sur=np.median(ring(1.6,2.4))
    inner=np.median(ring(0.0,0.5))
    rh=(rim-sur)/D*1000                  # rim above land, x1e-3 D, per azimuth
    return np.median(rh), np.mean(rh> 0.25*np.median(rh) if np.median(rh)>0 else rh>0), (np.median(rim)-inner)/D*1000, (sur-inner)/D*1000
rows=[]
for df in (fm,hl):
    for _,x in df.iterrows():
        a,cont,depth,below=measure(x.lon,x.lat,x.D); rows.append((x.grp,x.D,x.lon,x.lat,a,cont,depth,below))
T=pd.DataFrame(rows,columns=['grp','D','lon','lat','rim_above_land','rim_continuity','rim_to_floor','floor_below_land'])
T['sz']=pd.cut(T.D,[60,100,400],labels=['60-100','100+'],right=False)
g=T.groupby(['sz','grp'],observed=True).agg(n=('D','size'),rim=('rim_above_land','median'),cont=('rim_continuity','median'),depth=('rim_to_floor','median'),below=('floor_below_land','median')).round(1)
print(g)
T.to_csv('rim_ldem4.csv',index=False); g.to_csv('rim_ldem4_summary.csv')

for nm,(lo,la) in {'Sinus Iridum':(-31.5,44.8),'Plato':(-9.4,51.6),'Archimedes':(-4.0,29.7)}.items():
    j=((T.lon-lo)**2+(T.lat-la)**2).idxmin(); r=T.loc[j]; print(nm,r.grp,round(r.D),'rim',round(r.rim_above_land,1),'cont',round(r.rim_continuity,2),'below',round(r.floor_below_land,1))
