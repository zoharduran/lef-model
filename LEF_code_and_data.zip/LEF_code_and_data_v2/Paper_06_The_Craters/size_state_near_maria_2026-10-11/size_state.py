# Zohar's claim: large craters on the near-side maria came early (Earth close, maria hot) and were melted (Sinus Iridum),
# medium ones later as viscosity rose, smeared (Plato), small ones last, when the maria were cold, sharp (Kirch).
# Prediction: on near-side mare floors the share buried rises with size, the share intact falls.
import struct, numpy as np, pandas as pd
from matplotlib.path import Path
SH='/tmp/claude-0/-home-claude/823d745d-d585-5e62-ab3b-cc648f681ccc/scratchpad/lroc/'
shp=open(SH+'LROC_GLOBAL_MARE_180.SHP','rb').read(); dbf=open(SH+'LROC_GLOBAL_MARE_180.DBF','rb').read()
n=struct.unpack('<I',dbf[4:8])[0]; hl,rl=struct.unpack('<HH',dbf[8:12])
fields=[];i=32
while dbf[i]!=0x0D: fields.append((dbf[i:i+11].split(b'\0')[0].decode(),dbf[i+16])); i+=32
recs=[]
for k in range(n):
    r=dbf[hl+k*rl+1:hl+(k+1)*rl]; o=0; row={}
    for nm,ln in fields: row[nm]=r[o:o+ln].decode('latin1').strip(); o+=ln
    recs.append(row)
names=np.array([r['MARE_NAME'] for r in recs])
polys=[];pos=100
while pos<len(shp):
    clen=struct.unpack('>i',shp[pos+4:pos+8])[0]*2; c=shp[pos+8:pos+8+clen]; pos+=8+clen
    nparts,npts=struct.unpack('<2i',c[36:44]); parts=list(struct.unpack(f'<{nparts}i',c[44:44+4*nparts]))
    pts=np.frombuffer(c[44+4*nparts:44+4*nparts+16*npts],dtype='<f8').reshape(-1,2); parts.append(npts)
    polys.append([pts[parts[j]:parts[j+1]] for j in range(nparts)])
def inside_index(lon,lat):
    P=np.c_[lon,lat]; out=np.full(len(lon),-1)
    for idx,parts in enumerate(polys):
        allp=np.vstack(parts); x0,y0=allp.min(0); x1,y1=allp.max(0)
        m=(lon>=x0)&(lon<=x1)&(lat>=y0)&(lat<=y1)
        if not m.any(): continue
        par=np.zeros(m.sum(),bool)
        for p in parts: par^=Path(p).contains_points(P[m])
        out[np.where(m)[0][par]]=idx
    return out
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3,4]); c.columns=['lon','lat','D','d']; c['D']/=1000
c=c[(c.D>=3)&(c.D<400)&(c.d>0)].reset_index(drop=True); c['dD']=c.d/1000/c.D
ci=inside_index(c.lon.values,c.lat.values); c['mare']=np.where(ci>=0,names[np.clip(ci,0,None)],'')
bins=[3,5,10,20,40,80,400]; c['bin']=pd.cut(c.D,bins,right=False)
hlc=c[(c.mare=='')&(c.lat.abs()<60)]
q05=hlc.groupby('bin',observed=True).dD.quantile(.05); q25=hlc.groupby('bin',observed=True).dD.quantile(.25); med=hlc.groupby('bin',observed=True).dD.median()
near=c[(c.mare!='')&(c.lon.abs()<=90)].copy()
near['cls']=np.where(near.dD<near.bin.map(q05).astype(float),'buried',np.where(near.dD<near.bin.map(q25).astype(float),'partly','intact'))
t=pd.crosstab(near.bin,near.cls); t['n']=t.sum(1)
for k in ['buried','partly','intact']: t[k+'%']=(t[k]/t.n*100).round(0)
t['dD_med_mare']=near.groupby('bin',observed=True).dD.median().round(3); t['dD_med_highland']=med.round(3)
t['ratio']=(t.dD_med_mare/t.dD_med_highland).round(2)
print(t.to_string())
for nm,(lo,la) in {'Sinus Iridum':(-31.5,44.8),'Plato':(-9.4,51.6),'Kirch':(-5.6,39.2),'Archimedes':(-4.0,29.7),'Copernicus':(-20.1,9.6)}.items():
    d=np.hypot((c.lon-lo)*np.cos(np.radians(la)),c.lat-la); j=d.idxmin(); r=c.loc[j]
    print(nm, round(r.D,1),'km d/D',round(r.dD,3),'highland median same size',round(float(med[r.bin]),3), 'on mare floor:',r.mare or '-')
t.to_csv('size_state_near_maria.csv'); near.to_csv('near_mare_floor_craters_ge3.csv',index=False)
