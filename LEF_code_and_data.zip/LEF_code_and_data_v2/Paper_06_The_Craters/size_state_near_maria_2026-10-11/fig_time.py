import numpy as np, matplotlib.pyplot as plt
plt.rcParams['font.family']='DejaVu Sans Mono'
t=np.linspace(0,10,400)
Tc=1050+330*np.exp(-t/3.2)-0*t          # contact mare (stays hot longest)
Tl=1050+330*np.exp(-t/1.4)               # limb mare (cools earlier)
size=300*np.exp(-t/1.9)+3                # largest body reaching the Moon
fig,ax=plt.subplots(figsize=(10.5,4.8)); ax2=ax.twinx()
ax.axvspan(0,2.6,color='#c0392b',alpha=.10); ax.axvspan(2.6,5.6,color='#e69138',alpha=.12); ax.axvspan(5.6,10,color='#1f6fb2',alpha=.10)
for x,s,c in [(1.3,'MELTED\n(ring only)','#9b2d20'),(4.1,'SMEARED\n(partly buried)','#a35f14'),(7.8,'SHARP\n(intact)','#174f80')]:
    ax.text(x,1395,s,ha='center',va='top',fontsize=10,fontweight='bold',color=c)
ax.plot(t,Tc,color='#c0392b',lw=2.4,label='mare of the contact')
ax.plot(t,Tl,color='#c0392b',lw=1.6,ls='--',label='mare of the limb (cools earlier)')
ax.axhline(1200,color='#777',lw=.8,ls=':'); ax.text(9.95,1203,'liquid: low viscosity',ha='right',va='bottom',fontsize=8.5,color='#555')
ax.axhline(1080,color='#777',lw=.8,ls=':'); ax.text(9.95,1076,'near the solidus: viscosity rises steeply',ha='right',va='top',fontsize=8.5,color='#555')
ax.set_ylim(1000,1400); ax.set_ylabel('temperature of the mare (°C, schematic)',color='#9b2d20')
ax2.plot(t,size,color='#2b3a55',lw=2.4,label='largest body reaching the Moon')
ax2.set_yscale('log'); ax2.set_ylim(2,500); ax2.set_ylabel('crater size made (km, schematic)',color='#2b3a55')
for x,nm,D in [(0.7,'Sinus Iridum',246),(3.0,'Plato',101),(6.6,'Kirch',11)]:
    y=300*np.exp(-x/1.9)+3; ax2.plot(x,D,'o',color='#2b3a55',ms=7); ax2.annotate(f'{nm} {D} km',(x,D),xytext=(8,6),textcoords='offset points',fontsize=9)
ax.set_xticks([]); ax.set_xlabel('time after release  →   (the Earth recedes, the maria cool)')
h1,l1=ax.get_legend_handles_labels(); h2,l2=ax2.get_legend_handles_labels()
ax.legend(h1+h2,l1+l2,loc='lower left',fontsize=9,frameon=True)
for a in (ax,ax2): a.spines['top'].set_visible(False)
plt.tight_layout(); plt.savefig('fig_time_state.png',dpi=180)
