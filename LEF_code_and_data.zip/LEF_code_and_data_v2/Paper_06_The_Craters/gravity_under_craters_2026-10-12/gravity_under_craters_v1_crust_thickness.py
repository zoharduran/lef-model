# What lies beneath the shallow ring craters of the near-side maria?
# Three readings, decided before the data:
#  BURIED (literature): a whole bowl filled with dense basalt -> mass excess over the whole floor, out to ~0.8R,
#                       centre ~ floor, and the excess grows with the missing depth (fill thickness).
#  EXPOSURE (Zohar):    the landing pushed light material aside and brought dense material up / compacted it at the
#                       centre -> excess peaked at the centre (centre > floor), tied to size, not to missing depth.
#  MELTED, nothing below: interior ~ outside.
# Gravity proxies (no SH coefficients reachable from here):
#  (1) GRAIL crustal-thickness Model 1 (Wieczorek et al. 2013), 0.25 deg; it is the Bouguer field inverted onto the
#      Moho, so "thinner than the surroundings" = mass excess. Reported in km of equivalent Moho uplift.
#  (2) GRAIL Bouguer 6-660 QuickMap image, colour turned into an ordinal index (blue 0 ... red 1 ... white ~2).
# Each crater: plane fitted to 1.5-3 R and removed; rings C 0-0.3R, F 0.3-0.7R, W 0.7-1.0R, Rm 1.0-1.3R.
import numpy as np, pandas as pd, colorsys
from PIL import Image
from scipy.stats import spearmanr, mannwhitneyu
exec(open('/home/claude/LEF_המוח/מאמר_06_מכתשים_בלי_אסטרואידים/ג_נתונים_וקוד/גודל_ומצב_על_הימות_2026-10-11/size_state.py').read().split("t=pd.crosstab")[0])
R=1737.4
g=np.load('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/משלוח_7/09_חומרים_קודמים_של_מאמר_8/14_GRAIL_density_ring_chatgpt/data/grail_compact.npz')['Model1_thick'].astype(float)
LATg=90-np.arange(g.shape[0])*0.25; LONg=np.arange(g.shape[1])*0.25
im=np.asarray(Image.open('grail_bouguer_quickmap.jpg').convert('RGB')).astype(float)/255; H,W,_=im.shape
mx=im.max(2); mn=im.min(2); sat=mx-mn
hue=np.vectorize(lambda r,g_,b: colorsys.rgb_to_hsv(r,g_,b)[0]*360,otypes=[float])(im[...,0],im[...,1],im[...,2])
hue=np.where(hue>300,0,hue)                      # wrap magenta-red to red
val=np.where(sat>0.35,np.clip((240-hue)/240,0,1),1+np.clip((mx+mn)/2-0.45,0,0.55)/0.55)
redsat=(sat>0.6)&(hue<12)                         # flat red band: colour clipped there
LATq=75-(np.arange(H)+.5)*150/H; LONq=-180+(np.arange(W)+.5)*360/W

def rings(lat0,lon0,Rk,grid,LAT,LON,lonwrap):
    dd=3.0*Rk/R*180/np.pi
    ilat=np.where(np.abs(LAT-lat0)<=dd)[0]
    if len(ilat)==0: return None
    cl=max(np.cos(np.radians(lat0)),0.2)
    dlon=((LON-lon0+180)%360)-180 if lonwrap else LON-lon0
    jlon=np.where(np.abs(dlon)<=dd/cl)[0]
    if len(jlon)==0: return None
    la=LAT[ilat][:,None]; lo=dlon[jlon][None,:]
    y=(la-lat0)*np.pi/180*R; x=lo*np.cos(np.radians(la))*np.pi/180*R
    r=np.hypot(x,y)/Rk; z=grid[np.ix_(ilat,jlon)]
    a=(r>=1.5)&(r<=3)
    if a.sum()<8: return None
    A=np.c_[np.ones(a.sum()),x[np.broadcast_to(a,x.shape)] if False else np.broadcast_to(x,r.shape)[a],np.broadcast_to(y,r.shape)[a]]
    coef,*_=np.linalg.lstsq(A,z[a],rcond=None)
    zz=z-(coef[0]+coef[1]*np.broadcast_to(x,r.shape)+coef[2]*np.broadcast_to(y,r.shape))
    out={}
    for k,(lo_,hi_) in dict(C=(0,.3),F=(.3,.7),W=(.7,1),Rm=(1,1.3)).items():
        m=(r>=lo_)&(r<hi_); out[k]=np.nanmedian(zz[m]) if m.sum()>0 else np.nan
    return out,r,zz

rows=[]
mare=near[near.D>=20].copy(); mare['grp']='mare_'+mare.cls
hl=c[(c.mare=='')&(c.lat.abs()<60)&(c.D>=20)].copy(); hl['grp']='highland'
# keep highland controls whose 3R neighbourhood is mare-free (centre >3R from any near-side mare crater centre is not
# enough; use the mare map on 12 points of the 2R circle)
th=np.linspace(0,2*np.pi,12,endpoint=False)
def ring_on_mare(lat,lon,Rk):
    dla=2*Rk/R*180/np.pi*np.sin(th); dlo=2*Rk/R*180/np.pi*np.cos(th)/max(np.cos(np.radians(lat)),.2)
    return (inside_index(((lon+dlo+180)%360)-180,lat+dla)>=0).mean()
hl['mfrac']=[ring_on_mare(a,b,d/2) for a,b,d in zip(hl.lat,hl.lon,hl.D)]
hl=hl[hl.mfrac==0]
# SPA interior removed from controls (centre 53S 191E, radius ~1000 km)
def gc(l1,o1,l2,o2):
    l1,o1,l2,o2=map(np.radians,(l1,o1,l2,o2)); return R*np.arccos(np.clip(np.sin(l1)*np.sin(l2)+np.cos(l1)*np.cos(l2)*np.cos(o1-o2),-1,1))
hl=hl[gc(hl.lat,hl.lon,-53,191)>1000]
allc=pd.concat([mare,hl],ignore_index=True)
for _,k in allc.iterrows():
    Rk=k.D/2; row=dict(lon=k.lon,lat=k.lat,D=k.D,dD=k.dD,grp=k.grp,mare=k.mare if k.grp!='highland' else '',bin=str(k.bin))
    o=rings(k.lat,k.lon%360,Rk,g,LATg,LONg,True)
    if o:
        for kk,v in o[0].items(): row['crust_'+kk]=-v          # sign: thinner crust = mass excess (+)
    if abs(k.lat)<70:
        o=rings(k.lat,k.lon,Rk,val,LATq,LONq,True)
        if o:
            for kk,v in o[0].items(): row['col_'+kk]=v
            r=o[1]; ilat=None
        # clipped-colour flag: share of interior pixels in the flat red band
        dd=1.3*Rk/R*180/np.pi; il=np.abs(LATq-k.lat)<=dd; jl=np.abs(((LONq-k.lon+180)%360)-180)<=dd/max(np.cos(np.radians(k.lat)),.2)
        row['red_clip']=redsat[np.ix_(il,jl)].mean() if il.any() and jl.any() else np.nan
    rows.append(row)
t=pd.DataFrame(rows)
t['hfill_km']=t.D*(t.bin.map({str(b):v for b,v in med.items()}).astype(float)-t.dD)  # missing depth vs highland median
t['sz']=pd.cut(t.D,[20,40,80,400],right=False).astype(str)
t.to_csv('per_crater_gravity_rings.csv',index=False)

def boot(x,f=np.nanmedian,n=2000,cells=None):
    x=np.asarray(x); rng=np.random.default_rng(1)
    if cells is None: s=[f(rng.choice(x,len(x))) for _ in range(n)]
    else:
        u=np.unique(cells); idx={q:np.where(cells==q)[0] for q in u}
        s=[f(x[np.concatenate([idx[q] for q in rng.choice(u,len(u))])]) for _ in range(n)]
    return np.nanpercentile(s,[2.5,97.5])
t['cell']=(np.floor(t.lat/10)).astype(int).astype(str)+'_'+(np.floor(t.lon/10)).astype(int).astype(str)
t['crust_CmF']=t.crust_C-t.crust_F; t['col_CmF']=t.col_C-t.col_F
print('n by group/size'); print(pd.crosstab(t.sz,t.grp))
for pre in ['crust','col']:
    print(f'\n=== {pre}: medians (positive = mass excess vs 1.5-3R), [95% cell bootstrap] ===')
    sub=t if pre=='crust' else t[(t.red_clip<0.2)]
    for sz in ['[20, 40)','[40, 80)','[80, 400)']:
        for gname in ['highland','mare_intact','mare_partly','mare_buried']:
            s=sub[(sub.sz==sz)&(sub.grp==gname)]
            if len(s)<4: continue
            line=f'{sz:10s} {gname:12s} n={len(s):4d} '
            for kk in ['C','F','W','Rm','CmF']:
                x=s[f'{pre}_{kk}'].dropna().values; ci=boot(x,cells=s.loc[s[f'{pre}_{kk}'].notna(),'cell'].values)
                line+=f' {kk}={np.median(x):+.2f}[{ci[0]:+.2f},{ci[1]:+.2f}]'
            print(line)
print('\n=== does the excess follow the missing depth? (mare partly+buried) ===')
for sz in ['[20, 40)','[40, 80)','[80, 400)','all']:
    s=t[t.grp.isin(['mare_partly','mare_buried'])]; s=s if sz=='all' else s[s.sz==sz]
    for kk in ['crust_F','crust_C','col_F']:
        q=s[[kk,'hfill_km','D']].dropna()
        if kk.startswith('col'): q=q[s.loc[q.index,'red_clip']<0.2]
        rho,p=spearmanr(q[kk],q.hfill_km); rd,pd_=spearmanr(q[kk],q.D)
        print(f'{sz:10s} {kk:8s} n={len(q):3d}  vs missing depth rho={rho:+.2f} p={p:.3g}   vs size rho={rd:+.2f} p={pd_:.3g}')
print('\n=== mare buried vs highland, same size: floor ring F and centre-minus-floor (Mann-Whitney) ===')
for sz in ['[20, 40)','[40, 80)','[80, 400)']:
    for kk in ['crust_F','crust_CmF','col_F','col_CmF']:
        a=t[(t.sz==sz)&(t.grp=='mare_buried')][kk].dropna(); b=t[(t.sz==sz)&(t.grp=='highland')][kk].dropna()
        if kk.startswith('col'):
            a=a[t.loc[a.index,'red_clip']<0.2]; b=b[t.loc[b.index,'red_clip']<0.2]
        if len(a)>3: print(f'{sz:10s} {kk:9s} buried {a.median():+.2f} (n={len(a)}) vs highland {b.median():+.2f} (n={len(b)})  p={mannwhitneyu(a,b).pvalue:.3g}')
