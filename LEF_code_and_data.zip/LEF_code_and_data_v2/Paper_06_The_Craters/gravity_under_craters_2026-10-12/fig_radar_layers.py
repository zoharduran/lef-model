# Schematic: what an orbital radar sounder would see in the horizontal layers near a shallow ring crater on a mare.
import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
HL='#d9c49a'; MARE='#5a5f66'; LAYER='#f2d36b'; INK='#2f3338'
x=np.linspace(-3,3,1201)
fig,axs=plt.subplots(2,2,figsize=(12.5,7.6),gridspec_kw=dict(height_ratios=[1.55,1],hspace=0.25,wspace=0.06))
def radar(ax,xs,good,bad):
    for xx in xs: ax.annotate('',xy=(xx,0.02),xytext=(xx,0.42),arrowprops=dict(arrowstyle='->',color='#888',lw=1))
    ax.text(-2.95,0.47,'radar from orbit looks straight down',fontsize=8.5,color='#666')
# ---------- buried ----------
ax=axs[0,0]; ax.set_xlim(-3,3); ax.set_ylim(-1.75,0.55); ax.axis('off')
ax.set_title('Literature: buried',fontsize=12,loc='left')
bowl=np.where(np.abs(x)<1,-0.45-0.95*(1-x**2),-0.45)
rim=-0.45+0.53*np.exp(-((np.abs(x)-1.0)/0.11)**2)
crust_top=bowl+0.53*np.exp(-((np.abs(x)-1.0)/0.11)**2)
ax.fill_between(x,-1.75,crust_top,color=HL,lw=0)
ax.fill_between(x,crust_top,0,where=crust_top<0,color=MARE,lw=0)
for d in [-0.15,-0.3,-0.6,-0.85,-1.1]:               # flow boundaries (reflectors)
    y=np.where(crust_top<d,d,np.nan)
    ax.plot(x,y,color=LAYER,lw=2)
ax.plot(x,crust_top,color='#6b5a35',lw=1.4)
ax.plot(x,np.maximum(crust_top,0)*0,color=INK,lw=1.5)
ax.fill_between(x,0,np.maximum(rim,0),color=HL,lw=0); ax.plot(x,np.maximum(rim,0),color=INK,lw=1.2)
radar(ax,[-2.4,-1.6,0,1.6,2.4],None,None)
ax.annotate('1  layers end against the wall',xy=(-0.93,-0.6),xytext=(-2.95,-1.05),fontsize=9.5,color='#b3261e',arrowprops=dict(arrowstyle='->',color='#b3261e'))
ax.annotate('',xy=(0.93,-0.6),xytext=(-0.9,-1.0),arrowprops=dict(arrowstyle='->',color='#b3261e'))
ax.annotate('2  more layers inside the ring\n    than outside it',xy=(0,-1.1),xytext=(0.95,-1.55),fontsize=9.5,color='#b3261e',arrowprops=dict(arrowstyle='->',color='#b3261e'))
ax.text(2.3,-0.38,'outside: 2 layers',fontsize=8.5,color='white',ha='center')
ax.text(0,-0.47,'inside: 5 layers',fontsize=8.5,color='white',ha='center')
ax.text(2.3,-1.3,'highland crust',fontsize=8.5,color='#6b5a35',ha='center')
# ---------- melted ----------
ax=axs[0,1]; ax.set_xlim(-3,3); ax.set_ylim(-1.75,0.55); ax.axis('off')
ax.set_title('Model: melted',fontsize=12,loc='left')
surf=np.where(np.abs(x)<1,-0.06*(1-x**2),0)+0.06*np.exp(-((np.abs(x)-1.05)/0.13)**2)
base=np.where(np.abs(x)<1.1,-0.95-0.2*(1-np.clip(np.abs(x)/1.1,0,1)**2),-0.95)
ax.fill_between(x,-1.75,base,color=HL,lw=0); ax.fill_between(x,base,surf,color=MARE,lw=0)
for d in [-0.25,-0.5,-0.75]:
    sag=np.where(np.abs(x)<1.05,-0.05*(d+1)*(1-np.clip(np.abs(x)/1.05,0,1)**2),0)
    ax.plot(x,d+sag,color=LAYER,lw=2)
ax.plot(x,surf,color=INK,lw=1.5); ax.plot(x,base,color='#6b5a35',lw=1.2)
radar(ax,[-2.4,-1.6,0,1.6,2.4],None,None)
ax.annotate('1  layers run straight under the ring',xy=(1.0,-0.5),xytext=(-2.9,-1.3),fontsize=9.5,color='#1b7a4a',arrowprops=dict(arrowstyle='->',color='#1b7a4a'))
ax.text(0,-1.55,'2  same layers inside and outside',fontsize=9.5,color='#1b7a4a',ha='center')
ax.text(2.3,-0.12,'mare',fontsize=8.5,color='white',ha='center')
ax.text(2.3,-1.05,'highland crust',fontsize=8.5,color='#6b5a35',ha='center')
# ---------- radargrams ----------
def gram(ax,lines,title):
    ax.set_facecolor('#111'); ax.set_xlim(-3,3); ax.set_ylim(-1.2,0.08)
    ax.set_xticks([]); ax.set_yticks([0,-0.5,-1.0]); ax.set_yticklabels(['surface','~0.5 km','~1 km'],fontsize=8)
    for s in ax.spines.values(): s.set_visible(False)
    ax.plot(x,np.zeros_like(x),color='white',lw=2.2)
    for xs,ys,lw in lines: ax.plot(xs,ys,color=LAYER,lw=lw)
    ax.set_title(title,fontsize=9.5,loc='left',color='#333')
L=[]
for d in [-0.15,-0.3]:
    for side in [-1,1]:
        xs=np.linspace(1.12,3,50)*side; L.append((xs,np.full_like(xs,d),1.8))
for d in [-0.15,-0.3,-0.6,-0.85,-1.1]:
    w=np.sqrt(np.clip(1-(-0.45-d)/-0.95,0,1)) if d<-0.45 else 0.95
    xs=np.linspace(-w*0.98,w*0.98,50); L.append((xs,np.full_like(xs,d),1.8))
L.append((np.r_[-1.05,-1.05],np.r_[-0.05,-0.12],0.0))
gram(axs[1,0],L,'Radar record: layers stop at the ring; extra layers inside;\nno echo from the steep buried wall')
axs[1,0].axvspan(-1.2,-0.9,color='#555',alpha=0.5,lw=0); axs[1,0].axvspan(0.9,1.2,color='#555',alpha=0.5,lw=0)
axs[1,0].text(1.05,-1.12,'clutter\nfrom rim',fontsize=7.5,color='#ddd',ha='center')
M=[]
for d in [-0.25,-0.5,-0.75]:
    sag=np.where(np.abs(x)<1.05,-0.05*(d+1)*(1-np.clip(np.abs(x)/1.05,0,1)**2),0); M.append((x,d+sag,1.8))
gram(axs[1,1],M,'Radar record: the same layers run unbroken\nfrom one side to the other')
axs[1,1].set_yticklabels([])
axs[1,1].axvspan(-1.2,-0.9,color='#555',alpha=0.35,lw=0); axs[1,1].axvspan(0.9,1.2,color='#555',alpha=0.35,lw=0)
fig.text(0.5,0.02,'Schematic, not to scale. Yellow lines = boundaries between flows, the only surfaces a radar sounder sees well (flat ones).',ha='center',fontsize=9,color='#444')
fig.savefig('fig_radar_layers.png',dpi=200,bbox_inches='tight')
