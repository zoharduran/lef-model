# Radial profiles of mass excess beneath craters: highland vs mare sharp vs mare shallow.
# Proxy: Moho elevation = LDEM_4 surface - GRAIL crustal thickness Model 1; plane through 1.5-3R removed per crater.
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
R=1737.4
T=np.load('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/משלוח_7/09_חומרים_קודמים_של_מאמר_8/14_GRAIL_density_ring_chatgpt/data/grail_compact.npz')['Model1_thick'].astype(float)
L=np.fromfile('/home/claude/LEF_המוח/מאמר_09_SPA/ג_נתונים_וקוד/data/ldem_4.img',dtype='<i2').reshape(720,1440)*0.5/1000
Lr=np.vstack([L[:1],0.5*(L[:-1]+L[1:]),L[-1:]]); M=0.5*(Lr+np.roll(Lr,1,axis=1))-T
LAT=90-np.arange(721)*0.25; LON=np.arange(1440)*0.25
edges=np.arange(0,3.01,0.15); mid=0.5*(edges[1:]+edges[:-1])
def prof(lat0,lon0,Rk):
    dd=3*Rk/R*180/np.pi; il=np.where(np.abs(LAT-lat0)<=dd)[0]; cl=max(np.cos(np.radians(lat0)),.2)
    dlon=((LON-lon0%360+180)%360)-180; jl=np.where(np.abs(dlon)<=dd/cl)[0]
    la=LAT[il][:,None]; y=(la-lat0)*np.pi/180*R+0*dlon[jl][None,:]; x=dlon[jl][None,:]*np.cos(np.radians(la))*np.pi/180*R
    r=np.hypot(x,y)/Rk; z=M[np.ix_(il,jl)]; a=(r>=1.5)&(r<=3)
    if a.sum()<8: return None
    A=np.c_[np.ones(a.sum()),x[a],y[a]]; cf,*_=np.linalg.lstsq(A,z[a],rcond=None); zz=z-(cf[0]+cf[1]*x+cf[2]*y)
    idx=np.digitize(r.ravel(),edges)-1; out=np.full(len(mid),np.nan)
    for k in range(len(mid)):
        m=idx==k
        if m.any(): out[k]=np.median(zz.ravel()[m])
    return out
t=pd.read_csv('per_crater_gravity_rings.csv')
rng=np.random.default_rng(3)
groups={'highland':'Highland craters','mare_intact':'Mare craters, sharp','mare_buried':'Mare craters, shallow ring'}
cols={'highland':'#2a78d6','mare_intact':'#eb6834','mare_buried':'#1baf7a'}
bins=[(20,40),(40,80),(80,150)]
res={}
for b in bins:
    for g in groups:
        s=t[(t.grp==g)&(t.D>=b[0])&(t.D<b[1])]
        if g=='highland' and len(s)>700: s=s.sample(700,random_state=1)
        P=np.array([p for p in (prof(a,o,d/2) for a,o,d in zip(s.lat,s.lon,s.D)) if p is not None])
        med=np.nanmedian(P,0); bs=np.array([np.nanmedian(P[rng.integers(0,len(P),len(P))],0) for _ in range(400)])
        res[(b,g)]=(med,np.nanpercentile(bs,2.5,0),np.nanpercentile(bs,97.5,0),len(P))
pd.DataFrame({f'{b[0]}-{b[1]}_{g}':v[0] for (b,g),v in res.items()},index=np.round(mid,3)).to_csv('radial_profiles.csv')
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(1,3,figsize=(12,4.2),sharey=False)
for i,b in enumerate(bins):
    a=ax[i]; a.axhline(0,color='#999',lw=0.8); a.axvline(1,color='#bbb',lw=0.8,ls='--')
    a.text(1.02,0.97,'rim',transform=a.get_xaxis_transform(),color='#777',fontsize=8,va='top')
    a.axvspan(1.5,3,color='#f2f0ea',zorder=0)
    for g,lab in groups.items():
        med,lo,hi,n=res[(b,g)]
        a.fill_between(mid,lo,hi,color=cols[g],alpha=0.18,lw=0)
        a.plot(mid,med,color=cols[g],lw=2,label=f'{lab} (n={n})')
    a.set_title(f'{b[0]}–{b[1]} km',fontsize=11); a.set_xlabel('Distance from crater centre (crater radii)')
    a.set_xlim(0,3); a.legend(fontsize=8,frameon=False,loc='lower right')
ax[0].set_ylabel('Mass below the crater\n(km of equivalent Moho rise)')
[a.text(2.25,0.93,'reference ring',transform=a.get_xaxis_transform(),ha='center',fontsize=8,color='#777') for a in ax]
fig.suptitle('Below zero: lighter material under the crater than around it.  Above zero: denser.',fontsize=10.5,x=0.02,ha='left')
fig.tight_layout(); fig.savefig('fig_radial_profiles.png',dpi=200)
for k,v in res.items(): print(k, v[3], np.round(v[0][:4],2))
