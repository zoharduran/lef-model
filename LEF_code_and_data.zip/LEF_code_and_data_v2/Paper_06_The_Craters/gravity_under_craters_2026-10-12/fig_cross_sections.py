# Schematic cross-sections (not to scale) with the measured mass profile (40-80 km bin) above each.
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
p=pd.read_csv('radial_profiles.csv',index_col=0); r=p.index.values
meas={'hl':p['40-80_highland'].values,'ms':p['40-80_mare_intact'].values,'mb':p['40-80_mare_buried'].values}
HL='#d9c49a'; HLd='#c8b080'; MARE='#5a5f66'; MAREl='#7d838b'; CR='#f3ead7'; SKY='white'
x=np.linspace(-3,3,601)
def bowl(x,depth,R=1.0):
    y=np.where(np.abs(x)<R, -depth*(1-(x/R)**2), 0.0)
    rim=0.18*np.exp(-((np.abs(x)-1.05)/0.18)**2)
    return y+rim
def draw(ax,kind,title):
    ax.set_xlim(-3,3); ax.set_ylim(-1.9,0.45); ax.axis('off')
    ax.set_title(title,fontsize=11,loc='left')
    if kind=='hl':
        s=bowl(x,0.9)
        ax.fill_between(x,-1.9,s,color=HL,lw=0)
        lens=np.where(np.abs(x)<0.95,-0.9*(1-(x/0.95)**2)-0.55*(1-(x/0.95)**2),np.nan)
        ax.fill_between(x,lens,np.minimum(s,0),where=np.abs(x)<0.95,color=CR,hatch='....',edgecolor='#b9a77e',lw=0)
        for xx in np.linspace(-0.8,0.8,7): ax.plot([xx,xx*1.15],[ -0.9*(1-xx**2)-0.1, -0.9*(1-xx**2)-0.75],color='#9c8657',lw=0.7)
        ax.plot(x,s,color='#6b5a35',lw=1.5)
        ax.text(0,-1.62,'crushed, cracked, full of voids\n= lighter than the crust around',ha='center',fontsize=8.5)
        ax.text(2.2,-0.9,'highland crust',ha='center',fontsize=8.5,color='#6b5a35')
    elif kind=='ms':
        base=np.full_like(x,-0.55)
        s=bowl(x,0.9)
        ax.fill_between(x,-1.9,base,color=HL,lw=0)
        ax.fill_between(x,base,np.where(np.abs(x)<1,np.minimum(s,0)*0+0,0),color=MARE,lw=0)
        ax.fill_between(x,s,0,where=np.abs(x)<1.0,color=SKY,lw=0)
        lens=np.where(np.abs(x)<0.95,-1.45*(1-(x/0.95)**2),np.nan)
        ax.fill_between(x,lens,np.minimum(s,0),where=np.abs(x)<0.95,color=CR,hatch='....',edgecolor='#999',lw=0)
        ax.fill_between(x,0,s,where=(np.abs(x)>=0.85)&(s>0),color=MARE,lw=0)
        ax.plot(x,s,color='#2f3338',lw=1.5)
        ax.text(0,-1.62,'landed on a mare that had already frozen:\ncracked like a highland crater',ha='center',fontsize=8.5)
        ax.text(2.2,-0.25,'mare (frozen)',ha='center',fontsize=8.5,color='white')
        ax.text(2.2,-1.2,'highland crust',ha='center',fontsize=8.5,color='#6b5a35')
    elif kind=='lit':
        base=np.full_like(x,-0.55)
        old=np.where(np.abs(x)<1,-0.5-1.0*(1-x**2),-0.55)          # original bowl cut into crust under the flows
        ax.fill_between(x,-1.9,old,color=HL,lw=0)
        lens=np.where(np.abs(x)<0.95,-0.5-1.0*(1-(x/0.95)**2)-0.35*(1-(x/0.95)**2),np.nan)
        ax.fill_between(x,lens,old,where=np.abs(x)<0.95,color=CR,hatch='....',edgecolor='#b9a77e',lw=0)
        rimtop=-0.55+0.12*np.exp(-((np.abs(x)-1.05)/0.15)**2)+0.62*np.exp(-((np.abs(x)-1.05)/0.12)**2)
        ax.fill_between(x,old,0.0,color=MARE,lw=0)
        ax.fill_between(x,-0.55,np.where(np.abs(np.abs(x)-1.05)<0.35,rimtop,-0.55),color=HLd,lw=0)
        ax.plot(x,np.where(np.abs(x)<1,old,np.nan),color='#6b5a35',lw=1,ls='--')
        ax.plot(x,np.maximum(0,np.where(np.abs(np.abs(x)-1.05)<0.35,rimtop,-1)),color='#2f3338',lw=1.5)
        ax.text(0,-0.32,'later basalt fills the old bowl',ha='center',fontsize=8.5,color='white')
        ax.text(0,-1.62,'cracked zone still there, but the heavy fill\non top cancels its missing mass',ha='center',fontsize=8.5)
        ax.text(2.2,-0.25,'mare flows',ha='center',fontsize=8.5,color='white')
    elif kind=='mod':
        base=np.full_like(x,-0.55)
        s=np.where(np.abs(x)<1,-0.12*(1-x**2),0)+0.07*np.exp(-((np.abs(x)-1.05)/0.15)**2)
        dip=np.where(np.abs(x)<1.1,-0.55-0.25*(1-np.clip(np.abs(x)/1.1,0,1)**2),-0.55)
        ax.fill_between(x,-1.9,dip,color=HL,lw=0)
        ax.fill_between(x,dip,s,color=MARE,lw=0)
        ax.plot(x,s,color='#2f3338',lw=1.5)
        ax.text(0,-0.32,'liquid mare closed over the landing',ha='center',fontsize=8.5,color='white')
        ax.text(0,-1.62,'landed on a soft, liquid mare: nothing cracked,\nno light zone; only a low ring is left',ha='center',fontsize=8.5)
        ax.text(2.2,-0.25,'mare (still liquid)',ha='center',fontsize=8.5,color='white')
        ax.text(2.2,-1.2,'highland crust',ha='center',fontsize=8.5,color='#6b5a35')
def curve(ax,key,col):
    ax.set_xlim(-3,3); ax.set_ylim(-0.75,0.55)
    rr=np.r_[-r[::-1],r]; vv=np.r_[meas[key][::-1],meas[key]]
    ax.axhline(0,color='#999',lw=0.8); ax.fill_between(rr,0,vv,where=vv<0,color='#2a78d6',alpha=0.25,lw=0)
    ax.fill_between(rr,0,vv,where=vv>0,color='#eb6834',alpha=0.25,lw=0)
    ax.plot(rr,vv,color=col,lw=2); ax.axis('off')
    ax.text(-3,0.42,'measured mass below (GRAIL, 40–80 km craters)',fontsize=8,color='#555')
fig=plt.figure(figsize=(12,8.6))
gs=fig.add_gridspec(4,2,height_ratios=[0.55,1.6,0.55,1.6],hspace=0.15,wspace=0.06)
panels=[(0,0,'hl','A. Highland crater','hl'),(0,1,'ms','B. Sharp crater on the mare','ms'),
        (2,0,'lit','C. Shallow ring crater on the mare — literature: buried','mb'),
        (2,1,'mod','D. Shallow ring crater on the mare — model: melted','mb')]
for row,colm,kind,title,key in panels:
    a1=fig.add_subplot(gs[row,colm]); curve(a1,key,'#333')
    a2=fig.add_subplot(gs[row+1,colm]); draw(a2,kind,'')
    a1.set_title(title,fontsize=11,loc='left')
fig.text(0.5,0.015,'Upper curves: measured mass below the crater against its surroundings — blue = missing mass, orange = extra mass.\nSections: schematic, not to scale. C and D give the same measured curve: gravity alone cannot choose between them; a subsurface radar can.',ha='center',fontsize=9,color='#444')
fig.savefig('fig_cross_sections.png',dpi=200,bbox_inches='tight')
