import os,sys;sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','shared'))
"""Paper 6 — Craters Without Asteroids. Reproduces:
  A.2  flight table: peak height, return time, westward displacement for u = 2,3,5,8 km/s
  A.3  u_min and v_rel for targets at 8,000/10,000/12,000 km
  B.1  shock pressure table (basalt, C0=3.5, s=1.3, rho=2700)
  B.2  drag attenuation example: B=1.8e6, exp(-Sigma/2B)=0.51
  C.2  u_esc = 10.748 km/s; corotation of the initial field 15,883 km
  C.2  Hill radius 2,822 km; fall speed 1.31 km/s
  C.3  impactor-mass ratios 7.45 (mu=0.35), 23.47 (mu=0.55)
"""
import numpy as np
from lef_common import G, Mt, ME, m
K=G*Mt; r0=6.721e6; w=2*np.pi/(5.5*3600); l=w*r0**2
for u in (2e3,3e3,5e3,8e3):
    E=(u**2+w**2*r0**2)/2-K/r0; a=-K/(2*E); e=np.sqrt(1+2*E*l**2/K**2); n=np.sqrt(K/a**3)
    f0=np.arccos((l**2/(K*r0)-1)/e); E0=np.arccos((1-r0/a)/e); tf=2*(np.pi-E0+e*np.sin(E0))/n
    sW=r0*(w*tf-(2*np.pi-2*f0)); up=u/2; P=2700*(3500+1.3*up)*up/1e9
    print(f"A.2  u={u/1e3:.0f}: peak {(a*(1+e)-r0)/1e3:,.0f} km  t={tf/60:.2f} min  west {sW/1e3:,.1f} km  | B.1 P={P:.2f} GPa")
for r in (8e6,10e6,12e6):
    umin=np.sqrt(2*K*(1/r0-1/r)+l**2*(1/r**2-1/r0**2)); s=f"A.3  r={r/1e3:,.0f}: u_min={umin/1e3:.3f}"
    for u in (5e3,8e3):
        E=(u**2+w**2*r0**2)/2-K/r0; vr2=2*(E+K/r)-l**2/r**2
        s+=f"  v_rel(u={u/1e3:.0f})={np.sqrt(vr2+(l/r-w*r)**2)/1e3:.3f}" if vr2>0 else f"  u={u/1e3:.0f}: no reach"
    print(s)
B=2700*4*500/3; Sig=2*100e5/8.25; print(f"B.2  B={B:.1e}  Sigma/B={Sig/B:.2f}  factor={np.exp(-Sig/(2*B)):.2f}")
print(f"C.2  u_esc={np.sqrt(2*K/r0-w**2*r0**2)/1e3:.3f} km/s  r_co(M0)={(K/w**2)**(1/3)/1e3:,.0f} km")
rH=17631e3*(m/(3*ME))**(1/3); print(f"C.2  r_H={rH/1e3:,.0f} km  v_fall={np.sqrt(2*G*m*(1/1.89e6-1/rH))/1e3:.2f} km/s")
for mu_ in (0.35,0.55): print(f"C.3  mu={mu_}: mass ratio={(8.25/1.62)**(1.5*mu_)*3**(3*mu_):.2f}")
