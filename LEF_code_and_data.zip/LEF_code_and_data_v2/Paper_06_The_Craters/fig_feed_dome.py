import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
C=dict(high='#d9c7a0',mantle='#9c6b4e',dome='#5a2d22',basalt='#3d3d4a',melt='#d9541e')
x=np.linspace(-1.7,1.7,2400); a=np.abs(x)
terrain=np.where(a<1.0,np.nan,np.where(a<1.08,1.25,1.25-np.clip((a-1.08)/0.55,0,1)*0.7))
base=np.where(a<1,-1.6+1.6*a**2,np.nan)
crust_bot=-4.4+1.5*np.exp(-(x/0.75)**2)
L=0.6; inl=a<L
dome_bot=np.where(inl,-1.6+1.6*a**2-0.95*(1-(x/L)**2),np.nan)
def arrow(ax,p0,p1,col,lw=2,ms=16):
    ax.add_patch(FancyArrowPatch(p0,p1,arrowstyle='-|>',mutation_scale=ms,color=col,lw=lw,zorder=8))
def draw(ax,stage):
    ax.fill_between(x,-6.6,crust_bot,color=C['mantle'])
    ax.fill_between(x,crust_bot,np.where(a<1,base,terrain),color=C['high'])
    col=C['melt'] if stage==1 else C['dome']
    ax.fill_between(x,dome_bot,np.where(inl,base,np.nan),color=col,zorder=3)
    w=0.09; xc=np.linspace(-w,w,50)
    ax.fill_between(xc,np.interp(xc,x,crust_bot)-0.05,np.interp(xc,x,dome_bot)+0.05,color=col,zorder=3)
    if stage==1:
        ax.fill_between(x,base,np.where(a<1,1.25,np.nan),color=C['melt'],zorder=2)
        surf=np.where(a<1,1.25,terrain)
        for xs in [-0.25,0,0.25]: arrow(ax,(xs,-4.7),(xs,-3.2),'#ffd27a',2.5,18)
        for s in (-1,1):
            arrow(ax,(0.55*s,-2.0),(0.85*s,-1.75),'#ffd27a',2,14)   # widening of the margins
        # spray
        rng=np.random.default_rng(3)
        for k in range(26):
            x0=rng.uniform(-0.8,0.8); ang=rng.uniform(np.radians(55),np.radians(125)); h=rng.uniform(0.8,1.7)
            t=np.linspace(0,1,40); xx=x0+np.cos(ang)*t*1.2*(1.6 if abs(np.cos(ang))>0.3 else 0.6); yy=1.25+h*4*t*(1-t)
            land=xx[-1]
            ax.plot(xx,yy,color='#ff8a50',lw=0.8,alpha=0.8,zorder=6)
            if abs(land)>1.0: ax.scatter([land],[np.interp(abs(land),[1.0,1.08,1.63],[1.25,1.25,0.55])+0.03],s=10,color='#b5420f',zorder=7)
        ax.text(0,2.95,'spray rises all the time: part falls back into the melt and is remelted, part lands in the shelter of the rim and piles up',ha='center',fontsize=9.5)
        ax.text(0,1.4,'melt at the height of the rim',ha='center',fontsize=10)
        ax.annotate('the FEED DOME: pushed up from a subsurface focus;\nthe centre is raised, the margins are widened',xy=(0.35,-1.9),xytext=(0.72,-3.5),fontsize=9.5,arrowprops=dict(arrowstyle='->'))
        ax.text(0,-5.6,'feed rising from the subsurface focus',ha='center',color='w',fontsize=10)
        ax.set_title('1. Active: the feed dome lifts the floor to the rim; spray builds the rim',fontsize=12,loc='left')
    else:
        sag=np.where(a<1,-0.45*(1-a**2),np.nan)
        ax.fill_between(x,base,sag,color=C['basalt'],zorder=2)
        surf=np.where(a<1,sag,terrain)
        for xs in [-0.25,0,0.25]: arrow(ax,(xs,-3.2),(xs,-4.7),'#ffd27a',2.5,18)
        for s in [-1,1]:
            xr=0.81*s; yr=-0.45*(1-0.81**2); ax.plot([xr-0.035,xr,xr+0.035],[yr,yr+0.13,yr],color='k',lw=1.6,zorder=8)
            xg=0.94*s; yg=-0.45*(1-0.94**2); ax.plot([xg-0.025,xg-0.012,xg+0.012,xg+0.025],[yg,yg-0.2,yg-0.2,yg],color='#2e7d32',lw=2,zorder=8)
        ax.annotate('the frozen feed dome: dense, rich in iron and titanium\n(Bouguer gravity higher over the centre)',xy=(0.35,-2.0),xytext=(0.72,-3.5),fontsize=9.5,arrowprops=dict(arrowstyle='->'))
        ax.text(0,-0.95,'frozen mare: richer in iron and titanium at the centre',ha='center',color='w',fontsize=9.5,zorder=9)
        ax.annotate('centre sunk over the dense dome\n(~90 m where the dome is strong)',xy=(0,-0.45),xytext=(0.3,1.9),fontsize=9.5,color='#b22222',arrowprops=dict(arrowstyle='->',color='#b22222'))
        ax.annotate('wrinkle ridges ~0.81 R',xy=(-0.81,-0.08),xytext=(-1.65,1.9),fontsize=9,arrowprops=dict(arrowstyle='->'))
        ax.annotate('graben ~0.94 R, half concentric: the widened margin',xy=(-0.94,-0.12),xytext=(-1.65,2.55),fontsize=9,color='#2e7d32',arrowprops=dict(arrowstyle='->',color='#2e7d32'))
        ax.text(0,-5.6,'the feed stops; melt is drawn back; the dome freezes in place; cooling and contraction lower the level',ha='center',color='w',fontsize=10)
        ax.set_title('2. Frozen: the floor lowered, the centre sunk over the dense dome, the margin stretched',fontsize=12,loc='left')
    ax.plot(x,surf,color='k',lw=1.2,zorder=7)
    ax.text(1.5,-1.4,'crust',fontsize=9); ax.text(1.5,-6.1,'mantle',fontsize=9,color='w')
    ax.set_xlim(-1.7,1.7); ax.set_ylim(-6.6,3.2); ax.axis('off')
fig,axs=plt.subplots(2,1,figsize=(12,10.5)); draw(axs[0],1); draw(axs[1],2)
fig.text(0.5,0.01,'Schematic cross-section, not to scale; the sag of the floor is exaggerated about 100 times.',ha='center',fontsize=9)
plt.tight_layout(rect=(0,0.03,1,1)); plt.savefig('p6_feed_dome.png',dpi=150)
