# Figure: the three heights of a crater (Paper 6, §D.3)
import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams['font.family']='DejaVu Sans Mono'
import warnings; warnings.filterwarnings('ignore')
x=np.linspace(-2.2,2.2,800); r=np.abs(x)
floor=-1.0; rim=0.45
y=np.where(r<0.45,floor,0)
y=np.where((r>=0.45)&(r<1.0),floor+(rim-floor)*((r-0.45)/0.55)**1.6,y)
y=np.where((r>=1.0)&(r<2.2),rim*np.exp(-(r-1.0)/0.25),y)
pk=0.55*np.exp(-(x/0.12)**2); y2=y+np.where(r<0.3,pk,0)
fig,ax=plt.subplots(figsize=(10,4.3))
ax.fill_between(x,y2,-1.6,color='#e9e4d6'); ax.plot(x,y2,color='#2a3e5c',lw=2)
ax.plot(x[r<0.3],y[r<0.3],color='#2a3e5c',lw=1,ls=':')
ax.axhline(0,color='#888',lw=1,ls='--'); ax.text(1.42,-0.13,'the land around the crater',fontsize=13,color='#555')
def arr(xx,y0,y1,c,t,tx=None):
    ax.annotate('',xy=(xx,y1),xytext=(xx,y0),arrowprops=dict(arrowstyle='<->',color=c,lw=2))
    ax.text(xx+0.06 if tx is None else tx,(y0+y1)/2,t,color=c,fontsize=15,va='center',fontweight='bold')
arr(-1.0,0,rim,'#5b8c5a','1  rim above\n   the land',-2.15)
arr(-0.35,floor,0,'#c8763c','2  floor below\n   the land',-2.15)
arr(1.0,floor,rim,'#9e2c20','3  rim to floor\n   = 1 + 2')
ax.annotate('central peak\n(left out of the floor)',xy=(0.05,-0.5),xytext=(0.25,-1.27),fontsize=13,color='#555',arrowprops=dict(arrowstyle='->',color='#777'))
ax.set_xlim(-2.2,2.2); ax.set_ylim(-1.35,0.85); ax.axis('off')
fig.tight_layout(); fig.savefig('../א_מאמר/fig/p6_three_heights.png',dpi=200)
