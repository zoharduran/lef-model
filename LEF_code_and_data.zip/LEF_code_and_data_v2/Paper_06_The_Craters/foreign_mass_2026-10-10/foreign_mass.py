# If the visible craters were made by external impacting bodies, how much foreign mass did they bring?
# Pi-group scaling (Collins, Melosh & Marcus 2005, after Holsapple & Schmidt): D_tc = 1.161 (rho_i/rho_t)^(1/3) L^0.78 v^0.44 g^-0.22 sin^(1/3)theta
# final: simple D = 1.25 D_tc ; complex D = 1.17 D_tc^1.13 / Dc^0.13 (Dc = simple-complex transition)
import numpy as np, pandas as pd
g=1.62; rho_t=2800.; rho_i=2700.; theta=np.radians(45)
def L_from_D(D_km,v,Dc=18.0):
    D=D_km*1e3; Dc_m=Dc*1e3
    Dtc=np.where(D<Dc_m, D/1.25, (D*Dc_m**0.13/1.17)**(1/1.13))
    L=(Dtc/(1.161*(rho_i/rho_t)**(1/3)*v**0.44*g**-0.22*np.sin(theta)**(1/3)))**(1/0.78)
    return L
def mass(D_km,v,**k): L=L_from_D(D_km,v,**k); return rho_i*np.pi/6*L**3
rb=pd.read_csv('/home/claude/LEF_המוח/06_נתונים_משותפים/Robbins_Dge20_selected.csv').DIAM_CIRC_IMG.values
ww=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[3]).values[:,0]/1000
ww=ww[(ww>=1)&(ww<20)]
out=[]
for v in [12e3,18e3,25e3]:
    for Dc in [15.,20.]:
        mb=mass(rb[rb>=300],v,Dc=Dc).sum(); mc=mass(rb[(rb>=20)&(rb<300)],v,Dc=Dc).sum(); ms=mass(ww,v,Dc=Dc).sum()
        out.append(dict(v_kms=v/1e3,Dc_km=Dc,basins_ge300=mb,craters_20_300=mc,craters_1_20=ms,total=mb+mc+ms))
t=pd.DataFrame(out); pd.set_option('display.float_format','{:.2e}'.format); print(t.to_string(index=False))
v=18e3
for D in [20,50,100,300,1160]:
    print(D,'km -> L=%.1f km, M=%.2e kg'%(L_from_D(np.array([D]),v)[0]/1e3, mass(np.array([D]),v)[0]))
print('N basins>=300',(rb>=300).sum(),'N 20-300',((rb>=20)&(rb<300)).sum(),'N 1-20',len(ww))
t.to_csv('foreign_mass_table.csv',index=False)
