exec(open('lagging.py').read().split('# robustness')[0].replace("print(T.to_string())","").replace("print(nm,","0 and print(nm,"))
oc=angd(c.lon,c.lat,-95,-20)>1000/1737.4*180/np.pi; os_=angd(lon,lat,-95,-20)>1000/1737.4*180/np.pi
for lim in [0,1500,2000]:
    kc=(angd(c.lon,c.lat,-24.8,24.1)>lim/1737.4*180/np.pi)&oc&(c.lat.abs()<60); ks=(angd(lon,lat,-24.8,24.1)>lim/1737.4*180/np.pi)&os_&(np.abs(lat)<60)
    out=[]
    for x,y in [(5,10),(10,20),(20,50),(50,300)]:
        A1=((lon>=0)&(lon<90)&ks).sum()*cell; A2=((lon>=-90)&(lon<0)&ks).sum()*cell
        m=c[kc]; n1=((m.lon>=0)&(m.lon<90)&(m.D>=x)&(m.D<y)).sum(); n2=((m.lon>=-90)&(m.lon<0)&(m.D>=x)&(m.D<y)).sum()
        r=(n1/A1)/(n2/A2); se=np.sqrt(1/n1+1/n2); out.append(f'{x}-{y}: {r:.2f} ({r*np.exp(-1.96*se):.2f}-{r*np.exp(1.96*se):.2f}) n={n1}/{n2}')
    print('contact removed beyond',lim,'km | land E/W Mkm2',round(A1/1e6,2),round(A2/1e6,2)); print('   ','; '.join(out))
