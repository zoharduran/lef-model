# Zohar's claim: at release the Earth kept ejecting; part was drawn to the Moon, which lagged,
# so near-side craters crowd on the lagging (trailing, eastern) part of the near side.
# Crater density by longitude, |lat|<=60, mare removed on both sides (craters and area), Wang & Wu 2021.
import struct, numpy as np, pandas as pd
from matplotlib.path import Path
SH='/tmp/claude-0/-home-claude/823d745d-d585-5e62-ab3b-cc648f681ccc/scratchpad/lroc/'
shp=open(SH+'LROC_GLOBAL_MARE_180.SHP','rb').read()
polys=[];pos=100
while pos<len(shp):
    clen=struct.unpack('>i',shp[pos+4:pos+8])[0]*2; c=shp[pos+8:pos+8+clen]; pos+=8+clen
    nparts,npts=struct.unpack('<2i',c[36:44]); parts=list(struct.unpack(f'<{nparts}i',c[44:44+4*nparts]))
    pts=np.frombuffer(c[44+4*nparts:44+4*nparts+16*npts],dtype='<f8').reshape(-1,2); parts.append(npts)
    polys.append([pts[parts[j]:parts[j+1]] for j in range(nparts)])
def inmare(lon,lat):
    P=np.c_[lon,lat]; out=np.zeros(len(lon),bool)
    for parts in polys:
        allp=np.vstack(parts); x0,y0=allp.min(0); x1,y1=allp.max(0)
        m=(lon>=x0)&(lon<=x1)&(lat>=y0)&(lat<=y1)
        if not m.any(): continue
        par=np.zeros(m.sum(),bool)
        for p in parts: par^=Path(p).contains_points(P[m])
        out[np.where(m)[0]]|=par
    return out
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3]); c.columns=['lon','lat','D']; c['D']/=1000
c=c[(c.D>=5)&(c.lat.abs()<=60)].reset_index(drop=True)
c['mare']=inmare(c.lon.values,c.lat.values)
rng=np.random.default_rng(2); N=3_000_000
lon=rng.uniform(-180,180,N); lat=np.degrees(np.arcsin(rng.uniform(-1,1,N)))
k=np.abs(lat)<=60; lon,lat=lon[k],lat[k]; sm=inmare(lon,lat); cell=4*np.pi*1737.4**2/N
# SPA mask (centre 53S 169W, radius 1000 km) removed both sides
def angd(lo1,la1,lo2,la2):
    a,b,cc,d=map(np.radians,(lo1,la1,lo2,la2)); return np.degrees(np.arccos(np.clip(np.sin(b)*np.sin(d)+np.cos(b)*np.cos(d)*np.cos(a-cc),-1,1)))
spa_c=angd(c.lon,c.lat,-169,-53)<1000/1737.4*180/np.pi; spa_s=angd(lon,lat,-169,-53)<1000/1737.4*180/np.pi
c=c[~c.mare & ~spa_c]; land=~sm & ~spa_s; lon,lat=lon[land],lat[land]
edges=np.arange(-180,181,30)
rows=[]
for lo0 in edges[:-1]:
    A=((lon>=lo0)&(lon<lo0+30)).sum()*cell
    m=c[(c.lon>=lo0)&(c.lon<lo0+30)]
    rows.append([lo0,lo0+30,round(A/1e6,2)]+[round(((m.D>=a)&(m.D<b)).sum()/A*1e6,1) for a,b in [(5,10),(10,20),(20,50),(50,300)]]+[ ((m.D>=20)).sum()])
T=pd.DataFrame(rows,columns=['lon0','lon1','land_Mkm2','d5_10','d10_20','d20_50','d50_300','n20'])
print(T.to_string())
def quad(a,b):
    A=((lon>=a)&(lon<b)).sum()*cell; m=c[(c.lon>=a)&(c.lon<b)]
    return A,{k:(((m.D>=x)&(m.D<y)).sum(), ((m.D>=x)&(m.D<y)).sum()/A*1e6) for k,(x,y) in {'5-10':(5,10),'10-20':(10,20),'20-50':(20,50),'50+':(50,300)}.items()}
for nm,(a,b) in {'near east 0-90E (trailing)':(0,90),'near west 90W-0 (leading)':(-90,0),'far east 90-180E':(90,180),'far west 180-90W':(-180,-90)}.items():
    A,d=quad(a,b); print(nm,'land',round(A/1e6,2),'Mkm2', {k:(n,round(v,1)) for k,(n,v) in d.items()})
T.to_csv('density_by_longitude.csv',index=False)

# robustness: latitude bands; Orientale (20S 95W) within 1,000 km removed both sides; Poisson 95% CI of the ratio
def ratio(a1,b1,a2,b2,lat_ok_c,lat_ok_s,x,y,extra_c=None,extra_s=None):
    A1=((lon>=a1)&(lon<b1)&lat_ok_s&extra_s).sum()*cell; A2=((lon>=a2)&(lon<b2)&lat_ok_s&extra_s).sum()*cell
    m=c[lat_ok_c&extra_c]; n1=((m.lon>=a1)&(m.lon<b1)&(m.D>=x)&(m.D<y)).sum(); n2=((m.lon>=a2)&(m.lon<b2)&(m.D>=x)&(m.D<y)).sum()
    r=(n1/A1)/(n2/A2); se=np.sqrt(1/n1+1/n2); return n1,n2,round(r,2),round(r*np.exp(-1.96*se),2),round(r*np.exp(1.96*se),2)
oc=angd(c.lon,c.lat,-95,-20)>1000/1737.4*180/np.pi; os_=angd(lon,lat,-95,-20)>1000/1737.4*180/np.pi
allc=np.ones(len(c),bool); alls=np.ones(len(lon),bool)
for band,(l0,l1) in {'0-60':(0,60),'0-30':(0,30),'30-60':(30,60)}.items():
    bc=(c.lat.abs()>=l0)&(c.lat.abs()<l1); bs=(np.abs(lat)>=l0)&(np.abs(lat)<l1)
    for x,y in [(5,10),(10,20),(20,50),(50,300)]:
        print(band,f'{x}-{y}','near E/W',ratio(0,90,-90,0,bc,bs,x,y,oc,os_),' far E/W',ratio(90,180,-180,-90,bc,bs,x,y,allc,alls))

import matplotlib.pyplot as plt
plt.rcParams['font.family']='DejaVu Sans Mono'
bc=(c.lat.abs()<30)&oc; bs=(np.abs(lat)<30)&os_
xs=[];vals={}
for lo0 in edges[:-1]:
    A=((lon>=lo0)&(lon<lo0+30)&bs).sum()*cell; m=c[bc&(c.lon>=lo0)&(c.lon<lo0+30)]
    xs.append(lo0+15)
    for k,(a,b) in {'10-50 km':(10,50),'50 km and more':(50,300)}.items():
        vals.setdefault(k,[]).append(((m.D>=a)&(m.D<b)).sum()/A*1e6)
fig,ax=plt.subplots(figsize=(10,4.2))
cols=['#2b6cb0' if -90<=x<=90 else '#b8b8b8' for x in xs]
ax.bar(xs,vals['10-50 km'],width=26,color=cols)
for x,v in zip(xs,vals['10-50 km']): ax.text(x,v+8,f'{v:.0f}',ha='center',fontsize=9)
ax.axvspan(0,90,color='#f3d9b1',alpha=.4,zorder=0); ax.axvspan(-90,0,color='#dfe8f0',alpha=.4,zorder=0)
ax.text(45,ax.get_ylim()[1]*0.95,'near side, trailing\n(the lagging part)',ha='center',va='top',fontsize=9.5,color='#8a5a1a')
ax.text(-45,ax.get_ylim()[1]*0.95,'near side, leading',ha='center',va='top',fontsize=9.5,color='#2b3a55')
ax.set_xticks(range(-180,181,30)); ax.set_xticklabels([f'{abs(t)}°{"W" if t<0 else ("E" if 0<t<180 else "")}' for t in range(-180,181,30)])
ax.set_ylabel('craters 10–50 km\nper million km²'); ax.spines[['top','right']].set_visible(False)
ax.set_title('Craters of 10–50 km by longitude, latitude within 30°, maria, SPA and Orientale removed',fontsize=10.5,color='#2b3a55',loc='left')
plt.tight_layout(); plt.savefig('density_by_longitude.png',dpi=170)
