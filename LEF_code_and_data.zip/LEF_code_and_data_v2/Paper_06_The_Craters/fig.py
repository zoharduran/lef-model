import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
NAVY='#1f2a44'; RED='#a8322d'; SAND='#e8d8b0'; LAVA='#b5533c'; GREY='#8a8a8a'
D=25.0; R=D/2
x=np.linspace(-1.6*R,1.6*R,800); r=np.abs(x)/R
def fresh(r):
    rim=0.022*D; d=0.085*D
    z=np.where(r<=0.45,-d,np.where(r<=1,-d+(d+rim)*((r-0.45)/0.55)**1.7,rim*np.exp(-3*(r-1))))
    pk=0.25*d*np.exp(-(r/0.12)**2); return z+pk
def degraded(r):
    rim=0.008*D; d=0.032*D
    z=np.where(r<=1,-d+(d+rim)*(np.clip(r,0,1))**2.2,rim*np.exp(-2*(r-1))); return z
def ffc(r):
    rim=0.022*D; d=0.085*D; lift=0.045*D
    z=fresh(r)
    floor=r<=0.62
    z=np.where(floor,-d+lift,z)
    moat=(r>0.62)&(r<0.75); z=np.where(moat,-d+lift-0.35*lift*np.sin(np.pi*(r-0.62)/0.13),z)
    z=np.where((r>=0.75)&(r<=1),np.maximum(z,-d+lift),z)
    return z
fig,axs=plt.subplots(3,1,figsize=(12,10.5))
cases=[('A  A normal fresh crater (20–30 km)',fresh,'deep bowl for its size: depth ≈ 0.085 × diameter (≈ 2 km for 25 km)\nsharp, high rim · steep walls · floor flat or bowl-shaped · small central peak'),
       ('B  An old, worn crater — shallow because it was FILLED FROM ABOVE',degraded,'depth ≈ 0.03 × diameter\nrim worn low and rounded · walls slumped · floor buried under debris from the walls and from later impacts\nthe whole bowl is softened — nothing is cracked, nothing lifted'),
       ('C  A "shallow floor" — the floor LIFTED FROM BELOW (floor-fractured crater; a mare in the making)',ffc,'rim still sharp and high, like A · but the floor stands high: flat, cracked, with a moat by the walls\ndark mare patches and volcanic vents on it · heat rose beneath and pushed the floor up like a dome — the frozen lake')]
for ax,(t,f,txt) in zip(axs,cases):
    z=f(r)
    ax.fill_between(x,z,-3.5,color=SAND,ec=NAVY,lw=1.4)
    if f is ffc:
        xm=x[np.abs(x)<=0.62*R]; ax.fill_between(xm,ffc(np.abs(xm)/R),ffc(np.abs(xm)/R)-0.25,color=LAVA,alpha=0.85)
        for xc in (-0.35*R,0.1*R,0.4*R): ax.plot([xc,xc+0.15],[ffc(abs(xc)/R),ffc(abs(xc)/R)-0.6],color=NAVY,lw=1.2)
        xx=np.linspace(-0.6*R,0.6*R,100); ax.plot(xx,-3.2+1.1*np.cos(np.pi*xx/(1.2*R)),color=RED,ls='--',lw=1.3); ax.text(0,-3.0,'heat from below — a dome',ha='center',fontsize=9,family='monospace',color=RED)
        ax.plot(x,fresh(r),color=GREY,ls=':',lw=1.2); ax.text(0.05*R,-2.35,'where the floor of A would be',fontsize=8.5,family='monospace',color=GREY)
    if f is degraded:
        ax.plot(x,fresh(r),color=GREY,ls=':',lw=1.2); ax.text(-0.3*R,-2.35,'the original bowl, now filled',fontsize=8.5,family='monospace',color=GREY)
        xx=x[np.abs(x)<=0.95*R]; ax.fill_between(xx,degraded(np.abs(xx)/R),np.minimum(fresh(np.abs(xx)/R),degraded(np.abs(xx)/R)),color=GREY,alpha=0.35)
    ax.set_title(t,loc='left',fontsize=11.5,family='monospace',color=NAVY,fontweight='bold')
    ax.text(-1.58*R,1.25,txt,fontsize=9,family='monospace',color=NAVY,va='top')
    ax.set_xlim(-1.6*R,1.6*R); ax.set_ylim(-3.5,1.4); ax.set_yticks([-3,-2,-1,0,1]); ax.set_ylabel('km',fontsize=9)
    ax.set_xticks([-R,0,R]); ax.set_xticklabels(['rim','centre','rim'],fontsize=9)
    for s in ('top','right'): ax.spines[s].set_visible(False)
fig.text(0.01,0.005,'Cross-sections of a 25-km crater; heights exaggerated about 3×. "Shallow" always means shallower than a fresh crater of the same diameter.',fontsize=9,family='monospace',color=NAVY)
plt.tight_layout(rect=(0,0.02,1,1)); plt.savefig('/tmp/claude-0/floor/floors.png',dpi=140)
