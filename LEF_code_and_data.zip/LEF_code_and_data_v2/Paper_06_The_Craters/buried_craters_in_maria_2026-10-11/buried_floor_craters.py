# Craters >=10 km whose centre lies on a mare floor (LROC map), Wang & Wu 2021 depths.
# Buried (flooded) = depth/diameter far below that of the highland craters of the same size.
import struct, numpy as np, pandas as pd
from matplotlib.path import Path
SH='/tmp/claude-0/-home-claude/823d745d-d585-5e62-ab3b-cc648f681ccc/scratchpad/lroc/'
shp=open(SH+'LROC_GLOBAL_MARE_180.SHP','rb').read(); dbf=open(SH+'LROC_GLOBAL_MARE_180.DBF','rb').read()
n=struct.unpack('<I',dbf[4:8])[0]; hl,rl=struct.unpack('<HH',dbf[8:12])
fields=[];i=32
while dbf[i]!=0x0D: fields.append((dbf[i:i+11].split(b'\0')[0].decode(),dbf[i+16])); i+=32
recs=[]
for k in range(n):
    r=dbf[hl+k*rl+1:hl+(k+1)*rl]; o=0; row={}
    for nm,ln in fields: row[nm]=r[o:o+ln].decode('latin1').strip(); o+=ln
    recs.append(row)
polys=[];pos=100
while pos<len(shp):
    clen=struct.unpack('>i',shp[pos+4:pos+8])[0]*2; c=shp[pos+8:pos+8+clen]; pos+=8+clen
    nparts,npts=struct.unpack('<2i',c[36:44]); parts=list(struct.unpack(f'<{nparts}i',c[44:44+4*nparts]))
    pts=np.frombuffer(c[44+4*nparts:44+4*nparts+16*npts],dtype='<f8').reshape(-1,2); parts.append(npts)
    polys.append([pts[parts[j]:parts[j+1]] for j in range(nparts)])
names=np.array([r['MARE_NAME'] for r in recs]); areas=np.array([float(r['Area_km']) for r in recs])
def inside_index(lon,lat):
    P=np.c_[lon,lat]; out=np.full(len(lon),-1)
    for idx,parts in enumerate(polys):
        allp=np.vstack(parts); x0,y0=allp.min(0); x1,y1=allp.max(0)
        m=(lon>=x0)&(lon<=x1)&(lat>=y0)&(lat<=y1)
        if not m.any(): continue
        par=np.zeros(m.sum(),bool)
        for p in parts: par^=Path(p).contains_points(P[m])
        out[np.where(m)[0][par]]=idx
    return out
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3,4]); c.columns=['lon','lat','D','d']; c['D']/=1000
c=c[(c.D>=10)&(c.D<300)&(c.d>0)].reset_index(drop=True)
c['dD']=c.d/1000/c.D
ci=inside_index(c.lon.values,c.lat.values); c['mare']=np.where(ci>=0,names[np.clip(ci,0,None)],'')
bins=[10,20,40,80,300]; c['bin']=pd.cut(c.D,bins,right=False)
hl=c[c.mare=='']
thr=hl.groupby('bin',observed=True).dD.quantile(0.05)   # buried: shallower than 95% of highland craters of its size
med=hl.groupby('bin',observed=True).dD.median()
c['buried']=c.dD<c.bin.map(thr).astype(float)
print('highland d/D median and 5% threshold'); print(pd.DataFrame({'median':med,'thr5':thr}).round(3))
fm=c[c.mare!='']
t=fm.groupby('bin',observed=True).agg(n=('dD','size'),buried=('buried','sum'),median=('dD','median'))
t['share']=(t.buried/t.n*100).round(0); t['hl_median']=med.round(3); print(t)
near=['Mare Imbrium','Oceanus Procellarum','Mare Serenitatis','Mare Tranquillitatis','Mare Crisium','Mare Fecunditatis','Mare Nubium','Mare Humorum','Mare Nectaris','Mare Frigoris','Mare Insularum','Mare Vaporum','Mare Cognitum','Mare Smythii','Mare Marginis','Mare Australe','Mare Moscoviense','Mare Ingenii','Mare Orientale']
rows=[]
for nm in near:
    m=fm[(fm.mare==nm)&(fm.D>=20)]; a=areas[names==nm].sum()
    rows.append((nm,round(a/1e3),len(m),int(m.buried.sum()),len(m)-int(m.buried.sum()),round((len(m)-m.buried.sum())/a*1e6,1)))
T=pd.DataFrame(rows,columns=['mare','area_kkm2','N20','buried','on_top','on_top_per_Mkm2']); print(T.to_string())
tot=fm[fm.D>=20]; print('all maria >=20: n',len(tot),'buried',tot.buried.sum())
hA=4*np.pi*1737.4**2-areas.sum(); print('highland >=20 per Mkm2',round((hl.D>=20).sum()/hA*1e6,1),'mare on-top >=20 per Mkm2',round(((~tot.buried)).sum()/areas.sum()*1e6,1),'mare all',round(len(tot)/areas.sum()*1e6,1))
T.to_csv('buried_vs_on_top_by_mare.csv',index=False); t.to_csv('buried_share_by_size.csv')
fm.to_csv('mare_floor_craters_ge10.csv',index=False)
