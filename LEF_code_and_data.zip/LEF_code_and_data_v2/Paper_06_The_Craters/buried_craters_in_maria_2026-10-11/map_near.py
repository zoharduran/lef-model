import struct, numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle
plt.rcParams['font.family']='DejaVu Sans Mono'
SH='/tmp/claude-0/-home-claude/823d745d-d585-5e62-ab3b-cc648f681ccc/scratchpad/lroc/'
shp=open(SH+'LROC_GLOBAL_MARE_180.SHP','rb').read()
polys=[];pos=100
while pos<len(shp):
    clen=struct.unpack('>i',shp[pos+4:pos+8])[0]*2; c=shp[pos+8:pos+8+clen]; pos+=8+clen
    nparts,npts=struct.unpack('<2i',c[36:44]); parts=list(struct.unpack(f'<{nparts}i',c[44:44+4*nparts]))
    pts=np.frombuffer(c[44+4*nparts:44+4*nparts+16*npts],dtype='<f8').reshape(-1,2); parts.append(npts)
    polys.append([pts[parts[j]:parts[j+1]] for j in range(nparts)])
lam0,phi0=np.radians(-10),np.radians(10)
def ortho(lon,lat):
    l,p=np.radians(lon),np.radians(lat)
    cosc=np.sin(phi0)*np.sin(p)+np.cos(phi0)*np.cos(p)*np.cos(l-lam0)
    x=np.cos(p)*np.sin(l-lam0); y=np.cos(phi0)*np.sin(p)-np.sin(phi0)*np.cos(p)*np.cos(l-lam0)
    return x,y,cosc>0
fig,ax=plt.subplots(figsize=(11,11)); ax.set_aspect('equal'); ax.axis('off')
ax.add_patch(Circle((0,0),1,fc='#eeeae0',ec='#2b3a55',lw=1.5))
for parts in polys:
    for p in parts:
        x,y,v=ortho(p[:,0],p[:,1])
        if v.mean()>0.5: ax.add_patch(Polygon(np.c_[x,y],closed=True,fc='#9a9a9a',ec='none',alpha=.55))
# grid
for lo in range(-180,180,30):
    la=np.linspace(-90,90,181); x,y,v=ortho(np.full_like(la,lo),la); x[~v]=np.nan; ax.plot(x,y,color='#ccc',lw=.4)
for la0 in range(-60,90,30):
    lo=np.linspace(-180,180,361); x,y,v=ortho(lo,np.full_like(lo,la0)); x[~v]=np.nan; ax.plot(x,y,color='#ccc',lw=.4)
# contact and hill circles
def circ(lat0,lon0,km):
    d=km/1737.4; b=np.linspace(0,2*np.pi,361); p0,l0=np.radians(lat0),np.radians(lon0)
    p=np.arcsin(np.sin(p0)*np.cos(d)+np.cos(p0)*np.sin(d)*np.cos(b))
    l=l0+np.arctan2(np.sin(b)*np.sin(d)*np.cos(p0),np.cos(d)-np.sin(p0)*np.sin(p))
    x,y,v=ortho(np.degrees(l),np.degrees(p)); x=x.copy(); x[~v]=np.nan; return x,y
for km,ls,lab in [(1500,'-','contact (1,500 km)'),(3000,'--','hill (3,000 km)')]:
    x,y=circ(24.1,335.2,km); ax.plot(x,y,color='#a23b2a',ls=ls,lw=1.6)
fm=pd.read_csv('mare_floor_craters_ge10.csv'); fm=fm[fm.D>=20]
col={'buried':'#c0392b','partly':'#e69138','intact':'#1f6fb2'}
lab={'buried':'buried (seen only as a ring)','partly':'partly buried','intact':'intact (on the floor)'}
for k in ['buried','partly','intact']:
    m=fm[fm.cls==k]; x,y,v=ortho(m.lon.values,m.lat.values)
    r=m.D.values/2/1737.4
    for xi,yi,ri,vi in zip(x,y,r,v):
        if vi: ax.add_patch(Circle((xi,yi),ri,fc=col[k],ec='k',lw=.4,alpha=.85))
    ax.plot([],[],'o',color=col[k],ms=9,label=f'{lab[k]}: {int(v.sum())}')
# label intact >=40 km on big near maria
x,y,v=ortho(0,0)
ax.plot([],[],'-',color='#a23b2a',label='contact, 1,500 km from its centre'); ax.plot([],[],'--',color='#a23b2a',label='hill, 3,000 km')
ax.plot([],[],'s',color='#9a9a9a',alpha=.55,ms=10,label='mare floor (LROC)')
ax.legend(loc='lower left',fontsize=10,frameon=True,bbox_to_anchor=(-0.02,-0.04))
names={'Mare Imbrium':(-17,35),'Oceanus Procellarum':(-57,15),'Mare Serenitatis':(18,28),'Mare Tranquillitatis':(31,8),'Mare Crisium':(59,17),'Mare Fecunditatis':(51,-8),'Mare Nubium':(-17,-21),'Mare Frigoris':(0,57),'Mare Humorum':(-39,-24),'Mare Nectaris':(35,-15)}
for n,(lo,la) in names.items():
    x,y,v=ortho(lo,la); ax.text(x,y,n.replace('Mare ','').replace('Oceanus ',''),fontsize=9,color='#333',ha='center',alpha=.8)
ax.set_title('Craters of 20 km and more on the mare floors of the near side, by depth\n(Wang & Wu 2021; buried = shallower than 95% of highland craters of the same size)',fontsize=11,color='#2b3a55')
ax.set_xlim(-1.05,1.05); ax.set_ylim(-1.05,1.05)
plt.savefig('map_near_floor_craters.png',dpi=170,bbox_inches='tight')
