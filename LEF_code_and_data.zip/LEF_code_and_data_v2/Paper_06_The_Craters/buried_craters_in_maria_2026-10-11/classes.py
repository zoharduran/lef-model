import pandas as pd, numpy as np
fm=pd.read_csv('mare_floor_craters_ge10.csv')
c=pd.read_csv('/tmp/claude-0/ww/WangWu2021_LU1319373_raw.txt',skiprows=17,sep=r'\s+',header=None,usecols=[1,2,3,4]); c.columns=['lon','lat','D','d']; c['D']/=1000
c=c[(c.D>=10)&(c.D<300)&(c.d>0)]; c['dD']=c.d/1000/c.D
bins=[10,20,40,80,300]
ids=set(zip(fm.lon.round(4),fm.lat.round(4)))
hl=c[[ (round(a,4),round(b,4)) not in ids for a,b in zip(c.lon,c.lat)]].copy()
hl['bin']=pd.cut(hl.D,bins,right=False); fm['bin']=pd.cut(fm.D,bins,right=False)
q05=hl.groupby('bin',observed=True).dD.quantile(.05); q25=hl.groupby('bin',observed=True).dD.quantile(.25)
fm['cls']=np.where(fm.dD<fm.bin.map(q05).astype(float),'buried',np.where(fm.dD<fm.bin.map(q25).astype(float),'partly','intact'))
print(pd.crosstab(fm.bin,fm.cls,margins=True))
print('q25',q25.round(3).to_dict())
big=['Mare Imbrium','Oceanus Procellarum','Mare Serenitatis','Mare Tranquillitatis','Mare Crisium','Mare Fecunditatis','Mare Nubium','Mare Humorum','Mare Frigoris','Mare Insularum','Mare Nectaris','Mare Vaporum','Mare Cognitum']
import struct
A=pd.read_csv('buried_vs_on_top_by_mare.csv').set_index('mare').area_kkm2
r=[]
for nm in big+['Mare Smythii','Mare Marginis','Mare Australe']:
    m=fm[(fm.mare==nm)&(fm.D>=20)]; vc=m.cls.value_counts()
    r.append((nm,A[nm],len(m),vc.get('buried',0),vc.get('partly',0),vc.get('intact',0),round(vc.get('intact',0)/A[nm]*1e3,1)))
T=pd.DataFrame(r,columns=['mare','kkm2','N','buried','partly','intact','intact_perMkm2']);print(T.to_string())
s=T[T.mare.isin(big)].sum(numeric_only=True); print('near big maria total',s.to_dict(),'intact per Mkm2',round(s.intact/s.kkm2*1e3,1))
T.to_csv('classes_by_mare.csv',index=False)
fm.to_csv('mare_floor_craters_ge10.csv',index=False)
