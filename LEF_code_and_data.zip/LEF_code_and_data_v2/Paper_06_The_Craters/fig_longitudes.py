# Figure: the four longitudes side by side (Paper 6, Part D). Values from §D.2–D.5.
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['font.family']='DejaVu Sans Mono'
regs=['90°W\nleading','180°\nfar','90°E\ntrailing','0°\nnear']
cols=['#5b8c5a','#9aa5b1','#c8763c','#2a3e5c']
panels=[
 ('Craters ≥20 km per Mkm²\n(maria, SPA removed)',[139,203,249,135],'{:.0f}'),
 ('Central peak, 20–30 km (%)',[60,46,49,56],'{:.0f}'),
 ('Rim irregularity, deeper half, 20–30 km\n(×10⁻³ D)',[9.2,7.5,7.4,7.1],'{:.1f}'),
 ('Floor roughness, deeper half, 20–30 km (°)',[4.5,2.7,3.0,3.6],'{:.1f}'),
 ('Floor below the land / diameter,\npeak masked, 20–30 km',[0.041,0.054,0.038,0.027],'{:.3f}'),
 ('Rim above the land / diameter, 20–30 km',[0.013,0.016,0.017,0.015],'{:.3f}'),
]
fig,axs=plt.subplots(2,3,figsize=(13,7.2))
for ax,(t,v,f) in zip(axs.flat,panels):
    b=ax.bar(range(4),v,color=cols,width=0.65)
    for i,x in enumerate(v): ax.text(i,x*1.02,f.format(x),ha='center',va='bottom',fontsize=9)
    ax.set_xticks(range(4)); ax.set_xticklabels(regs,fontsize=8.5)
    ax.set_title(t,fontsize=9.5,color='#2a3e5c',loc='left')
    ax.set_ylim(0,max(v)*1.22)
    for s in ['top','right']: ax.spines[s].set_visible(False)
    ax.tick_params(axis='y',labelsize=8)
fig.tight_layout()
fig.savefig('../א_מאמר/fig/p6_longitudes.png',dpi=200)
