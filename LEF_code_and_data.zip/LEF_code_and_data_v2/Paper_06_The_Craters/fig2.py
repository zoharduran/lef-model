import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
NAVY='#1f2a44'; RED='#a8322d'; SAND='#e8d8b0'; LAVA='#c8643f'; COOL='#7a4a3a'; BLUE='#3b5b92'
D=25.0; R=D/2; x=np.linspace(-1.6*R,1.6*R,900); r=np.abs(x)/R
rim=0.55
def walls(r):
    d=2.4; return np.where(r<=0.8,-d,np.where(r<=1,-d+(d+rim)*((np.clip(r,0.8,1)-0.8)/0.2)**1.6,rim*np.exp(-3*(r-1))))
fig,axs=plt.subplots(3,1,figsize=(12,10.8))
# 1 liquid at rim height, overflowing
ax=axs[0]; z=walls(r)
ax.fill_between(x,z,-3.6,color=SAND,ec=NAVY,lw=1.3)
lvl=rim; m=r<=1.08
ax.fill_between(x[m],np.minimum(z[m],lvl),lvl,color=LAVA,alpha=0.9)
for s in (-1,1): ax.annotate('',xy=(s*1.3*R,0.35),xytext=(s*1.02*R,0.62),arrowprops=dict(arrowstyle='-|>',color=LAVA,lw=2))
xx=np.linspace(-0.7*R,0.7*R,100); ax.plot(xx,-3.3+1.1*np.cos(np.pi*xx/(1.4*R)),color=RED,ls='--',lw=1.4)
for xc in (-0.3*R,0,0.3*R): ax.annotate('',xy=(xc,-1.9),xytext=(xc,-2.7),arrowprops=dict(arrowstyle='-|>',color=RED,lw=1.3))
ax.text(0,-3.05,'heat from below (a dome)',ha='center',fontsize=9,family='monospace',color=RED)
ax.set_title('1  Hot and liquid: the floor stands at the height of the rim',loc='left',fontsize=11.5,family='monospace',color=NAVY,fontweight='bold')
ax.text(-1.58*R,1.35,'the melt fills the crater to the brim and spills over the sides — the spill builds the rim',fontsize=9,family='monospace',color=NAVY,va='top')
# 2 cooling: centre held by heat, edge not
ax=axs[1]; z=walls(r)
ax.fill_between(x,z,-3.6,color=SAND,ec=NAVY,lw=1.3)
def floor2(r):
    base=-0.35; e=np.clip((r-0.55)/0.27,0,1)
    return base-0.55*np.sin(np.pi*e/2)
m=r<=1.0; f2=np.where(r<=0.82,floor2(r),-0.9)
ax.fill_between(x[m],z[m],np.maximum(f2[m],z[m]),color=LAVA,alpha=0.85)
ax.plot(x,np.where(r<=1.0,rim,np.nan),color=NAVY,ls=':',lw=1); ax.text(-0.95*R,rim+0.08,'old level',fontsize=8.5,family='monospace',color=NAVY)
for xc in (-0.2*R,0.2*R): ax.annotate('',xy=(xc,-0.5),xytext=(xc,0.35),arrowprops=dict(arrowstyle='-|>',color=BLUE,lw=1.2))
for s in (-1,1): ax.annotate('',xy=(s*0.8*R,-1.05),xytext=(s*0.8*R,0.35),arrowprops=dict(arrowstyle='-|>',color=BLUE,lw=2.2))
xx=np.linspace(-0.55*R,0.55*R,100); ax.plot(xx,-3.3+1.1*np.cos(np.pi*xx/(1.1*R)),color=RED,ls='--',lw=1.4)
ax.text(0,-3.05,'heat still beneath the centre',ha='center',fontsize=9,family='monospace',color=RED)
ax.set_title('2  Cooling: everything sinks, the edge sinks more',loc='left',fontsize=11.5,family='monospace',color=NAVY,fontweight='bold')
ax.text(-1.58*R,1.35,'centre: sinks by cooling only — the heat beneath holds it up\nedge, along the walls: no heat beneath — sinks by cooling AND by compaction of the lighter material',fontsize=9,family='monospace',color=NAVY,va='top')
# 3 final: flat floor + moat ring
ax=axs[2]; z=walls(r)
ax.fill_between(x,z,-3.6,color=SAND,ec=NAVY,lw=1.3)
def floor3(r):
    base=-0.7; e=np.clip((r-0.58)/0.24,0,1)
    return base-0.95*np.sin(np.pi*e/2)
f3=np.where(r<=0.82,floor3(r),-1.65); m=r<=1.0
ax.fill_between(x[m],z[m],np.maximum(f3[m],z[m]),color=COOL,alpha=0.85)
for xc in (-0.6*R,0.6*R): ax.plot([xc,xc+0.1],[floor3(0.6),floor3(0.6)-0.6],color='k',lw=1.2)
ax.annotate('the MOAT: the ring along the walls,\ndeeper than the floor',xy=(0.79*R,floor3(0.79)),xytext=(0.95*R,-2.6),fontsize=9.5,family='monospace',color=BLUE,fontweight='bold',arrowprops=dict(arrowstyle='->',color=BLUE))
ax.annotate('concentric cracks at the edge of the held-up centre',xy=(-0.6*R,floor3(0.6)-0.3),xytext=(-1.58*R,-2.6),fontsize=9,family='monospace',color=NAVY,arrowprops=dict(arrowstyle='->',color=NAVY))
ax.text(0,-0.55,'flat, smooth floor — the frozen lake',ha='center',fontsize=9,family='monospace',color='white')
ax.set_title('3  Frozen: a flat floor held up in the middle, a moat around it',loc='left',fontsize=11.5,family='monospace',color=NAVY,fontweight='bold')
ax.text(-1.58*R,1.35,'the rim keeps the height the spill gave it; the floor stands below it, and the ring by the walls stands lowest',fontsize=9,family='monospace',color=NAVY,va='top')
for ax in axs:
    ax.set_xlim(-1.6*R,1.6*R); ax.set_ylim(-3.6,1.45); ax.set_yticks([]); ax.set_xticks([-R,0,R]); ax.set_xticklabels(['rim','centre','rim'],fontsize=9)
    for s in ('top','right','left'): ax.spines[s].set_visible(False)
fig.text(0.01,0.005,"Zohar's account of a floor-fractured crater (9.10.2026). Schematic cross-sections, not to scale.",fontsize=9,family='monospace',color=NAVY)
plt.tight_layout(rect=(0,0.02,1,1)); plt.savefig('/tmp/claude-0/floor/moat.png',dpi=140)
